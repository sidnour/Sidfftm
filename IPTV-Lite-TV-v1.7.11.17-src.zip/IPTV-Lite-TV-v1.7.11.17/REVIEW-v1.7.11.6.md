# v1.7.11.6 / 190 — remaining logic repairs together

Built on delivered189, preserving the restored1.7.11 lineage. This release combines planned logic stages2–4; it is NOT a certification that every bug or physical-device issue is resolved.

## Changes
- Browse operations now own a terminal cancellation scope, not only a snapshot of open calls. Blocking HTTP and streaming parsers check that scope; canceled fallback work cannot open new sockets. Playback preemption cancels registered browse work. MainActivity request generations reject stale results even across A→B→A navigation; badge requests have separate ownership and account identity checks. Partial snapshots are ignored after completion/cancellation.
- Stalker ordered pagination honors advertised totals before the legacy small-page heuristic. Failed/malformed later pages, premature exhaustion with a known outstanding total, repeated pages with known missing items, and unfinished safety caps fail instead of caching partial results as complete. Xtream all-live no longer converts a failed parse into an empty success. Existing displayed partial items receive an incomplete/retry message on failure.
- Per-account Stalker session discovery is serialized. Waiting playback can cancel a lower-priority discovery owner. Auth retry passes the failed session identity, so a newer session already produced by another caller is reused rather than refreshed again. Existing fingerprint/header generation is retained.
- Localhost rewriting uses exact URI host matching including IPv6 loopback. An explicit media port wins; otherwise the portal port is inherited. Encoded path/query/fragment remain intact; host substrings and query text are not rewritten.
- Recorder/download starts are gated until the prior worker has completed sink close/finalize/delete and shared-state cleanup. A worker registry, rather than the running flag, acknowledges completion. Exit prevents new starts, stops workers off the UI thread and waits for acknowledgment, with a separate2.5-second watchdog before process termination. A stuck provider/storage driver can still hit the deadline: finalization is best-effort in that case. Explicit future schedules are not erased by ordinary app exit.

## Scope preserved
SCOPE-CHECK-v1.7.11.6.json compares against the delivered189 source archive:62 existing main files unchanged. PlayerActivity, Media3 dependencies/configuration, LiveRecoveryPolicy, LiveLinkMemory, AppStore, DataIdentity, manifest and resources unchanged. PortalClient session/pagination/cancellation/localhost code intentionally changes; this is not a byte-identical network rollback. No OpenSubtitles, alternate-server failover, PiP, Multi-View, Live pause or live timeshift added. Only selected VOD/series category is fetched in ordinary browsing; no new background category prefetch.

## Evidence
109 JVM/Robolectric tests,0 failures/errors/skips (12 added over189). New tests cover exact localhost/ports/IPv6/raw URI preservation, terminal browse cancellation, same-account serialization vs different-account independence, request generations, worker acknowledgment/deadline/old-completion isolation, second-page failure followed by a fresh successful fetch, and advertised totals on short pages. Repeated-page contract now requires an incomplete failure when total_items promises more data.

These tests use synthetic loopback HTTP, injected Android preferences and concurrency helpers. They do not exercise an actual TV, recording storage driver, Media3 playback or subscription. Final verification/signing evidence is in VERIFICATION.txt and verification/.

## Remaining verification and compatibility risks
- TV/Nox visual/remote behavior, rapid switching, real-provider session races/outages, continuous playback, actual recording/SAF finalization on exit, Doze/reboot/scheduled jobs and encrypted in-place upgrade remain untested here. No claim of eliminating continuous stuttering without a device test.
- The old category-preference namespace is deliberately retained, including its known case-collision risk; it is not migrated by190. Full-backup account-ID remapping and missing old recent/resume restore paths are not redesigned. Unknown legacy ownership remains conservatively unassigned. These compatibility topics require a separately validated migration rather than risking existing user data in this release.
- Unknown provider totals still require the legacy short-page heuristic; a provider that silently omits records without a truthful total cannot be proven complete. Unsupported bulk-live endpoints may fall back to ordered pages.
- WorkerDrain tests validate the completion gate, not a real disk flush/power-loss guarantee. Process watchdog can interrupt a driver that ignores cancellation.

Install as an update without uninstalling; make an independent backup first. Distributed APK uses the existing private signing certificate; that key and user credentials are excluded from source. Included GitHub Actions generates its own key by default, so its APK will not update this signed release unless securely configured with the matching signing key. No existing Drive file is modified/deleted.
