plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.23" apply false
}

val extBuildRoot = System.getenv("ANDROID_BUILD_ROOT")
if (!extBuildRoot.isNullOrBlank()) {
    allprojects {
        layout.buildDirectory.set(file("$extBuildRoot/${project.name}"))
    }
}
