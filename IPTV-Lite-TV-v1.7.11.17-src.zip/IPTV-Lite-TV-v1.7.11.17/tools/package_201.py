#!/usr/bin/env python3
"""Freeze and package v201 after the final build, unit-test, lint and signature checks."""
from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile, xml.etree.ElementTree as ET

W=Path('/home/user'); P=W/'iptv_lite_tv_201'; PREV=W/'iptv_lite_tv_200'; V=P/'verification/v201'
VERSION='1.7.11.17'; CODE=201

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

log=W/'docs/v201-check.log'
assert 'FINAL_201_PASS' in log.read_text()
reports=sorted((P/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml'))
assert len(reports)==37, len(reports)
roots=[ET.parse(p).getroot() for p in reports]
counts={k:sum(int(r.get(k,0)) for r in roots) for k in ('tests','failures','errors','skipped')}
assert counts=={'tests':318,'failures':0,'errors':0,'skipped':0},counts
lint=P/'app/build/reports/lint-results-debug.xml'; lr=ET.parse(lint).getroot()
issues={sev:sum(1 for i in lr.iter('issue') if i.get('severity')==sev) for sev in ('Error','Warning')}
assert issues=={'Error':0,'Warning':308},issues
apk=P/'app/build/outputs/apk/release/app-release.apk'; assert apk.is_file()
env=__import__('os').environ.copy(); env['JAVA_HOME']='/var/tmp/android-env/jdk17'; env['PATH']=env['JAVA_HOME']+'/bin:'+env['PATH']
sig=subprocess.check_output(['/var/tmp/android-env/sdk/build-tools/34.0.0/apksigner','verify','--verbose','--print-certs',str(apk)],env=env,text=True,stderr=subprocess.STDOUT)
cert='1bcf4f23d41353cedf6a17b869442ddd38abff12d89f6228f1398aa166b1309b'
assert cert in sig
for n in (1,2,3): assert f'Verified using v{n} scheme' in sig
V.mkdir(parents=True,exist_ok=True)
(P/'tools').mkdir(exist_ok=True); (P/'docs').mkdir(exist_ok=True)
shutil.copy2(W/'tools/verify_201.sh',P/'tools/verify_201.sh')
shutil.copy2(W/'tools/package_201.py',P/'tools/package_201.py')
shutil.copy2(log,P/'docs/v201-check.log')
suite=ET.Element('testsuites',attrib={k:str(v) for k,v in counts.items()})
for r in roots: suite.append(r)
ET.ElementTree(suite).write(V/'tests.xml',encoding='utf-8',xml_declaration=True)
shutil.copy2(lint,V/'lint.xml'); shutil.copy2(log,V/'build-test-lint.log'); shutil.copy2(W/'tools/verify_201.sh',V/'sandbox-verification.sh')
(V/'signature.txt').write_text(sig)
(W/'docs/v201-signature.txt').write_text(sig)
shutil.copy2(W/'docs/v201-signature.txt',P/'docs/v201-signature.txt')

# Source scope is narrowly pinned to the account-snapshot comparison fix and version metadata.
paths=sorted({str(p.relative_to(P)) for p in (P/'app/src/main').rglob('*') if p.is_file()}|{'app/build.gradle.kts'})
modified=[]; added=[]
for rel in paths:
    cur,old=P/rel,PREV/rel
    if not old.exists(): added.append(rel)
    elif sha(cur)!=sha(old): modified.append(rel)
expected_modified={
 'app/build.gradle.kts',
 'app/src/main/java/com/iptvlite/tv/model/Models.kt',
 'app/src/main/java/com/iptvlite/tv/network/SelectedCategoryLoad.kt',
 'app/src/main/java/com/iptvlite/tv/ui/MainActivity.kt',
}
assert set(modified)==expected_modified,modified
assert not added,added
new_tests={
 'app/src/test/java/com/iptvlite/tv/network/NetworkIdentityTest.kt',
 'app/src/test/java/com/iptvlite/tv/store/StatusEvidenceRegressionTest.kt',
 'app/src/test/java/com/iptvlite/tv/ui/AboutDialogTest.kt',
}
for rel in new_tests: assert sha(P/rel)!=sha(PREV/rel),rel
assert (P/f'REVIEW-v{VERSION}.md').is_file()

files=set(json.loads((W/'docs/frozen-v200.json').read_text()))
files.update({'REVIEW-v'+VERSION+'.md','tools/verify_201.sh','tools/package_201.py','docs/v201-check.log','docs/v201-signature.txt'})
files.update(str(p.relative_to(P)) for p in V.rglob('*') if p.is_file())
assert all((P/r).is_file() for r in files),sorted(r for r in files if not (P/r).is_file())
for rel in files:
    parts=Path(rel).parts
    assert not any(x in {'build','.gradle','.git','keystore'} for x in parts),rel
    assert not rel.endswith(('.jks','.keystore')) and Path(rel).name!='local.properties',rel
freeze={r:sha(P/r) for r in sorted(files)}
zipout=W/f'IPTV-Lite-TV-v{VERSION}-src.zip'
with zipfile.ZipFile(zipout,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for rel in sorted(files): z.write(P/rel,f'IPTV-Lite-TV-v{VERSION}/'+rel)
with zipfile.ZipFile(zipout) as z:
    assert z.testzip() is None
    for rel,h in freeze.items(): assert hashlib.sha256(z.read(f'IPTV-Lite-TV-v{VERSION}/'+rel)).hexdigest()==h,rel
apkout=W/f'IPTV-Lite-TV-v{VERSION}.apk'; shutil.copy2(apk,apkout)
(W/'docs/frozen-v201.json').write_text(json.dumps(freeze,indent=2)+'\n')
art={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (apkout,zipout)}
(W/'docs/artifacts-v201.json').write_text(json.dumps(art,indent=2)+'\n')
print(json.dumps({'version':VERSION,'versionCode':CODE,'scope':modified,'tests':counts,'lint':issues,'signing':'official v1/v2/v3 verified','files':len(files),'artifacts':art},indent=2))
