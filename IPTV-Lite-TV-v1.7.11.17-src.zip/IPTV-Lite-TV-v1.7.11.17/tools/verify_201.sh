#!/usr/bin/env bash
set -euo pipefail
cd /home/user
source tools/setup_android.sh
cd iptv_lite_tv_201
COMMON=(--no-daemon --max-workers=1 -Dkotlin.compiler.execution.strategy=in-process)
JVM="-Xmx384m -XX:MaxMetaspaceSize=300m -XX:+UseSerialGC -Dfile.encoding=UTF-8"
./gradlew compileReleaseKotlin "${COMMON[@]}" -Dorg.gradle.jvmargs="$JVM"
./gradlew assembleRelease "${COMMON[@]}" -Dorg.gradle.jvmargs="$JVM"
./gradlew compileDebugUnitTestKotlin "${COMMON[@]}" -Dorg.gradle.jvmargs="$JVM"
rm -rf app/build/test-results/testDebugUnitTest app/build/reports/tests/testDebugUnitTest
./gradlew testDebugUnitTest "${COMMON[@]}" -Dorg.gradle.jvmargs="$JVM"
./gradlew lintDebug "${COMMON[@]}" -Dorg.gradle.jvmargs="$JVM"
echo FINAL_201_PASS
