# v1.7.11.4 /188 — expanded production-path provider contracts

## Authorized scope and baseline
User approved adopting additional test cases from the externally modified archive, not its runtime implementation. Baseline is delivered187 (v1.7.11.3). This release changes no runtime logic. APK version metadata and two existing displayed version labels are updated only to identify the tested source unambiguously.

PortalClient, StalkerEndpointHints, AppStore, Models, PlayerActivity, LiveRecoveryPolicy/LiveLinkMemory, fingerprint, media configuration, request priority, lists/pagination, manifest and resources remain byte-identical to187. No PortalContractParsers copy, account-model fields, account-store persistence changes, OpenSubtitles or alternate-server behavior were imported. Existing CI workflow and dependencies unchanged.

## Adopted material
Five synthetic fixtures were copied from the user-provided ZIP (uploaded with a .txt suffix) into app/src/test/resources/contracts/variants: plain-root Stalker handshake, ffrt and ffmpeg create_link, Stalker genre field variants, Xtream category rows. They contain artificial tokens and reserved example.test hosts only. Additional edge payloads are inline synthetic JSON in the tests. No real subscription requests or media downloads.

Unlike the external archive's parallel parsers, every added contract calls the existing production PortalClient public facade. Android JSON behavior runs under existing Robolectric API28, with MockWebServer providing loopback responses. There is no new runtime parser.

## 16 added tests (76 total)
1. Plain-root handshake token reaches real profile and category Authorization headers.
2. ffrt create_link resolves correctly with original cmd/type, one handshake/link call, no media fetch.
3. ffmpeg create_link same assertions, preserving query token in returned URL.
4. Genre fixture filters All/empty rows and accepts title/name variants.
5. Wrapped category data accepts category_id/alias and array rows, rejects incomplete object rows.
6. Ordered-list items accept ch_id/title and id/o_name fallbacks, reject missing ID/name.
7. Five empty/missing/invalid handshake bodies exhaust exactly the five current discovery endpoints, do not publish a usable session and persist no hint (account status facade throws).
8. Empty/malformed category bodies terminate after four existing action variants without bogus rows.
9. Xtream category fixture and id/title/name variants use actual production parsing and reject incomplete rows.
10. Malformed Xtream category JSON fails explicitly; subsequent valid load succeeds without poisoned cache.
11. Repeated HTTP401 and403 each terminate: four current category-action variants, each at most one retry; exactly8 API calls,5 handshakes,5 profile requests (18 total). This is not a claim that the entire category operation performs only one refresh.
12. Saved-path ConnectException falls back to existing discovery and persists replacement.
13. Saved-path SocketTimeoutException in fastProbe mode likewise falls back.
14. Saved-path UnknownHostException likewise falls back.
15. Changed MAC cannot reuse another MAC's remembered secondary route through the facade; Cookie uses new MAC.
16. Changed portal path starts its own discovery with correct Referer, not the previous remembered route.

Transport-failure tests inject a deterministic IOException subtype through a temporary application interceptor on the existing probe client, using test-only reflection of the OkHttp instance interceptor list and restoring it in finally. The production discovery branch and subsequent fallback HTTP are real. These tests DO NOT simulate OS DNS infrastructure, actual TCP refusal, real network delays or elapsed provider timeout behavior. No production test hook is added. Initial test harness attempted replacing a static-final client and failed on JDK17 (3 harness failures); it was corrected solely in tests. Final complete run passes. Tests remain single-fork as configured in187.

## Verification
Final build helper build_v17114.sh exited0 (v1.7.11.4-final.log): assembleRelease, compileDebugUnitTestKotlin, testDebugUnitTest and lintDebug PASS.
- 76 tests,0 failures,0 errors,0 skips (60 existing +16 new).
- Lint:0 errors,312 warnings, unchanged from187.
- com.iptvlite.tv /188 /1.7.11.4. APK signatures v1/v2/v3 verify.
- Same release certificate SHA256:1bcf4f23d41353cedf6a17b869442ddd38abff12d89f6228f1398aa166b1309b.
- verify_188_scope.py checks all baseline production/main files, rejects new/deleted main files, allows only exact version substitutions in Gradle and two UI labels:65 production files unchanged. See SCOPE-CHECK-v1.7.11.4.json. Build script and scope verifier are included under verification/ for transparency; build helper workspace paths must be adapted outside this workspace. Portable CI remains .github/workflows/build-apk.yml. CI retains its previous ephemeral signing behavior; delivered APK uses the original private key, never included in source.

## Interpretation and remaining work
The additional contracts passed with the existing runtime implementation. No runtime fix was needed for these specified synthetic cases. This is regression coverage, NOT a new playback feature, performance improvement, stutter fix or certification of all provider dialects. Existing documented edge limitations from187 remain, including the small-page heuristic and localhost-with-explicit-port rewrite; they were not silently fixed or reclassified.

No physical TV/Nox, real subscription, real OS force-stop/reboot, long-running video or real network outage validation. JVM repository/RAM resets and injected exception branches are not those physical tests. DEVICE-CHECK-v1.7.11.4.md lists the pending manual checks; ROADMAP_TV.md retains remaining phases. No cloud testing/billing performed. Earlier APK/source archives retained.
