# v1.7.11.5 /189 — logic repair stage 1 of 4

## Scope and status
Baseline: delivered v188. User authorized the logic-review repair plan; implementation is deliberately staged. THIS BUILD COMPLETES ONLY STAGE 1: account-scoped favorites/history/resume and network-cache identities, conservative legacy handling, and serialized account read-modify-write transactions. Remaining review findings are not claimed fixed. See remaining stages below.

## Changes
### Account-scoped personal data
- StreamItem.favKey now hashes length-delimited accountId, kind and item ID for known owners. Explicitly ownerless legacy rows retain their old kind:id namespace, separate from every known account. No new field/schema requirement is imposed on old favorites/recent JSON.
- Favorite membership, toggling, custom-folder keys and recent-item replacement/deletion use the full owned identity. Recent deletion passes the actual item from MainActivity, not merely its numeric ID. TV favorites import duplicate checks include owner; desktop ownerless imports do not deduplicate against known-account favorites.
- PortalClient's category/seasons/episodes/global-search facades stamp returned items with the requested account ID. Partial list callbacks carry the owner too. Private provider fetching, parsing, pagination, request priority, stream URL resolution and renewal remain unchanged.
- Resume positions have new account+kind+ID keys. Series quick-continue lookups take the selected item's owner. Item deletion/completion clears only that owner's position/entry. Explicit clear-all removes new and old position keys.
- The same shared personal-data monitor protects relevant list/position read-modify-write operations across AppStore instances.

### Legacy preservation (important)
- Existing favorites/recent with accountId remain owned and readable. Ownerless saved rows remain ownerless and visible; this stage does not guess a provider or silently bind them to the currently active account. Consequently they are not automatically marked as the equivalent of a newly loaded owned row. Re-adding an item from its correct account creates a properly owned entry; the old row can then be removed individually if desired.
- Old folder mappings are moved to a scoped key only when exactly one original saved favorite identifies the owner. Ambiguous/orphan map keys are left intact, not inherited by later-added accounts; they may need manual folder reassignment.
- Resume JSON snapshots with explicit accId migrate lazily on read, using that entry's own posMs when there is no v2 value. Unassigned JSON snapshots stay in the unassigned namespace. Legacy global pos_ID/pos_KIND_ID values with no reliable owner are retained but deliberately NOT applied to a known account: doing so could resume the wrong film. They are removed only by the user's explicit clear-all action. This is conservative quarantine, not a claim that every historic raw-only position can be automatically recovered.
- Fuzzy title-based resume inheritance is no longer used to choose another item implicitly. New favorite/position keys are stable across URL/password edits because personal data belongs to accountId, not the credential revision.

### Network cache and account transactions
- A separate networkCacheKey uses accountId, provider, exact path/query and username, normalized HTTP scheme/host and MAC, and credential revision, all hashed via SHA-256 with length delimiters. Passwords/usernames/MACs are not exposed in the key. Password edits, user-case differences and portal path-case changes no longer reuse the same cached lists/URLs/session. No new network request is made merely to compute an identity.
- Legacy AccountProfile.cacheKey is intentionally retained ONLY for existing category lock/pin/hidden/last-category preference and unlock namespaces. This prevents loss of parental/category preferences on upgrade. Those legacy preference namespaces can still share the old case-normalization limitation; a separate tested migration is deferred. Do not interpret network-cache isolation as a migration of every historical preference.
- Account deduplication preserves exact URL-path and username case, while treating HTTP scheme/host case and default ports canonically. Editing an existing account keeps its ID.
- getAccounts/saveAccounts/upsertAccount/updateAccountStatus/sortAccountsByFastest/deleteAccount share a companion-level monitor enclosing read+modify+save, not only individual writes. This serializes status updates from probes across AppStore instances and prevents stale snapshots from resurrecting deleted accounts. No lock is held over provider HTTP.
- Existing encrypted account storage/fallback behavior, source signing and asynchronous preference flush policy remain unchanged. This is not a key-management or OS process-death durability rewrite.

## Tests and results
Added21 tests (97 total):14 Robolectric AppStore tests,5 JVM identity tests,2 added provider contracts. Coverage includes:
- Two accounts with identical item IDs remain independent in favorites, folders, recent and resume; owner-scoped deletion/completion and series quick-continue.
- RAM reset/repository reads preserve the two owned positions independently.
- Owner-known old folder map migration; old ownerless favorites remain unassigned.
- Legacy resume snapshot ignores ambiguous global position; no adoption by another account; explicit clear-all includes old keys.
- Concurrent status updates across16accounts/8workers and separate AppStore instances; repeated concurrent delete/status update; exact-case account dedup and stable edit ID.
- Scheme/host canonicalization, path/query/user/credential/account isolation, delimiter safety, no plaintext credentials in key, retained legacy category namespace.
- Production PortalClient returned/partial item ownership and new Xtream password triggering a fresh list with new generated playback credentials rather than stale cached URL.

Final build_v17115.sh exited0 (v1.7.11.5-final.log): assembleRelease, compileDebugUnitTestKotlin, testDebugUnitTest and lintDebug PASS.
- 97 tests;0 failures,0 errors,0 skips.
- Lint0 errors,312 warnings (unchanged from188).
- com.iptvlite.tv /189 /1.7.11.5. v1/v2/v3 APK signatures verified; same release certificate SHA256:1bcf4f23d41353cedf6a17b869442ddd38abff12d89f6228f1398aa166b1309b.
- verify_189_scope.py PASS;61 existing main files unchanged. Exact UI changes restricted to owner-aware recent removal/series resume and version labels. PlayerActivity byte-identical, as are private provider parsers/fingerprint/session/link code, endpoint hints, recovery policy/memory, Media3 config, manifest/resources, recorder/exit. Added DataIdentity helper only. See SCOPE-CHECK-v1.7.11.5.json.
- Initial build release/test compilation succeeded; a source edit during staged work triggered recompilation in the low-memory test stage and an OOM. Final fixed-source build completed all stages; release DataIdentity.class timestamp is later than its final source edit. The failed intermediate artifact is not a separate delivery.

## Limits
No physical Android TV/Nox, real provider, OS force-stop/reboot or production data upgrade test. AppStore tests inject real plain SharedPreferences for deterministic logic tests; they DO NOT certify Android Keystore, encrypted storage migration, disk power-loss behavior or physical installation. Synthetic MockWebServer provider tests never contact an actual subscription or fetch media. No claim of a stutter fix.

Backup/import: account-bound favorite duplicate checks are fixed, but this stage does not redesign full-backup account-ID remapping or add missing recent/resume import behavior from older versions. Existing ambiguous/unowned backup links may need reassociation; do not claim a fully certified backup restore. Old data/previous archives are retained. Upgrade over188 without uninstalling; keep an independent backup if using production accounts.

## Remaining stages — NOT fixed in189
2. Partial lists vs complete-cache state; pagination totals/small pages; browse operation ownership/cancellation; stale account/generation UI callbacks.
3. Per-account Stalker single-flight/session generation and URI-based localhost/port rewrite, preserving fingerprint and confirmed-link-first Live policy.
4. Recorder stop/finalization acknowledgment before bounded exit; then actual TV/Nox/provider/outage/long-running playback validation.

Legacy category-preference namespace migration and robust full-backup owner remapping should be included in the follow-up data-compatibility checks, not silently inferred from this phase. No automatic alternate-server failover, PiP, Multi-View, Timeshift, Live pause or OpenSubtitles introduced. The phased roadmap remains in ROADMAP_TV.md.
