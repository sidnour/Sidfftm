# v1.7.11.3 (187) — provider contracts and persistent discovery hints

Baseline: delivered v1.7.11.2 (186). Scope: only contract coverage and successful Stalker endpoint/referer persistence. Xtream has no equivalent Stalker discovery/handshake: tests cover its auth, lists, stream construction and no-network direct resolution; no invented refresh-token mechanism was added.

## Runtime changes
- New private SharedPreferences repository stores only endpoint, referer and saved_at. Keys are SHA-256 of length-delimited provider, account ID, exact portal URL and MAC; no raw account identifier is used as a preference key. Tokens, cookies, profile payloads, credentials and playback URLs are never written by this repository.
- A remembered endpoint/referer must exactly match a pair in the CURRENT portal's existing discovery list. URLs with userinfo/query/fragment and URLs longer than 2048 characters are not cached. This is not new encryption of account preferences.
- Preserve existing RAM session precedence. After process restart, try valid remembered pair first, perform a NEW handshake/profile warmup, and save after existing success criteria. Profile warmup remains best-effort exactly as before. No fingerprint or auth acceptance changes.
- Failed remembered pair is removed with compare-before-delete protection. Discovery continues in existing order, skipping the already-attempted endpoint. Cached-path DNS/connect/fast-probe timeout errors do not prematurely abort fallback. This stays within the same account/portal; it is NOT alternate-server failover.
- Cache bounded to 128 accounts; oldest saved entries evicted. Unchanged successful pair does not rewrite flash on every renewal. Small synchronous commits occur in the existing network call path, not added UI tasks, so a completed discovery is durable across immediate exit. Three additional ApplySharedPref lint warnings explicitly reflect this durability choice.
- Storage exceptions remain nonfatal. Account UI/models/AppStore unchanged. Hints for removed accounts are inert and eventually evicted; no new account-delete UI hook. Corrupt JSON is ignored and replaced after next success.

## Contract coverage (19 new tests, 60 total)
- MockWebServer + Robolectric API28 exercise production PortalClient with real HTTP on loopback and Android JSONObject/JsonReader (not mocked parsing).
- Stalker handshake/profile order, token/auth/cookie/referer/device-ID shape; categories; selected-category ordered-list pagination/partial callback; repeated-page termination; 401 renewal/retry; nothing_to_play fresh-session/link retry; saved-path-first with fresh auth and deterministic identity after RAM/repository recreation; stale path fallback/replacement persistence; malformed handshake fallback.
- Xtream credential encoding/auth acceptance+denial; selected VOD categories/items/extension and invalid-row filtering; streaming Live archive metadata; Series category isolation; direct playback URL resolution with zero extra HTTP calls.
- Repository recreation/schema/privacy, account/MAC/portal isolation, foreign/mismatched pairs, credential/query/fragment rejection, malformed/unavailable storage, bounded cache, unchanged-success no-rewrite and compare-before-delete.
- All provider data are synthetic fixtures in app/src/test/resources/contracts. No real subscription requests, media downloads or provider credentials. The synthetic media.fixture.invalid playback link is compared as text, never requested.

## Automated verification
- assembleRelease: PASS. compileDebugUnitTestKotlin: PASS. testDebugUnitTest: 60 tests, 0 failures/errors/skips.
- lintDebug: PASS, 0 errors, 312 warnings (309 previous + 3 intentional synchronous preference-write warnings).
- APK: com.iptvlite.tv, versionCode 187, versionName 1.7.11.3; v1/v2/v3 signatures verify. Same release certificate SHA-256: 1bcf4f23d41353cedf6a17b869442ddd38abff12d89f6228f1398aa166b1309b.
- Scope checker compares delivered186 ZIP: 63 existing main files byte-identical; only PortalClient initialization/discovery and UI version labels changed, plus Gradle test dependencies/version and new repository. Playback engine/configuration, Live recovery, request priority, lists/pagination, fingerprint, create_link renewal, manifest and resources unchanged.
- CI already runs tests and lint before packaging. Added Robolectric dependencies are test-only. CI release signing remains its existing ephemeral-key behavior; this delivered APK retains the original key, which is excluded from source ZIP.

## Limits and remaining verification
- No physical Android TV/Nox, real-provider compatibility test, real OS force-stop/reboot or uninterrupted-video performance test. JVM RAM/repository recreation is not a physical process-death test. Install over186, open one account, close/relaunch and verify lists/playback; then repeat after provider endpoint changes. Do not treat fixture tests as proof of every portal dialect or a stutter fix.
- Existing small-page pagination heuristic and localhost-with-explicit-port rewrite quirks are not changed. Fixtures use the current 14-item page convention and a non-localhost synthetic media host; those edge cases are not certified by these contracts and are outside this narrow task.
- Remaining roadmap phases/device tests are in ROADMAP_TV.md. No OpenSubtitles, Timeshift, Live pause, PiP, Multi-View or server failover introduced.
