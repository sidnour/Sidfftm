# 1.7.11.8 / 192 — bounded list and image work

## Scope
Based on frozen191. PlayerActivity, Media3 dependencies, PortalClient, PlaybackRequestScope, all network/recovery/service/store code, manifest and resources unchanged byte-for-byte. No buffer/reconnect tuning, data migration/deletion, category prefetch, OpenSubtitles, Timeshift, Live pause, multi-view or failover added.

- Lists: linear identity/content comparison; no RecyclerView invalidation for an equal submission; targeted metadata changes; verified tail insertion/removal; reset safely on reorder. Stream deduplication and stable IDs include account, kind and provider ID.
- Categories: old/new selection row notifications instead of full-list reset when content/theme is unchanged.
- Images: bounded two-worker/16-queued work, view-owned weak references and cancellable network scopes; cancel on recycle/detach/rebind and ordinary image preemption when playback becomes active. Existing explicit OSD image permission retained. Response caps, decode dimensions, RGB565 and 5MiB/1MiB caches retained; six-second overall request deadline. Expiring 512-entry/30-second failure cache replaces unbounded session-long failed-URL set; cancellation does not blacklist URLs.
- Search: combined letter/query pass, cooperative cancellation every128 rows and checks around existing sort. Existing category fetching and playback priority mechanisms untouched.
- Debug-only system trace spans have constant labels and no URLs, account/title data, disk logs or experimental UI. Release path bypasses tracing.

## Evidence
Release assemble, staged test compilation/execution and lint completed successfully. 162 tests, zero failures/errors/skips (19 new). Lint: zero errors,313 warnings, same count as191. APK version192/1.7.11.8, same official signing certificate; v1/v2/v3 verification successful.

New tests cover list planner, account identities, cancellation/expiry, RecyclerView notification observation, and image ownership/preemption/rebinding against local MockWebServer under Robolectric. The initial image-rebind test incorrectly assumed setImageBitmap(null) makes ImageView.drawable null (Android may retain an empty BitmapDrawable); corrected to assert cancellation, removed ownership and new binding tag. Final complete run passed.

Synthetic30,000-row operation counts: unchanged submission full invalidations1→0; one metadata edit full invalidations1→0 with one targeted row; category-selection-only targets at most2 rows. This avoids broad invalidation; it does NOT mean191 actually rebound every one of30,000 rows. Query+letter filtering passes2→1. Measured new planner-only p50≈1.23ms/p95≈1.75ms on sandbox JVM; not end-to-end timing and not a measured percentage speedup. Machine-readable report in verification/v192/.

## Limits / next phase
No physical TV/Nox/provider, first-frame latency, frame pacing/dropped frames, actual peak memory, Android driver/storage or install-upgrade test.191 and192 are not yet user-confirmed on device;190 remains the last user-confirmed stable rollback. No claim that strict real-world bandwidth priority or continuous stutter-free playback has been proven. Existing playback/category priority logic was deliberately not rewritten.

Install as an update without uninstall/data clearing, preferably after an ordinary precautionary backup. Check long-list remote navigation, rapid category/query changes, image reattachment, favourite markers, category selection, theme switching and channel start/recovery on TV. Then measure first frame, frame pacing and memory before considering any further changes. CI source includes GitHub Actions; its default generated test key does not match the official upgrade certificate. Supply the matching private key securely for upgrade-compatible CI builds; the key is not distributed.
