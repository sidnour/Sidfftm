from pathlib import Path
import zipfile,json,hashlib
root=Path('/home/user/iptv_lite_tv_191')
z=zipfile.ZipFile('/home/user/IPTV-Lite-TV-v1.7.11.6-src.zip')
prefix='app/src/main/java/com/iptvlite/tv/'
allowed={'app/build.gradle.kts'}|{prefix+x for x in ['network/SessionFlight.kt','network/XmltvHelper.kt','service/RecordingService.kt','store/AppStore.kt','util/StreamRecorder.kt','ui/MainActivity.kt','ui/TvDialogs.kt']}
added={prefix+x for x in ['network/GuideInput.kt','store/FullBackupPlan.kt','util/TransferOutput.kt']}
same=[];changed=[];baseline=set()
for n in z.namelist():
 r='/'.join(n.split('/')[1:])
 if not(r.startswith('app/src/main/') or r=='app/build.gradle.kts'):continue
 baseline.add(r);p=root/r;assert p.is_file(),r
 if p.read_bytes()==z.read(n):same.append(r)
 else:
  assert r in allowed,r
  if r=='app/build.gradle.kts':assert z.read(n).decode().replace('versionCode = 190','versionCode = 191').replace('versionName = "1.7.11.6"','versionName = "1.7.11.7"')==p.read_text()
  changed.append(r)
new={str(p.relative_to(root)) for p in (root/'app/src/main').rglob('*') if p.is_file()}-baseline
assert new==added,new
for critical in ['ui/PlayerActivity.kt','network/PortalClient.kt','network/PlaybackRequestScope.kt','util/LiveRecoveryPolicy.kt','util/LiveLinkMemory.kt','model/DataIdentity.kt']:
 assert prefix+critical in same,critical
freeze=json.loads(Path('/home/user/v191-frozen-sources.json').read_text())
for f,sha in freeze.items():assert hashlib.sha256((root/f).read_bytes()).hexdigest()==sha,f+' changed after freeze'
result={'baseline':'delivered190 /1.7.11.6','result':'PASS','changed':changed,'new':sorted(new),'unchanged_main_and_build_files':len(same),'frozen_source_files':len(freeze),'critical_unchanged':['PlayerActivity','PortalClient (fingerprint/session resolution/playback link generation)','PlaybackRequestScope','LiveRecoveryPolicy','LiveLinkMemory','DataIdentity','Media3 dependencies','manifest/resources'],'limits':'Synthetic verification only. No physical TV, provider, storage-driver, encrypted-upgrade or power-loss certification.'}
(root/'SCOPE-CHECK-v1.7.11.7.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
