from pathlib import Path
import zipfile,json
root=Path('/home/user/iptv_lite_tv_1711');z=zipfile.ZipFile('/home/user/IPTV-Lite-TV-v1.7.11.4-src.zip')
allowed={'app/build.gradle.kts','app/src/main/java/com/iptvlite/tv/model/Models.kt','app/src/main/java/com/iptvlite/tv/network/PortalClient.kt','app/src/main/java/com/iptvlite/tv/store/AppStore.kt','app/src/main/java/com/iptvlite/tv/ui/FeatureDialogs.kt','app/src/main/java/com/iptvlite/tv/ui/MainActivity.kt','app/src/main/java/com/iptvlite/tv/ui/TvDialogs.kt'}
changed=[];same=[];baseline=set()
for n in z.namelist():
    p=Path(*Path(n).parts[1:]);r=str(p);f=root/p
    if not (r.startswith('app/src/main/') or r=='app/build.gradle.kts'):continue
    baseline.add(r);assert f.is_file(),r
    old=z.read(n).decode();new=f.read_text()
    if old==new:same.append(r);continue
    assert r in allowed,r
    if p.name=='MainActivity.kt':
        expected=old.replace('v1.7.11.4','v1.7.11.5')
        for v in ['focused','item','cand']:expected=expected.replace(f'store.removeRecentItem({v}.id, {v}.kind)',f'store.removeRecentItem({v})')
        for v in ['item','seriesItem']:expected=expected.replace(f'store.getLatestSeriesResumeEntry({v}.id)',f'store.getLatestSeriesResumeEntry({v}.id, {v}.accountId)')
        assert expected==new,'MainActivity beyond account-aware deletion/resume/version'
    if p.name=='FeatureDialogs.kt':assert old.replace('store.getLatestSeriesResumeEntry(item.id)','store.getLatestSeriesResumeEntry(item.id, item.accountId)')==new
    if p.name=='TvDialogs.kt':assert old.replace('v1.7.11.4','v1.7.11.5')==new
    if p.name=='PortalClient.kt':
        anchor='    private fun safeMacForHeader'
        assert old[old.index(anchor):]==new[new.index(anchor):],'Private provider/recovery/link/fingerprint code changed'
        anchor='    fun resolveStreamUrl('
        end='    private fun sessionKey('
        assert old[old.index(anchor):old.index(end)]==new[new.index(anchor):new.index(end)],'Resolution/EPG/details modified'
    if p.name=='build.gradle.kts':assert old.replace('versionCode = 188','versionCode = 189').replace('versionName = "1.7.11.4"','versionName = "1.7.11.5"')==new
    changed.append(r)
newmain={str(p.relative_to(root)) for p in (root/'app/src/main').rglob('*') if p.is_file()}-baseline
assert newmain=={'app/src/main/java/com/iptvlite/tv/model/DataIdentity.kt'},newmain
result={'baseline':'delivered188','stage':'1 of4: account data/network cache identity and account transactions','result':'PASS','changed_existing_main_or_build_files':changed,'unchanged_main_files':len(same),'new_main_file':list(newmain),'unchanged_critical':'PlayerActivity/Media3, playback/recovery policy and memory, private provider parsing/pagination/session/link/fingerprint, endpoint hints, cancellation, manifest/resources, recorder/exit','remaining':'Partial-list cache/pagination/cancellation/UI generation; session single-flight/localhost ports; recorder finalization/exit. Legacy category preference namespace intentionally retained.'}
(root/'SCOPE-CHECK-v1.7.11.5.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
