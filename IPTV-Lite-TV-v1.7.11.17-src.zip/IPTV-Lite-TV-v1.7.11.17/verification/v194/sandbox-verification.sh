#!/usr/bin/env bash
set -euo pipefail
cd /home/user
source tools/setup_android.sh
cd iptv_lite_tv_194
COMMON=(--no-daemon --max-workers=1 -Dkotlin.compiler.execution.strategy=in-process)
./gradlew assembleRelease "${COMMON[@]}" -Dorg.gradle.jvmargs='-Xmx384m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC -Dfile.encoding=UTF-8'
./gradlew compileDebugUnitTestKotlin "${COMMON[@]}" -Dorg.gradle.jvmargs='-Xmx512m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC -Dfile.encoding=UTF-8'
rm -rf app/build/test-results/testDebugUnitTest app/build/reports/tests/testDebugUnitTest
./gradlew testDebugUnitTest "${COMMON[@]}" -Dorg.gradle.jvmargs='-Xmx192m -XX:MaxMetaspaceSize=192m -XX:+UseSerialGC -Dfile.encoding=UTF-8'
./gradlew lintDebug "${COMMON[@]}" -Dorg.gradle.jvmargs='-Xmx384m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC -Dfile.encoding=UTF-8'
echo FINAL_194_PASS
