set -e
mkdir -p /var/tmp/android-env/sdk/cmdline-tools /var/tmp/android-home /var/tmp/gradle-cache /var/tmp/android-env/jdk17
if [ ! -x /var/tmp/android-env/jdk17/bin/java ]; then
 curl -fsSL 'https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse?project=jdk' -o /var/tmp/jdk17.tar.gz
 tar -xzf /var/tmp/jdk17.tar.gz -C /var/tmp/android-env/jdk17 --strip-components=1
 rm /var/tmp/jdk17.tar.gz
fi
export JAVA_HOME=/var/tmp/android-env/jdk17 ANDROID_HOME=/var/tmp/android-env/sdk ANDROID_SDK_ROOT=/var/tmp/android-env/sdk ANDROID_USER_HOME=/var/tmp/android-home GRADLE_USER_HOME=/var/tmp/gradle-cache
export PATH="$JAVA_HOME/bin:$ANDROID_HOME/cmdline-tools/latest/bin:$PATH"
export GRADLE_OPTS='-Xmx64m -XX:+UseSerialGC'
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
 curl -fsSL https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -o /var/tmp/cmdtools.zip
 unzip -q /var/tmp/cmdtools.zip -d "$ANDROID_HOME/cmdline-tools"
 mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
 yes | sdkmanager --licenses >/dev/null 2>&1 || true
 sdkmanager 'platforms;android-34' 'build-tools;34.0.0' >/dev/null
fi
cd /home/user/iptv_lite_tv_1711
chmod +x gradlew
./gradlew assembleRelease --no-daemon --max-workers=1 -Dorg.gradle.jvmargs='-Xmx512m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC -Dfile.encoding=UTF-8' -Dkotlin.compiler.execution.strategy=in-process
cp app/build/outputs/apk/release/app-release.apk /home/user/IPTV-Lite-TV-v1.7.11.4.apk
./gradlew compileDebugUnitTestKotlin --no-daemon --max-workers=1 -Dorg.gradle.jvmargs='-Xmx512m -XX:MaxMetaspaceSize=384m -XX:+UseSerialGC -Dfile.encoding=UTF-8' -Dkotlin.compiler.execution.strategy=in-process
./gradlew testDebugUnitTest --no-daemon --max-workers=1 -Dorg.gradle.jvmargs='-Xmx192m -XX:MaxMetaspaceSize=192m -XX:+UseSerialGC -Dfile.encoding=UTF-8' -Dkotlin.compiler.execution.strategy=in-process
./gradlew lintDebug --no-daemon --max-workers=1 -Dorg.gradle.jvmargs='-Xmx384m -XX:MaxMetaspaceSize=256m -XX:+UseSerialGC -Dfile.encoding=UTF-8' -Dkotlin.compiler.execution.strategy=in-process
