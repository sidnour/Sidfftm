from pathlib import Path
import zipfile,json
root=Path('/home/user/iptv_lite_tv_1711')
z=zipfile.ZipFile('/home/user/IPTV-Lite-TV-v1.7.11.3-src.zip')
unchanged=[];versions=[];baseline_main=set()
for n in z.namelist():
    r=Path(*Path(n).parts[1:])
    if str(r).startswith('app/src/main/') or str(r)=='app/build.gradle.kts':
        baseline_main.add(str(r));f=root/r
        assert f.is_file(),f'Missing: {r}'
        old=z.read(n).decode();new=f.read_text()
        if r.name in ('MainActivity.kt','TvDialogs.kt'):
            assert old.replace('v1.7.11.3','v1.7.11.4')==new,str(r)
            versions.append(str(r))
        elif str(r)=='app/build.gradle.kts':
            assert old.replace('versionCode = 187','versionCode = 188').replace('versionName = "1.7.11.3"','versionName = "1.7.11.4"')==new
            versions.append(str(r))
        else:
            assert old==new,str(r)
            unchanged.append(str(r))
assert {str(p.relative_to(root)) for p in (root/'app/src/main').rglob('*') if p.is_file()}=={p for p in baseline_main if p.startswith('app/src/main/')},'unexpected main files'
result={'baseline':'delivered v1.7.11.3 /187 source ZIP','result':'PASS','unchanged_production_files':len(unchanged),'version_only_files':versions,'runtime_changes':'NONE: PortalClient, StalkerEndpointHints, AppStore, Models, PlayerActivity, recovery, manifest/resources byte-identical. No production parsers added.'}
(root/'SCOPE-CHECK-v1.7.11.4.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
