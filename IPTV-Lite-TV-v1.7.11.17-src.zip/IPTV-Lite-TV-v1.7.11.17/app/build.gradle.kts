import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.iptvlite.tv"
    compileSdk = 34
    buildFeatures { buildConfig = true }

    defaultConfig {
        applicationId = "com.iptvlite.tv"
        minSdk = 21
        targetSdk = 34
        versionCode = 201
        versionName = "1.7.11.17"
        // Single source of truth for the "البرنامج" About section; bump both lines together.
        buildConfigField("String", "APP_VERSION_NAME", "\"1.7.11.17\"")

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86_64")
        }
    }

    val defaultKs = rootProject.file("keystore/iptv_release.jks")
    val ksFile = System.getenv("SIGN_KEYSTORE_PATH")?.takeIf { it.isNotBlank() }?.let { file(it) }
        ?: defaultKs

    signingConfigs {
        if (ksFile.exists()) {
            create("releaseSign") {
                storeFile = ksFile
                storePassword = System.getenv("SIGN_STORE_PASS") ?: "iptvlite2026"
                keyAlias = System.getenv("SIGN_KEY_ALIAS") ?: "iptvlite"
                keyPassword = System.getenv("SIGN_KEY_PASS") ?: "iptvlite2026"
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("releaseSign")
                ?: signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        unitTests.isReturnDefaultValues = true
        unitTests.all {
            it.maxHeapSize="320m"
            it.systemProperty("iptv.performance.report",layout.buildDirectory.file("reports/performance-v198.json").get().asFile.absolutePath)
            it.maxParallelForks=1
            it.systemProperty("robolectric.dependency.repo.url","https://repo.maven.apache.org/maven2")
            it.systemProperty("user.home", File(System.getProperty("java.io.tmpdir"),"iptv-robolectric").apply { mkdirs() }.absolutePath)
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    testImplementation("com.squareup.okhttp3:mockwebserver:4.12.0")
    testImplementation("org.robolectric:robolectric:4.13")
    testImplementation("org.mockito:mockito-inline:4.11.0")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.security:security-crypto:1.0.0")
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    implementation("com.google.zxing:core:3.5.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    val media3Version = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-datasource-okhttp:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2")
}
