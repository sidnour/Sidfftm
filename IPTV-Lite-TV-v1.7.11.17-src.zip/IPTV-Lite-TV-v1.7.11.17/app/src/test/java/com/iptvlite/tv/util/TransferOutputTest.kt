package com.iptvlite.tv.util

import java.io.*
import org.junit.Test
import org.junit.Assert.*

class TransferOutputTest {
    @Test fun writtenProgressSurvivesAnExceptionAboveTransferLoop() {
        val sink=TransferOutput(ByteArrayOutputStream())
        var returned=0L
        try {returned=run {sink.write(ByteArray(70_000));throw IOException("network")}}catch(_:IOException){}
        assertEquals(0L,returned);assertEquals(70_000L,sink.bytesWritten)
        var published=false;var deleted=false
        assertTrue(sink.finish(sink.bytesWritten>=32_768,{published=true},{deleted=true}).isSuccess)
        assertTrue(published);assertFalse(deleted)
    }
    @Test fun failedCloseMustNotPublishOrClaimSuccess() {
        val sink=TransferOutput(object:ByteArrayOutputStream() {override fun close(){throw IOException("disk")}})
        sink.write(ByteArray(70_000));var published=false;var deleted=false
        assertTrue(sink.finish(true,{published=true},{deleted=true}).isFailure)
        assertFalse(published);assertFalse(deleted) // Preserve the partial file for recovery.
    }
    @Test fun failedPublishIsFailureEvenWithEnoughBytes() {
        val sink=TransferOutput(ByteArrayOutputStream());sink.write(ByteArray(70_000))
        assertTrue(sink.finish(true,{throw IOException("MediaStore update returned zero")},{}).isFailure)
    }
    @Test fun earlierFlushFailureIsNotHiddenBySuccessfulClose() {
        val sink=TransferOutput(object:ByteArrayOutputStream() {override fun flush(){throw IOException("full")}})
        sink.write(ByteArray(70_000));runCatching {sink.flush()};var published=false
        assertTrue(sink.finish(true,{published=true},{}).isFailure);assertFalse(published)
    }
    @Test fun incompleteDownloadDeletesOnlyAfterSuccessfulClose() {
        var closed=false;var deleted=false
        val sink=TransferOutput(object:ByteArrayOutputStream(){override fun close(){closed=true}})
        assertTrue(sink.finish(false, {fail("must not publish")}, {assertTrue(closed);deleted=true}).isSuccess)
        assertTrue(deleted)
    }
    @Test fun finalizationIsNotRepeated() {
        val sink=TransferOutput(ByteArrayOutputStream());var count=0
        assertTrue(sink.finish(true,{count++},{}).isSuccess)
        assertTrue(sink.finish(true,{count++},{}).isFailure);assertEquals(1,count)
    }
    @Test fun byteAndSliceWritesCountExactlyOnce() {
        val target=ByteArrayOutputStream();val sink=TransferOutput(target)
        sink.write(1);sink.write(byteArrayOf(2,3,4),1,2)
        assertEquals(3L,sink.bytesWritten);assertArrayEquals(byteArrayOf(1,3,4),target.toByteArray())
    }
}
