package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class AccountManagementTest {
    private val a=AccountProfile("a","Cinema",ProviderType.XTREAM,"https://user:secret@portal.example:8443/stalker/c/?token=private")
    private fun info(status:String,expiry:String="",ping:Int=30)=AccountStatusInfo(expiry,"",status,ping,
        access=when {
            status in setOf("Expired","Disabled","Banned","Blocked","Inactive","محظور ⛔")->AccountAccess.REJECTED
            status=="Active" || status.startsWith("نشط")->AccountAccess.ACCEPTED
            else->AccountAccess.UNKNOWN
        },verifiedExpiry=expiry)
    @Test fun nameHostPortAndPathSearchAreLocalAndCaseInsensitive() {
        for(q in listOf("cinEMA","portal.example","8443","stalker"))assertEquals(listOf(a),AccountManagement.filter(listOf(a),q))
        assertTrue(AccountManagement.filter(listOf(a),"absent").isEmpty())
        assertEquals(listOf(a),AccountManagement.filter(listOf(a),"  "))
    }
    @Test fun previewAddressHidesCredentialsAndQuery() {
        assertEquals("portal.example:8443",AccountManagement.host(a))
        for(q in listOf("secret","private","user:"))assertTrue(AccountManagement.filter(listOf(a),q).isEmpty())
    }
    @Test fun transportErrorsNeverMeanInvalidSubscription() {
        for(e in listOf(IOException("403"),IOException("timeout"),IllegalStateException("offline")))
            assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classifyFailure(e))
    }
    @Test fun providerAuthRejectionIsExplicitEvidence() {
        assertEquals(AccountManagement.Verdict.REJECTED,AccountManagement.classifyFailure(IllegalStateException("بيانات دخول Xtream غير صحيحة")))
    }
    @Test fun providerInactiveStatusOverridesPositivePing() {
        for(s in listOf("Expired","Disabled","Banned","Blocked","Inactive","محظور ⛔"))
            assertEquals(AccountManagement.Verdict.REJECTED,AccountManagement.classify(info(s),System.currentTimeMillis()))
    }
    @Test fun unknownAndNegativePingAreUncertain() {
        assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(info("error",ping=-1),0))
        assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(info("something"),0))
    }
    @Test fun activeStatusIsWorking() {
        for(s in listOf("Active","نشط ✔","نشط ✔ (50)"))assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(info(s),0))
    }
    @Test fun strictPastExpiryNotTodayOrMalformed() {
        val f=java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.US)
        val now=f.parse("2026-11-05")!!.time
        assertEquals(AccountManagement.Verdict.REJECTED,AccountManagement.classify(info("Active","2026-11-04"),now))
        for(e in listOf("2026-11-05","2027-01-01","2026-99-99","unknown"))
            assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(info("Active",e),now))
    }
    @Test fun evidenceRequiresSameAccountCredentialsAndRecentExplicitRejection() {
        val e=AccountManagement.Evidence(a.networkCacheKey(),"attempt",AccountManagement.Verdict.REJECTED,100)
        assertTrue(AccountManagement.eligible(a,e,101))
        assertFalse(AccountManagement.eligible(a.copy(password="new"),e,101))
        assertFalse(AccountManagement.eligible(a,e,99))
        assertFalse(AccountManagement.eligible(a,e,100+AccountManagement.FRESH_MS+1))
        assertFalse(AccountManagement.eligible(a,e.copy(verdict=AccountManagement.Verdict.UNCERTAIN),101))
    }
    @Test fun rawDisplayTextCannotAuthorizeWorkingOrRejection() {
        for(status in listOf("Active","نشط ✔","Expired","محظور")) {
            val info=AccountStatusInfo("2020-01-01","",status,30)
            assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(info,System.currentTimeMillis()))
        }
    }
    @Test fun unverifiedOrEmbeddedExpiryCannotAuthorizeDeletion() {
        val base=AccountStatusInfo("Contact since 2020-01-01","","Active",30,AccountAccess.ACCEPTED)
        assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(base,System.currentTimeMillis()))
        assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(base.copy(verifiedExpiry="Contact since 2020-01-01"),System.currentTimeMillis()))
    }

}
