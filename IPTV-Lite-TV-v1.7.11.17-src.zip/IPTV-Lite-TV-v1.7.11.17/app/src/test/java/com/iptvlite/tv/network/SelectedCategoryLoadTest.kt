package com.iptvlite.tv.network

import com.iptvlite.tv.model.*
import okhttp3.mockwebserver.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class SelectedCategoryLoadTest {
    private lateinit var server:MockWebServer
    private lateinit var account:AccountProfile
    private val requests=CopyOnWriteArrayList<Pair<String,Int>>()
    private val running=AtomicInteger();private val peak=AtomicInteger()
    @Volatile private var slowMs=140L
    @Volatile private var failPage=0
    @Volatile private var repeatPages=false
    @Volatile private var totalItems=20
    @Volatile private var pageWidth=2
    @Volatile private var advertiseTotal=true
    @Volatile private var advertisePages=false
    private fun reset() {
        SelectedCategoryLoad.discard();PortalClient.preemptBrowse();PortalClient.clearCaches()
        val f=PortalClient::class.java.getDeclaredField("stalkerSessions").apply {isAccessible=true}
        (f.get(PortalClient) as MutableMap<*,*>).clear()
    }
    @Before fun setup() {
        reset();server=MockWebServer()
        server.dispatcher=object:Dispatcher() {
            override fun dispatch(r:RecordedRequest):MockResponse {
                val action=r.requestUrl!!.queryParameter("action")
                if(action=="handshake")return MockResponse().setBody("{\"js\":{\"token\":\"test-token\"}}")
                if(action=="get_profile")return MockResponse().setBody("{\"js\":{}}")
                if(action!="get_ordered_list")return MockResponse().setResponseCode(500)
                val n=r.requestUrl!!.queryParameter("p")!!.toInt()
                val category=r.requestUrl!!.queryParameter("category")!!
                requests.add(category to n)
                val active=running.incrementAndGet();peak.updateAndGet {maxOf(it,active)}
                try {Thread.sleep(if(n==2)slowMs*2 else slowMs)}finally {running.decrementAndGet()}
                if(n==failPage)return MockResponse().setResponseCode(500)
                val page=if(repeatPages)1 else n
                val from=(page-1)*pageWidth+1
                val to=minOf(page*pageWidth,totalItems)
                val data=if(from>to)"" else (from..to).joinToString(",") {"{\"id\":\"$category-$it\",\"name\":\"Item $it\",\"cmd\":\"http://fixture/$it\"}"}
                val total=if(advertiseTotal)totalItems else 0
                val pages=if(advertisePages)(totalItems+pageWidth-1)/pageWidth else 0
                return MockResponse().setBody("{\"js\":{\"total_items\":$total,\"total_pages\":$pages,\"max_page_items\":$pageWidth,\"data\":[$data]}}")
            }
        }
        server.start();account=AccountProfile("parallel-fixture","Fixture",ProviderType.STALKER,server.url("/c/").toString(),mac="02:00:00:00:00:09")
    }
    private fun await(timeoutMs:Long=12000,predicate:()->Boolean) {
        val deadline=System.nanoTime()+TimeUnit.MILLISECONDS.toNanos(timeoutMs)
        while(System.nanoTime()<deadline) {if(predicate())return;Thread.sleep(20)}
        fail("Timed out: ${SelectedCategoryLoad.status()} requests=$requests")
    }
    @After fun cleanup() {SelectedCategoryLoad.discard();PortalClient.preemptBrowse();server.shutdown();reset();PlayQueueHolder.clear()}
    @Test fun fiveActualOverlappingRequestsCompleteInPageOrder() {
        SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        val status=SelectedCategoryLoad.status()!!
        assertFalse(status.failed);assertTrue(status.complete)
        assertEquals((1..20).map {"A-$it"},status.items.map {it.id})
        assertEquals(5,peak.get());assertEquals(10,requests.size)
        assertEquals(1,requests.first().second);assertTrue(status.items.all {it.accountId==account.id})
    }
    @Test fun playbackSuspendsAndReturnResumesWithoutRefetchingCompletedFirstPage() {
        slowMs=400
        SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {requests.size>=6}
        SelectedCategoryLoad.playbackStarting();PortalClient.preemptBrowse()
        Thread.sleep(1100)
        val count=requests.size;val paused=SelectedCategoryLoad.status()!!
        assertTrue(paused.paused);assertFalse(paused.complete);assertFalse(paused.failed)
        assertTrue(paused.items.size>=2)
        Thread.sleep(300);assertEquals(count,requests.size)
        SelectedCategoryLoad.browsing()
        await {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        assertTrue(SelectedCategoryLoad.status()!!.complete)
        assertEquals(1,requests.count {it==("A" to 1)})
    }
    @Test fun changingCategoryCannotPublishOldResultsOrCancelNewOwner() {
        slowMs=300;SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {requests.size>=6}
        SelectedCategoryLoad.start(account,ContentTab.VOD,"B")
        await {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        val status=SelectedCategoryLoad.status()!!
        assertTrue(status.complete);assertFalse(status.failed)
        assertEquals((1..20).map {"B-$it"},status.items.map {it.id})
    }
    @Test fun httpFailureIsExplicitlyIncompleteNotCachedSuccess() {
        failPage=3;SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {SelectedCategoryLoad.status()?.failed==true}
        assertFalse(SelectedCategoryLoad.status()!!.complete)
        failPage=0;SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        assertTrue(SelectedCategoryLoad.status()!!.complete)
        assertEquals(2,requests.count {it==("A" to 1)})
    }
    @Test fun stablePlaybackResumesWithOneWorkerAndBufferingSuspendsAgain() {
        slowMs=220;SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await {requests.size>=6}
        SelectedCategoryLoad.playbackStarting();PortalClient.preemptBrowse()
        Thread.sleep(800);peak.set(0)
        val before=requests.size
        val deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(13)
        var position=0L
        while(System.nanoTime()<deadline && requests.size==before) {
            position+=1000;SelectedCategoryLoad.observePlayback(position,true);Thread.sleep(1000)
        }
        await {requests.size>before}
        assertEquals(1,peak.get())
        SelectedCategoryLoad.observePlayback(position,false)
        Thread.sleep(800);val after=requests.size
        Thread.sleep(500);assertEquals(after,requests.size)
        assertFalse(SelectedCategoryLoad.status()!!.failed)
        assertFalse(SelectedCategoryLoad.status()!!.complete)
        assertTrue(SelectedCategoryLoad.status()!!.paused)
    }
    @Test fun liveQueueExpandsWithoutLosingCurrentIdentity() {
        slowMs=300;SelectedCategoryLoad.start(account,ContentTab.LIVE,"A")
        await {SelectedCategoryLoad.status()!!.items.size>=2}
        SelectedCategoryLoad.playbackStarting();PortalClient.preemptBrowse();Thread.sleep(800)
        val initial=SelectedCategoryLoad.status()!!.items
        SelectedCategoryLoad.bindQueue(account,initial,true)
        PlayQueueHolder.activeAccount=account;PlayQueueHolder.playlist=initial;PlayQueueHolder.currentIndex=1
        val current=initial[1]
        SelectedCategoryLoad.browsing()
        await {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        assertTrue(SelectedCategoryLoad.status()!!.complete)
        assertTrue(SelectedCategoryLoad.refreshQueue(current))
        assertEquals(20,PlayQueueHolder.playlist.size)
        assertEquals(current,PlayQueueHolder.playlist[PlayQueueHolder.currentIndex])
    }
    @Test fun filteredOrFavouriteQueueIsNeverWidened() {
        SelectedCategoryLoad.start(account,ContentTab.LIVE,"A")
        await {SelectedCategoryLoad.status()?.complete==true}
        val item=SelectedCategoryLoad.status()!!.items[0]
        PlayQueueHolder.activeAccount=account;PlayQueueHolder.playlist=listOf(item)
        SelectedCategoryLoad.bindQueue(account,listOf(item),false)
        assertFalse(SelectedCategoryLoad.refreshQueue(item));assertEquals(1,PlayQueueHolder.playlist.size)
    }
    @Test fun largeVodCategoryFetchesPastEveryOldCap() {
        totalItems=3010;pageWidth=14;slowMs=0
        SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await(30000) {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        val status=SelectedCategoryLoad.status()!!
        assertFalse(status.failed);assertTrue(status.complete);assertEquals(3010,status.items.size)
        assertEquals((1..3010).map {"A-$it"},status.items.map {it.id})
        assertEquals(215,requests.size);assertEquals(215,requests.maxOf {it.second})
    }
    @Test fun unknownTotalKeepsGoingPast160UntilEmptyResponse() {
        totalItems=2268;pageWidth=14;slowMs=0;advertiseTotal=false
        SelectedCategoryLoad.start(account,ContentTab.LIVE,"A")
        await(30000) {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        val status=SelectedCategoryLoad.status()!!
        assertFalse(status.failed);assertTrue(status.complete);assertEquals(2268,status.items.size)
        assertTrue(requests.any {it.second==163});assertTrue(requests.maxOf {it.second}<=167)
    }
    @Test fun providerPageCountWorksWithoutItemTotal() {
        totalItems=1127;pageWidth=14;slowMs=0;advertiseTotal=false;advertisePages=true
        SelectedCategoryLoad.start(account,ContentTab.SERIES,"A")
        await(30000) {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        assertTrue(SelectedCategoryLoad.status()!!.complete);assertEquals(1127,SelectedCategoryLoad.status()!!.items.size)
        assertEquals(81,requests.size)
    }
    @Test fun lastBatchAtFormer80PageBoundaryIsFullyPublished() {
        totalItems=1120;pageWidth=14;slowMs=0
        SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await(30000) {SelectedCategoryLoad.status()?.complete==true || SelectedCategoryLoad.status()?.failed==true}
        assertTrue(SelectedCategoryLoad.status()!!.complete);assertEquals(1120,SelectedCategoryLoad.status()!!.items.size)
        assertEquals(80,requests.size)
    }
    @Test fun failedFinalPageDoesNotHideOtherCompletedFinalBatchPages() {
        totalItems=1120;pageWidth=14;slowMs=0;failPage=80
        SelectedCategoryLoad.start(account,ContentTab.VOD,"A")
        await(30000) {SelectedCategoryLoad.status()?.failed==true}
        val status=SelectedCategoryLoad.status()!!
        assertFalse(status.complete);assertEquals(1106,status.items.size);assertTrue(status.error.isNotBlank())
    }
    @Test fun repeatedPagesFailInsteadOfSilentlyTruncating() {
        repeatPages=true;SelectedCategoryLoad.start(account,ContentTab.SERIES,"A")
        await {SelectedCategoryLoad.status()?.failed==true}
        assertFalse(SelectedCategoryLoad.status()!!.complete);assertTrue(requests.size<=6)
    }
}
