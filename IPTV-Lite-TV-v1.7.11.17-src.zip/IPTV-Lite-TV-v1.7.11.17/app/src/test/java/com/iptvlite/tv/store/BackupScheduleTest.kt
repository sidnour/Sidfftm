package com.iptvlite.tv.store

import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.json.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class BackupScheduleTest {
    private lateinit var ctx:Context
    private lateinit var fast:SharedPreferences
    private lateinit var secret:SharedPreferences
    private lateinit var store:AppStore
    private val a=AccountProfile("A","A",ProviderType.XTREAM,"https://a.fixture.invalid",username="User",password="pass")
    private val b=a.copy(id="B",name="B",url="https://b.fixture.invalid")
    private fun item(owner:String)=StreamItem("42","Fixture",cmd="http://media.fixture.invalid/a",kind=ItemKind.VOD,accountId=owner)
    private fun resetRam() {
        for(name in listOf("cachedAccounts","cachedFavorites","cachedFavIds","cachedRecent","cachedResumeEntries","cachedReminders","cachedScheduledRecs","cachedPrefs"))
            AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.set(null,null)
        for(name in listOf("resumePosRamCache","catPrefsRamCache"))
            (AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.get(null) as MutableMap<*,*>).clear()
    }
    @Before fun setup() {
        ctx=RuntimeEnvironment.getApplication()
        fast=ctx.getSharedPreferences("backup_schedule_fast",0);secret=ctx.getSharedPreferences("backup_schedule_secret",0)
        fast.edit().clear().commit();secret.edit().clear().commit();resetRam()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,secret to fast)
        store=AppStore(ctx);store.saveAccounts(listOf(a,b))
    }
    @After fun cleanup() {
        resetRam();AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    private fun fresh() {fast.edit().clear().commit();secret.edit().clear().commit();resetRam();store=AppStore(ctx)}
    private fun seed() {
        store.setFavoriteItemFolder(item("A"),"📂 A folder")
        store.setFavoriteItemFolder(item("B"),"📂 B folder")
        store.addRecent(item("A"));store.addRecent(item("B"))
        store.saveResumeEntry(item("A"),30_000,100_000)
        store.saveResumeEntry(item("B"),40_000,100_000)
        store.setAutoLockAdult(false)
    }
    @Test fun freshRestorePreservesTwoOwnersFavoritesFoldersRecentResumeAndAdultPreference() {
        seed();val backup=store.exportFullBackupJson();fresh()
        assertEquals(2,store.importAnyPortalsOrBackup(backup).accountsAdded)
        assertEquals(setOf("A","B"),store.getAccounts().map {it.id}.toSet())
        assertEquals(2,store.getFavorites().size);assertEquals(2,store.getRecent().size)
        assertEquals("📂 A folder",store.getFavoriteItemFolder(item("A")))
        assertEquals("📂 B folder",store.getFavoriteItemFolder(item("B")))
        assertEquals(30_000L,store.getResumePos(item("A")))
        assertEquals(40_000L,store.getResumePos(item("B")))
        assertFalse(store.getAutoLockAdult())
        resetRam();assertEquals(2,store.getResumeEntries().size)
        assertEquals(30_000L,store.getResumePos(item("A")))
    }
    @Test fun identityMatchRemapsAllPersonalDataToExistingLocalId() {
        seed();val backup=store.exportFullBackupJson();fresh()
        store.saveAccounts(listOf(a.copy(id="LOCAL")))
        store.importAnyPortalsOrBackup(backup)
        assertEquals(setOf("LOCAL","B"),store.getAccounts().map {it.id}.toSet())
        assertTrue(store.getFavorites().any {it.accountId=="LOCAL"})
        assertEquals("📂 A folder",store.getFavoriteItemFolder(item("LOCAL")))
        assertEquals(30_000L,store.getResumePos(item("LOCAL")))
        assertFalse(store.getRecent().any {it.accountId=="A"})
    }
    @Test fun collidingAccountIdDoesNotAttachRestoredItemsToUnrelatedLocalAccount() {
        seed();val backup=store.exportFullBackupJson();fresh()
        store.saveAccounts(listOf(a.copy(url="https://unrelated.fixture.invalid")))
        store.toggleFavorite(item("A").copy(name="Local"))
        store.importAnyPortalsOrBackup(backup)
        val restored=store.getAccounts().single {it.url==a.url}
        assertNotEquals("A",restored.id)
        assertEquals(30_000L,store.getResumePos(item(restored.id)))
        assertTrue(store.getFavorites().any {it.accountId=="A" && it.name=="Local"})
        assertEquals("📂 A folder",store.getFavoriteItemFolder(item(restored.id)))
    }
    @Test fun mergeDoesNotOverwriteExistingResumePositionOrRemoveLocalRecent() {
        seed();val backup=store.exportFullBackupJson()
        store.saveResumeEntry(item("A"),60_000,100_000)
        store.addRecent(item("A").copy(id="local-only"))
        store.importAnyPortalsOrBackup(backup)
        assertEquals(60_000L,store.getResumePos(item("A")))
        assertTrue(store.getRecent().any {it.id=="local-only"})
        assertEquals(2,store.getFavorites().size)
    }
    @Test fun malformedFullBackupIsRejectedBeforeAccountsOrFavoritesAreChanged() {
        seed();val before=secret.getString("accounts_json",null);val fav=fast.getString("favorites_json",null)
        val root=JSONObject(store.exportFullBackupJson()).put("resume_entries","bad array")
        assertEquals(0,store.importAnyPortalsOrBackup(root.toString()).accountsAdded)
        assertEquals(before,secret.getString("accounts_json",null));assertEquals(fav,fast.getString("favorites_json",null))
    }
    @Test fun duplicateSourceAccountIdsAreRejectedBeforeMutation() {
        seed();val root=JSONObject(store.exportFullBackupJson());val array=root.getJSONArray("accounts")
        array.getJSONObject(1).put("id",array.getJSONObject(0).getString("id"))
        val before=secret.getString("accounts_json",null)
        assertEquals(0,store.importAnyPortalsOrBackup(root.toString()).accountsAdded)
        assertEquals(before,secret.getString("accounts_json",null))
    }
    @Test fun exportUsesLatestPositionNotStaleEntrySnapshot() {
        store.saveResumeEntry(item("A"),20_000,100_000)
        store.saveResumePos("42",50_000,100_000,ItemKind.VOD,"A")
        val root=JSONObject(store.exportFullBackupJson())
        assertEquals(50_000L,root.getJSONArray("resume_entries").getJSONObject(0).getLong("posMs"))
    }
    @Test fun missingOwnerRemainsIsolatedFromLocalAccountWithSameId() {
        val root=JSONObject().put("app","IPTV_Lite_TV").put("accounts",JSONArray())
            .put("favorites",JSONArray().put(JSONObject().put("id","42").put("name","Unknown").put("kind","VOD").put("accountId","A")))
        store.importAnyPortalsOrBackup(root.toString())
        assertNotEquals("A",store.getFavorites().single().accountId)
    }
    @Test fun remindersDeduplicateWithinAccountOnly() {
        val now=System.currentTimeMillis()/1000+3600
        val ra=ProgramReminder("ra","42","Channel","http://media.invalid","Program",now,now,"A")
        store.addReminder(ra);store.addReminder(ra.copy(id="rb",accountId="B"))
        assertEquals(2,store.getReminders().size)
        store.addReminder(ra.copy(id="ra2"))
        assertEquals(setOf("ra2","rb"),store.getReminders().map {it.id}.toSet())
    }
    @Test fun recordingsDeduplicateWithinAccountOnly() {
        val now=System.currentTimeMillis()/1000+3600
        val rec=ScheduledRecording("ra","A","42","Channel","http://media.invalid","Program",now,30)
        store.addScheduledRec(rec);store.addScheduledRec(rec.copy(id="rb",accountId="B"))
        assertEquals(2,store.getScheduledRecs().size)
        store.addScheduledRec(rec.copy(id="ra2"))
        assertEquals(setOf("ra2","rb"),store.getScheduledRecs().map {it.id}.toSet())
    }
    @Test fun olderMinimalFullBackupStillImportsWithoutErasingLocalData() {
        store.toggleFavorite(item("A"))
        val root=JSONObject().put("app","IPTV_Lite_TV").put("accounts",JSONArray())
        store.importAnyPortalsOrBackup(root.toString())
        assertEquals(1,store.getFavorites().size);assertEquals(2,store.getAccounts().size)
    }
}
