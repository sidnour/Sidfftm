package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import org.junit.Assert.*
import org.junit.Test

class DuplicateAccountsTest {
    private val a=AccountProfile("A","Server",ProviderType.STALKER,"https://portal.invalid/c/",mac="00:1A:79:01:02:03")
    private val b=a.copy(id="B")
    private fun plan(vararg accounts:AccountProfile,protected:Set<String> = emptySet(),active:String="")=
        DuplicateAccounts.plan(accounts.toList(),protected,active)
    @Test fun samePortalAndMacIgnoresDisplayName() {
        val p=plan(a,b.copy(name="Renamed"));assertEquals(listOf("B"),p.removable.map {it.id})
    }
    @Test fun activeAccountAlwaysSurvives() {
        assertEquals(listOf("A"),plan(a,b,active="B").removable.map {it.id})
    }
    @Test fun personalDataProtectsWholeGroup() {
        assertTrue(plan(a,b,protected=setOf("B")).removable.isEmpty())
    }
    @Test fun differentPortalIsOnlyPotentialMatch() {
        val p=plan(a,b.copy(url="https://other.invalid/c/"))
        assertTrue(p.groups.isEmpty());assertEquals(1,p.potential.size);assertTrue(p.removable.isEmpty())
    }
    @Test fun differentProtocolPathQueryOrCaseSensitivePathNeverMerge() {
        for(url in listOf("http://portal.invalid/c/","https://portal.invalid/C/","https://portal.invalid/c",
            "https://portal.invalid/c/?token=X","https://portal.invalid:8443/c/"))
            assertTrue(url,plan(a,b.copy(url=url)).removable.isEmpty())
    }
    @Test fun safeHostDefaultPortAndMacNormalization() {
        assertEquals(1,plan(a,b.copy(url="HTTPS://PORTAL.INVALID:443/c/",mac="00-1a-79-01-02-03")).removable.size)
    }
    @Test fun invalidOrMissingMacCannotQualify() {
        for(mac in listOf("","123","not-mac"))assertTrue(plan(a.copy(mac=mac),b.copy(mac=mac)).groups.isEmpty())
    }
    @Test fun sameNameDifferentMacDoesNotQualify() {
        assertTrue(plan(a,b.copy(mac="00:1A:79:01:02:04")).groups.isEmpty())
    }
    @Test fun epgOrCredentialsDifferenceNeverDiscarded() {
        for(other in listOf(b.copy(epgUrl="https://epg.invalid"),b.copy(password="different"),b.copy(username="other")))
            assertTrue(plan(a,other).removable.isEmpty())
    }
    @Test fun unknownPersonalDataOrAmbiguousIdsProtectAll() {
        assertTrue(DuplicateAccounts.plan(listOf(a,b),emptySet(),"",true).removable.isEmpty())
        assertTrue(plan(a,a.copy(name="other")).removable.isEmpty())
    }
    @Test fun xtreamRequiresSameCredentialsNotOnlyHost() {
        val x=a.copy(provider=ProviderType.XTREAM,username="User",password="secret",mac="")
        assertEquals(1,plan(x,x.copy(id="B")).removable.size)
        assertTrue(plan(x,x.copy(id="B",password="different")).removable.isEmpty())
        assertTrue(plan(x,x.copy(id="B",username="user")).removable.isEmpty())
    }
    @Test fun m3uUsesExactHttpIdentityAndExcludesLocalFiles() {
        val x=a.copy(provider=ProviderType.M3U,mac="",url="https://playlist.invalid/get?token=fixture")
        assertEquals(1,plan(x,x.copy(id="B")).removable.size)
        assertTrue(plan(x,x.copy(id="B",url=x.url+"2")).removable.isEmpty())
        val local=x.copy(url="content://file/same")
        assertTrue(plan(local,local.copy(id="B")).groups.isEmpty())
    }
    @Test fun planIsDeterministicWhenListOrderChanges() {
        assertEquals(plan(a,b).removable.map {it.id},plan(b,a).removable.map {it.id})
    }
    @Test fun identityKeyDoesNotContainSecrets() {
        val key=DuplicateAccounts.key(a.copy(password="private"))!!
        assertEquals(64,key.length);assertFalse(key.contains("private"));assertFalse(key.contains("portal"))
    }
}
