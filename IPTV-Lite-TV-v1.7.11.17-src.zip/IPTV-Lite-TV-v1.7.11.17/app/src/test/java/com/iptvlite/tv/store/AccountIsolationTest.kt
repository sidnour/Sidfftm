package com.iptvlite.tv.store

import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.CountDownLatch

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class AccountIsolationTest {
    private lateinit var context:Context
    private lateinit var fast:SharedPreferences
    private lateinit var secret:SharedPreferences
    private lateinit var store:AppStore
    private val a=AccountProfile("A","A",ProviderType.XTREAM,"https://fixture.invalid",username="User",password="fixture+pass")
    private val b=a.copy(id="B",name="B")
    private fun item(owner:String,kind:ItemKind=ItemKind.VOD)=StreamItem("100","Fixture Movie","https://media.fixture.invalid/movie",kind=kind,accountId=owner)
    private fun resetRam() {
        for(name in listOf("cachedAccounts","cachedFavorites","cachedFavIds","cachedRecent","cachedResumeEntries"))
            AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.set(null,null)
        val map=AppStore::class.java.getDeclaredField("resumePosRamCache").apply {isAccessible=true}.get(null) as MutableMap<*,*>
        map.clear()
    }
    @Before fun setup() {
        context=RuntimeEnvironment.getApplication()
        secret=context.getSharedPreferences("isolation_test_secret",Context.MODE_PRIVATE)
        fast=context.getSharedPreferences("isolation_test_fast",Context.MODE_PRIVATE)
        secret.edit().clear().commit();fast.edit().clear().commit()
        // Exercise AppStore with real preferences; encryption/key management is not under test.
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,secret to fast)
        resetRam();store=AppStore(context)
        store.saveAccounts(listOf(a,b));store.setActiveAccountId(a.id)
    }
    @After fun cleanup() {
        resetRam()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    @Test fun favoritesWithSameProviderIdAreIndependentAcrossAccounts() {
        assertTrue(store.toggleFavorite(item("A")))
        assertFalse(store.isFavorite(item("B")))
        assertTrue(store.toggleFavorite(item("B")))
        assertEquals(2,store.getFavorites().size)
        assertFalse(store.toggleFavorite(item("A")))
        assertFalse(store.isFavorite(item("A")));assertTrue(store.isFavorite(item("B")))
        resetRam();assertEquals("B",store.getFavorites().single().accountId)
    }
    @Test fun folderMembershipAndRemovalAreAccountScoped() {
        store.setFavoriteItemFolder(item("A"),"A folder")
        store.setFavoriteItemFolder(item("B"),"B folder")
        assertEquals(listOf("A"),store.getFavoritesInFolder("A folder").map {it.accountId})
        store.toggleFavorite(item("A"))
        assertEquals("B folder",store.getFavoriteItemFolder(item("B")))
        assertEquals(1,store.getFavorites().size)
    }
    @Test fun oldFolderMappingMovesToItsKnownOriginalOwnerAndCannotLeakToNewAccount() {
        val raw=JSONArray().put(JSONObject().put("id","100").put("name","Fixture").put("kind","VOD").put("accountId","A"))
        fast.edit().putString("favorites_json",raw.toString())
            .putString("fav_item_folders_json",JSONObject().put("VOD:100","Existing folder").toString()).commit()
        resetRam();store.getFavorites()
        assertEquals("Existing folder",store.getFavoriteItemFolder(item("A")))
        store.toggleFavorite(item("B"))
        assertEquals("",store.getFavoriteItemFolder(item("B")))
        resetRam();store.getFavorites()
        assertEquals("Existing folder",store.getFavoriteItemFolder(item("A")))
        assertEquals("",store.getFavoriteItemFolder(item("B")))
    }
    @Test fun unownedLegacyFavoriteIsRetainedWithoutAssigningItToTheActiveAccount() {
        store.toggleFavorite(item(""));store.setFavoriteItemFolder(item(""),"Legacy")
        assertEquals("",store.getFavorites().single().accountId)
        assertFalse(store.isFavorite(item("A")))
        store.toggleFavorite(item("A"))
        assertEquals(2,store.getFavorites().size)
        assertEquals("",store.getFavoriteItemFolder(item("A")))
        assertEquals("Legacy",store.getFavoriteItemFolder(item("")))
    }
    @Test fun sameIdRecentItemsAndIndividualDeletionAreAccountScoped() {
        store.addRecent(item("A"));store.addRecent(item("B"));store.addRecent(item("A"))
        assertEquals(listOf("A","B"),store.getRecent().map {it.accountId})
        store.saveResumeEntry(item("A"),10_000L,1_000_000L)
        store.saveResumeEntry(item("B"),20_000L,1_000_000L)
        store.removeRecentItem(item("A"))
        assertEquals("B",store.getRecent().single().accountId)
        assertEquals(0L,store.getResumePos(item("A")))
        assertEquals(20_000L,store.getResumePos(item("B")))
    }
    @Test fun resumePositionsPersistIndependentlyAndClearOnlyTheSelectedAccount() {
        store.saveResumeEntry(item("A"),10_000L,1_000_000L)
        store.saveResumeEntry(item("B"),20_000L,1_000_000L)
        resetRam()
        assertEquals(10_000L,store.getResumePos(item("A")))
        assertEquals(20_000L,store.getResumePos(item("B")))
        store.clearResumePos(item("A"));resetRam()
        assertEquals(0L,store.getResumePos(item("A")))
        assertEquals(20_000L,store.getResumePos(item("B")))
    }
    @Test fun episodeResumeAndSeriesQuickContinueCannotCrossAccounts() {
        val epA=item("A",ItemKind.EPISODE).copy(seriesId="55",seasonId="1")
        val epB=epA.copy(accountId="B")
        store.saveResumeEntry(epA,15_000L,1_000_000L)
        assertNull(store.getLatestSeriesResumeEntry("55","B"))
        store.saveResumeEntry(epB,35_000L,1_000_000L)
        assertEquals(15_000L,store.getLatestSeriesResumeEntry("55","A")!!.posMs)
        assertEquals(35_000L,store.getLatestSeriesResumeEntry("55","B")!!.posMs)
    }
    @Test fun legacyResumeJsonUsesOwnerSnapshotNotAmbiguousGlobalPosition() {
        val raw=JSONArray().put(JSONObject().put("id","100").put("name","Fixture").put("kind","VOD")
            .put("accId","A").put("posMs",15_000L).put("durMs",1_000_000L))
        fast.edit().putString("resume_entries_json",raw.toString()).putLong("pos_VOD_100",99_000L).putLong("pos_100",99_000L).commit()
        resetRam()
        assertEquals(15_000L,store.getResumePos(item("A")))
        assertEquals(0L,store.getResumePos(item("B")))
        assertEquals(99_000L,fast.getLong("pos_VOD_100",0L)) // Preserved, not reassigned or deleted.
        store.saveResumeEntry(item("B"),25_000L,1_000_000L);resetRam()
        assertEquals(15_000L,store.getResumePos(item("A")))
        assertEquals(25_000L,store.getResumePos(item("B")))
    }
    @Test fun ownerlessResumeSnapshotRemainsUnassignedAndRawOnlyPositionIsNotGuessed() {
        val raw=JSONArray().put(JSONObject().put("id","100").put("name","Legacy").put("kind","VOD").put("posMs",15_000L))
        fast.edit().putString("resume_entries_json",raw.toString()).putLong("pos_100",88_000L).commit()
        resetRam()
        assertEquals(0L,store.getResumePos(item("A")))
        assertEquals(0L,store.getResumePos(item("B")))
        assertEquals(15_000L,store.getResumePos(item("")))
        assertEquals("",store.getResumeEntries().single().accountId)
    }
    @Test fun completionClearsOnlyItsExplicitOwnerEvenWhenInputItemIsUnstamped() {
        store.saveResumeEntry(item("A"),10_000L,1_000_000L)
        store.saveResumeEntry(item("B"),20_000L,1_000_000L)
        store.saveResumeEntry(item(""),980_000L,1_000_000L,"A")
        assertEquals(0L,store.getResumePos(item("A")))
        assertEquals(20_000L,store.getResumePos(item("B")))
    }
    @Test fun clearAllRemovesNewAndQuarantinedLegacyPositions() {
        store.saveResumeEntry(item("A"),10_000L,1_000_000L)
        fast.edit().putLong("pos_100",99_000L).commit()
        store.clearAllResumeEntries();resetRam()
        assertTrue(store.getResumeEntries().isEmpty())
        assertFalse(fast.all.keys.any {it.startsWith("pos_")})
    }
    @Test fun concurrentStatusUpdatesAcrossStoreInstancesDoNotLoseEachOther() {
        val accounts=(1..16).map {a.copy(id="fixture-$it")}
        store.saveAccounts(accounts)
        val pool=Executors.newFixedThreadPool(8)
        val start=CountDownLatch(1)
        try {
            val tasks=accounts.mapIndexed {i,acc->pool.submit {
                start.await();AppStore(context).updateAccountStatus(acc.id,"fixture expiry","fixture ready",i+1)
            }}
            start.countDown();tasks.forEach {it.get(10,TimeUnit.SECONDS)}
            assertTrue(store.getAccounts().all {it.status=="fixture ready" && it.pingMs>0})
            resetRam();assertTrue(store.getAccounts().all {it.status=="fixture ready" && it.pingMs>0})
        } finally {pool.shutdownNow()}
    }
    @Test fun concurrentStatusCannotResurrectDeletedAccount() {
        val pool=Executors.newFixedThreadPool(2)
        try {
            repeat(20) {
                store.saveAccounts(listOf(a,b))
                val start=CountDownLatch(1)
                val one=pool.submit {start.await();AppStore(context).deleteAccount("A")}
                val two=pool.submit {start.await();AppStore(context).updateAccountStatus("B","expiry","ready",7)}
                start.countDown();one.get(10,TimeUnit.SECONDS);two.get(10,TimeUnit.SECONDS)
                assertEquals(listOf("B"),store.getAccounts().map {it.id})
                assertEquals("ready",store.getAccounts().single().status)
            }
        } finally {pool.shutdownNow()}
    }

    @Test fun editingCredentialsKeepsAccountIdButCaseSensitiveAccountsDoNotMerge() {
        store.saveAccounts(listOf(a))
        val updated=store.upsertAccount(a.copy(password="changed"))
        assertEquals("A",updated.id);assertEquals(1,store.getAccounts().size)
        store.upsertAccount(a.copy(id="C",username="user"))
        store.upsertAccount(a.copy(id="D",url="https://fixture.invalid/Portal"))
        store.upsertAccount(a.copy(id="E",url="https://fixture.invalid/portal"))
        assertEquals(setOf("A","C","D","E"),store.getAccounts().map {it.id}.toSet())
    }
}
