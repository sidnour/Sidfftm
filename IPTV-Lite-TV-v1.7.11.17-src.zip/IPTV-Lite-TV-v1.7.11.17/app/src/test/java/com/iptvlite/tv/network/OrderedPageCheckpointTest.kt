package com.iptvlite.tv.network

import org.junit.Assert.*
import org.junit.Test

class OrderedPageCheckpointTest {
    private fun checkpoint()=OrderedPageCheckpoint<Int> {it.toString()}
    private fun page(vararg items:Int,total:Int=0,width:Int=2)=OrderedPageCheckpoint.Page(items.toList(),items.size,total,width)
    @Test fun firstPageAlwaysAlone() {assertEquals(listOf(1),checkpoint().missing(5))}
    @Test fun knownTotalAdmitsFivePagesAfterFirst() {
        val c=checkpoint();c.put(1,page(1,2,total=20));assertEquals((2..6).toList(),c.missing(5))
    }
    @Test fun outOfOrderPagesAreRetainedButNotDisplayedAcrossGap() {
        val c=checkpoint();c.put(1,page(1,2,total=8));c.put(3,page(5,6,total=8))
        assertEquals(listOf(1,2),c.snapshot().items);assertEquals(listOf(2,4),c.missing(5))
        c.put(2,page(3,4,total=8));assertEquals((1..6).toList(),c.snapshot().items)
    }
    @Test fun resumedRequestSkipsCompletedPages() {
        val c=checkpoint();c.put(1,page(1,2,total=12));c.put(2,page(3,4,total=12));c.put(4,page(7,8,total=12))
        assertEquals(listOf(3,5,6),c.missing(5));assertFalse(c.snapshot().complete)
    }
    @Test fun knownTotalCompletesOnlyAfterAllUniqueItems() {
        val c=checkpoint();c.put(1,page(1,2,total=4));assertFalse(c.snapshot().complete)
        c.put(2,page(3,4,total=4));assertTrue(c.snapshot().complete);assertTrue(c.missing(5).isEmpty())
    }
    @Test fun unknownTotalRequiresEmptyTerminalNotJustShortPage() {
        val c=checkpoint();c.put(1,page(1,2));c.put(2,page(3));assertFalse(c.snapshot().complete)
        c.put(3,page());assertTrue(c.snapshot().complete)
    }
    @Test fun unknownTotalIgnoresSpeculativePagesBeyondTerminal() {
        val c=checkpoint();c.put(1,page(1,2));c.put(3,page(9,10));c.put(2,page())
        assertEquals(listOf(1,2),c.snapshot().items);assertTrue(c.snapshot().complete)
    }
    @Test(expected=IllegalStateException::class) fun repeatedPageCannotBeComplete() {
        val c=checkpoint();c.put(1,page(1,2,total=6));c.put(2,page(1,2,total=6));assertNotNull(c.snapshot().error);c.missing(5)
    }
    @Test(expected=IllegalStateException::class) fun emptyPageBeforeKnownTotalFails() {
        val c=checkpoint();c.put(1,page(1,2,total=6));c.put(2,page(total=6));assertNotNull(c.snapshot().error);c.missing(5)
    }
    @Test fun noArtificialPageCapAndNoLastBatchLoss() {
        val c=checkpoint()
        for(n in 1..2001)c.put(n,page(n*2-1,n*2,total=4002))
        val snap=c.snapshot();assertTrue(snap.complete);assertEquals(4002,snap.items.size)
        assertNull(snap.error);assertEquals(4002,snap.items.last())
    }
    @Test fun missingBudgetIsBoundedEvenForBadCaller() {
        val c=checkpoint();c.put(1,page(1,2,total=40));assertEquals(5,c.missing(99).size)
    }
    @Test fun completeEmptyCategory() {val c=checkpoint();c.put(1,page());assertTrue(c.snapshot().complete)}
    @Test fun metadataFreeProviderUsesActualFirstPageWidth() {
        val c=checkpoint();c.put(1,OrderedPageCheckpoint.Page(listOf(1,2,3),3,4));c.put(2,OrderedPageCheckpoint.Page(listOf(4),1,4))
        assertTrue(c.snapshot().complete)
    }
    @Test fun unknownTotalCanPassOldCapsUntilExplicitEmptyPage() {
        val c=checkpoint()
        for(n in 1..181)c.put(n,page(n*2-1,n*2))
        assertFalse(c.snapshot().complete);assertEquals((182..186).toList(),c.missing(5))
        c.put(182,page());assertTrue(c.snapshot().complete);assertEquals(362,c.snapshot().items.size)
    }
    @Test fun totalPageCountWithoutItemTotalIsHonoured() {
        val c=checkpoint()
        c.put(1,OrderedPageCheckpoint.Page(listOf(1),1,totalPages=202))
        assertEquals((2..6).toList(),c.missing(5))
        for(n in 2..202)c.put(n,OrderedPageCheckpoint.Page(listOf(n),1,totalPages=202))
        assertTrue(c.snapshot().complete);assertEquals(202,c.snapshot().items.size)
    }
    @Test fun inconsistentMetadataPreservesLatestContiguousPrefix() {
        val c=checkpoint()
        c.put(1,OrderedPageCheckpoint.Page(listOf(1),1,20,14))
        c.put(2,OrderedPageCheckpoint.Page(listOf(2),1,20,14))
        val snap=c.snapshot();assertFalse(snap.complete);assertNotNull(snap.error)
        assertEquals(listOf(1,2),snap.items)
    }
    @Test fun hugeAdvertisedTotalDoesNotAllocateOrLaunchAllPages() {
        val c=checkpoint();c.put(1,page(1,2,total=Int.MAX_VALUE))
        assertEquals((2..6).toList(),c.missing(5));assertEquals(listOf(1,2),c.snapshot().items)
    }
    @Test fun changedTotalIsExplicitFailureRatherThanSilentSuccess() {
        val c=checkpoint();c.put(1,page(1,2,total=6));c.put(2,page(3,4,total=8))
        assertFalse(c.snapshot().complete);assertNotNull(c.snapshot().error)
    }
    @Test fun knownTotalMissingUniqueItemsKeepsLastBatchVisible() {
        val c=checkpoint();c.put(1,page(1,2,total=4));c.put(2,page(2,3,total=4))
        val snap=c.snapshot();assertEquals(listOf(1,2,3),snap.items);assertFalse(snap.complete);assertNotNull(snap.error)
    }

}

class BrowsePlaybackGateTest {
    private var time=0L
    private fun gate()=BrowsePlaybackGate {time}
    @Test fun browseFiveHiddenZero() {val g=gate();assertEquals(0,g.budget());g.browsing();assertEquals(5,g.budget());g.hidden();assertEquals(0,g.budget())}
    @Test fun stableProgressAdmitsOnlyOneAfterEightSeconds() {
        val g=gate();g.playback();g.observe(0,true)
        for(i in 1..8) {time=i*1000L;g.observe(i*1000L,true);assertEquals(0,g.budget())}
        time=9000;g.observe(9000,true);assertEquals(1,g.budget())
    }
    @Test fun bufferingImmediatelySuspendsAndResetsStability() {
        val g=gate();g.playback();for(i in 0..10){time=i*1000L;g.observe(time,true)}
        assertEquals(1,g.budget());g.observe(time,false);assertEquals(0,g.budget())
        time+=1000;g.observe(time,true);assertEquals(0,g.budget())
    }
    @Test fun staleObservationNeverKeepsAdmissionOpen() {
        val g=gate();g.playback();for(i in 0..10){time=i*1000L;g.observe(time,true)}
        time+=3000;assertEquals(0,g.budget())
    }
    @Test fun frozenPositionDoesNotAdmitBrowse() {
        val g=gate();g.playback();for(i in 0..20){time=i*1000L;g.observe(0,true)};assertEquals(0,g.budget())
    }
    @Test fun newChannelResetsEvenPreviouslyHealthyPlayback() {
        val g=gate();g.playback();for(i in 0..10){time=i*1000L;g.observe(time,true)}
        assertEquals(1,g.budget());g.playback();assertEquals(0,g.budget())
    }
}
