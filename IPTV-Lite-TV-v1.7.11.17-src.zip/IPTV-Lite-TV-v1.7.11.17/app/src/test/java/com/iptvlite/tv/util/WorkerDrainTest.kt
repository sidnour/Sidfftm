package com.iptvlite.tv.util

import org.junit.Test
import org.junit.Assert.*
import java.util.concurrent.*

class WorkerDrainTest {
    @Test fun stopFlagIsNotFinalizationAcknowledgment() {
        val drain=WorkerDrain();val worker=Thread()
        drain.register(worker,"rec")
        assertTrue(drain.hasKind("rec"));assertFalse(drain.await(20))
        drain.complete(Thread())
        assertFalse(drain.await(0))
        drain.complete(worker)
        assertFalse(drain.hasKind("rec"));assertTrue(drain.await(0))
    }
    @Test fun awaitIsWokenAfterFileFinalization() {
        val drain=WorkerDrain();val worker=Thread();drain.register(worker,"download")
        val pool=Executors.newSingleThreadExecutor()
        try {
            val result=pool.submit<Boolean> {drain.await(2000)}
            drain.complete(worker)
            assertTrue(result.get(2,TimeUnit.SECONDS))
        } finally {pool.shutdownNow()}
    }
    @Test fun oldCompletionCannotAcknowledgeNewWorker() {
        val drain=WorkerDrain();val old=Thread();val fresh=Thread()
        drain.register(old,"rec");drain.complete(old);drain.register(fresh,"rec")
        drain.complete(old);assertFalse(drain.await(0));drain.complete(fresh);assertTrue(drain.await(0))
    }
    @Test fun generationRejectsAtoBtoAStaleResults() {
        val generation=RequestGeneration();val first=generation.current()
        generation.next();generation.next()
        assertFalse(generation.accepts(first));assertTrue(generation.accepts(generation.current()))
    }
}
