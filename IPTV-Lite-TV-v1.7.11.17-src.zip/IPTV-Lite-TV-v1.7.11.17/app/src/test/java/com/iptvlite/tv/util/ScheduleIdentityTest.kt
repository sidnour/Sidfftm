package com.iptvlite.tv.util

import org.junit.Test
import org.junit.Assert.*

class ScheduleIdentityTest {
    @Test fun hashCollisionsDoNotSharePendingIntentData() {
        assertEquals("Aa".hashCode(),"BB".hashCode())
        assertNotEquals(ScheduleIdentity.data("record","Aa"),ScheduleIdentity.data("record","BB"))
    }
    @Test fun actionsAndFullIdsAreSeparatedAndDeterministic() {
        assertNotEquals(ScheduleIdentity.data("record","id"),ScheduleIdentity.data("reminder","id"))
        assertEquals(ScheduleIdentity.data("record","id"),ScheduleIdentity.data("record","id"))
    }
    @Test fun specialIdsCannotChangeUriStructure() {
        val id="عربي /?#%+"
        val uri=java.net.URI(ScheduleIdentity.data("record",id))
        assertNull(uri.rawQuery);assertNull(uri.rawFragment)
        assertEquals(id,java.net.URLDecoder.decode(uri.rawPath.substringAfterLast('/'),"UTF-8"))
    }
}
