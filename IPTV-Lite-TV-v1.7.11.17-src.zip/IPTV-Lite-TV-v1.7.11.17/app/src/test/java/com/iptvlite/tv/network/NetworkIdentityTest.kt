package com.iptvlite.tv.network

import com.iptvlite.tv.model.*
import org.junit.Assert.*
import org.junit.Test

class NetworkIdentityTest {
    private val a=AccountProfile("A","Fixture",ProviderType.XTREAM,"https://fixture.invalid/Portal",username="User",password="fixture-password")
    @Test fun cacheSeparatesAccountPathCaseUsernameCaseAndCredentialRevision() {
        for(other in listOf(a.copy(id="B"),a.copy(url="https://fixture.invalid/portal"),
            a.copy(username="user"),a.copy(password="changed"),a.copy(url="https://fixture.invalid/Portal?Key=VALUE")))
            assertNotEquals(a.networkCacheKey(),other.networkCacheKey())
    }
    @Test fun displayStatusRefreshDoesNotChangeTransportIdentityButCredentialChangesDo() {
        val refreshed=a.copy(expiry="2030-01-01",status="Online",pingMs=42)
        assertNotEquals(a,refreshed) // data-class equality includes presentation fields.
        assertTrue(a.hasSameNetworkIdentity(refreshed))
        assertTrue(refreshed.hasSameNetworkIdentity(a))
        assertFalse(a.hasSameNetworkIdentity(a.copy(password="changed")))
        assertFalse(a.hasSameNetworkIdentity(a.copy(id="B")))
        assertFalse(a.hasSameNetworkIdentity(null))
    }
    @Test fun onlySchemeAndHostCaseAreNormalizedForHttpIdentity() {
        assertEquals(a.networkCacheKey(),a.copy(url="HTTPS://FIXTURE.INVALID/Portal").networkCacheKey())
        assertEquals(a.networkCacheKey(),a.copy(url="https://fixture.invalid:443/Portal").networkCacheKey())
        assertNotEquals(a.copy(url="file:///Storage/Movie.m3u").networkCacheKey(),a.copy(url="file:///storage/movie.m3u").networkCacheKey())
    }
    @Test fun hashedKeysDoNotExposeRawCredentialsOrPermitDelimiterAmbiguity() {
        val key=a.networkCacheKey()
        assertFalse(key.contains(a.username));assertFalse(key.contains(a.password));assertFalse(key.contains("fixture.invalid"))
        assertNotEquals(DataIdentity.digest("a|b","c"),DataIdentity.digest("a","b|c"))
        assertNotEquals(a.copy(url="https://fixture.invalid/?key=VALUE/").networkCacheKey(),
            a.copy(url="https://fixture.invalid/?key=VALUE").networkCacheKey())
    }
    @Test fun itemsSeparateOwnersKindsAndDelimiterLikeIds() {
        val item=StreamItem("1","Fixture",accountId="A")
        assertNotEquals(item.favKey(),item.copy(accountId="B").favKey())
        assertNotEquals(item.favKey(),item.copy(kind=ItemKind.VOD).favKey())
        assertNotEquals(item.copy(accountId="A|LIVE",id="1").favKey(),item.copy(accountId="A",id="LIVE|1").favKey())
        assertEquals("LIVE:1",item.copy(accountId="").favKey()) // Retains explicitly unassigned legacy namespace.
    }
    @Test fun persistentCategoryNamespaceIsRetainedWhenNetworkCredentialsChange() {
        assertEquals(a.cacheKey(),a.copy(password="changed").cacheKey())
        assertNotEquals(a.networkCacheKey(),a.copy(password="changed").networkCacheKey())
    }
}
