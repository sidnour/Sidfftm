package com.iptvlite.tv.store

import com.iptvlite.tv.util.AccountManagement
import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.CountDownLatch

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class StatusEvidenceRegressionTest {
    private lateinit var context:Context
    private lateinit var fast:SharedPreferences
    private lateinit var secret:SharedPreferences
    private lateinit var store:AppStore
    private val a=AccountProfile("A","A",ProviderType.XTREAM,"https://fixture.invalid",username="User",password="fixture+pass")
    private val b=a.copy(id="B",name="B")
    private fun item(owner:String,kind:ItemKind=ItemKind.VOD)=StreamItem("100","Fixture Movie","https://media.fixture.invalid/movie",kind=kind,accountId=owner)
    private fun resetRam() {
        for(name in listOf("cachedAccounts","cachedFavorites","cachedFavIds","cachedRecent","cachedResumeEntries"))
            AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.set(null,null)
        val map=AppStore::class.java.getDeclaredField("resumePosRamCache").apply {isAccessible=true}.get(null) as MutableMap<*,*>
        map.clear()
    }
    @Before fun setup() {
        context=RuntimeEnvironment.getApplication()
        secret=context.getSharedPreferences("isolation_test_secret",Context.MODE_PRIVATE)
        fast=context.getSharedPreferences("isolation_test_fast",Context.MODE_PRIVATE)
        secret.edit().clear().commit();fast.edit().clear().commit()
        // Exercise AppStore with real preferences; encryption/key management is not under test.
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,secret to fast)
        resetRam();store=AppStore(context)
        store.saveAccounts(listOf(a,b));store.setActiveAccountId(a.id)
    }
    @After fun cleanup() {
        resetRam()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    private val now=1_800_000_000_000L
    private fun reject(acc:AccountProfile=a) {
        val token=store.beginAccountProbe(acc,now)!!
        assertTrue(store.finishAccountProbe(acc,token,AccountManagement.Verdict.REJECTED,"","Expired",-1,now))
    }
    // Updating display status must never preserve a conflicting deletion authorization.
    @Test fun legacyStatusUpdateRevokesPriorRejectionEvidence() {
        reject()
        store.updateAccountStatus(a.id,"2030-01-01","نشط ✔",20)
        assertEquals("نشط ✔",store.getAccounts().first {it.id==a.id}.status)
        assertTrue(store.rejectedAccounts(now+1000).isEmpty())
        val result=store.deleteAccountsIfUnchanged(store.rejectedAccounts(now+1000),true,now+1000)
        assertTrue(result.removed.isEmpty())
    }
    @Test fun finishedProbesDoNotRewriteAccountCredentialsList() {
        val accounts=(1..20).map {a.copy(id="audit-$it",url="https://fixture-$it.invalid")}
        store.saveAccounts(accounts)
        val writes=ArrayList<Int>();val delegate=secret
        val counted=object:SharedPreferences by delegate {
            override fun edit():SharedPreferences.Editor {
                val editor=delegate.edit()
                return object:SharedPreferences.Editor by editor {
                    override fun putString(key:String?,value:String?):SharedPreferences.Editor {
                        if(key=="accounts_json")writes.add(JSONArray(value).length())
                        editor.putString(key,value);return this
                    }
                }
            }
        }
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,counted to fast)
        val countedStore=AppStore(context)
        accounts.forEach {acc->
            val token=countedStore.beginAccountProbe(acc,now)!!
            assertTrue(countedStore.finishAccountProbe(acc,token,AccountManagement.Verdict.WORKING,"","Active",20,now))
        }
        assertTrue(writes.isEmpty())
        resetRam();assertTrue(countedStore.getAccounts().all {it.status=="Active"})
    }

    private fun acceptedInfo()=AccountStatusInfo("2030-01-01","1","نشط ✔",20,AccountAccess.ACCEPTED,"2030-01-01")
    @Test fun automaticRefreshNeverCreatesDeletionAuthorizationAndRevokesPreviousProof() {
        reject();val current=store.getAccounts().first {it.id==a.id}
        val token=store.beginAccountStatusRefresh(current,now+1)!!
        assertTrue(store.rejectedAccounts(now+1).isEmpty())
        assertTrue(store.finishAccountStatusRefresh(current,token,acceptedInfo(),now+2))
        assertTrue(store.rejectedAccounts(now+2).isEmpty())
        assertFalse(store.getAccountProbe(a.id)!!.explicit)
    }
    @Test fun statusRefreshReplacesSnapshotButPreservesNetworkIdentity() {
        val before=store.getActiveAccount()!!
        val token=store.beginAccountStatusRefresh(before,now)!!
        assertTrue(store.finishAccountStatusRefresh(before,token,acceptedInfo(),now+1))
        val after=store.getActiveAccount()!!
        assertNotEquals(before,after) // Presentation fields changed, so data-class equality is false.
        assertTrue(before.hasSameNetworkIdentity(after)) // An in-flight category observer must remain attached.
    }
    @Test fun automaticRejectionIsStillNotAnExplicitDeletionAuthorization() {
        val token=store.beginAccountStatusRefresh(a,now)!!
        assertTrue(store.finishAccountStatusRefresh(a,token,acceptedInfo().copy(access=AccountAccess.REJECTED),now+1))
        assertTrue(store.rejectedAccounts(now+1).isEmpty())
    }
    @Test fun olderAutomaticResultCannotOverrideNewerExplicitRejection() {
        val old=store.beginAccountStatusRefresh(a,now)!!
        val fresh=store.beginAccountProbe(a,now+1)!!
        assertTrue(store.finishAccountProbe(a,fresh,AccountManagement.Verdict.REJECTED,"","Expired",-1,now+2))
        assertFalse(store.finishAccountStatusRefresh(a,old,acceptedInfo(),now+3))
        assertEquals(listOf("A"),store.rejectedAccounts(now+3).map {it.id})
    }
    @Test fun olderExplicitRejectionCannotOverrideNewerAutomaticAttempt() {
        val old=store.beginAccountProbe(a,now)!!
        val fresh=store.beginAccountStatusRefresh(a,now+1)!!
        assertTrue(store.finishAccountStatusRefresh(a,fresh,acceptedInfo(),now+2))
        assertFalse(store.finishAccountProbe(a,old,AccountManagement.Verdict.REJECTED,"","Expired",-1,now+3))
        assertTrue(store.rejectedAccounts(now+3).isEmpty())
    }
    @Test fun lateAutomaticResultCannotAffectEditedOrDeletedAccount() {
        val token=store.beginAccountStatusRefresh(a,now)!!
        store.upsertAccount(a.copy(password="different"))
        assertFalse(store.finishAccountStatusRefresh(a,token,acceptedInfo(),now+1))
        store.deleteAccount(a.id)
        assertFalse(store.finishAccountStatusRefresh(a,token,acceptedInfo(),now+2))
        assertEquals(listOf("B"),store.getAccounts().map {it.id})
    }
    @Test fun backupMaterializesLatestOverlayWithoutWritingCredentialsList() {
        val token=store.beginAccountProbe(a,now)!!
        store.finishAccountProbe(a,token,AccountManagement.Verdict.WORKING,"2030-01-01","Active",22,now+1)
        val backup=JSONObject(store.exportFullBackupJson()).getJSONArray("accounts")
        val record=(0 until backup.length()).map {backup.getJSONObject(it)}.first {it.getString("id")==a.id}
        assertEquals("Active",record.getString("status"));assertEquals(22,record.getInt("pingMs"))
        resetRam();assertEquals("Active",store.getAccounts().first {it.id==a.id}.status)
    }
    @Test fun legacyTextDerivedRejectionLedgerDoesNotSurviveSafetyUpgrade() {
        val e=JSONObject().put("fingerprint",a.networkCacheKey()).put("attempt","old")
            .put("verdict","REJECTED").put("checkedAt",now)
        secret.edit().putString("explicit_account_probes_v1",JSONObject().put(a.id,e).toString()).commit()
        assertTrue(store.rejectedAccounts(now+1).isEmpty());assertNull(store.getAccountProbe(a.id))
    }
    private fun failCommits():AppStore {
        val delegate=secret
        val failing=object:SharedPreferences by delegate {
            override fun edit():SharedPreferences.Editor {
                val editor=delegate.edit()
                return object:SharedPreferences.Editor by editor {
                    override fun putString(key:String?,value:String?):SharedPreferences.Editor {editor.putString(key,value);return this}
                    override fun remove(key:String?):SharedPreferences.Editor {editor.remove(key);return this}
                    override fun commit():Boolean {editor.apply();return false}
                }
            }
        }
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,failing to fast)
        return AppStore(context)
    }
    @Test fun failedResultCommitCannotAuthorizeDeletionThroughPreferencesRam() {
        val token=store.beginAccountProbe(a,now)!!;val failing=failCommits()
        assertFalse(failing.finishAccountProbe(a,token,AccountManagement.Verdict.REJECTED,"","Expired",-1,now+1))
        assertTrue(failing.rejectedAccounts(now+1).isEmpty())
    }
    @Test fun failedDeletionCommitRestoresMemorySnapshotAndRecords() {
        reject();val expected=store.getAccounts();val failing=failCommits()
        assertTrue(failing.deleteAccountsIfUnchanged(expected,false,now+1).failed)
        resetRam();assertEquals(setOf("A","B"),failing.getAccounts().map {it.id}.toSet())
        assertNotNull(failing.getAccountProbe(a.id))
    }
    @Test fun failedBeginCommitLeavesNoPendingOrRejectedAuthorization() {
        val failing=failCommits();assertNull(failing.beginAccountProbe(a,now))
        assertNull(failing.getAccountProbe(a.id));assertTrue(failing.rejectedAccounts(now).isEmpty())
    }

}
