package com.iptvlite.tv.util

import com.iptvlite.tv.model.StreamItem
import org.junit.Test
import org.junit.Assert.*
import java.io.File

/** Operation-count baseline from delivered191 adapter; timing is sandbox-only, not a TV benchmark. */
class PerformanceComparisonTest {
    @Test fun reportThirtyThousandRowUpdateWork() {
        val old=(0 until 30_000).map {StreamItem("$it","Row $it",accountId="A")}
        fun current(next:List<StreamItem>)=ListUpdates.planMatching(old,next) {a,b->a.accountId==b.accountId && a.kind==b.kind && a.id==b.id}
        fun legacyReset(next:List<StreamItem>):Int {
            val append=old.size in 1 until next.size && old.first().id==next.first().id &&
                old.first().kind==next.first().kind && old.last().id==next[old.lastIndex].id && old.last().kind==next[old.lastIndex].kind
            return if(append)0 else 1
        }
        val same=old.toList()
        val edited=old.toMutableList().apply {this[15_000]=this[15_000].copy(name="Edited")}
        val pSame=current(same);val pEdited=current(edited)
        assertEquals(1,legacyReset(same));assertFalse(pSame.reset);assertTrue(pSame.changed.isEmpty())
        assertEquals(1,legacyReset(edited));assertEquals(listOf(ListUpdates.Range(15_000,1)),pEdited.changed)
        val samples=ArrayList<Long>()
        repeat(5) {current(same)}
        repeat(25) {val start=System.nanoTime();current(same);samples.add(System.nanoTime()-start)}
        samples.sort()
        val path=System.getProperty("iptv.performance.report") ?: return
        val output=File(path);output.parentFile.mkdirs()
        output.writeText("""{
  "environment": "sandbox JVM, synthetic data; NOT TV/provider/Media3",
  "rows": 30000,
  "unchanged_list": {"v191_full_invalidations": 1, "v192_full_invalidations": 0, "v192_row_change_targets": 0},
  "one_metadata_edit": {"v191_full_invalidations": 1, "v192_full_invalidations": 0, "v192_row_change_targets": 1},
  "category_selection_only": {"v191_full_invalidations": 1, "v192_full_invalidations": 0, "v192_row_change_targets_max": 2},
  "query_plus_letter_scan": {"v191_filter_passes": 2, "v192_filter_passes": 1, "note": "same predicates; avoids intermediate filtered list"},
  "v192_plan_only_p50_ns": ${samples[samples.size/2]},
  "v192_plan_only_p95_ns": ${samples[(samples.size*95/100).coerceAtMost(samples.lastIndex)]},
  "timing_note": "new planner only; not an end-to-end speedup, frame-rate or first-frame measurement"
}""")
    }
}
