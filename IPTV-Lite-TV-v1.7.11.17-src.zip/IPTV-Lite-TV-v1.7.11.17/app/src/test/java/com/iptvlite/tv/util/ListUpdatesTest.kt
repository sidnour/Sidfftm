package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import org.junit.Test
import org.junit.Assert.*
import java.util.concurrent.CancellationException

class ListUpdatesTest {
    private fun rows(n:Int)=(0 until n).map {StreamItem("$it","Row $it",accountId="A")}
    private fun plan(a:List<StreamItem>,b:List<StreamItem>)=ListUpdates.plan(a,b,ListUpdates::key)
    @Test fun unchangedSnapshotProducesNoNotifications() {
        val a=rows(30_000);assertEquals(ListUpdates.Plan(),plan(a,a.toList()))
    }
    @Test fun trueAppendInsertsSuffixOnly() {
        val a=rows(14);val p=plan(a,rows(28))
        assertFalse(p.reset);assertTrue(p.changed.isEmpty());assertEquals(ListUpdates.Range(14,14),p.inserted)
    }
    @Test fun changedInteriorDuringAppendIsNotHiddenByMatchingEndpoints() {
        val a=rows(14);val b=rows(28).toMutableList();b[5]=b[5].copy(name="Changed")
        val p=plan(a,b)
        assertEquals(listOf(ListUpdates.Range(5,1)),p.changed);assertEquals(ListUpdates.Range(14,14),p.inserted)
    }
    @Test fun reorderedInteriorForcesResetEvenWithSameEndpoints() {
        val a=rows(14);val b=rows(28).toMutableList();val tmp=b[4];b[4]=b[5];b[5]=tmp
        assertTrue(plan(a,b).reset)
    }
    @Test fun accountAndKindBelongToIdentity() {
        val a=rows(1).single();val b=a.copy(accountId="B");val c=a.copy(kind=ItemKind.VOD)
        val result=ListUpdates.dedupe(listOf(a,b,c,a),ListUpdates::key)
        assertEquals(3,result.size);assertTrue(plan(listOf(a),listOf(b)).reset)
        assertNotEquals(ListUpdates.streamId(a),ListUpdates.streamId(b))
        assertNotEquals(ListUpdates.streamId(a),ListUpdates.streamId(c))
    }
    @Test fun stableIdIsIndependentOfPositionAndNotDelimiterAmbiguous() {
        val a=StreamItem("bc","",accountId="a");val b=StreamItem("c","",accountId="ab")
        assertNotEquals(ListUpdates.streamId(a),ListUpdates.streamId(b))
        assertEquals(ListUpdates.streamId(a),ListUpdates.streamId(a.copy(name="Renamed")))
    }
    @Test fun suffixRemovalAndChangedRangesArePrecise() {
        val a=rows(10);val b=a.take(6).toMutableList();b[1]=b[1].copy(rating="8");b[2]=b[2].copy(name="N")
        val p=plan(a,b);assertEquals(listOf(ListUpdates.Range(1,2)),p.changed);assertEquals(ListUpdates.Range(6,4),p.removed)
    }
    @Test fun cancellationDuringScanThrowsInsteadOfReturningPartialList() {
        var checks=0
        try {CancellableScan.filter(rows(30_000),{if(++checks==3)throw CancellationException()}) {true};fail("cancel")}
        catch(_:CancellationException){}
        assertEquals(3,checks)
    }
    @Test fun combinedScanMatchesOldTwoPassFilter() {
        val input=rows(5000)
        val expected=input.filter {it.id.toInt()%2==0}.filter {it.name.contains("1")}
        val actual=CancellableScan.filter(input,{}) {it.id.toInt()%2==0 && it.name.contains("1")}
        assertEquals(expected,actual)
    }
    @Test fun negativeCacheExpiresAndIsBounded() {
        var now=0L;val cache=FailureBackoff(2,100) {now}
        cache.failed("a");cache.failed("b");cache.failed("c")
        assertEquals(2,cache.size());assertFalse(cache.blocked("a"));assertTrue(cache.blocked("b"))
        now=100;assertFalse(cache.blocked("b"));cache.clear();assertEquals(0,cache.size())
    }
}
