package com.iptvlite.tv.util

import org.junit.Assert.assertEquals
import org.junit.Test

class TelevisionUiTest {
    @Test fun televisionHasReadableBaseline() {
        assertEquals(1.2f, TelevisionUi.readingScale(1f), 0.001f)
        assertEquals(1.2f, TelevisionUi.readingScale(0.85f), 0.001f)
    }
    @Test fun largerAccessibilitySettingIsPreserved() {
        assertEquals(1.5f, TelevisionUi.readingScale(1.5f), 0.001f)
    }
    @Test fun wrappingTwiceDoesNotCompoundEnlargement() {
        assertEquals(1.2f, TelevisionUi.readingScale(TelevisionUi.readingScale(1f)), 0.001f)
    }
}
