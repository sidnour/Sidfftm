package com.iptvlite.tv.network

import org.junit.Test
import org.junit.Assert.*
import java.util.concurrent.*

class SessionOwnershipTest {
    @Test fun latePreemptionUsesOldSnapshotNotNewHighPriorityOwner() {
        val flight=SessionFlight();val old=PlaybackRequestScope();val fresh=PlaybackRequestScope()
        val snapshot=SessionFlight.Owner(old,false)
        val observed=CountDownLatch(1);val switched=CountDownLatch(1)
        val pool=Executors.newSingleThreadExecutor()
        try {
            val cancel=pool.submit {
                observed.countDown();assertTrue(switched.await(2,TimeUnit.SECONDS))
                flight.preempt(snapshot,true) {it.cancel()}
            }
            assertTrue(observed.await(2,TimeUnit.SECONDS))
            val replacement=SessionFlight.Owner(fresh,true)
            switched.countDown();cancel.get(2,TimeUnit.SECONDS)
            assertFalse(old.isActive());assertTrue(replacement.scope!!.isActive())
        } finally {switched.countDown();pool.shutdownNow()}
    }
    @Test fun highPriorityOwnerIsNeverPreemptedByAnotherWaiter() {
        val flight=SessionFlight();val scope=PlaybackRequestScope()
        flight.preempt(SessionFlight.Owner(scope,true),true) {fail("wrong owner")}
        assertTrue(scope.isActive())
    }
    @Test fun browseWaiterDoesNotPreemptAnotherBrowse() {
        val flight=SessionFlight()
        flight.preempt(SessionFlight.Owner(PlaybackRequestScope(),false),false) {fail("not priority")}
    }
}
