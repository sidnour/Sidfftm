package com.iptvlite.tv.network

import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.mockito.Mockito.*
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class StalkerEndpointHintsTest {
    private lateinit var prefs:SharedPreferences
    private lateinit var hints:StalkerEndpointHints
    private val account=AccountProfile("fixture-id","Fixture",ProviderType.STALKER,"https://fixture.invalid/c/",mac="02:00:00:00:00:01")
    private val route="https://fixture.invalid/server/load.php" to "https://fixture.invalid/c/"
    @Before fun setup() {
        prefs=RuntimeEnvironment.getApplication().getSharedPreferences("hint_contract_fixture",Context.MODE_PRIVATE)
        prefs.edit().clear().commit();hints=StalkerEndpointHints(prefs)
    }
    @Test fun repositoryRecreationPreservesOnlyEndpointRefererAndTimestamp() {
        hints.save(account,route,listOf(route))
        assertEquals(route,StalkerEndpointHints(prefs).load(account,listOf(route)))
        val entry=prefs.all.entries.single()
        assertEquals(64,entry.key.length);assertFalse(entry.key.contains(account.id))
        val json=org.json.JSONObject(entry.value as String)
        assertEquals(setOf("endpoint","referer","saved_at"),json.keys().asSequence().toSet())
        assertFalse(entry.value.toString().contains(account.mac))
    }
    @Test fun accountPortalCaseAndMacChangesCannotReuseHints() {
        hints.save(account,route,listOf(route))
        for(changed in listOf(account.copy(id="other"),account.copy(mac="02:00:00:00:00:02"),account.copy(url="https://fixture.invalid/Other/c/")))
            assertNull(hints.load(changed,listOf(route)))
        assertEquals(route,hints.load(account,listOf(route)))
    }
    @Test fun foreignOrMismatchedRefererIsNeverTrusted() {
        hints.save(account,route,listOf(route))
        assertNull(hints.load(account,listOf(route.first to "https://foreign.invalid/c/")))
        assertTrue(prefs.all.isEmpty())
        hints.save(account,"https://foreign.invalid/api.php" to route.second,listOf(route))
        assertTrue(prefs.all.isEmpty())
    }
    @Test fun urlsWithCredentialsQueryOrFragmentAreNotPersisted() {
        for(url in listOf("https://user:password@fixture.invalid/a.php","https://fixture.invalid/a.php?token=private","https://fixture.invalid/a.php#private")) {
            val unsafe=url to route.second;hints.save(account,unsafe,listOf(unsafe))
        }
        assertTrue(prefs.all.isEmpty())
    }
    @Test fun malformedStorageAndStorageFailureAreNonFatal() {
        hints.save(account,route,listOf(route))
        prefs.edit().putString(prefs.all.keys.single(),"not-json").commit()
        assertNull(hints.load(account,listOf(route)))
        val broken=mock(SharedPreferences::class.java)
        `when`(broken.getString(anyString(),isNull())).thenThrow(IllegalStateException("fixture failure"))
        val unavailable=StalkerEndpointHints(broken)
        assertNull(unavailable.load(account,listOf(route)))
        unavailable.save(account,route,listOf(route));unavailable.forgetIfMatches(account,route)
    }
    @Test fun invalidationDoesNotEraseDifferentReplacementAndUnchangedSuccessDoesNotRewrite() {
        hints.save(account,route,listOf(route))
        val before=prefs.all.toMap();hints.save(account,route,listOf(route));assertEquals(before,prefs.all)
        val newer="https://fixture.invalid/portal.php" to route.second
        hints.save(account,newer,listOf(route,newer))
        hints.forgetIfMatches(account,route)
        assertEquals(newer,hints.load(account,listOf(route,newer)))
        hints.forgetIfMatches(account,newer);assertNull(hints.load(account,listOf(route,newer)))
    }
    @Test fun obsoleteAccountHintsHaveABoundedStorageBudget() {
        for(i in 1..140)hints.save(account.copy(id="fixture-$i"),route,listOf(route))
        assertEquals(StalkerEndpointHints.MAX_ENTRIES,prefs.all.size)
        assertEquals(route,hints.load(account.copy(id="fixture-140"),listOf(route)))
    }
}
