package com.iptvlite.tv.util

import org.junit.Assert.*
import org.junit.Test

class LiveLinkMemoryTest {
    private fun link(url: String = "https://example.invalid/live") = LiveLinkMemory.Link(url,"fixture-UA",mapOf("Cookie" to "fixture-cookie"))
    @Test fun unknownOrUnconfirmedChannelRequiresResolver() {
        assertNull(LiveLinkMemory().nextReuse("A"))
    }
    @Test fun twoCachedOpensThenFreshUntilSustainedPlayback() {
        val memory=LiveLinkMemory();memory.confirm("A",link())
        assertNotNull(memory.nextReuse("A"));assertNotNull(memory.nextReuse("A"));assertNull(memory.nextReuse("A"))
        // One frame alone must not reset failed-attempt budget.
        memory.confirm("A",link());assertNull(memory.nextReuse("A"))
        memory.stable("A");assertNotNull(memory.nextReuse("A"))
    }
    @Test fun cookiesAndAgentArePreservedAndCopied() {
        val headers=mutableMapOf("Cookie" to "old")
        val memory=LiveLinkMemory();memory.confirm("A",LiveLinkMemory.Link("https://example.invalid/a","UA",headers))
        headers["Cookie"]="changed"
        val saved=memory.nextReuse("A")!!
        assertEquals("old",saved.headers["Cookie"]);assertEquals("UA",saved.userAgent)
    }
    @Test fun rejectingOneChannelDoesNotInvalidateAnother() {
        val memory=LiveLinkMemory();memory.confirm("account1/A",link());memory.confirm("account2/A",link("https://example.invalid/b"))
        memory.reject("account1/A");assertNull(memory.nextReuse("account1/A"))
        assertEquals("https://example.invalid/b",memory.nextReuse("account2/A")!!.url)
    }
    @Test fun memoryIsBoundedAndClearDropsCredentials() {
        val memory=LiveLinkMemory(2);memory.confirm("A",link());memory.confirm("B",link());memory.confirm("C",link())
        assertNull(memory.nextReuse("A"));assertNotNull(memory.nextReuse("B"))
        memory.clear();assertNull(memory.nextReuse("B"));assertNull(memory.nextReuse("C"))
    }
    @Test fun blankUrlsNeverBecomeReusable() {
        val memory=LiveLinkMemory();memory.confirm("A",link(""));assertNull(memory.nextReuse("A"))
    }
}
