package com.iptvlite.tv.ui

import android.content.Context
import com.iptvlite.tv.BuildConfig
import com.iptvlite.tv.util.AboutInfo
import com.iptvlite.tv.util.ControlGuide
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config

/**
 * Content guarantees for the two information windows.
 * The dialogs inflate app drawables, so the model they render is asserted here; layout is a device check.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], manifest = Config.NONE, application = android.app.Application::class)
class AboutDialogTest {
    private val ctx: Context get() = RuntimeEnvironment.getApplication()

    @Test fun versionLineMatchesBuildConfigExactly() {
        assertEquals("1.7.11.17", BuildConfig.APP_VERSION_NAME)
        assertEquals("الإصدار 1.7.11.17 · بناء ${BuildConfig.VERSION_CODE}", AboutInfo.versionLine())
        assertEquals(201, BuildConfig.VERSION_CODE)
    }
    @Test fun bothWindowsArePublicEntryPoints() {
        for (name in listOf("showAboutDialog", "showHelpShortcutsDialog")) {
            val method = TvDialogs::class.java.methods.firstOrNull { it.name == name }
            assertNotNull("TvDialogs.$name must exist", method)
            assertEquals(listOf<Class<*>>(Context::class.java), method!!.parameterTypes.toList())
        }
    }
    @Test fun aboutNeverRepeatsTheControlGuide() {
        val aboutText = (listOf(AboutInfo.PRIVACY, AboutInfo.DISCLAIMER, AboutInfo.ACCOUNT_SAFETY) +
            AboutInfo.CAPABILITIES + AboutInfo.STORAGE + AboutInfo.versionLine()).joinToString("\n")
        val guideText = ControlGuide.SECTIONS.joinToString("\n") { it.title + "\n" + it.rows.joinToString("\n") }
        // Buttons/gestures must not be described twice.
        for (phrase in listOf("OK", "CH+", "سحب عمودي", "⏩", "MUTE", "BACK"))
            assertFalse("About must not duplicate control: $phrase", aboutText.contains(phrase, ignoreCase = true))
        // Storage paths are the one intentional shared fact, and only there.
        for (row in AboutInfo.STORAGE) assertTrue(guideText.contains(row))
        assertEquals(AboutInfo.STORAGE.toSet(), ControlGuide.STORAGE.rows.toSet())
    }
    @Test fun controlGuideStaysInputOnlyWithoutReleaseNotes() {
        val text = ControlGuide.SECTIONS.joinToString("\n") { it.title + "\n" + it.rows.joinToString("\n") }
        for (banned in listOf("مزايا", "تحسينات", "الإصدار", "الإصدار", "Neon", "Deep Precision", "v1.7"))
            assertFalse("guide must not carry release copy: $banned", text.contains(banned, ignoreCase = true))
        // Every row must be a single concise line: no paragraphs.
        ControlGuide.SECTIONS.forEach { section ->
            section.rows.forEach { row ->
                assertTrue("row too long (${row.length}): $row", row.length <= 90)
                assertFalse(row.contains("\n"))
            }
        }
    }
    @Test fun aboutRowsStayConciseAndFreeOfMarketing() {
        for (row in AboutInfo.CAPABILITIES + AboutInfo.STORAGE) assertTrue("row too long: $row", row.length <= 70)
        for (paragraph in listOf(AboutInfo.PRIVACY, AboutInfo.DISCLAIMER, AboutInfo.ACCOUNT_SAFETY))
            assertTrue("paragraph too long (${paragraph.length})", paragraph.length <= 200)
        val all = (AboutInfo.CAPABILITIES + AboutInfo.STORAGE + listOf(AboutInfo.PRIVACY, AboutInfo.DISCLAIMER, AboutInfo.ACCOUNT_SAFETY)).joinToString("\n")
        for (banned in listOf("✨", "🎨", "🪶", "مزايا الأساسية", "خفض جذري", "نهائياً"))
            assertFalse("marketing copy leaked: $banned", all.contains(banned))
    }
    @Test fun aboutNeverLeaksAccountsOrEndpoints() {
        val all = (listOf(AboutInfo.PRIVACY, AboutInfo.DISCLAIMER, AboutInfo.ACCOUNT_SAFETY) +
            AboutInfo.CAPABILITIES + AboutInfo.STORAGE + AboutInfo.versionLine()).joinToString("\n")
        for (forbidden in listOf("http://", "https://", "password", "token", "username"))
            assertFalse("About must not embed $forbidden", all.contains(forbidden, ignoreCase = true))
    }
    @Test fun deviceAndPlatformLabelsAreAlwaysNonBlank() {
        assertTrue(AboutInfo.platform(ctx).isNotBlank())
        assertTrue(AboutInfo.deviceLabel().isNotBlank())
        assertTrue(AboutInfo.androidLabel().contains("API"))
    }
}
