package com.iptvlite.tv.util

import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException

class ProbeWorkPoolTest {
    @Test fun fastHostDoesNotWaitBehindSameHostQueue()=runBlocking {
        val unblock=CompletableDeferred<Unit>();val visited=ArrayList<Int>()
        withTimeout(2000) {
            ProbeWorkPool.run((0..19).toList(),2,host={if(it<19)"slow" else "fast"}) {i->
                if(i==0)unblock.await()
                if(i==19)unblock.complete(Unit)
                visited.add(i)
            }
        }
        assertEquals(19,visited.first());assertEquals(20,visited.size)
    }
    @Test fun respectsGlobalAndPerHostLimits()=runBlocking {
        var total=0;var maximum=0;val hosts=HashMap<String,Int>()
        ProbeWorkPool.run((0..99).toList(),50,host={"host-${it%15}"}) {i->
            val host="host-${i%15}";total++;maximum=maxOf(maximum,total)
            hosts[host]=(hosts[host] ?: 0)+1;assertEquals(1,hosts[host])
            delay(2);hosts[host]=hosts[host]!!-1;total--
        }
        assertEquals(10,maximum);assertEquals(0,total)
    }
    @Test fun rotatesReadyHostsFairly()=runBlocking {
        val order=ArrayList<String>()
        ProbeWorkPool.run(listOf("A1","A2","B1","B2","C1","C2"),1,host={it.take(1)}) {order.add(it)}
        assertEquals(listOf("A1","B1","C1","A2","B2","C2"),order)
    }
    @Test fun cancellationDrainsActiveWorkersAndNeverStartsPendingWork()=runBlocking {
        var active=0;var started=0
        try {
            withTimeout(80) {ProbeWorkPool.run((0..99).toList(),host={"$it"}) {
                active++;started++
                try {awaitCancellation()} finally {active--}
            }}
            fail("must time out")
        } catch(_:TimeoutCancellationException) {}
        assertEquals(0,active);assertEquals(10,started)
    }
    @Test fun exceptionCancelsOtherWorkers()=runBlocking {
        var active=0
        try {
            ProbeWorkPool.run((0..29).toList(),host={"$it"}) {i->
                active++
                try {if(i==0)throw IOException("fixture");awaitCancellation()} finally {active--}
            }
            fail("must fail")
        } catch(_:IOException) {}
        assertEquals(0,active)
    }
    @Test fun emptyInputReturnsWithoutWorker()=runBlocking {
        ProbeWorkPool.run(emptyList<Int>(),host={"$it"}) {fail("no work")}
    }
}
