package com.iptvlite.tv.network

import org.junit.Test
import org.junit.Assert.*
import org.mockito.Mockito.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class NetworkCleanupTest {
    @Test fun socketPoolCleanupRunsOffCallerAndShutsOwnedExecutor() {
        val caller=Thread.currentThread()
        val client=mock(okhttp3.OkHttpClient::class.java)
        val dispatcher=okhttp3.Dispatcher()
        val pool=mock(okhttp3.ConnectionPool::class.java)
        val done=CountDownLatch(1)
        `when`(client.dispatcher).thenReturn(dispatcher)
        `when`(client.connectionPool).thenReturn(pool)
        doAnswer {assertNotSame(caller,Thread.currentThread());done.countDown();null}.`when`(pool).evictAll()
        NetworkCleanup.close(client)
        assertTrue(done.await(3,TimeUnit.SECONDS))
        val drained=CountDownLatch(1);NetworkCleanup.execute {drained.countDown()}
        assertTrue(drained.await(3,TimeUnit.SECONDS))
        assertTrue(dispatcher.executorService.isShutdown)
    }
    @Test fun cleanupFailureDoesNotPoisonNextTask() {
        NetworkCleanup.execute {throw java.io.IOException("fixture failure")}
        val done=CountDownLatch(1);NetworkCleanup.execute {done.countDown()}
        assertTrue(done.await(3,TimeUnit.SECONDS))
    }
    @Test fun queuedCancellationCannotCancelANewerChannelRequest() {
        val gate=CountDownLatch(1)
        NetworkCleanup.execute {gate.await(3,TimeUnit.SECONDS)}
        val dispatcher=mock(okhttp3.Dispatcher::class.java)
        val old=mock(okhttp3.Call::class.java);val fresh=mock(okhttp3.Call::class.java)
        val calls=mutableListOf(old)
        `when`(dispatcher.runningCalls()).thenAnswer {calls.toList()}
        `when`(dispatcher.queuedCalls()).thenReturn(emptyList())
        try {
            NetworkCleanup.cancelCurrent(dispatcher)
            calls.add(fresh)
        } finally {gate.countDown()}
        val done=CountDownLatch(1);NetworkCleanup.execute {done.countDown()}
        assertTrue(done.await(3,TimeUnit.SECONDS))
        verify(old).cancel();verify(fresh,never()).cancel()
    }

}
