package com.iptvlite.tv.network

import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.model.ImportSummary
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.mockito.Mockito.*
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URL
import java.net.URLEncoder

/** Real localhost HTTP requests against production server; UI/Android storage are not exercised. */
class WebSetupServerTest {
    private lateinit var store: AppStore
    private lateinit var server: WebSetupServer
    private var base = ""
    @Before fun setup() {
        store = mock(AppStore::class.java)
        `when`(store.exportFullBackupJson()).thenReturn("{\"fixture\":\"PRIVATE_BACKUP\"}")
        val port = ServerSocket(0).use { it.localPort }
        server = WebSetupServer(store, port, "#EXTM3U\n#EXTINF:-1,قناة تجريبية\nhttps://example.invalid/test", "bad\r\nname.m3u") {}
        val actual = server.start().substringAfterLast(':')
        base = "http://127.0.0.1:$actual"
    }
    @After fun close() { server.stop() }
    private fun request(path: String, body: String? = null): Pair<HttpURLConnection, String> {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.connectTimeout = 3000; c.readTimeout = 3000
        if (body != null) {
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val text = (if(c.responseCode >= 400) c.errorStream else c.inputStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        return c to text
    }
    @Test fun backupRequiresCorrectToken() {
        for (token in listOf("", "000000")) {
            val (c,text) = request("/backup.json?token=$token")
            assertEquals(403,c.responseCode); assertFalse(text.contains("PRIVATE_BACKUP")); c.disconnect()
        }
        verify(store,never()).exportFullBackupJson()
    }
    @Test fun authorisedBackupIsDownloadAndNotCached() {
        val (c,text)=request("/backup.json?token=${server.accessToken}")
        assertEquals(200,c.responseCode); assertTrue(text.contains("PRIVATE_BACKUP"))
        assertEquals("no-store",c.getHeaderField("Cache-Control"))
        assertEquals("no-referrer",c.getHeaderField("Referrer-Policy"))
        assertTrue(c.getHeaderField("Content-Disposition").contains("attachment")); c.disconnect()
    }
    @Test fun selectedM3uIsProtectedAndFilenameCannotInjectHeaders() {
        val (denied,_) = request("/selection.m3u")
        assertEquals(403,denied.responseCode); denied.disconnect()
        val (c,text) = request("/selection.m3u?token=${server.accessToken}")
        assertTrue(text.contains("قناة تجريبية")); assertTrue(text.startsWith("#EXTM3U"))
        assertTrue(c.getHeaderField("Content-Disposition").contains("bad__name.m3u"));c.disconnect()
    }
    @Test fun similarlyNamedPathDoesNotExportBackup() {
        val (c,text)=request("/backup.json.attacker?token=${server.accessToken}")
        assertFalse(text.contains("PRIVATE_BACKUP"));c.disconnect()
        verify(store,never()).exportFullBackupJson()
    }
    @Test fun rejectedPostNeverImports() {
        val (c,_) = request("/", "token=000000&bulk=anything")
        c.disconnect();verify(store,never()).importAnyPortalsOrBackup(anyString())
    }
    @Test fun importedNoticesAreHtmlEscaped() {
        `when`(store.importAnyPortalsOrBackup("fixture")).thenReturn(ImportSummary(0,0,"<script>alert(1)</script>"))
        val (c,text) = request("/", "token=${server.accessToken}&bulk="+URLEncoder.encode("fixture","UTF-8"))
        assertFalse(text.contains("<script>alert(1)</script>"));assertTrue(text.contains("&lt;script&gt;alert(1)&lt;/script&gt;"));c.disconnect()
    }
    private fun raw(request:String,finishBody:Boolean=true):String {
        val port=base.substringAfterLast(':').toInt()
        return java.net.Socket("127.0.0.1",port).use { socket ->
            socket.soTimeout=3000
            socket.getOutputStream().write(request.toByteArray(Charsets.UTF_8));socket.getOutputStream().flush()
            if(finishBody)socket.shutdownOutput()
            socket.getInputStream().bufferedReader().readText()
        }
    }
    @Test fun incompleteBodyCannotPartiallyImport() {
        val body="token=${server.accessToken}&bulk=fixture"
        val response=raw("POST / HTTP/1.1\r\nContent-Length: ${body.toByteArray().size+10}\r\n\r\n$body")
        assertTrue(response.startsWith("HTTP/1.1 400"))
        verify(store,never()).importAnyPortalsOrBackup(anyString())
    }
    @Test fun invalidLengthsAndOversizedPayloadAreRejectedBeforeAllocation() {
        for(length in listOf("-1","no-number","999999999999999")) {
            assertTrue(raw("POST / HTTP/1.1\r\nContent-Length: $length\r\n\r\n").startsWith("HTTP/1.1 400"))
        }
        assertTrue(raw("POST / HTTP/1.1\r\nContent-Length: 18000001\r\n\r\n").startsWith("HTTP/1.1 413"))
        verify(store,never()).importAnyPortalsOrBackup(anyString())
    }
    @Test fun duplicateLengthAndChunkedEncodingAreNotMisparsed() {
        assertTrue(raw("POST / HTTP/1.1\r\nContent-Length: 1\r\nContent-Length: 2\r\n\r\nx").startsWith("HTTP/1.1 400"))
        assertTrue(raw("POST / HTTP/1.1\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n").startsWith("HTTP/1.1 400"))
    }
    @Test fun stopClosesAcceptedAndQueuedSocketsAndServerCanRestart() {
        val port=base.substringAfterLast(':').toInt()
        val clients=(1..16).map {java.net.Socket("127.0.0.1",port).apply {soTimeout=3000}}
        // A complete request after these connections forces the accept loop to advance.
        try {
            val rejected=clients.last().getInputStream().read()
            assertEquals(-1,rejected)
            server.stop()
            clients.forEach {socket ->
                try {assertEquals(-1,socket.getInputStream().read())}catch(_:java.net.SocketException){}
            }
            base="http://127.0.0.1:"+server.start().substringAfterLast(':')
            val(c,text)=request("/backup.json?token=${server.accessToken}")
            assertEquals(200,c.responseCode);assertTrue(text.contains("PRIVATE_BACKUP"));c.disconnect()
        } finally {clients.forEach {it.close()}}
    }

}
