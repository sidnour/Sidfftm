package com.iptvlite.tv.util

import org.junit.Assert.*
import org.junit.Test

class LiveRecoveryPolicyTest {
    @Test fun retriesBackOffAndRemainBounded() {
        assertEquals(listOf(2000L,4000L,8000L,15000L,30000L,30000L), (1..6).map { LiveRecoveryPolicy.delayMs(it) })
        assertEquals(30000L, LiveRecoveryPolicy.delayMs(1000))
    }
    @Test fun portalRefreshIsNotRepeatedOnEveryAttempt() {
        assertFalse(LiveRecoveryPolicy.refreshSession(1))
        assertTrue(LiveRecoveryPolicy.refreshSession(2))
        assertFalse(LiveRecoveryPolicy.refreshSession(3))
        assertTrue(LiveRecoveryPolicy.refreshSession(4))
        assertFalse(LiveRecoveryPolicy.refreshSession(5))
        assertTrue(LiveRecoveryPolicy.refreshSession(8))
    }
}
