package com.iptvlite.tv.store

import com.iptvlite.tv.util.AccountManagement
import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.CountDownLatch

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class DuplicateAccountsStoreTest {
    private lateinit var context:Context
    private lateinit var fast:SharedPreferences
    private lateinit var secret:SharedPreferences
    private lateinit var store:AppStore
    private val a=AccountProfile("A","A",ProviderType.XTREAM,"https://fixture.invalid",username="User",password="fixture+pass")
    private val b=a.copy(id="B",name="B")
    private fun item(owner:String,kind:ItemKind=ItemKind.VOD)=StreamItem("100","Fixture Movie","https://media.fixture.invalid/movie",kind=kind,accountId=owner)
    private fun resetRam() {
        for(name in listOf("cachedAccounts","cachedFavorites","cachedFavIds","cachedRecent","cachedResumeEntries"))
            AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.set(null,null)
        val map=AppStore::class.java.getDeclaredField("resumePosRamCache").apply {isAccessible=true}.get(null) as MutableMap<*,*>
        map.clear()
    }
    @Before fun setup() {
        context=RuntimeEnvironment.getApplication()
        secret=context.getSharedPreferences("isolation_test_secret",Context.MODE_PRIVATE)
        fast=context.getSharedPreferences("isolation_test_fast",Context.MODE_PRIVATE)
        secret.edit().clear().commit();fast.edit().clear().commit()
        // Exercise AppStore with real preferences; encryption/key management is not under test.
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,secret to fast)
        resetRam();store=AppStore(context)
        store.saveAccounts(listOf(a,b));store.setActiveAccountId(a.id)
    }
    @After fun cleanup() {
        resetRam()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    @Test fun previewDoesNotWriteAccountsAndNeedsNoProbe() {
        val before=secret.all.toMap();val p=store.duplicateAccountPlan()
        assertEquals(listOf("B"),p.removable.map {it.id});assertEquals(before,secret.all)
    }
    @Test fun retainsActiveAccountAndPersistsOnlyDuplicateRemoval() {
        store.setActiveAccountId("B");val p=store.duplicateAccountPlan()
        assertEquals(setOf("A"),store.deleteDuplicateAccounts(p).removed)
        assertEquals("B",store.getActiveAccountId());resetRam();assertEquals(listOf("B"),store.getAccounts().map {it.id})
    }
    @Test fun favoritesProtectGroupWithoutMigration() {
        store.toggleFavorite(item("B"));assertTrue(store.duplicateAccountPlan().removable.isEmpty())
        assertEquals("B",store.getFavorites().single().accountId)
    }
    @Test fun newFavoriteAfterPreviewBlocksDeletion() {
        val p=store.duplicateAccountPlan();store.toggleFavorite(item("B"))
        assertTrue(store.deleteDuplicateAccounts(p).removed.isEmpty());assertEquals(2,store.getAccounts().size)
    }
    @Test fun recentAndRemindersAndRecordingHistoryProtectGroup() {
        for((key,owner) in listOf("recent_json" to "accountId","reminders_json" to "accId","scheduled_recs_json" to "accId")) {
            fast.edit().putString(key,"[{\"$owner\":\"B\"}]").commit()
            assertTrue(key,store.duplicateAccountPlan().removable.isEmpty())
            fast.edit().remove(key).commit()
        }
    }
    @Test fun standaloneResumeAndCorruptOrUnownedDataFailClosed() {
        fast.edit().putLong("pos_v2_unknown",60000).commit()
        assertTrue(store.duplicateAccountPlan().removable.isEmpty());fast.edit().clear().commit()
        for(raw in listOf("not-json","[{}]")) {
            fast.edit().putString("favorites_json",raw).commit()
            assertTrue(store.duplicateAccountPlan().removable.isEmpty())
        }
    }
    @Test fun busyRecordingBlocksCleanup() {
        val p=store.duplicateAccountPlan();val result=store.deleteDuplicateAccounts(p,isBusy={true})
        assertTrue(result.blocked);assertTrue(result.removed.isEmpty());assertEquals(2,store.getAccounts().size)
    }
    @Test fun changedOrAddedGroupMemberInvalidatesEntireGroup() {
        val p=store.duplicateAccountPlan();store.saveAccounts(listOf(a,b.copy(name="edited")))
        assertTrue(store.deleteDuplicateAccounts(p).removed.isEmpty())
        store.saveAccounts(listOf(a,b,b.copy(id="C")))
        assertTrue(store.deleteDuplicateAccounts(p).removed.isEmpty())
    }
    @Test fun switchingActiveToDeletionCandidateInvalidatesPreview() {
        val p=store.duplicateAccountPlan();store.setActiveAccountId("B")
        assertTrue(store.deleteDuplicateAccounts(p).removed.isEmpty())
    }
    @Test fun protectedGroupDoesNotBlockIndependentCleanGroup() {
        val c=a.copy(id="C",url="https://other.invalid");val d=c.copy(id="D")
        store.saveAccounts(listOf(a,b,c,d));store.toggleFavorite(item("B"))
        assertEquals(setOf("D"),store.deleteDuplicateAccounts(store.duplicateAccountPlan()).removed)
        assertEquals(setOf("A","B","C"),store.getAccounts().map {it.id}.toSet())
    }
    @Test fun knownResumeProtectsOwnerButNotUnrelatedGroup() {
        val c=a.copy(id="C",url="https://other.invalid");val d=c.copy(id="D")
        store.saveAccounts(listOf(a,b,c,d));store.saveResumeEntry(item("B"),60000,600000)
        assertEquals(listOf("D"),store.duplicateAccountPlan().removable.map {it.id})
        assertEquals(setOf("D"),store.deleteDuplicateAccounts(store.duplicateAccountPlan()).removed)
        assertEquals("B",store.getResumeEntries().single().accountId)
    }
    @Test fun missingActiveIdStillPreservesEffectiveFallbackAccount() {
        store.saveAccounts(listOf(b,a));store.setActiveAccountId("missing")
        assertEquals("B",store.getActiveAccount()?.id)
        assertEquals(listOf("A"),store.duplicateAccountPlan().removable.map {it.id})
    }
    @Test fun cleanupCannotResurrectViaLateProbe() {
        val token=store.beginAccountProbe(b)!!
        val p=store.duplicateAccountPlan();assertEquals(setOf("B"),store.deleteDuplicateAccounts(p).removed)
        assertFalse(store.finishAccountProbe(b,token,AccountManagement.Verdict.WORKING,"","Active",30))
    }
}
