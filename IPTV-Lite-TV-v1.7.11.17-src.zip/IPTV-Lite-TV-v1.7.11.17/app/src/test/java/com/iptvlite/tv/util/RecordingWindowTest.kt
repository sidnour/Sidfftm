package com.iptvlite.tv.util

import org.junit.Test
import org.junit.Assert.*

class RecordingWindowTest {
    @Test fun expiredOrExactlyEndedMustNotStart() {
        assertEquals(0,RecordingWindow.remainingSeconds(99,100))
        assertEquals(0,RecordingWindow.remainingSeconds(100,100))
    }
    @Test fun shortRemainingDurationIsNotExtendedToOneMinute() {
        assertEquals(5,RecordingWindow.remainingSeconds(105,100))
    }
    @Test fun farFutureCannotOverflowIntBeforeClamp() {
        assertEquals(21600,RecordingWindow.remainingSeconds(Long.MAX_VALUE,100))
        assertEquals(21600,RecordingWindow.remainingSeconds(Long.MAX_VALUE,Long.MIN_VALUE))
    }
}
