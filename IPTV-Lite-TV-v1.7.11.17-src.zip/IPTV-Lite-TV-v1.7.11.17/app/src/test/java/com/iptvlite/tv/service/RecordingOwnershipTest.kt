package com.iptvlite.tv.service

import android.app.Notification
import android.content.*
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.model.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.*
import org.robolectric.annotation.Config

/** Real service command handling with an injected active owner; no real recording/provider. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class RecordingOwnershipTest {
    private lateinit var ctx:Context
    private lateinit var service:RecordingService
    private lateinit var store:AppStore
    private lateinit var wake:android.os.PowerManager.WakeLock
    private val ownerField=RecordingService::class.java.getDeclaredField("activeRecordingId").apply {isAccessible=true}
    private fun reset() {
        for(n in listOf("cachedScheduledRecs","cachedAccounts"))AppStore::class.java.getDeclaredField(n).apply {isAccessible=true}.set(null,null)
    }
    @Before fun setup() {
        ctx=RuntimeEnvironment.getApplication()
        val s=ctx.getSharedPreferences("rec_service_secret",0);val f=ctx.getSharedPreferences("rec_service_fast",0)
        s.edit().clear().commit();f.edit().clear().commit();reset()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,s to f)
        store=AppStore(ctx)
        service=Robolectric.buildService(RecordingService::class.java).create().get()
        service.startForeground(7740,Notification.Builder(ctx,"test").setContentTitle("Owner").setSmallIcon(android.R.drawable.ic_media_play).build())
        ownerField.set(service,"A")
        wake=(ctx.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager)
            .newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK,"test:owner").apply {acquire(60_000)}
        RecordingService::class.java.getDeclaredField("wakeLock").apply {isAccessible=true}.set(service,wake)
    }
    @After fun cleanup() {
        service.onDestroy();reset();AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    private fun rec(id:String,state:String="pending")=ScheduledRecording(id,"account","42","Channel","http://fixture.invalid","Program",System.currentTimeMillis()/1000+3600,30,state)
    private fun command(id:String)=Intent().putExtra("extra_rec_id",id)
    @Test fun duplicateCommandDoesNotStopForegroundOrMarkOwnerError() {
        store.addScheduledRec(rec("A","recording"))
        service.onStartCommand(command("A"),0,2)
        assertEquals("A",ownerField.get(service));assertEquals("recording",store.getScheduledRecs().single().state)
        assertFalse(Shadows.shadowOf(service).isStoppedBySelf)
        assertFalse(Shadows.shadowOf(service).isForegroundStopped)
        assertTrue(wake.isHeld)
    }
    @Test fun overlapRejectsOnlyIncomingAndKeepsOwnersForeground() {
        store.addScheduledRec(rec("A","recording"));store.addScheduledRec(rec("B"))
        service.onStartCommand(command("B"),0,2)
        assertEquals("recording",store.getScheduledRecs().first {it.id=="A"}.state)
        assertEquals("error",store.getScheduledRecs().first {it.id=="B"}.state)
        assertEquals("A",ownerField.get(service));assertFalse(Shadows.shadowOf(service).isStoppedBySelf)
        assertFalse(Shadows.shadowOf(service).isForegroundStopped)
        assertTrue(wake.isHeld)
    }
    @Test fun invalidIncomingCommandCannotStopExistingOwner() {
        service.onStartCommand(command("missing"),0,3)
        assertEquals("A",ownerField.get(service));assertFalse(Shadows.shadowOf(service).isStoppedBySelf)
    }
    @Test fun missingScheduledAccountFailsWithoutBorrowingActiveAccount() {
        ownerField.set(service,null)
        val other=AccountProfile("OTHER","Other",ProviderType.XTREAM,"http://unrelated.invalid",username="user",password="pass")
        store.saveAccounts(listOf(other));store.setActiveAccountId("OTHER")
        store.addScheduledRec(rec("M").copy(startTs=System.currentTimeMillis()/1000-2))
        service.onStartCommand(command("M"),0,1)
        assertEquals("error",store.getScheduledRecs().single().state)
        assertNull(ownerField.get(service));assertTrue(Shadows.shadowOf(service).isStoppedBySelf)
    }
}
