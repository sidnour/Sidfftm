package com.iptvlite.tv.network

import org.junit.Test
import org.junit.Assert.*
import java.util.concurrent.*

class BrowseLifecycleTest {
    @Test fun localhostPreservesRawPartsAndMediaPort() {
        assertEquals("http://portal.example:9000/a%2Fb?q=a%2Bb#x",PortalLocalhost.rewrite("http://portal.example:8080/c/","http://localhost:9000/a%2Fb?q=a%2Bb#x"))
    }
    @Test fun missingMediaPortInheritsPortalPort() {
        assertEquals("http://portal.example:8080/a",PortalLocalhost.rewrite("https://portal.example:8080/c/","http://127.0.0.1/a"))
    }
    @Test fun noSubstringHostRewrite() {
        val url="http://localhost.evil.example/a?next=http://localhost/"
        assertEquals(url,PortalLocalhost.rewrite("http://portal.example",url))
    }
    @Test fun ipv6LoopbackAndPortalAreWellFormed() {
        assertEquals("http://[2001:db8::1]:80/a",PortalLocalhost.rewrite("http://[2001:db8::1]:80/","http://[::1]/a"))
    }
    @Test fun cancellationIsTerminalForFallbacks() {
        val scope=PlaybackRequestScope()
        scope.run {
            BrowseWork.cancelAll() // An unregistered playback scope must survive.
            scope.checkActive()
        }
        try {
            BrowseWork.run(scope) {BrowseWork.cancelAll();scope.checkActive()}
            fail("browse cancellation must survive fallback boundaries")
        } catch(expected:CancellationException) { }
        try {scope.run {fail("terminal")};fail("must throw")}catch(expected:CancellationException) { }
    }
    @Test fun singleflightSerializesOneAccountButNotDifferentAccounts() {
        val flight=SessionFlight()
        val pool=Executors.newFixedThreadPool(3)
        val entered=CountDownLatch(1);val release=CountDownLatch(1);val second=CountDownLatch(1)
        try {
            val first=pool.submit {flight.run("a",false) {entered.countDown();release.await(3,TimeUnit.SECONDS)}}
            assertTrue(entered.await(2,TimeUnit.SECONDS))
            val next=pool.submit {flight.run("a",false) {second.countDown()}}
            pool.submit {flight.run("b",false) {true}}.get(2,TimeUnit.SECONDS)
            assertFalse(second.await(100,TimeUnit.MILLISECONDS))
            release.countDown();first.get(2,TimeUnit.SECONDS);next.get(2,TimeUnit.SECONDS)
            assertEquals(0L,second.count)
        } finally {release.countDown();pool.shutdownNow()}
    }
}
