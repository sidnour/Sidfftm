package com.iptvlite.tv.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.junit.Test
import org.junit.Assert.*
import java.io.IOException
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class PlaybackRequestScopeTest {
    @Test fun cancelledScopeCannotStartAnotherRequest() {
        val scope = PlaybackRequestScope()
        scope.cancel()
        try { scope.run { fail("cancelled work must not execute") }; fail("must throw") }
        catch (_: java.util.concurrent.CancellationException) { }
    }
    @Test fun cancellingStalledChannelClosesCallButNextChannelWorks() {
        val executor = Executors.newCachedThreadPool()
        val client = OkHttpClient.Builder().readTimeout(60,TimeUnit.SECONDS).build()
        val first = ServerSocket(0)
        val accepted = CountDownLatch(1)
        val release = CountDownLatch(1)
        val old = PlaybackRequestScope()
        try {
            val server = executor.submit { first.accept().use { accepted.countDown(); release.await(8,TimeUnit.SECONDS) } }
            val failed = executor.submit<Boolean> {
                try {
                    old.run { PlaybackRequestScope.execute(client,Request.Builder().url("http://127.0.0.1:${first.localPort}/stalled").build()) { it.body?.string() } }
                    false
                } catch (_: IOException) { true }
            }
            assertTrue(accepted.await(3,TimeUnit.SECONDS))
            old.cancel()
            assertTrue("cancel must close a blocked socket without waiting 60 seconds",failed.get(3,TimeUnit.SECONDS))
            ServerSocket(0).use { next ->
                val successServer = executor.submit {
                    next.accept().use { socket ->
                        val input = socket.getInputStream().bufferedReader()
                        while (!input.readLine().isNullOrEmpty()) { }
                        socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".toByteArray())
                    }
                }
                val fresh = PlaybackRequestScope()
                // A late duplicate cancel of old work must not cancel the new channel's request.
                old.cancel()
                val text = fresh.run { PlaybackRequestScope.execute(client, Request.Builder().url("http://127.0.0.1:${next.localPort}/next").build()) { it.body?.string() } }
                assertEquals("OK",text)
                successServer.get(3,TimeUnit.SECONDS)
                fresh.cancel()
            }
            release.countDown();server.get(3,TimeUnit.SECONDS)
        } finally {
            old.cancel();release.countDown();first.close();executor.shutdownNow()
            client.connectionPool.evictAll();client.dispatcher.executorService.shutdownNow()
        }
    }
}
