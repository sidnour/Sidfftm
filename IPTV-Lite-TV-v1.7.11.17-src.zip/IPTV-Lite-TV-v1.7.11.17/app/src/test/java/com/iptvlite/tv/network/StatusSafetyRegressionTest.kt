package com.iptvlite.tv.network

import com.iptvlite.tv.model.*
import com.iptvlite.tv.util.AccountManagement
import okhttp3.mockwebserver.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.*

/** Regression assertions for defects reproduced against frozen197. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class StatusSafetyRegressionTest {
    private lateinit var server:MockWebServer
    private val io=Executors.newSingleThreadExecutor()
    private fun <T> worker(block:()->T):T=io.submit(Callable {block()}).get(20,TimeUnit.SECONDS)
    private fun account(type:ProviderType)=AccountProfile("audit-fixture","Audit",type,server.url("/").toString(),
        mac="02:00:00:00:00:01",username="fixture",password="fixture")
    private fun resetSessions() {
        PortalClient.clearCaches()
        val f=PortalClient::class.java.getDeclaredField("stalkerSessions").apply {isAccessible=true}
        (f.get(PortalClient) as MutableMap<*,*>).clear()
    }
    private fun info(a:AccountProfile)=worker {PortalClient.fetchAccountStatus(a,forceProbe=true)}
    private fun verdict(a:AccountProfile)=AccountManagement.classify(info(a),System.currentTimeMillis())
    @Before fun setup() {
        resetSessions();PortalClient.initAppContext(RuntimeEnvironment.getApplication())
        server=MockWebServer();server.start()
    }
    @After fun cleanup() {server.shutdown();io.shutdownNow();resetSessions()}
    @Test fun missingXtreamUserInfoIsUncertain() {
        server.enqueue(MockResponse().setBody("{}"))
        assertEquals(AccountManagement.Verdict.UNCERTAIN,verdict(account(ProviderType.XTREAM)))
    }
    @Test fun missingXtreamAuthAndStatusAreUncertain() {
        server.enqueue(MockResponse().setBody("{\"user_info\":{}}"))
        assertEquals(AccountManagement.Verdict.UNCERTAIN,verdict(account(ProviderType.XTREAM)))
    }
    private fun stalkerFixture(profile:String,mainCode:Int=200,profileCode:Int=200) {
        server.dispatcher=object:Dispatcher() {
            override fun dispatch(request:RecordedRequest):MockResponse=when(request.requestUrl!!.queryParameter("action")) {
                "handshake"->MockResponse().setBody("{\"js\":{\"token\":\"audit-token\"}}")
                "get_profile"->MockResponse().setResponseCode(profileCode).setBody(profile)
                "get_main_info"->MockResponse().setResponseCode(mainCode).setBody("{\"js\":{}}")
                else->MockResponse().setResponseCode(500)
            }
        }
    }
    @Test fun handshakeOnlyWithMissingProfileAndFailedAccountInfoIsUncertain() {
        stalkerFixture("{\"js\":{}}",503)
        assertEquals(AccountManagement.Verdict.UNCERTAIN,verdict(account(ProviderType.STALKER)))
    }
    @Test fun contactPhoneDateNeverAuthorizesExpiryRejection() {
        stalkerFixture("{\"js\":{\"phone\":\"Support since 2020-01-01\",\"blocked\":0}}")
        val result=info(account(ProviderType.STALKER))
        assertEquals("",result.verifiedExpiry)
        assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(result,System.currentTimeMillis()))
    }
    @Test fun htmlInsteadOfM3uIsUncertain() {
        server.enqueue(MockResponse().setBody("<html>Maintenance</html>"))
        val result=info(account(ProviderType.M3U))
        assertEquals(AccountAccess.UNKNOWN,result.access)
        assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(result,System.currentTimeMillis()))
    }
    @Test fun forcedM3uRecheckActuallyMakesFreshRequest() {
        server.enqueue(MockResponse().setBody("#EXTM3U\n#EXTINF:-1,Fixture\nhttp://media.invalid/live.ts\n"))
        val a=account(ProviderType.M3U);info(a)
        assertEquals(1,server.requestCount)
        server.enqueue(MockResponse().setResponseCode(503))
        try {info(a);fail("fresh HTTP503 must not return cached success")}
        catch(e:ExecutionException) {assertTrue(e.cause is IllegalStateException)}
        assertEquals(2,server.requestCount)
        // Failed refresh preserves the good browsing snapshot, without hiding the probe error.
        assertTrue(worker {PortalClient.loadCategories(a,ContentTab.LIVE)}.isNotEmpty())
        assertEquals(2,server.requestCount)
    }
    @Test fun cacheClearDoesNotDestroySessionsUsedByPlayback() {
        stalkerFixture("{\"js\":{\"id\":123,\"blocked\":0}}")
        for(i in 1..12)info(account(ProviderType.STALKER).copy(id="audit-$i"))
        val f=PortalClient::class.java.getDeclaredField("stalkerSessions").apply {isAccessible=true}
        val sessions=f.get(PortalClient) as Map<*,*>
        assertEquals(12,sessions.size);PortalClient.clearCaches();assertEquals(12,sessions.size)
    }
    @Test fun activeStalkerAccountIgnoresContactDateForDeletionEvidence() {
        stalkerFixture("""{"js":{"id":7,"status":"1","phone":"Support since 2020-01-01"}}""")
        val result=info(account(ProviderType.STALKER))
        assertEquals("",result.verifiedExpiry)
        assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(result,System.currentTimeMillis()))
    }
    @Test fun realSubscriptionExpiryRemainsRejectionEvidence() {
        stalkerFixture("""{"js":{"id":7,"status":"1","end_date":"2020-01-01"}}""")
        val result=info(account(ProviderType.STALKER))
        assertEquals("2020-01-01",result.verifiedExpiry)
        assertEquals(AccountManagement.Verdict.REJECTED,AccountManagement.classify(result,System.currentTimeMillis()))
    }
    @Test fun failedProfileHttpResponseCannotSupplyAcceptedMetadata() {
        stalkerFixture("""{"js":{"id":7,"status":"1"}}""",profileCode=403)
        assertEquals(AccountManagement.Verdict.UNCERTAIN,verdict(account(ProviderType.STALKER)))
    }
    @Test fun xtreamRequiresAuthEvenWhenStatusSaysActiveOrExpired() {
        for(status in listOf("Active","Expired")) {
            server.enqueue(MockResponse().setBody("""{"user_info":{"status":"$status","exp_date":"1577836800"}}"""))
            val result=info(account(ProviderType.XTREAM))
            assertEquals("",result.verifiedExpiry)
            assertEquals(AccountManagement.Verdict.UNCERTAIN,AccountManagement.classify(result,System.currentTimeMillis()))
        }
    }
    @Test fun verifiedXtreamExpiredStatusAndExpiryStillClassifyCorrectly() {
        server.enqueue(MockResponse().setBody("""{"user_info":{"auth":1,"status":"Active","exp_date":"1577836800"}}"""))
        assertEquals(AccountManagement.Verdict.REJECTED,verdict(account(ProviderType.XTREAM)))
    }
    @Test fun outOfRangeXtreamTimestampCannotOverflowIntoPastExpiryEvidence() {
        server.enqueue(MockResponse().setBody("""{"user_info":{"auth":1,"status":"Active","exp_date":"9223372036854775"}}"""))
        val result=info(account(ProviderType.XTREAM))
        assertEquals("",result.verifiedExpiry)
        assertEquals(AccountManagement.Verdict.WORKING,AccountManagement.classify(result,System.currentTimeMillis()))
    }
    @Test fun emptyExplicitM3uRefreshDoesNotPoisonGoodBrowsingCache() {
        val a=account(ProviderType.M3U)
        server.enqueue(MockResponse().setBody("#EXTM3U\n#EXTINF:-1,Fixture\nhttp://media.invalid/live.ts\n"))
        assertEquals(AccountManagement.Verdict.WORKING,verdict(a))
        server.enqueue(MockResponse().setBody("<html>maintenance</html>"))
        assertEquals(AccountManagement.Verdict.UNCERTAIN,verdict(a))
        assertEquals(1,worker {PortalClient.loadCategoryItems(a,ContentTab.LIVE,"*")}.size)
        assertEquals(2,server.requestCount)
    }
    @Test fun rawUrlPlaylistAndSeriesOnlyPlaylistRemainSupported() {
        val a=account(ProviderType.M3U)
        server.enqueue(MockResponse().setBody("http://media.invalid/live.ts\n"))
        assertEquals(AccountManagement.Verdict.WORKING,verdict(a))
        server.enqueue(MockResponse().setBody("#EXTM3U\n#EXTINF:-1,Fixture S01E01\nhttp://media.invalid/series/episode.mp4\n"))
        val result=info(a)
        assertEquals(AccountAccess.ACCEPTED,result.access);assertTrue(result.status.contains("(1)"))
        assertEquals(2,server.requestCount)
    }
    @Test fun explicitM3uRefreshCanBeCancelledDuringBlockingRead() {
        val a=account(ProviderType.M3U);val owner=PlaybackRequestScope()
        server.enqueue(MockResponse().setBody("#EXTM3U\n#EXTINF:-1,Fixture\nhttp://media.invalid/live.ts\n")
            .throttleBody(1,100,TimeUnit.MILLISECONDS))
        val task=io.submit(Callable {owner.run {PortalClient.fetchAccountStatus(a,true)}})
        assertNotNull(server.takeRequest(2,TimeUnit.SECONDS));owner.cancel()
        try {task.get(2,TimeUnit.SECONDS);fail("cancelled probe cannot succeed")}
        catch(e:ExecutionException) {assertTrue(e.cause is java.io.IOException || e.cause is CancellationException)}
        assertFalse(owner.isActive())
    }

}
