package com.iptvlite.tv.store

import com.iptvlite.tv.util.AccountManagement
import android.content.Context
import android.content.SharedPreferences
import com.iptvlite.tv.model.*
import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Before
import org.junit.After
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.CountDownLatch

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class AccountManagementStoreTest {
    private lateinit var context:Context
    private lateinit var fast:SharedPreferences
    private lateinit var secret:SharedPreferences
    private lateinit var store:AppStore
    private val a=AccountProfile("A","A",ProviderType.XTREAM,"https://fixture.invalid",username="User",password="fixture+pass")
    private val b=a.copy(id="B",name="B")
    private fun item(owner:String,kind:ItemKind=ItemKind.VOD)=StreamItem("100","Fixture Movie","https://media.fixture.invalid/movie",kind=kind,accountId=owner)
    private fun resetRam() {
        for(name in listOf("cachedAccounts","cachedFavorites","cachedFavIds","cachedRecent","cachedResumeEntries"))
            AppStore::class.java.getDeclaredField(name).apply {isAccessible=true}.set(null,null)
        val map=AppStore::class.java.getDeclaredField("resumePosRamCache").apply {isAccessible=true}.get(null) as MutableMap<*,*>
        map.clear()
    }
    @Before fun setup() {
        context=RuntimeEnvironment.getApplication()
        secret=context.getSharedPreferences("isolation_test_secret",Context.MODE_PRIVATE)
        fast=context.getSharedPreferences("isolation_test_fast",Context.MODE_PRIVATE)
        secret.edit().clear().commit();fast.edit().clear().commit()
        // Exercise AppStore with real preferences; encryption/key management is not under test.
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,secret to fast)
        resetRam();store=AppStore(context)
        store.saveAccounts(listOf(a,b));store.setActiveAccountId(a.id)
    }
    @After fun cleanup() {
        resetRam()
        AppStore::class.java.getDeclaredField("sharedStores").apply {isAccessible=true}.set(null,null)
    }
    private val now=1_800_000_000_000L
    private fun reject(acc:AccountProfile=a) {
        val token=store.beginAccountProbe(acc,now)!!
        assertTrue(store.finishAccountProbe(acc,token,AccountManagement.Verdict.REJECTED,"","Expired",-1,now))
    }
    @Test fun legacyImportedFailureDoesNotAuthorizeDeletion() {
        store.saveAccounts(listOf(a.copy(status="Expired",pingMs=-1),b))
        assertTrue(store.rejectedAccounts(now).isEmpty())
        assertTrue(store.deleteAccountsIfUnchanged(store.getAccounts(),true,now).removed.isEmpty())
    }
    @Test fun onlyExplicitRecentRejectionQualifies() {
        reject();assertEquals(listOf("A"),store.rejectedAccounts(now).map {it.id})
        val result=store.deleteAccountsIfUnchanged(store.getAccounts(),true,now)
        assertEquals(setOf("A"),result.removed);assertEquals("B",store.getActiveAccountId())
    }
    @Test fun evidenceExpiresAndClockRollbackIsSafe() {
        reject();assertTrue(store.rejectedAccounts(now+AccountManagement.FRESH_MS+1).isEmpty())
        assertTrue(store.rejectedAccounts(now-1).isEmpty())
    }
    @Test fun editingCredentialsInvalidatesEvidenceAndLateResponse() {
        val token=store.beginAccountProbe(a,now)!!
        store.upsertAccount(a.copy(password="different"))
        assertFalse(store.finishAccountProbe(a,token,AccountManagement.Verdict.REJECTED,"","Expired",-1,now))
        assertTrue(store.rejectedAccounts(now).isEmpty())
    }
    @Test fun newAttemptInvalidatesOldSuccessOrFailure() {
        val old=store.beginAccountProbe(a,now)!!
        val current=store.beginAccountProbe(a,now+1)!!
        assertFalse(store.finishAccountProbe(a,old,AccountManagement.Verdict.REJECTED,"","Expired",-1,now))
        assertTrue(store.finishAccountProbe(a,current,AccountManagement.Verdict.UNCERTAIN,"","timeout",-1,now))
        assertTrue(store.rejectedAccounts(now).isEmpty())
    }
    @Test fun deletedAccountCannotBeResurrectedByProbe() {
        val token=store.beginAccountProbe(a,now)!!
        assertEquals(setOf("A"),store.deleteAccountsIfUnchanged(listOf(a),false,now).removed)
        assertFalse(store.finishAccountProbe(a,token,AccountManagement.Verdict.REJECTED,"","Expired",-1,now))
        assertNull(store.getAccountProbe(a.id));assertEquals(listOf("B"),store.getAccounts().map {it.id})
    }
    @Test fun confirmationDoesNotDeleteNewOrEditedAccounts() {
        val preview=store.getAccounts()
        store.upsertAccount(a.copy(name="renamed"));store.upsertAccount(b.copy(id="C",url="https://other.invalid"))
        val result=store.deleteAccountsIfUnchanged(preview,false,now)
        assertEquals(setOf("B"),result.removed);assertEquals(setOf("A","C"),store.getAccounts().map {it.id}.toSet())
    }
    @Test fun concurrentRecorderGuardBlocksAtCommit() {
        val result=store.deleteAccountsIfUnchanged(store.getAccounts(),false,now,isBusy={true})
        assertTrue(result.blocked);assertEquals(2,store.getAccounts().size)
    }
    @Test fun deletingAllLeavesEmptyStateAndPreservesPersonalOwnership() {
        store.toggleFavorite(item("A"));store.toggleFavorite(item("B"))
        store.addRecent(item("A"))
        val result=store.deleteAccountsIfUnchanged(store.getAccounts(),false,now)
        assertEquals(setOf("A","B"),result.removed);assertNull(store.getActiveAccount())
        assertEquals("",store.getActiveAccountId());assertEquals(setOf("A","B"),store.getFavorites().map {it.accountId}.toSet())
        assertEquals("A",store.getRecent().single().accountId)
    }
    @Test fun automaticBadgeDoesNotAuthorizeBulkDeletion() {
        store.updateAccountStatus(a.id,"","Expired",-1)
        assertTrue(store.rejectedAccounts(now).isEmpty())
    }
    @Test fun pendingRecheckRevokesPreviousEligibility() {
        reject();assertEquals(1,store.rejectedAccounts(now).size)
        store.beginAccountProbe(store.getAccounts().first {it.id==a.id},now+1)
        assertTrue(store.rejectedAccounts(now+1).isEmpty())
    }
    @Test fun approvedDeletionIsPersistedNotJustCached() {
        store.deleteAccountsIfUnchanged(store.getAccounts(),false,now)
        resetRam();assertTrue(AppStore(context).getAccounts().isEmpty())
    }
}
