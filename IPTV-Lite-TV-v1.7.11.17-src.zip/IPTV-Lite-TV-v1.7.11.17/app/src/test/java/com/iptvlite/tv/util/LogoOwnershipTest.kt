package com.iptvlite.tv.util

import android.app.Application
import android.widget.ImageView
import com.iptvlite.tv.network.PlaybackRequestScope
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.TimeUnit

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=Application::class)
class LogoOwnershipTest {
    private val server=MockWebServer()
    private fun task(view:ImageView):Any? {
        val f=LogoLoader::class.java.getDeclaredField("requests").apply {isAccessible=true}
        val lock=LogoLoader::class.java.getDeclaredField("lock").apply {isAccessible=true}.get(null)
        return synchronized(lock) {(f.get(null) as Map<*,*>)[view]}
    }
    private fun scope(task:Any)=task.javaClass.getDeclaredField("scope").apply {isAccessible=true}.get(task) as PlaybackRequestScope
    @After fun cleanup() {LogoLoader.trimMemory(true);LogoLoader.isPlaybackActive=false;server.shutdown()}
    @Test fun recycleCancelsOwnedRunningRequest() {
        server.enqueue(MockResponse().setBody("x".repeat(200)).setBodyDelay(3,TimeUnit.SECONDS))
        val view=ImageView(RuntimeEnvironment.getApplication())
        LogoLoader.load(server.url("/cancel").toString(),view)
        val owner=task(view)!!
        assertNotNull(server.takeRequest(5,TimeUnit.SECONDS))
        LogoLoader.cancel(view)
        assertFalse(scope(owner).isActive());assertNull(task(view));assertNull(view.tag)
    }
    @Test fun playbackPreemptsOrdinaryImagesWithoutCancellingExplicitOsdPermission() {
        repeat(2) {server.enqueue(MockResponse().setBody("x".repeat(200)).setBodyDelay(3,TimeUnit.SECONDS))}
        val view=ImageView(RuntimeEnvironment.getApplication());val osd=ImageView(RuntimeEnvironment.getApplication())
        LogoLoader.load(server.url("/ordinary").toString(),view)
        LogoLoader.load(server.url("/osd").toString(),osd,allowDuringPlayback=true)
        val ordinaryOwner=task(view)!!;val osdOwner=task(osd)!!
        LogoLoader.isPlaybackActive=true
        assertFalse(scope(ordinaryOwner).isActive());assertTrue(scope(osdOwner).isActive());assertNull(task(view))
    }
    @Test fun reboundViewDoesNotRetainOldOwner() {
        server.enqueue(MockResponse().setBody("x".repeat(200)).setBodyDelay(3,TimeUnit.SECONDS))
        val view=ImageView(RuntimeEnvironment.getApplication())
        LogoLoader.load(server.url("/old").toString(),view);val old=task(view)!!
        LogoLoader.load("",view)
        assertFalse(scope(old).isActive());assertNull(task(view));assertEquals("",view.tag)
    }
}
