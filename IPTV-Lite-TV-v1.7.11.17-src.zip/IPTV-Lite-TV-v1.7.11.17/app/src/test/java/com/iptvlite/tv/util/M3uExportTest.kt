package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.CancellationException

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class M3uExportTest {
    private val a=AccountProfile("A","A",ProviderType.STALKER,"http://portal.invalid/c/",mac="02:00:00:00:00:01")
    private val b=a.copy(id="B",mac="02:00:00:00:00:02")
    private fun item(id:String="1",cmd:String="ffmpeg http://localhost/ch/1_",owner:String="A")=StreamItem(id,"Channel $id",cmd=cmd,accountId=owner)
    private fun prepare(items:List<StreamItem>,resolve:(AccountProfile,StreamItem)->String)=M3uExport.prepare(items,listOf(a,b),"B","Group",{}, {_,_->},resolve)
    @Test fun directPublicUrlPreservedWithoutAnyResolverCall() {
        val url="http://media.invalid/play/live.php?stream=42&play_token=example"
        val result=prepare(listOf(item(cmd=url))) {_,_->fail("must not resolve direct URLs");""}
        assertEquals(1,result.exported);assertTrue(result.payload.contains(url));assertEquals(0,result.resolved)
    }
    @Test fun localhostCommandIsResolvedOnlyInExplicitPreparation() {
        val original=item();var calls=0
        val result=prepare(listOf(original)) {acc,ch->calls++;assertEquals("A",acc.id);assertEquals(original,ch);"ffmpeg http://media.invalid/play/live.php?stream=1&amp;play_token=example"}
        assertEquals(1,calls);assertEquals(1,result.resolved);assertTrue(result.payload.contains("&play_token="));assertFalse(result.payload.contains("localhost"))
        assertEquals("ffmpeg http://localhost/ch/1_",original.cmd)
    }
    @Test fun directSerializerNeverExportsInternalCommands() {
        val (count,payload)=M3uExport.direct(listOf(item(),item("2","http://media.invalid/live/2")),"G")
        assertEquals(1,count);assertFalse(payload.contains("localhost"));assertTrue(payload.contains("http://media.invalid/live/2"))
    }
    @Test fun unresolvedOrStillVirtualResponseIsSkipped() {
        for(url in listOf("","http://localhost/ch/1_","http://127.0.0.1/play/live.php")) {
            val r=prepare(listOf(item())) {_,_->url};assertEquals(0,r.exported);assertEquals(1,r.skipped)
        }
    }
    @Test fun explicitMissingOwnerNeverFallsBackToActiveAccount() {
        val r=prepare(listOf(item(owner="deleted"))) {_,_->fail("wrong-account fallback");""}
        assertEquals(1,r.skipped)
    }
    @Test fun blankLegacyOwnerUsesCapturedActiveAccount() {
        val r=prepare(listOf(item(owner=""))) {acc,_->assertEquals("B",acc.id);"http://media.invalid/legacy"}
        assertEquals(1,r.exported)
    }
    @Test fun mixedAccountSameChannelIdsUseEachCorrectOwner() {
        val owners=ArrayList<String>()
        val r=prepare(listOf(item(owner="A"),item(owner="B"))) {acc,_->owners.add(acc.id);"http://media.invalid/${acc.id}/1"}
        assertEquals(listOf("A","B"),owners);assertEquals(2,r.exported)
    }
    @Test fun oneFailedResolutionDoesNotDiscardOtherExports() {
        val r=prepare(listOf(item(),item("2","http://media.invalid/2"))) {_,_->throw java.io.IOException("fixture failure")}
        assertEquals(1,r.exported);assertEquals(1,r.skipped);assertFalse(r.payload.contains("fixture failure"))
    }
    @Test(expected=CancellationException::class) fun cancellationNeverReturnsPartialSuccess() {
        prepare(listOf(item(),item("2"))) {_,_->throw CancellationException()}
    }
    @Test(expected=CancellationException::class) fun cancellationBeforeFirstItemSendsNoRequests() {
        M3uExport.prepare(listOf(item()),listOf(a),"A","G",{throw CancellationException()}, {_,_->}) {_,_->fail("cancelled");""}
    }
    @Test fun seriesAndSeasonFoldersDoNotTriggerCreateLink() {
        val r=prepare(listOf(item().copy(kind=ItemKind.SERIES),item().copy(kind=ItemKind.SEASON))) {_,_->fail("folder is not media");""}
        assertEquals(2,r.skipped)
    }
    @Test fun metadataCannotInjectPlaylistLines() {
        val malicious=item(cmd="http://media.invalid/1").copy(name="Title\n#EXTINF:-1,bad",logo="pic\"\nhttp://injected")
        val r=M3uExport.direct(listOf(malicious),"G\"\r\n#EXTM3U").second
        assertEquals(3,r.lines().filter {it.isNotEmpty()}.size)
        assertEquals(1,r.lines().count {it.startsWith("#EXTINF:")})
    }
    @Test fun nonHttpNetworkProtocolsRemainSupported() {
        for(scheme in listOf("rtsp","rtmp","udp","rtp","mms"))assertEquals("$scheme://media.invalid/live",M3uExport.portableUrl("$scheme://media.invalid/live"))
    }
    @Test fun loopbackFormsAndEmbeddedNewlinesAreRejected() {
        for(host in listOf("localhost","LOCALHOST.","x.localhost","127.2.3.4","[::1]","0.0.0.0"))
            assertEquals("",M3uExport.portableUrl("http://$host/live"))
        assertEquals("",M3uExport.portableUrl("http://media.invalid/live\n#EXTINF:bad"))
    }
    @Test fun externalChPathIsNotAssumedToBeVirtualOrRewritten() {
        val url="http://media.invalid/ch/1_"
        val result=prepare(listOf(item(cmd=url))) {_,_->fail("external path must be preserved");""}
        assertEquals(1,result.exported);assertTrue(result.payload.contains(url))
    }
    @Test fun progressAndCountsMatchSnapshotIncludingFailures() {
        val progress=ArrayList<Int>()
        val r=M3uExport.prepare(listOf(item(),item("2","http://media.invalid/2")),listOf(a),"A","G",{}, {done,total->assertEquals(2,total);progress.add(done)}) {_,_->""}
        assertEquals(listOf(1,2),progress);assertEquals(1,r.exported);assertEquals(1,r.skipped)
    }
}
