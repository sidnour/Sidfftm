package com.iptvlite.tv.ui

import androidx.recyclerview.widget.RecyclerView
import com.iptvlite.tv.model.*
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class AdapterUpdateTest {
    private class Events:RecyclerView.AdapterDataObserver() {
        val events=ArrayList<String>()
        override fun onChanged(){events.add("reset")}
        override fun onItemRangeChanged(start:Int,count:Int){events.add("change:$start:$count")}
        override fun onItemRangeInserted(start:Int,count:Int){events.add("insert:$start:$count")}
        override fun onItemRangeRemoved(start:Int,count:Int){events.add("remove:$start:$count")}
    }
    private fun rows(n:Int)=(0 until n).map {StreamItem("$it","Row $it",accountId="A")}
    private fun adapter()=StreamAdapter({false},{_,_,_->})
    @Test fun equalSubmissionDoesNotInvalidateRecyclerView() {
        val a=adapter();val e=Events();a.registerAdapterDataObserver(e)
        a.submit(rows(1000));e.events.clear();a.submit(rows(1000));assertTrue(e.events.isEmpty())
    }
    @Test fun sameProviderIdFromDifferentAccountsIsNotDropped() {
        val a=adapter();val first=rows(1).single();a.submit(listOf(first,first.copy(accountId="B")))
        assertEquals(2,a.itemCount);assertNotEquals(a.getItemId(0),a.getItemId(1))
    }
    @Test fun interiorChangePlusAppendNotifiesBoth() {
        val a=adapter();a.submit(rows(14));val e=Events();a.registerAdapterDataObserver(e)
        val next=rows(28).toMutableList();next[5]=next[5].copy(name="New")
        a.submit(next);assertEquals(listOf("insert:14:14","change:5:1"),e.events)
    }
    @Test fun categorySelectionOnlyRebindsOldAndNewSelectedRows() {
        val a=CategoryAdapter({_,_->});val input=(0..99).map {CategoryItem("$it","Category $it")}
        a.submit(input,"0");val e=Events();a.registerAdapterDataObserver(e)
        a.submit(input,"1");assertEquals(listOf("change:0:1","change:1:1"),e.events)
    }
    @Test fun reorderingIsDeliberatelyResetInsteadOfUnsafeAppend() {
        val a=adapter();a.submit(rows(14));val e=Events();a.registerAdapterDataObserver(e)
        a.submit(rows(28).toMutableList().apply {val old=this[3];this[3]=this[4];this[4]=old})
        assertEquals(listOf("reset"),e.events)
    }
}
