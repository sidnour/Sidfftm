package com.iptvlite.tv.network

import android.content.Context
import com.iptvlite.tv.model.*
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** Production facade + real loopback HTTP + real Android JSON/JsonReader. Never a provider account. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class PortalContractTest {
    private lateinit var context:Context
    private lateinit var server:MockWebServer
    private lateinit var stalker:AccountProfile
    private lateinit var xtream:AccountProfile
    private val requests=CopyOnWriteArrayList<RecordedRequest>()
    private val executor=Executors.newSingleThreadExecutor()
    private var reply:(RecordedRequest)->MockResponse = { MockResponse().setResponseCode(500) }
    private fun <T> io(block:()->T):T = executor.submit(java.util.concurrent.Callable {block()}).get(20,TimeUnit.SECONDS)
    private fun fixture(name:String):String = javaClass.getResource("/contracts/$name")!!.readText()
        .replace("{{BASE}}",server.url("/").toString().trimEnd('/'))
    private fun json(name:String)=MockResponse().setHeader("Content-Type","application/json").setBody(fixture(name))
    private fun action(r:RecordedRequest)=r.requestUrl!!.queryParameter("action").orEmpty()
    private fun ramReset() {
        PortalClient.clearCaches()
        val f=PortalClient::class.java.getDeclaredField("stalkerSessions").apply {isAccessible=true}
        (f.get(PortalClient) as MutableMap<*,*>).clear()
        PortalClient::class.java.getDeclaredField("endpointHints").apply {isAccessible=true}.set(PortalClient,null)
        PortalClient.initAppContext(context)
    }
    @Before fun setup() {
        context=RuntimeEnvironment.getApplication()
        context.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE).edit().clear().commit()
        ramReset()
        server=MockWebServer()
        server.dispatcher=object:okhttp3.mockwebserver.Dispatcher() {
            override fun dispatch(request:RecordedRequest):MockResponse {requests.add(request);return reply(request)}
        }
        server.start()
        stalker=AccountProfile("stalker-fixture","Fixture",ProviderType.STALKER,server.url("/c/").toString(),mac="02:00:00:00:00:01")
        xtream=AccountProfile("xtream-fixture","Fixture",ProviderType.XTREAM,server.url("/").toString(),username="fixture user",password="fixture+pass")
        reply={r->when(action(r)) {
            "handshake"->json("stalker/handshake.json").setHeader("Set-Cookie","fixture_session=cookie-A; Path=/")
            "get_profile"->json("stalker/profile.json")
            "get_categories","get_genres"->json("stalker/categories.json")
            "get_ordered_list"->json(if(r.requestUrl!!.queryParameter("p")=="1")"stalker/page1.json" else "stalker/page2.json")
            "create_link"->json("stalker/link.json")
            else->MockResponse().setResponseCode(500)
        }}
    }
    @After fun teardown() {
        server.shutdown();executor.shutdownNow()
        context.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE).edit().clear().commit()
        ramReset()
    }
    @Test fun stalkerHandshakeProfileHeadersAndCategoriesContract() {
        val categories=io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals(listOf("7","8"),categories.map {it.id})
        assertEquals(listOf("handshake","get_profile","get_categories"),requests.map(::action))
        val handshake=requests[0];assertNull(handshake.getHeader("Authorization"))
        assertTrue(handshake.getHeader("Cookie")!!.contains("mac=02:00:00:00:00:01"))
        assertEquals("1-xml",handshake.requestUrl!!.queryParameter("JsHttpRequest"))
        val profile=requests[1]
        assertEquals("Bearer fixture-token-A",profile.getHeader("Authorization"))
        assertTrue(profile.getHeader("Cookie")!!.contains("fixture_session=cookie-A"))
        assertEquals("MAG250",profile.requestUrl!!.queryParameter("stb_type"))
        assertEquals(64,profile.requestUrl!!.queryParameter("device_id")!!.length)
        assertEquals(profile.requestUrl!!.queryParameter("device_id"),profile.requestUrl!!.queryParameter("device_id2"))
        assertEquals(server.url("/c/").toString(),profile.getHeader("Referer"))
    }
    @Test fun selectedStalkerCategoryPaginatesAndEmitsFirstPage() {
        val snapshots=mutableListOf<List<StreamItem>>()
        val items=io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7") {snapshots.add(it)}}
        assertEquals((101..115).map {it.toString()},items.map {it.id})
        val pages=requests.filter {action(it)=="get_ordered_list"}
        assertEquals(listOf("1","2"),pages.map {it.requestUrl!!.queryParameter("p")})
        assertTrue(pages.all {it.requestUrl!!.queryParameter("category")=="7" || it.requestUrl!!.queryParameter("category_id")=="7"})
        assertFalse(requests.any {action(it) in listOf("get_all_channels","get_series")})
        assertTrue(snapshots.isNotEmpty());assertEquals(14,snapshots.first().size)
    }
    @Test fun pageRepeatingProviderStopsWithoutUnboundedRequestsOrDuplicateItems() {
        val normal=reply;reply={r->if(action(r)=="get_ordered_list")json("stalker/page1.json") else normal(r)}
        try {io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7")};fail("repeated page with advertised missing items is incomplete")}
        catch(e:java.util.concurrent.ExecutionException) {assertTrue(e.cause is IncompleteListException)}
        assertEquals(2,requests.count {action(it)=="get_ordered_list"})
    }
    @Test fun failedSecondPageIsNotCachedAsCompleteAndRetryFetchesAgain() {
        val normal=reply
        reply={r->if(action(r)=="get_ordered_list" && r.requestUrl!!.queryParameter("p")=="2")MockResponse().setResponseCode(500)else normal(r)}
        val snapshots=mutableListOf<List<StreamItem>>()
        try {io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7") {snapshots.add(it)}};fail("must report incomplete")}
        catch(e:java.util.concurrent.ExecutionException) {assertNotNull(e.cause)}
        assertEquals(14,snapshots.first().size)
        reply=normal;requests.clear()
        assertEquals(15,io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7")}.size)
        assertEquals(listOf("1","2"),requests.filter {action(it)=="get_ordered_list"}.map {it.requestUrl!!.queryParameter("p")})
    }
    @Test fun advertisedTotalWinsOverShortFirstPage() {
        val normal=reply
        reply={r->if(action(r)=="get_ordered_list") {
            val second=r.requestUrl!!.queryParameter("p")=="2"
            MockResponse().setBody("""{"js":{"total_items":2,"data":[{"id":"${if(second)202 else 201}","name":"Fixture","cmd":"http://media.invalid/a"}]}}""")
        } else normal(r)}
        assertEquals(listOf("201","202"),io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7")}.map {it.id})
        assertEquals(2,requests.count {action(it)=="get_ordered_list"})
    }
    @Test fun sequentialCategoryCallerAlsoUsesProviderCountBeyondOld160Cap() {
        val normal=reply
        reply={r->if(action(r)=="get_ordered_list") {
            val n=r.requestUrl!!.queryParameter("p")!!.toInt()
            MockResponse().setBody("{\"js\":{\"total_items\":175,\"max_page_items\":1,\"data\":[{\"id\":\"$n\",\"name\":\"Item $n\"}]}}")
        } else normal(r)}
        val items=io {PortalClient.loadCategoryItems(stalker,ContentTab.LIVE,"7")}
        assertEquals(175,items.size);assertEquals((1..175).map {it.toString()},items.map {it.id})
        assertEquals(175,requests.count {action(it)=="get_ordered_list"})
    }
    @Test fun unknownTotalShortNonemptyPagesContinueUntilEmpty() {
        val normal=reply
        reply={r->if(action(r)=="get_ordered_list") {
            val n=r.requestUrl!!.queryParameter("p")!!.toInt()
            val data=if(n<=3)"{\"id\":\"$n\",\"name\":\"Item $n\"}" else ""
            MockResponse().setBody("{\"js\":{\"max_page_items\":14,\"data\":[$data]}}")
        } else normal(r)}
        val items=io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7")}
        assertEquals(listOf("1","2","3"),items.map {it.id})
        assertEquals(4,requests.count {action(it)=="get_ordered_list"})
    }
    @Test fun explicitM3uExportResolvesInternalCmdWithoutMutatingIt() {
        val normal=reply
        reply={r->if(action(r)=="create_link")MockResponse().setBody("{\"js\":{\"cmd\":\"ffmpeg http://cdn.example.test/play/live.php?stream=42&amp;play_token=fixture\"}}") else normal(r)}
        val item=StreamItem("42","Fixture",cmd="ffmpeg http://localhost/ch/42_",accountId=stalker.id)
        assertEquals("http://cdn.example.test/play/live.php?stream=42&play_token=fixture",io {PortalClient.resolveM3uExportUrl(stalker,item)})
        val create=requests.single {action(it)=="create_link"}
        assertEquals(item.cmd,create.requestUrl!!.queryParameter("cmd"))
        assertEquals("itv",create.requestUrl!!.queryParameter("type"))
        assertEquals("false",create.requestUrl!!.queryParameter("download"))
        assertEquals("ffmpeg http://localhost/ch/42_",item.cmd)
    }
    @Test fun m3uExportPreservesDirectUrlsWithoutHandshakeOrCreateLink() {
        val direct="http://cdn.example.test/play/live.php?stream=42&play_token=fixture"
        assertEquals(direct,io {PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd=direct))})
        assertTrue(requests.isEmpty())
    }
    @Test fun m3uExportNeverGuessesFromUnresolvedVirtualCreateResponse() {
        val normal=reply
        reply={r->if(action(r)=="create_link")MockResponse().setBody("{\"js\":{\"cmd\":\"ffmpeg http://localhost/ch/42_\"}}") else normal(r)}
        assertEquals("",io {PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd="http://localhost/ch/42_"))})
    }
    @Test fun failedM3uCreateDoesNotFallbackToOriginalLocalhostUrl() {
        val normal=reply;reply={r->if(action(r)=="create_link")MockResponse().setResponseCode(500)else normal(r)}
        assertEquals("",io {PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd="http://localhost/ch/42_"))})
    }
    @Test fun exportDoesNotSetPlaybackForceCreateLinkFlag() {
        val normal=reply
        reply={r->if(action(r)=="create_link")MockResponse().setBody("{\"js\":{\"cmd\":\"http://cdn.example.test/play/live.php?stream=42\"}}") else normal(r)}
        io {PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd="http://localhost/ch/42_"))}
        val creates=requests.count {action(it)=="create_link"}
        val direct="http://cdn.example.test/direct/43"
        assertEquals(direct,io {PortalClient.resolveStreamUrl(stalker,StreamItem("43","Fixture",cmd=direct))})
        assertEquals(creates,requests.count {action(it)=="create_link"})
    }
    @Test fun exportDoesNotPreemptUnrelatedBrowseOwner() {
        val owner=PlaybackRequestScope();val entered=java.util.concurrent.CountDownLatch(1);val release=java.util.concurrent.CountDownLatch(1)
        val other=Executors.newSingleThreadExecutor()
        try {
            val f=other.submit {BrowseWork.run(owner) {entered.countDown();release.await(10,TimeUnit.SECONDS)}}
            assertTrue(entered.await(3,TimeUnit.SECONDS))
            io {PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd="http://localhost/ch/42_"))}
            assertTrue(owner.isActive());release.countDown();f.get(3,TimeUnit.SECONDS)
        } finally {release.countDown();other.shutdownNow()}
    }
    @Test fun playbackPreemptionCancelsExportWithoutStartingNextItem() {
        val normal=reply;val entered=java.util.concurrent.CountDownLatch(1)
        reply={r->if(action(r)=="create_link") {
            entered.countDown();MockResponse().setBody("{\"js\":{\"cmd\":\"http://cdn.example.test/live/42\"}}")
                .setBodyDelay(5,TimeUnit.SECONDS)
        }else normal(r)}
        val f=executor.submit(java.util.concurrent.Callable {
            PortalClient.resolveM3uExportUrl(stalker,StreamItem("42","Fixture",cmd="http://localhost/ch/42_"))
        })
        assertTrue(entered.await(5,TimeUnit.SECONDS));PortalClient.preemptBrowse()
        try {f.get(4,TimeUnit.SECONDS);fail("must cancel")}
        catch(e:java.util.concurrent.ExecutionException) {assertTrue(e.cause is java.util.concurrent.CancellationException)}
        assertEquals(1,requests.count {action(it)=="create_link"})
    }
    @Test fun authExpiryRefreshesSessionThenRetriesTheSameApiCall() {
        var handshakes=0;var categories=0
        val normal=reply
        reply={r->when(action(r)) {
            "handshake"->{handshakes++;json("stalker/handshake.json").setBody(fixture("stalker/handshake.json").replace("token-A","token-$handshakes"))}
            "get_categories"->{categories++;if(categories==1)MockResponse().setResponseCode(401)else json("stalker/categories.json")}
            else->normal(r)
        }}
        assertEquals(2,io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.size)
        assertEquals(2,handshakes)
        val calls=requests.filter {action(it)=="get_categories"}
        assertEquals(listOf("Bearer fixture-token-1","Bearer fixture-token-2"),calls.map {it.getHeader("Authorization")})
    }
    @Test fun nothingToPlayRefreshesAndCreatesAFreshMediaLink() {
        var creates=0;val normal=reply
        reply={r->if(action(r)=="create_link") {creates++;json(if(creates==1)"stalker/expired_link.json" else "stalker/link.json")}else normal(r)}
        val item=StreamItem("42","Fixture Live","ffmpeg http://localhost/ch/42",kind=ItemKind.LIVE)
        val url=io {PortalClient.resolveStreamUrl(stalker,item,forceCreateLink=true)}
        assertEquals("https://media.fixture.invalid/media/fixture.ts?play_token=fixture-media-token",url)
        assertEquals(2,creates);assertEquals(2,requests.count {action(it)=="handshake"})
        assertFalse(requests.any {it.requestUrl!!.encodedPath.startsWith("/media/")})
    }
    @Test fun savedEndpointIsTriedFirstAfterRamAndRepositoryRecreationWithNoSavedAuth() {
        val normal=reply
        reply={r->if(r.requestUrl!!.encodedPath=="/server/load.php")MockResponse().setResponseCode(404)else normal(r)}
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals("/portal.php",requests.first {action(it)=="get_profile"}.requestUrl!!.encodedPath)
        val firstProfile=requests.first {action(it)=="get_profile"}.requestUrl!!
        val stored=context.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE).all.toString()
        assertFalse(stored.contains("fixture-token"));assertFalse(stored.contains("cookie-A"));assertFalse(stored.contains(stalker.mac))
        requests.clear();ramReset()
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals("/portal.php",requests.first().requestUrl!!.encodedPath)
        assertEquals("handshake",action(requests.first()));assertNull(requests.first().getHeader("Authorization"))
        val profile=requests.first {action(it)=="get_profile"}.requestUrl!!
        assertEquals(firstProfile.queryParameter("sn"),profile.queryParameter("sn"))
        assertEquals(firstProfile.queryParameter("device_id"),profile.queryParameter("device_id"))
    }
    @Test fun failedSavedPathFallsBackAndReplacementSurvivesTheNextRecreation() {
        val normal=reply
        reply={r->if(r.requestUrl!!.encodedPath=="/server/load.php")MockResponse().setResponseCode(404)else normal(r)}
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        ramReset();requests.clear()
        reply={r->if(r.requestUrl!!.encodedPath=="/portal.php")MockResponse().setResponseCode(404)else normal(r)}
        assertEquals(2,io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.size)
        val attempts=requests.filter {action(it)=="handshake"}.map {it.requestUrl!!.encodedPath}
        assertEquals(listOf("/portal.php","/server/load.php"),attempts)
        ramReset();requests.clear()
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals("/server/load.php",requests.first().requestUrl!!.encodedPath)
    }
    @Test fun malformedHandshakeIsNotRememberedAndDiscoveryContinues() {
        val normal=reply
        reply={r->if(r.requestUrl!!.encodedPath=="/server/load.php")MockResponse().setBody("<html>fixture login page</html>")else normal(r)}
        assertEquals(2,io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.size)
        val stored=context.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE).all.values.joinToString()
        assertTrue(stored.contains("/portal.php"));assertFalse(stored.contains("/server/load.php"))
    }
    private fun xtreamReplies(r:RecordedRequest):MockResponse=when(action(r)) {
        ""->json("xtream/auth.json")
        "get_live_categories","get_vod_categories","get_series_categories"->json("xtream/categories.json")
        "get_vod_streams"->json("xtream/vod.json")
        "get_live_streams"->json("xtream/live.json")
        "get_series"->json("xtream/series.json")
        else->MockResponse().setResponseCode(500)
    }
    @Test fun xtreamAuthUsesEncodedCredentialsAndRejectsDeniedAccount() {
        reply=::xtreamReplies
        assertTrue(io {PortalClient.fetchAccountStatus(xtream)}.status.contains("نشط"))
        val r=requests.single()
        assertEquals("/player_api.php",r.requestUrl!!.encodedPath)
        assertEquals(xtream.username,r.requestUrl!!.queryParameter("username"))
        assertEquals(xtream.password,r.requestUrl!!.queryParameter("password"))
        assertNull(r.getHeader("Authorization"))
        reply={json("xtream/auth_denied.json")}
        try {io {PortalClient.fetchAccountStatus(xtream)};fail("must reject denied auth")}
        catch(e:java.util.concurrent.ExecutionException) {assertTrue(e.cause is IllegalStateException)}
    }
    @Test fun xtreamOnlyLoadsSelectedVodCategoryAndBuildsCorrectExtension() {
        reply=::xtreamReplies
        assertEquals(listOf("7","8"),io {PortalClient.loadCategories(xtream,ContentTab.VOD,true)}.map {it.id})
        val items=io {PortalClient.loadCategoryItems(xtream,ContentTab.VOD,"7")}
        assertEquals(1,items.size);assertEquals("mkv",items.single().containerExt)
        assertTrue(items.single().cmd.endsWith("/101.mkv"))
        assertEquals(listOf("get_vod_categories","get_vod_streams"),requests.map(::action))
        assertEquals("7",requests.last().requestUrl!!.queryParameter("category_id"))
    }
    @Test fun xtreamLiveStreamingJsonReaderAndSeriesKeepCategoryIsolation() {
        reply=::xtreamReplies
        val live=io {PortalClient.loadCategoryItems(xtream,ContentTab.LIVE,"7")}
        assertEquals("201",live.single().id);assertTrue(live.single().tvArchive)
        val series=io {PortalClient.loadCategoryItems(xtream,ContentTab.SERIES,"7")}
        assertEquals("301",series.single().seriesId)
        assertEquals(listOf("get_live_streams","get_series"),requests.map(::action))
        assertTrue(requests.all {it.requestUrl!!.queryParameter("category_id")=="7"})
    }
    @Test fun xtreamResolvingPlaybackDoesNotProbeOrFetchAnotherCategory() {
        reply=::xtreamReplies
        val item=StreamItem("101","Fixture Movie",server.url("/movie/fixture/101.mkv").toString(),kind=ItemKind.VOD)
        assertEquals(item.cmd,io {PortalClient.resolveStreamUrl(xtream,item)})
        assertEquals(0,requests.size)
    }

    // Additional fixtures borrowed from the reviewed archive, but exercised through the
    // real PortalClient facade. No parallel parser or production implementation is copied.
    @Test fun plainRootHandshakeTokenIsUsedByTheRealProfileAndCategoryRequests() {
        val normal=reply
        reply={r->if(action(r)=="handshake")json("variants/stalker_handshake_plain.json") else normal(r)}
        assertEquals(2,io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.size)
        assertEquals(listOf("handshake","get_profile","get_categories"),requests.map(::action))
        assertEquals("Bearer PLAIN_TOKEN_99",requests[1].getHeader("Authorization"))
        assertEquals("Bearer PLAIN_TOKEN_99",requests[2].getHeader("Authorization"))
    }
    private fun assertLinkVariant(name:String,expected:String) {
        val normal=reply
        reply={r->if(action(r)=="create_link")json("variants/$name") else normal(r)}
        val item=StreamItem("120","Fixture","ffmpeg http://localhost/ch/120",kind=ItemKind.LIVE)
        assertEquals(expected,io {PortalClient.resolveStreamUrl(stalker,item,forceCreateLink=true)})
        assertEquals(1,requests.count {action(it)=="handshake"})
        assertEquals(1,requests.count {action(it)=="create_link"})
        val link=requests.single {action(it)=="create_link"}
        assertEquals(item.cmd,link.requestUrl!!.queryParameter("cmd"))
        assertEquals("itv",link.requestUrl!!.queryParameter("type"))
        assertTrue(requests.all {it.requestUrl!!.host==server.hostName})
    }
    @Test fun ffrtCreateLinkUsesProductionResolverWithoutFetchingMedia() {
        assertLinkVariant("stalker_create_link_ffrt.json","http://edge.example.test/s/1.m3u8?t=1")
    }
    @Test fun ffmpegCreateLinkUsesProductionResolverWithoutFetchingMedia() {
        assertLinkVariant("stalker_create_link_ffmpeg.json","http://cdn.example.test/live/ch120.ts?play_token=tok_short")
    }
    @Test fun categoryNameVariantsFilterAllAndIncompleteRowsInProduction() {
        val normal=reply
        reply={r->if(action(r)=="get_categories")json("variants/stalker_genres.json") else normal(r)}
        val rows=io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals(listOf("1","2"),rows.map {it.id})
        assertEquals(listOf("News","Sports"),rows.map {it.title})
        assertEquals(1,requests.count {action(it)=="get_categories"})
    }
    @Test fun categoryDataWrapperAliasAndArrayRowsUseRealStalkerParser() {
        val normal=reply
        reply={r->if(action(r)=="get_categories")MockResponse().setBody(
            """{"js":{"data":[{"category_id":"9","alias":"Alias"},["10","Array title"],{"id":"11"},{"title":"No ID"}]}}"""
        )else normal(r)}
        val rows=io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals(listOf("9","10"),rows.map {it.id})
        assertEquals(listOf("Alias","Array title"),rows.map {it.title})
    }
    @Test fun orderedItemsUseChIdAndTitleFallbackWhileRejectingIncompleteRows() {
        val normal=reply
        reply={r->if(action(r)=="get_ordered_list")MockResponse().setBody(
            """{"js":{"total_items":2,"data":[{"ch_id":"501","title":"Fallback title","cmd":"/media/501"},{"id":"502","o_name":"Original name","cmd":"/media/502"},{"name":"No ID"},{"id":"503"}]}}"""
        )else normal(r)}
        val rows=io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7")}
        assertEquals(listOf("501","502"),rows.map {it.id})
        assertEquals(listOf("Fallback title","Original name"),rows.map {it.name})
        assertEquals(1,requests.count {action(it)=="get_ordered_list"})
    }
    @Test fun incompleteHandshakeBodiesNeverPublishSessionOrPersistAHint() {
        for(body in listOf("","{}","{\"js\":{}}","{\"js\":{\"token\":\"\"}}","<html>invalid</html>")) {
            ramReset();requests.clear()
            reply={MockResponse().setBody(body)}
            // Status has no category-action fallbacks; this isolates one discovery pass.
            try {io {PortalClient.fetchAccountStatus(stalker,true)};fail("handshake must fail for $body")}
            catch(e:java.util.concurrent.ExecutionException) {assertTrue(e.cause is IllegalStateException)}
            assertEquals(5,requests.size)
            assertTrue(requests.all {action(it)=="handshake"})
            assertTrue(context.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE).all.isEmpty())
        }
    }
    @Test fun malformedAndEmptyCategoryBodiesTerminateWithoutCachingBogusRows() {
        val normal=reply
        for(body in listOf("","{}","{\"js\":[]}","<html>not json</html>")) {
            ramReset();requests.clear()
            reply={r->if(action(r) in listOf("get_categories","get_genres"))MockResponse().setBody(body) else normal(r)}
            assertTrue(io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.isEmpty())
            assertEquals(4,requests.count {action(it) in listOf("get_categories","get_genres")})
            assertEquals(1,requests.count {action(it)=="handshake"})
        }
    }
    @Test fun xtreamCategoryFixturesAndAlternativeFieldNamesUseProductionParsing() {
        reply={json("variants/xtream_live_categories.json")}
        assertEquals(listOf("1","2"),io {PortalClient.loadCategories(xtream,ContentTab.VOD,true)}.map {it.id})
        reply={MockResponse().setBody("""[{"id":"9","title":"Title"},{"id":"10","name":"Name"},{"id":"11"},{"name":"No ID"}]""")}
        val rows=io {PortalClient.loadCategories(xtream,ContentTab.VOD,true)}
        assertEquals(listOf("9","10"),rows.map {it.id})
        assertEquals(listOf("Title","Name"),rows.map {it.title})
        assertEquals(listOf("get_vod_categories","get_vod_categories"),requests.map(::action))
    }
    @Test fun xtreamMalformedCategoryResponseDoesNotPoisonTheNextValidLoad() {
        reply={MockResponse().setBody("<html>not json</html>")}
        try {io {PortalClient.loadCategories(xtream,ContentTab.VOD,true)};fail("invalid JSON must fail")}
        catch(e:java.util.concurrent.ExecutionException) {assertTrue(e.cause is org.json.JSONException)}
        reply=::xtreamReplies
        assertEquals(2,io {PortalClient.loadCategories(xtream,ContentTab.VOD)}.size)
        assertEquals(2,requests.size)
    }
    @Test fun repeated401And403HaveOneRenewalPerApiAttemptAndTerminate() {
        val normal=reply
        for(code in listOf(401,403)) {
            ramReset();requests.clear()
            reply={r->if(action(r) in listOf("get_categories","get_genres"))MockResponse().setResponseCode(code)else normal(r)}
            assertTrue(io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}.isEmpty())
            // Four existing category action variants, each with at most one re-auth/retry.
            assertEquals(8,requests.count {action(it) in listOf("get_categories","get_genres")})
            assertEquals(5,requests.count {action(it)=="handshake"})
            assertEquals(5,requests.count {action(it)=="get_profile"})
            assertEquals(18,requests.size)
        }
    }
    private fun rememberSecondaryEndpoint() {
        val normal=reply
        reply={r->if(r.requestUrl!!.encodedPath=="/server/load.php")MockResponse().setResponseCode(404)else normal(r)}
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals("/portal.php",requests.first {action(it)=="get_profile"}.requestUrl!!.encodedPath)
        ramReset();requests.clear();reply=normal
    }
    /** Inject deterministic transport failure into the existing probe client only.
     * No real DNS outage, sleeps, OS networking changes, or production test hooks. */
    private fun assertSavedTransportFailureFallsBack(failure:java.io.IOException) {
        rememberSecondaryEndpoint()
        val client=PortalClient.probeHttp
        val field=okhttp3.OkHttpClient::class.java.getDeclaredField("interceptors").apply {isAccessible=true}
        val original=field.get(client)
        val attempts=CopyOnWriteArrayList<String>()
        val fault=okhttp3.Interceptor {chain->
            val req=chain.request()
            if(req.url.queryParameter("action")=="handshake") {
                attempts.add(req.url.encodedPath)
                if(req.url.encodedPath=="/portal.php")throw failure
            }
            chain.proceed(req)
        }
        field.set(client,client.interceptors + fault)
        try {
            assertTrue(io {PortalClient.fetchAccountStatus(stalker,true)}.status.contains("نشط"))
            assertEquals(listOf("/portal.php","/server/load.php"),attempts.toList())
            assertEquals(1,requests.count {action(it)=="handshake"})
        } finally {field.set(client,original)}
        ramReset();requests.clear()
        io {PortalClient.loadCategories(stalker,ContentTab.VOD,true)}
        assertEquals("/server/load.php",requests.first().requestUrl!!.encodedPath)
    }
    @Test fun savedConnectionRefusalDoesNotAbortDiscovery() {
        assertSavedTransportFailureFallsBack(java.net.ConnectException("synthetic refusal"))
    }
    @Test fun savedFastProbeTimeoutDoesNotAbortDiscovery() {
        assertSavedTransportFailureFallsBack(java.net.SocketTimeoutException("synthetic timeout"))
    }
    @Test fun savedDnsFailureDoesNotAbortDiscovery() {
        assertSavedTransportFailureFallsBack(java.net.UnknownHostException("synthetic DNS failure"))
    }
    @Test fun changingMacDoesNotReusePersistedSecondaryEndpointThroughFacade() {
        rememberSecondaryEndpoint()
        val changed=stalker.copy(mac="02:00:00:00:00:02")
        io {PortalClient.loadCategories(changed,ContentTab.VOD,true)}
        assertEquals("/server/load.php",requests.first().requestUrl!!.encodedPath)
        assertTrue(requests.first().getHeader("Cookie")!!.contains(changed.mac))
        assertFalse(requests.first().getHeader("Cookie")!!.contains(stalker.mac))
    }
    @Test fun changingPortalPathDoesNotReusePersistedSecondaryEndpointThroughFacade() {
        rememberSecondaryEndpoint()
        val changed=stalker.copy(url=server.url("/new/c/").toString())
        io {PortalClient.loadCategories(changed,ContentTab.VOD,true)}
        assertEquals("/new/server/load.php",requests.first().requestUrl!!.encodedPath)
        assertTrue(requests.all {it.requestUrl!!.encodedPath.startsWith("/new/")})
        assertEquals(server.url("/new/c/").toString(),requests[1].getHeader("Referer"))
    }

    @Test fun returnedAndPartialItemsCarryTheirExactAccountOwner() {
        val partial=mutableListOf<List<StreamItem>>()
        val items=io {PortalClient.loadCategoryItems(stalker,ContentTab.VOD,"7") {partial.add(it)}}
        assertTrue(items.isNotEmpty());assertTrue(items.all {it.accountId==stalker.id})
        assertTrue(partial.isNotEmpty());assertTrue(partial.flatten().all {it.accountId==stalker.id})
        reply=::xtreamReplies
        val movies=io {PortalClient.loadCategoryItems(xtream,ContentTab.VOD,"7")}
        assertTrue(movies.all {it.accountId==xtream.id})
    }
    @Test fun changedXtreamPasswordDoesNotReuseOldCachedMovieUrls() {
        reply=::xtreamReplies
        val old=io {PortalClient.loadCategoryItems(xtream,ContentTab.VOD,"7")}.single()
        val changed=xtream.copy(password="fixture-new-password")
        val fresh=io {PortalClient.loadCategoryItems(changed,ContentTab.VOD,"7")}.single()
        assertNotEquals(old.cmd,fresh.cmd)
        assertTrue(fresh.cmd.contains("fixture-new-password"))
        assertEquals(2,requests.count {action(it)=="get_vod_streams"})
        assertEquals(changed.password,requests.last().requestUrl!!.queryParameter("password"))
    }
}
