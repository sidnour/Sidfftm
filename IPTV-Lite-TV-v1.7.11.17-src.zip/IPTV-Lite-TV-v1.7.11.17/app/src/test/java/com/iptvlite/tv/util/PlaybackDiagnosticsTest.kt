package com.iptvlite.tv.util

import org.junit.Assert.*
import org.junit.After
import org.junit.Test

class PlaybackDiagnosticsTest {
    @After fun clean() = PlaybackDiagnostics.configure(false)
    @Test fun disabledNeverRetainsEvents() {
        PlaybackDiagnostics.configure(false)
        PlaybackDiagnostics.record(1, PlaybackDiagnostics.Operation.OPEN, PlaybackDiagnostics.Stage.ERROR, 5, 2004)
        assertFalse(PlaybackDiagnostics.snapshot().contains("2004"))
    }
    @Test fun bufferIsBoundedAndDisablingClearsIt() {
        PlaybackDiagnostics.configure(true)
        for (i in 1..135) PlaybackDiagnostics.record(i.toLong(), PlaybackDiagnostics.Operation.MANUAL_REOPEN, PlaybackDiagnostics.Stage.FIRST_FRAME, i.toLong())
        val text = PlaybackDiagnostics.snapshot()
        assertEquals(120, text.lines().size)
        assertTrue(text.startsWith("#16 "))
        assertTrue(text.contains("#135 "))
        PlaybackDiagnostics.configure(false)
        PlaybackDiagnostics.configure(true)
        assertEquals("", PlaybackDiagnostics.snapshot())
    }
    @Test fun recordsHaveOnlyAllowListedFields() {
        PlaybackDiagnostics.configure(true)
        PlaybackDiagnostics.record(7, PlaybackDiagnostics.Operation.CHANNEL_SWITCH, PlaybackDiagnostics.Stage.ERROR, -10, 2004)
        assertEquals("#7 CHANNEL_SWITCH ERROR 0ms code=2004", PlaybackDiagnostics.snapshot())
    }
}
