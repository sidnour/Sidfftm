package com.iptvlite.tv.util

import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.InputStream

class BoundedInputTest {
    @Test fun exactBoundaryAndEmptyAreAccepted() {
        assertArrayEquals(byteArrayOf(1,2,3),BoundedInput.read(ByteArrayInputStream(byteArrayOf(1,2,3)),3))
        assertEquals(0,BoundedInput.read(ByteArrayInputStream(byteArrayOf()),0).size)
    }
    @Test(expected=BoundedInput.TooLarge::class) fun rejectsOverflow() {
        BoundedInput.read(ByteArrayInputStream(ByteArray(10)),9)
    }
    @Test fun unknownSizeEndlessStreamStopsAtOneSentinelByte() {
        var read=0
        val stream=object:InputStream() {override fun read():Int {read++;return 1}}
        try {BoundedInput.read(stream,17);fail("must reject")}catch(_:BoundedInput.TooLarge){}
        assertEquals(18,read)
    }
    @Test(expected=IllegalArgumentException::class) fun rejectsNegativeLimit() {
        BoundedInput.read(ByteArrayInputStream(byteArrayOf()),-1)
    }
    @Test fun handlesZeroLengthBulkReadWithoutSpinning() {
        val stream=object:InputStream() {
            var count=0
            override fun read():Int=if(count++==0)65 else -1
            override fun read(b:ByteArray,o:Int,l:Int):Int=0
        }
        assertEquals("A",BoundedInput.read(stream,1).toString(Charsets.UTF_8))
    }
    @Test fun preservesInterruptionAndDoesNotRead() {
        Thread.currentThread().interrupt()
        try {
            try {BoundedInput.read(ByteArrayInputStream(byteArrayOf(1)),1);fail("must cancel")}
            catch(_:java.io.InterruptedIOException){assertTrue(Thread.currentThread().isInterrupted)}
        } finally {Thread.interrupted()}
    }
}
