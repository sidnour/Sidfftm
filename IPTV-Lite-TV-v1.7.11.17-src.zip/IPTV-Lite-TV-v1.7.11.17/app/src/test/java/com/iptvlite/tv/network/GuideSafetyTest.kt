package com.iptvlite.tv.network

import com.iptvlite.tv.model.StreamItem
import java.io.*
import java.util.concurrent.*
import java.util.zip.GZIPOutputStream
import java.text.SimpleDateFormat
import java.util.*
import org.junit.*
import org.junit.Assert.*
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import okhttp3.mockwebserver.*

@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],manifest=Config.NONE,application=android.app.Application::class)
class GuideSafetyTest {
    private lateinit var server:MockWebServer
    private val pool=Executors.newSingleThreadExecutor()
    private val ch=StreamItem("42","Fixture",tvgId="fixture")
    @Before fun setup(){XmltvHelper.clearCache();server=MockWebServer();server.start()}
    @After fun cleanup(){XmltvHelper.clearCache();pool.shutdownNow();server.shutdown()}
    private fun xml(desc:String="Description"):String {
        val fmt=SimpleDateFormat("yyyyMMddHHmmss Z",Locale.US).apply {timeZone=TimeZone.getTimeZone("UTC")}
        val now=System.currentTimeMillis()
        return """<tv><channel id="fixture"><display-name>Fixture</display-name></channel><programme channel="fixture" start="${fmt.format(Date(now-60_000))}" stop="${fmt.format(Date(now+3600_000))}"><title>Program</title><desc>$desc</desc></programme></tv>"""
    }
    private fun fetch()=pool.submit<List<com.iptvlite.tv.model.EpgProgram>> {XmltvHelper.getProgramsForChannel(server.url("/guide.xml").toString(),ch)}.get(5,TimeUnit.SECONDS)
    @Test fun normalGuideStillLoadsAndCaches() {
        server.enqueue(MockResponse().setBody(xml()))
        assertEquals("Program",fetch().single().name);assertEquals(1,fetch().size)
        assertEquals(1,server.requestCount)
    }
    @Test fun textIsCappedWhileParsingNotOnlyAtTheEnd() {
        server.enqueue(MockResponse().setBody(xml("x".repeat(20_000))))
        assertEquals(450,fetch().single().descr.length)
    }
    @Test fun oversizedCompressedTokenIsRejectedAndNotCachedAsComplete() {
        val bytes=ByteArrayOutputStream()
        GZIPOutputStream(bytes).use {it.write(xml("x".repeat(300_000)).toByteArray())}
        server.enqueue(MockResponse().setBody(okio.Buffer().write(bytes.toByteArray())))
        assertTrue(fetch().isEmpty())
        server.enqueue(MockResponse().setBody(xml()))
        assertEquals(1,fetch().size);assertEquals(2,server.requestCount)
    }
    @Test fun clearCacheCancelsAnActiveOwnedHttpRequestAndNextRequestCanWork() {
        server.enqueue(MockResponse().setSocketPolicy(SocketPolicy.NO_RESPONSE))
        val pending=pool.submit<List<com.iptvlite.tv.model.EpgProgram>> {XmltvHelper.getProgramsForChannel(server.url("/guide.xml").toString(),ch)}
        assertNotNull(server.takeRequest(2,TimeUnit.SECONDS))
        XmltvHelper.clearCache()
        try {pending.get(3,TimeUnit.SECONDS);fail("must cancel")}
        catch(e:ExecutionException){assertTrue(e.cause is CancellationException)}
        server.enqueue(MockResponse().setBody(xml()))
        assertEquals(1,fetch().size)
    }
    @Test fun guideInputBoundsDecompressedBytesEvenWhenTagsAreSmall() {
        val input=GuideInput(ByteArrayInputStream("<a>x</a>".repeat(100).toByteArray()),{},maxBytes=64,maxSpan=100)
        try {input.readBytes();fail("limit") }catch(_:IOException){}
    }
    @Test fun guideInputChecksCancellationOnEveryChunk() {
        var active=true
        val input=GuideInput(ByteArrayInputStream(ByteArray(100)),{if(!active)throw CancellationException()})
        input.read();active=false
        try {input.read(ByteArray(8));fail("cancel") }catch(_:CancellationException){}
    }
    @Test fun cdataCannotBypassTokenLimitWithEmbeddedLessThanCharacters() {
        val text="<tv><![CDATA["+"<x>".repeat(1000)+"]]></tv>"
        val input=GuideInput(ByteArrayInputStream(text.toByteArray()),{},maxBytes=10_000,maxSpan=200)
        try {input.readBytes();fail("CDATA limit")}catch(_:IOException){}
    }
    @Test fun oversizedGuideIdentifierIsRejectedWithoutCaching() {
        server.enqueue(MockResponse().setBody(xml().replace("channel id=\"fixture\"","channel id=\"${"a".repeat(513)}\"")))
        assertTrue(fetch().isEmpty())
        server.enqueue(MockResponse().setBody(xml()))
        assertEquals(1,fetch().size)
    }
    @Test fun zeroLimitDoesNotOpenNetwork() {
        assertTrue(XmltvHelper.getProgramsForChannel(server.url("/guide.xml").toString(),ch,0).isEmpty())
        assertEquals(0,server.requestCount)
    }
}
