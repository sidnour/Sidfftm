package com.iptvlite.tv.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.CheckBox
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.iptvlite.tv.R
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.CategoryItem
import com.iptvlite.tv.model.ContentTab
import com.iptvlite.tv.model.EpgProgram
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.ProgramReminder
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.ResumeEntry
import com.iptvlite.tv.model.ScheduledRecording
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.network.WebSetupServer
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.ui.TvDialogs.dp
import com.iptvlite.tv.ui.TvDialogs.makeEdit
import com.iptvlite.tv.ui.TvDialogs.makeTvButton
import com.iptvlite.tv.util.LogoLoader
import com.iptvlite.tv.util.MediaTitleFormatter
import com.iptvlite.tv.util.QrCodeHelper
import com.iptvlite.tv.util.StreamRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FeatureDialogs {

    private fun styleNeonDialog(dlg: AlertDialog) {
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun makeTvSearchEdit(ctx: Context, hintText: String): android.widget.EditText {
        return makeEdit(ctx, hintText, "").apply {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                showSoftInputOnFocus = false
            }
            setOnClickListener {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    showSoftInputOnFocus = true
                }
                requestFocus()
                val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                imm?.showSoftInput(this, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    showSoftInputOnFocus = false
                }
            }
        }
    }

    // ==================== 1. نافذة الرمز السري العائلي (PIN) ====================

    fun showPinPromptDialog(
        ctx: Context,
        store: AppStore,
        titleText: String = "🔒 أدخل الرمز السري العائلي (PIN)",
        onUnlocked: () -> Unit
    ) {
        if (!store.hasPin()) {
            onUnlocked()
            return
        }
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
        }
        root.addView(
            TextView(ctx).apply {
                text = titleText
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )
        val etPin = makeEdit(
            ctx,
            "••••",
            "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        )
        etPin.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(ctx, 10); bottomMargin = dp(ctx, 10) }
        root.addView(etPin)

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        styleNeonDialog(dlg)
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val btnOk = makeTvButton(ctx, "🔓 فتح", primary = true) {
            if (store.verifyPin(etPin.text.toString())) {
                dlg.dismiss()
                onUnlocked()
            } else {
                Toast.makeText(ctx, "✖ الرمز السري غير صحيح", Toast.LENGTH_SHORT).show()
                etPin.setText("")
            }
        }
        val btnCancel = makeTvButton(ctx, "إلغاء") { dlg.dismiss() }
        bar.addView(btnOk)
        bar.addView(btnCancel)
        root.addView(bar)
        dlg.show()
        etPin.requestFocus()
    }

    // ==================== 2. دليل البرامج والأرشيف (EPG + Catch-up TV) ====================

    fun showEpgArchiveDialog(
        ctx: Context,
        store: AppStore,
        scope: CoroutineScope,
        acc: AccountProfile,
        ch: StreamItem,
        onPlayLive: (StreamItem) -> Unit,
        onPlayCatchup: (StreamItem, StreamItem) -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
        }

        val arLabel = if (ch.tvArchive) " · ↺ يدعم أرشيف الإعادة (${ch.tvArchiveDays} أيام)" else ""
        root.addView(
            TextView(ctx).apply {
                text = "📋 دليل البرامج والأرشيف — ${ch.name}"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 16.5f
            }
        )
        val tvStatus = TextView(ctx).apply {
            text = "⏳ جارٍ جلب جدول البرامج والأرشيف$arLabel..."
            setTextColor(Color.parseColor("#FBBF24"))
            textSize = 12f
            setPadding(0, dp(ctx, 3), 0, dp(ctx, 8))
        }
        root.addView(tvStatus)

        var currentFilter = "ALL"
        var allPrograms: List<EpgProgram> = emptyList()
        var selectedProg: EpgProgram? = null
        var armedProg: EpgProgram? = null

        val filterScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val filterRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        filterScroll.addView(filterRow)
        root.addView(filterScroll)

        val etSearch = makeTvSearchEdit(ctx, "🔍 ابحث في برامج القناة (اضغط OK للكتابة)...")
        etSearch.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(ctx, 6); bottomMargin = dp(ctx, 6) }
        root.addView(etSearch)

        val listScroll = ScrollView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(ctx, 215)
            )
        }
        val listCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        listScroll.addView(listCol)
        root.addView(listScroll)

        val tvDescr = TextView(ctx).apply {
            text = "اختر برنامجاً من الجدول لعرض قصّته أو تشغيله من الأرشيف أو ضبط تنبيه."
            setTextColor(Color.parseColor("#C6D0E0"))
            textSize = 12f
            maxLines = 3
            setPadding(0, dp(ctx, 8), 0, dp(ctx, 8))
        }
        root.addView(tvDescr)

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        styleNeonDialog(dlg)

        val bottomScroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val bottomRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        bottomScroll.addView(bottomRow)
        root.addView(bottomScroll)

        fun playArchiveProg(p: EpgProgram) {
            tvStatus.setTextColor(Color.parseColor("#FBBF24"))
            tvStatus.text = "⏳ جارٍ تجهيز رابط أرشيف «${p.name}»..."
            scope.launch {
                val url = runCatching {
                    withContext(Dispatchers.IO) { PortalClient.resolveCatchupUrl(acc, ch, p) }
                }.getOrDefault("")
                if (url.isBlank()) {
                    tvStatus.setTextColor(Color.parseColor("#F87171"))
                    tvStatus.text = "✖ السيرفر لا يوفّر تسجيل أرشيف لهذا البرنامج"
                    Toast.makeText(ctx, "لا يتوفّر تسجيل أرشيف لهذا البرنامج على السيرفر", Toast.LENGTH_SHORT).show()
                } else {
                    val catchupItem = StreamItem(
                        id = "cu_${ch.id}_${p.startTs}",
                        name = "↺ ${ch.name} — ${p.name}",
                        cmd = url,
                        categoryId = ch.categoryId,
                        logo = ch.logo,
                        kind = ItemKind.CATCHUP,
                        subtitle = formatProgTimeRange(p)
                    )
                    dlg.dismiss()
                    onPlayCatchup(catchupItem, ch)
                }
            }
        }

        val btnPlayArch = makeTvButton(ctx, "▶ تشغيل من الأرشيف", primary = true) {
            val p = selectedProg
            if (p == null) {
                Toast.makeText(ctx, "اختر برنامجاً أولاً من الجدول", Toast.LENGTH_SHORT).show()
            } else if (p.isNow) {
                dlg.dismiss()
                onPlayLive(ch)
            } else {
                playArchiveProg(p)
            }
        }
        val btnLiveNow = makeTvButton(ctx, "📺 البثّ الحي") {
            dlg.dismiss()
            onPlayLive(ch)
        }
        val btnRemind = makeTvButton(ctx, "🔔 تنبيه") {
            val p = selectedProg
            val nowSec = System.currentTimeMillis() / 1000L
            if (p == null || p.startTs <= nowSec) {
                Toast.makeText(ctx, "اختر برنامجاً قادماً لضبط تنبيه له", Toast.LENGTH_SHORT).show()
            } else {
                store.addReminder(
                    ProgramReminder(
                        id = "${acc.id}_${ch.id}_${p.startTs}",
                        channelId = ch.id,
                        channelName = ch.name,
                        channelCmd = ch.cmd,
                        progName = p.name,
                        startTs = p.startTs,
                        remindAtTs = (p.startTs - 60L).coerceAtLeast(nowSec),
                        accountId = acc.id
                    )
                )
                Toast.makeText(ctx, "🔔 تمّت جدولة إشعار «${p.name}» (يعمل حتى لو أُغلِق التطبيق)", Toast.LENGTH_LONG).show()
            }
        }
        val btnSchedRec = makeTvButton(ctx, "⏰ تسجيل مجدول") {
            val p = selectedProg
            val nowSec = System.currentTimeMillis() / 1000L
            if (p == null || (p.startTs <= nowSec && !p.isNow)) {
                Toast.makeText(ctx, "اختر برنامجاً قادماً أو جارياً لجدولة تسجيله", Toast.LENGTH_SHORT).show()
            } else {
                val startAt = if (p.isNow) nowSec + 2L else p.startTs
                val rawDurMin = if (p.stopTs > startAt) ((p.stopTs - startAt) / 60L).toInt() else 45
                val durMin = rawDurMin.coerceIn(5, 240)
                store.addScheduledRec(
                    ScheduledRecording(
                        id = "rec_${acc.id}_${ch.id}_${p.startTs}",
                        accountId = acc.id,
                        channelId = ch.id,
                        channelName = ch.name,
                        channelCmd = ch.cmd,
                        progName = p.name,
                        startTs = startAt,
                        durationMin = durMin,
                        state = "pending"
                    )
                )
                Toast.makeText(
                    ctx,
                    "⏰ تمّت جدولة تسجيل «${p.name}» (${durMin} دقيقة) — سيعمل في موعده حتى لو كان التطبيق مغلقاً",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        val btnClearRem = makeTvButton(ctx, "🗑 مسح التنبيهات") {
            val remCnt = store.getReminders().size
            val schCnt = store.getScheduledRecs().size
            if (remCnt == 0 && schCnt == 0) {
                Toast.makeText(ctx, "لا توجد تنبيهات أو تسجيلات مجدولة حالياً", Toast.LENGTH_SHORT).show()
            } else {
                store.clearReminders()
                store.clearScheduledRecs()
                Toast.makeText(ctx, "✔ تمّ مسح التنبيهات والتسجيلات المجدولة", Toast.LENGTH_SHORT).show()
            }
        }
        val btnClose = makeTvButton(ctx, "إغلاق") { dlg.dismiss() }

        bottomRow.addView(btnPlayArch)
        bottomRow.addView(btnLiveNow)
        bottomRow.addView(btnRemind)
        bottomRow.addView(btnSchedRec)
        bottomRow.addView(btnClearRem)
        bottomRow.addView(btnClose)

        val dfDay = SimpleDateFormat("yyyy-MM-dd", Locale.US)

        fun updateDescrFor(p: EpgProgram) {
            tvDescr.text = buildString {
                append("📌 ")
                append(p.name)
                if (p.descr.isNotBlank()) {
                    append(" — ")
                    append(p.descr)
                }
                if (p.hasArchive) append("\n(اضغط OK مرّة أخرى أو «▶ تشغيل من الأرشيف» للمشاهدة)")
            }
        }

        fun renderList(focusSelectedRow: Boolean = false) {
            listCol.removeAllViews()
            val q = etSearch.text.toString().trim().lowercase(Locale.ROOT)
            val nowMs = System.currentTimeMillis()
            val todayStr = dfDay.format(Date(nowMs))
            val yestStr = dfDay.format(Date(nowMs - 86_400_000L))

            val filtered = allPrograms.filter { p ->
                val dayOk = when (currentFilter) {
                    "ARCH" -> p.hasArchive
                    "TODAY" -> p.startTs > 0 && dfDay.format(Date(p.startTs * 1000L)) == todayStr
                    "YEST" -> p.startTs > 0 && dfDay.format(Date(p.startTs * 1000L)) == yestStr
                    else -> true
                }
                val qOk = q.isEmpty() || p.name.lowercase(Locale.ROOT).contains(q) || p.descr.lowercase(Locale.ROOT).contains(q)
                dayOk && qOk
            }

            if (filtered.isEmpty()) {
                listCol.addView(
                    TextView(ctx).apply {
                        text = "لا توجد برامج مطابقة في هذا الفلتر."
                        setTextColor(Color.parseColor("#8B96A8"))
                        textSize = 13f
                        setPadding(0, dp(ctx, 18), 0, dp(ctx, 18))
                    }
                )
                return
            }

            var rowToFocus: View? = null
            val rowPairs = ArrayList<Pair<EpgProgram, View>>(filtered.size)

            for (p in filtered) {
                val badge = when {
                    p.isNow -> "🟢 الآن"
                    p.hasArchive -> "↺ أرشيف"
                    p.startTs > (nowMs / 1000L) -> "🕒 قادم"
                    else -> "—"
                }
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    isFocusable = true
                    isClickable = true
                    isSelected = (selectedProg == p)
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 4) }
                }

                val tvRow = TextView(ctx).apply {
                    text = "${formatProgTimeRange(p)}  [$badge]  ${p.name}"
                    setTextColor(
                        when {
                            p.isNow -> Color.parseColor("#34D399")
                            p.hasArchive -> Color.parseColor("#93C5FD")
                            else -> Color.parseColor("#E8ECF3")
                        }
                    )
                    textSize = 12.5f
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
                row.addView(tvRow)

                row.setOnFocusChangeListener { _, hasFocus ->
                    if (hasFocus) {
                        selectedProg = p
                        for ((progItem, rView) in rowPairs) {
                            rView.isSelected = (progItem == p)
                        }
                        updateDescrFor(p)
                    }
                }

                row.setOnClickListener {
                    if (armedProg == p && p.hasArchive) {
                        playArchiveProg(p)
                    } else if (armedProg == p && p.isNow) {
                        dlg.dismiss()
                        onPlayLive(ch)
                    } else {
                        selectedProg = p
                        armedProg = p
                        for ((progItem, rView) in rowPairs) {
                            rView.isSelected = (progItem == p)
                        }
                        updateDescrFor(p)
                    }
                }
                if (selectedProg == p) {
                    rowToFocus = row
                }
                rowPairs.add(p to row)
                listCol.addView(row)
            }

            if (focusSelectedRow) {
                val target = rowToFocus ?: rowPairs.firstOrNull()?.second
                target?.post {
                    listScroll.scrollTo(0, (target.top - dp(ctx, 50)).coerceAtLeast(0))
                    target.requestFocus()
                }
            }
        }

        val filters = listOf(
            "ALL" to "الكل",
            "ARCH" to "↺ الأرشيف فقط",
            "TODAY" to "اليوم",
            "YEST" to "أمس"
        )
        fun rebuildFilterButtons(focusCode: String? = null) {
            filterRow.removeAllViews()
            var targetBtn: View? = null
            for ((code, label) in filters) {
                val btn = makeTvButton(ctx, label, primary = (currentFilter == code)) {
                    currentFilter = code
                    armedProg = null
                    rebuildFilterButtons(focusCode = code)
                    renderList(focusSelectedRow = false)
                }
                if (code == focusCode) targetBtn = btn
                filterRow.addView(btn)
            }
            targetBtn?.let { v -> v.post { v.requestFocus() } }
        }
        rebuildFilterButtons()

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderList(focusSelectedRow = false) }
            override fun afterTextChanged(s: Editable?) {}
        })

        dlg.show()

        scope.launch {
            val progs = runCatching {
                withContext(Dispatchers.IO) { PortalClient.fetchFullEpgAndArchive(acc, ch) }
            }.getOrDefault(emptyList())
            allPrograms = progs
            selectedProg = progs.firstOrNull { it.isNow } ?: progs.lastOrNull { it.hasArchive } ?: progs.firstOrNull()
            armedProg = selectedProg
            val archCnt = progs.count { it.hasArchive }
            tvStatus.setTextColor(Color.parseColor("#34D399"))
            tvStatus.text = if (progs.isEmpty()) {
                "لا يوفّر السيرفر بيانات EPG لهذه القناة حالياً"
            } else {
                "✔ تم جلب ${progs.size} برنامج ($archCnt متاح في أرشيف الإعادة)"
            }
            selectedProg?.let { p -> updateDescrFor(p) }
            renderList(focusSelectedRow = progs.isNotEmpty())
        }
    }

    private fun formatProgTimeRange(p: EpgProgram): String {
        if (p.startTs <= 0L) return p.startStr.take(16)
        val df = SimpleDateFormat("MM/dd HH:mm", Locale.US)
        val dfEnd = SimpleDateFormat("HH:mm", Locale.US)
        val s = df.format(Date(p.startTs * 1000L))
        return if (p.stopTs > p.startTs) "$s–${dfEnd.format(Date(p.stopTs * 1000L))}" else s
    }

    // ==================== 3. بطاقة السينما الغنيّة (Media Info Card) ====================

    fun showMediaInfoDialog(
        ctx: Context,
        store: AppStore,
        scope: CoroutineScope,
        acc: AccountProfile,
        item: StreamItem,
        onOpenOrPlay: (StreamItem) -> Unit,
        onFavChanged: () -> Unit,
        onDownloadVod: ((StreamItem) -> Unit)? = null
    ) {
        val scroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            setPadding(dp(ctx, 18), dp(ctx, 16), dp(ctx, 18), dp(ctx, 14))
        }
        scroll.addView(root)

        val headerRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }

        val ivPoster = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundResource(R.drawable.bg_poster_card)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 110), dp(ctx, 160)).apply {
                marginEnd = dp(ctx, 14)
            }
        }
        LogoLoader.load(item.logo, ivPoster, allowDuringPlayback = true, isPoster = true)
        headerRow.addView(ivPoster)

        val parsedMedia = MediaTitleFormatter.parseMedia(item.name)
        val metaCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val tvTitle = TextView(ctx).apply {
            text = parsedMedia.cleanTitle
            setTextColor(Color.WHITE)
            textSize = 18f
        }
        val tvBadges = TextView(ctx).apply {
            text = "⏳ جارٍ جلب تفاصيل العمل..."
            setTextColor(Color.parseColor("#FBBF24"))
            textSize = 12.5f
            setPadding(0, dp(ctx, 4), 0, dp(ctx, 4))
        }
        val tvPeople = TextView(ctx).apply {
            text = ""
            setTextColor(Color.parseColor("#93C5FD"))
            textSize = 12f
        }
        metaCol.addView(tvTitle)
        metaCol.addView(tvBadges)
        metaCol.addView(tvPeople)
        headerRow.addView(metaCol)
        root.addView(headerRow)

        val tvPlot = TextView(ctx).apply {
            text = item.plot.ifBlank { "…" }
            setTextColor(Color.parseColor("#E8ECF3"))
            textSize = 13f
            setPadding(0, dp(ctx, 12), 0, dp(ctx, 14))
        }
        root.addView(tvPlot)

        val dlg = AlertDialog.Builder(ctx).setView(scroll).create()

        val barScroll = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        barScroll.addView(bar)

        val savedPos = if (item.kind == ItemKind.VOD || item.kind == ItemKind.EPISODE) {
            store.getResumePos(item)
        } else 0L
        val seriesResume = if (item.kind == ItemKind.SERIES) {
            store.getLatestSeriesResumeEntry(item.id, item.accountId)
        } else null

        val playLabel = when {
            item.kind == ItemKind.SERIES -> "📂 عرض المواسم والحلقات"
            savedPos >= AppStore.MIN_RESUME_POS_MS -> "⏵ متابعة من ${AppStore.formatResumeTime(savedPos)}"
            else -> "▶ مشاهدة الآن"
        }
        val btnPlay = makeTvButton(ctx, playLabel, primary = true) {
            dlg.dismiss()
            onOpenOrPlay(item)
        }
        var favNow = store.isFavorite(item)
        lateinit var btnFav: TextView
        btnFav = makeTvButton(ctx, if (favNow) "★ إزالة من المفضّلة" else "☆ أضف للمفضّلة") {
            favNow = store.toggleFavorite(item)
            btnFav.text = if (favNow) "★ إزالة من المفضّلة" else "☆ أضف للمفضّلة"
            onFavChanged()
        }
        val btnClose = makeTvButton(ctx, "إغلاق") { dlg.dismiss() }

        if (seriesResume != null) {
            val epLabel = MediaTitleFormatter.parseMedia(seriesResume.item.name).cleanTitle
            bar.addView(
                makeTvButton(
                    ctx,
                    "⏵ متابعة: $epLabel (${AppStore.formatResumeTime(seriesResume.posMs)})",
                    primary = true
                ) {
                    dlg.dismiss()
                    onOpenOrPlay(seriesResume.item)
                }
            )
        }
        bar.addView(btnPlay)
        if (savedPos >= AppStore.MIN_RESUME_POS_MS) {
            bar.addView(
                makeTvButton(ctx, "⏮ من البداية") {
                    store.clearResumePos(item)
                    dlg.dismiss()
                    onOpenOrPlay(item)
                }
            )
        }
        if ((item.kind == ItemKind.VOD || item.kind == ItemKind.EPISODE) && onDownloadVod != null) {
            bar.addView(
                makeTvButton(ctx, "📥 تحميل للجهاز") {
                    dlg.dismiss()
                    onDownloadVod(item)
                }
            )
        }
        bar.addView(btnFav)
        bar.addView(btnClose)
        root.addView(barScroll)

        dlg.show()
        btnPlay.requestFocus()

        scope.launch {
            val d = runCatching {
                withContext(Dispatchers.IO) { PortalClient.fetchMediaDetails(acc, item) }
            }.getOrNull() ?: return@launch

            if (d.poster.isNotBlank() && d.poster != item.logo) {
                LogoLoader.load(d.poster, ivPoster, allowDuringPlayback = true, isPoster = true)
            }
            val cleanRating = MediaTitleFormatter.formatRating(d.rating.ifBlank { item.rating })
            val cleanYear = d.year.takeIf { it.isNotBlank() && it != "0" } ?: parsedMedia.extractedYear.takeIf { it.isNotBlank() }
            val badges = listOfNotNull(
                cleanRating.takeIf { it.isNotBlank() }?.let { "⭐ $it" },
                cleanYear?.let { "📅 $it" },
                parsedMedia.regionOrLangTag.takeIf { it.isNotBlank() }?.let { "🌐 $it" },
                d.duration.takeIf { it.isNotBlank() && it != "0" }?.let { "⏱ $it" },
                d.country.takeIf { it.isNotBlank() }?.let { "🌍 $it" },
                d.genres.takeIf { it.isNotBlank() }?.let { "🎭 $it" }
            ).joinToString("  ·  ")
            tvBadges.setTextColor(Color.parseColor("#34D399"))
            tvBadges.text = badges.ifBlank { "فيلم / مسلسل" }

            val castTxt = buildString {
                if (d.director.isNotBlank()) append("🎬 إخراج: ${d.director}\n")
                if (d.actors.isNotBlank()) append("👥 بطولة: ${d.actors.take(140)}")
            }.trim()
            tvPeople.text = castTxt
            tvPlot.text = d.plot.ifBlank { "لا يوجد ملخّص قصّة مسجّل على السيرفر لهذا العمل." }
        }
    }

    // ==================== 4. مدير الأقسام والرقابة العائلية (PIN + Pin/Hide/Lock) ====================

    fun showCategoryManagerDialog(
        ctx: Context,
        store: AppStore,
        acc: AccountProfile,
        tab: ContentTab,
        rawCategories: List<CategoryItem>,
        onChanged: () -> Unit
    ) {
        fun openVerifiedManager() {
            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setBackgroundResource(R.drawable.bg_dialog_surface)
                clipChildren = false
                clipToPadding = false
                setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
            }

            root.addView(
                TextView(ctx).apply {
                    text = "🗂 إدارة الأقسام والرقابة العائلية (${tab.titleAr})"
                    setTextColor(Color.parseColor("#60A5FA"))
                    textSize = 17f
                }
            )

            val dlg = AlertDialog.Builder(ctx).setView(root).create()
            styleNeonDialog(dlg)

            val topScroll = HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                clipChildren = false
                clipToPadding = false
                setPadding(0, dp(ctx, 6), 0, dp(ctx, 6))
            }
            val topBar = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                clipChildren = false
                clipToPadding = false
            }
            topScroll.addView(topBar)
            root.addView(topScroll)

            val btnSetPin = makeTvButton(
                ctx,
                if (store.hasPin()) "🔐 تغيير/إلغاء الرمز السري" else "🔐 تعيين رمز PIN عائلي",
                primary = !store.hasPin()
            ) {
                showSetOrClearPinDialog(ctx, store) {
                    dlg.dismiss()
                    openVerifiedManager()
                }
            }
            val chkAdult = CheckBox(ctx).apply {
                text = "🔞 قفل +18 تلقائياً"
                isChecked = store.isAutoLockAdult()
                setTextColor(Color.parseColor("#E8ECF3"))
                setOnCheckedChangeListener { _, checked ->
                    store.setAutoLockAdult(checked)
                    onChanged()
                }
            }
            val btnUnhideAll = makeTvButton(ctx, "👁 إظهار كل المخفي") {
                store.unhideAllCategories(acc, tab)
                Toast.makeText(ctx, "✔ تم إظهار جميع الأقسام المخفية", Toast.LENGTH_SHORT).show()
                onChanged()
                dlg.dismiss()
                openVerifiedManager()
            }

            topBar.addView(btnSetPin)
            topBar.addView(btnUnhideAll)
            topBar.addView(chkAdult)

            val etSearch = makeTvSearchEdit(ctx, "🔍 ابحث عن قسم لتثبيته أو إخفائه أو قفله (اضغط OK للكتابة)...")
            root.addView(etSearch)

            val listScroll = ScrollView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 250)
                )
            }
            val listCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            listScroll.addView(listCol)
            root.addView(listScroll)

            fun renderCats(restoreCatId: String? = null, restoreBtnSlot: Int = 0) {
                listCol.removeAllViews()
                val q = etSearch.text.toString().trim().lowercase(Locale.ROOT)
                val prefs = store.getCategoryPrefsMap(acc, tab)
                val editable = rawCategories.filter {
                    it.id != "*" && (q.isEmpty() || it.title.lowercase(Locale.ROOT).contains(q))
                }
                var viewToFocus: View? = null
                for (c in editable) {
                    val pref = prefs[c.id]
                    val isPin = pref?.pinned == true
                    val isHid = pref?.hidden == true
                    val isLck = (pref?.locked == true) || (store.isAutoLockAdult() && AppStore.isAdultCategoryTitle(c.title))

                    val row = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        clipChildren = false
                        clipToPadding = false
                        setBackgroundResource(R.drawable.bg_tv_row)
                        setPadding(dp(ctx, 8), dp(ctx, 6), dp(ctx, 8), dp(ctx, 6))
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = dp(ctx, 4) }
                    }

                    val tvName = TextView(ctx).apply {
                        text = c.title
                        setTextColor(if (isHid) Color.parseColor("#6B7280") else Color.parseColor("#E8ECF3"))
                        textSize = 12.5f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                    row.addView(tvName)

                    val btnPin = makeTvButton(ctx, if (isPin) "📌 مثبّت" else "📌", primary = isPin) {
                        store.updateCategoryPref(acc, tab, c.id) { it.copy(pinned = !isPin) }
                        onChanged()
                        renderCats(restoreCatId = c.id, restoreBtnSlot = 0)
                    }
                    val btnHide = makeTvButton(ctx, if (isHid) "👁 إظهار" else "🚫 إخفاء", primary = isHid) {
                        store.updateCategoryPref(acc, tab, c.id) { it.copy(hidden = !isHid) }
                        onChanged()
                        renderCats(restoreCatId = c.id, restoreBtnSlot = 1)
                    }
                    val btnLock = makeTvButton(ctx, if (isLck) "🔒 مقفول" else "🔓", primary = isLck) {
                        if (!store.hasPin() && !isLck) {
                            Toast.makeText(ctx, "عيّن رمز PIN أولاً بالأعلى لتفعيل القفل العائلي", Toast.LENGTH_LONG).show()
                        } else {
                            store.updateCategoryPref(acc, tab, c.id) { it.copy(locked = !(pref?.locked ?: false)) }
                            onChanged()
                            renderCats(restoreCatId = c.id, restoreBtnSlot = 2)
                        }
                    }
                    row.addView(btnPin)
                    row.addView(btnHide)
                    row.addView(btnLock)
                    if (c.id == restoreCatId) {
                        viewToFocus = when (restoreBtnSlot) {
                            1 -> btnHide
                            2 -> btnLock
                            else -> btnPin
                        }
                    }
                    listCol.addView(row)
                }
                viewToFocus?.let { v -> v.post { v.requestFocus() } }
            }

            etSearch.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderCats() }
                override fun afterTextChanged(s: Editable?) {}
            })

            val btnDone = makeTvButton(ctx, "✔ تمّ", primary = true) { dlg.dismiss() }
            btnDone.layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 8) }
            root.addView(btnDone)

            renderCats()
            dlg.show()
            btnSetPin.post { btnSetPin.requestFocus() }
        }

        if (store.hasPin()) {
            showPinPromptDialog(ctx, store, "🔒 أدخل الرمز السري لفتح إعدادات الرقابة والأقسام") {
                openVerifiedManager()
            }
        } else {
            openVerifiedManager()
        }
    }

    private fun showSetOrClearPinDialog(
        ctx: Context,
        store: AppStore,
        onDone: () -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
        }
        root.addView(
            TextView(ctx).apply {
                text = "🔐 تعيين أو إلغاء الرمز السري العائلي (4 أرقام أو أكثر)"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 16f
            }
        )
        val etPin = makeEdit(
            ctx,
            "أدخل الرمز الجديد (مثلاً 1234)",
            "",
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        )
        etPin.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(ctx, 10); bottomMargin = dp(ctx, 10) }
        root.addView(etPin)

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        styleNeonDialog(dlg)
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(
            makeTvButton(ctx, "💾 حفظ الرمز", primary = true) {
                val p = etPin.text.toString().trim()
                if (p.length < 4) {
                    Toast.makeText(ctx, "يجب أن يتكوّن الرمز من 4 أرقام على الأقل", Toast.LENGTH_SHORT).show()
                } else {
                    store.setPin(p)
                    Toast.makeText(ctx, "✔ تم تفعيل الرمز السري العائلي", Toast.LENGTH_SHORT).show()
                    dlg.dismiss()
                    onDone()
                }
            }
        )
        if (store.hasPin()) {
            bar.addView(
                makeTvButton(ctx, "🗑 إلغاء الرمز نهائياً") {
                    store.clearPin()
                    Toast.makeText(ctx, "تم إلغاء الرمز السري", Toast.LENGTH_SHORT).show()
                    dlg.dismiss()
                    onDone()
                }
            )
        }
        bar.addView(makeTvButton(ctx, "إغلاق") { dlg.dismiss() })
        root.addView(bar)
        dlg.show()
        etPin.requestFocus()
    }

    // ==================== 5. الإرسال السريع عبر متصفّح الشبكة (Web Setup) ====================

    fun showWebSetupDialog(
        ctx: Context,
        store: AppStore,
        downloadPayload: String? = null,
        downloadFileName: String = "iptv_playlist.m3u",
        onImported: () -> Unit
    ) {
        var server: WebSetupServer? = null
        val outerScroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 22), dp(ctx, 16), dp(ctx, 22), dp(ctx, 16))
        }
        outerScroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = "🌐 استيراد وتصدير الملفات عبر Wi-Fi"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 16.5f
                gravity = Gravity.CENTER
            }
        )

        val ivQr = ImageView(ctx).apply {
            layoutParams = LinearLayout.LayoutParams(dp(ctx, 164), dp(ctx, 164)).apply {
                topMargin = dp(ctx, 10)
                bottomMargin = dp(ctx, 6)
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            visibility = View.GONE
        }
        root.addView(ivQr)

        val tvUrl = TextView(ctx).apply {
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#34D399"))
            textSize = 18f
            setPadding(0, dp(ctx, 4), 0, dp(ctx, 4))
        }
        root.addView(tvUrl)

        val tvPinBadge = TextView(ctx).apply {
            gravity = Gravity.CENTER
            setTextColor(Color.parseColor("#FDE047"))
            textSize = 16f
            setPadding(0, dp(ctx, 2), 0, dp(ctx, 8))
        }
        root.addView(tvPinBadge)

        val tvHint = TextView(ctx).apply {
            text = "📱 من هاتف أو حاسوب على نفس الشبكة: امسح QR أو افتح الرابط وأدخل الرمز. ارفع JSON/M3U للاستيراد، أو اضغط تنزيل النسخة الاحتياطية للتصدير. النسخة تحتوي بيانات اشتراكك؛ لا تشارك الرابط أو الرمز وأغلق النافذة بعد الانتهاء."
            setTextColor(Color.parseColor("#C6D0E0"))
            textSize = 12.5f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(ctx, 12))
        }
        root.addView(tvHint)

        val dlg = AlertDialog.Builder(ctx).setView(outerScroll).create()
        styleNeonDialog(dlg)
        dlg.setOnDismissListener { server?.stop() }

        runCatching {
            val s = WebSetupServer(store, port = 8765, downloadPayload = downloadPayload, downloadFileName = downloadFileName) { msg ->
                Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                dlg.dismiss()
                onImported()
            }
            server = s
            val baseUrl = s.start()
            tvUrl.text = baseUrl
            tvPinBadge.text = "🔑 رمز الحماية المؤقّت:  ${s.accessToken}"
            QrCodeHelper.generateBitmap(s.qrPairUrl(), dp(ctx, 180))?.let { bmp ->
                ivQr.setImageBitmap(bmp)
                ivQr.visibility = View.VISIBLE
            }
        }.onFailure {
            tvUrl.text = "تعذّر فتح المنفذ المحلي: ${it.message}"
            tvPinBadge.visibility = View.GONE
        }

        val btnClose = makeTvButton(ctx, "إغلاق وإيقاف الخادم المؤقّت", primary = true) {
            dlg.dismiss()
        }
        root.addView(btnClose)
        dlg.show()
        btnClose.requestFocus()
    }

    // ==================== 6. الإحصائيات والنسخ الاحتياطي الشامل + مواصلة المشاهدة والجدولة ====================

    private fun formatPosClock(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0L) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun showStatsAndBackupDialog(
        ctx: Context,
        store: AppStore,
        onExportBackupFile: () -> Unit,
        onImportBackupFile: () -> Unit,
        onExportFavM3u: () -> Unit,
        onExportCurrentListM3u: () -> Unit,
        onHistoryCleared: () -> Unit,
        onResumeItem: ((ResumeEntry) -> Unit)? = null,
        onPlayLocalMedia: ((StreamItem) -> Unit)? = null
    ) {
        val outerScroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
        }
        outerScroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = "📊 إحصائيات المشاهدة · مواصلة المشاهدة · المهام المجدولة"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )

        val tvStatsSummary = TextView(ctx).apply {
            setTextColor(Color.parseColor("#E8ECF3"))
            textSize = 13f
            setLineSpacing(dp(ctx, 3).toFloat(), 1f)
            setPadding(0, dp(ctx, 8), 0, dp(ctx, 10))
        }
        root.addView(tvStatsSummary)

        fun refreshSummaryText() {
            val totalSec = store.getWatchSeconds()
            val hrs = totalSec / 3600L
            val mins = (totalSec % 3600L) / 60L
            val (liveCnt, vodCnt, catchupCnt) = store.getWatchCounts()
            val recCnt = store.getRecCount()
            val accCnt = store.getAccounts().size
            val favCnt = store.getFavorites().size
            val remCnt = store.getReminders().size
            val schCnt = store.getScheduledRecs().count { it.state == "pending" || it.state == "recording" }
            tvStatsSummary.text = buildString {
                append("⏱ وقت المشاهدة: ${hrs} س و ${mins} د  ·  ⏺ التسجيلات المحفوظة: $recCnt\n")
                append("📺 مباشر: $liveCnt  ·  🎬 أفلام وحلقات: $vodCnt  ·  ↺ أرشيف: $catchupCnt\n")
                append("👤 السيرفرات: $accCnt  ·  ⭐ المفضّلة: $favCnt  ·  🔔 التنبيهات: $remCnt  ·  ⏰ مجدول: $schCnt")
            }
        }
        refreshSummaryText()

        val dlg = AlertDialog.Builder(ctx).setView(outerScroll).create()
        styleNeonDialog(dlg)

        // 1) قسم مواصلة المشاهدة (⏵ Resume Positions — مطابق لـ v66.86)
        root.addView(
            TextView(ctx).apply {
                text = "⏵ مواصلة المشاهدة (الأفلام والحلقات المتوقّفة في المنتصف)"
                setTextColor(Color.parseColor("#34D399"))
                textSize = 14f
                setPadding(0, dp(ctx, 4), 0, dp(ctx, 4))
            }
        )
        val resumeCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resumeCol)

        fun renderResumeList() {
            resumeCol.removeAllViews()
            val entries = store.getResumeEntries().take(25)
            if (entries.isEmpty()) {
                resumeCol.addView(
                    TextView(ctx).apply {
                        text = "لا توجد أفلام أو حلقات متوقّفة حالياً."
                        setTextColor(Color.parseColor("#8B96A8"))
                        textSize = 12f
                        setPadding(0, 0, 0, dp(ctx, 8))
                    }
                )
                return
            }
            for (entry in entries) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 8), dp(ctx, 5), dp(ctx, 8), dp(ctx, 5))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 4) }
                }
                val posTxt = formatPosClock(entry.posMs)
                val durTxt = if (entry.durMs > 0L) " / ${formatPosClock(entry.durMs)}" else ""
                row.addView(
                    TextView(ctx).apply {
                        text = "🎬 ${entry.item.name}\n⏱ متوقّف عند $posTxt$durTxt"
                        setTextColor(Color.parseColor("#E8ECF3"))
                        textSize = 12f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )
                if (onResumeItem != null) {
                    row.addView(
                        makeTvButton(ctx, "▶ متابعة", primary = true) {
                            dlg.dismiss()
                            onResumeItem(entry)
                        }
                    )
                }
                row.addView(
                    makeTvButton(ctx, "🗑") {
                        store.clearResumePos(entry.item)
                        renderResumeList()
                    }
                )
                resumeCol.addView(row)
            }
        }
        renderResumeList()

        // 2) قسم المهام المجدولة والتنبيهات (⏰ التسجيلات المجدولة + 🔔 التنبيهات — مطابق لـ v66.86)
        root.addView(
            TextView(ctx).apply {
                text = "⏰ التسجيلات المجدولة و🔔 تنبيهات البرامج"
                setTextColor(Color.parseColor("#FBBF24"))
                textSize = 14f
                setPadding(0, dp(ctx, 6), 0, dp(ctx, 4))
            }
        )
        val jobsCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(jobsCol)

        val dfJob = SimpleDateFormat("MM/dd HH:mm", Locale.US)
        fun renderJobsList() {
            jobsCol.removeAllViews()
            val scheds = store.getScheduledRecs()
            val rems = store.getReminders()
            if (scheds.isEmpty() && rems.isEmpty()) {
                jobsCol.addView(
                    TextView(ctx).apply {
                        text = "لا توجد تسجيلات مجدولة أو تنبيهات نشطة."
                        setTextColor(Color.parseColor("#8B96A8"))
                        textSize = 12f
                        setPadding(0, 0, 0, dp(ctx, 10))
                    }
                )
                return
            }
            for (sc in scheds) {
                val stBadge = when (sc.state) {
                    "recording" -> "🔴 يُسجّل الآن"
                    "done" -> "✔ اكتمل"
                    "missed" -> "⚠ فات موعده"
                    "error" -> "✖ تعذّر"
                    else -> "⏳ بالانتظار"
                }
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 8), dp(ctx, 5), dp(ctx, 8), dp(ctx, 5))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 4) }
                }
                val dt = if (sc.startTs > 0L) dfJob.format(Date(sc.startTs * 1000L)) else ""
                row.addView(
                    TextView(ctx).apply {
                        text = "⏰ [$stBadge] ${sc.channelName} — ${sc.progName} ($dt · ${sc.durationMin}د)"
                        setTextColor(Color.parseColor("#E8ECF3"))
                        textSize = 12f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )
                row.addView(
                    makeTvButton(ctx, "🗑") {
                        store.removeScheduledRec(sc.id)
                        renderJobsList()
                        refreshSummaryText()
                    }
                )
                jobsCol.addView(row)
            }
            for (rm in rems) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 8), dp(ctx, 5), dp(ctx, 8), dp(ctx, 5))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 4) }
                }
                val dt = if (rm.startTs > 0L) dfJob.format(Date(rm.startTs * 1000L)) else ""
                row.addView(
                    TextView(ctx).apply {
                        text = "🔔 [تنبيه] ${rm.channelName} — ${rm.progName} ($dt)"
                        setTextColor(Color.parseColor("#93C5FD"))
                        textSize = 12f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )
                row.addView(
                    makeTvButton(ctx, "🗑") {
                        store.removeReminder(rm.id)
                        renderJobsList()
                        refreshSummaryText()
                    }
                )
                jobsCol.addView(row)
            }
        }
        renderJobsList()

        // 3) شريط أدوات التصدير والاستيراد ومسح السجلّ والكاش
        val barScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(ctx, 6), 0, 0)
        }
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        barScroll.addView(bar)
        root.addView(barScroll)

        if (onPlayLocalMedia != null) {
            bar.addView(
                makeTvButton(ctx, "📂 مكتبة تسجيلاتي وتنزيلاتي", primary = true) {
                    dlg.dismiss()
                    showSavedMediaLibraryDialog(ctx, onPlayLocalMedia)
                }
            )
        }
        bar.addView(
            makeTvButton(ctx, "💾 تصدير نسخة احتياطية JSON", primary = (onPlayLocalMedia == null)) {
                dlg.dismiss()
                onExportBackupFile()
            }
        )
        bar.addView(
            makeTvButton(ctx, "📂 استيراد نسخة / بوابات JSON") {
                dlg.dismiss()
                onImportBackupFile()
            }
        )
        bar.addView(
            makeTvButton(ctx, "⭐ تصدير المفضّلة M3U") {
                dlg.dismiss()
                onExportFavM3u()
            }
        )
        bar.addView(
            makeTvButton(ctx, "📤 تصدير القائمة الحالية M3U") {
                dlg.dismiss()
                onExportCurrentListM3u()
            }
        )
        bar.addView(
            makeTvButton(ctx, "🧹 مسح الكاش") {
                PortalClient.clearCaches()
                LogoLoader.trimMemory(clearAll = true)
                Toast.makeText(ctx, "✔ تم تفريغ الكاش المؤقّت بنجاح", Toast.LENGTH_SHORT).show()
            }
        )
        bar.addView(
            makeTvButton(ctx, "🗑 مسح السجلّ والإحصائيات") {
                store.clearHistory()
                store.clearAllResumeEntries()
                store.resetStats()
                Toast.makeText(ctx, "✔ تم مسح سجلّ المشاهدة والإحصائيات", Toast.LENGTH_SHORT).show()
                onHistoryCleared()
                dlg.dismiss()
            }
        )
        bar.addView(makeTvButton(ctx, "إغلاق") { dlg.dismiss() })

        dlg.show()
    }

    // ==================== 7. نافذة تحميل الأفلام والحلقات (📥 مطابقة لـ v66.86) ====================

    fun showVodDownloadChoiceDialog(
        ctx: Context,
        scope: CoroutineScope,
        acc: AccountProfile?,
        item: StreamItem,
        directResolvedUrl: String = "",
        onDownloadStopped: (() -> Unit)? = null,
        onStartInternalDownload: (resolvedUrl: String) -> Unit
    ) {
        if (StreamRecorder.isDownloading()) {
            val stopBtnText = if (onDownloadStopped != null) {
                "⏹ إيقاف التحميل والاستئناف فوراً"
            } else {
                "⏹ إيقاف التحميل الجاري"
            }
            TvDialogs.showNeonChoiceDialog(
                ctx = ctx,
                title = "📥 جارٍ تحميل «${StreamRecorder.activeDlTitle}»",
                items = listOf(stopBtnText),
                defaultIndex = 0,
                cancelLabel = "إبقاء التحميل"
            ) {
                StreamRecorder.stopDownload()
                onDownloadStopped?.invoke()
            }
            return
        }

        val options = listOf(
            "📥 التحميل المباشر داخل التطبيق (Downloads/IPTVLite_Downloads)",
            "🌐 الفتح في مدير تحميل خارجي (ADM / 1DM / المتصفّح)"
        )
        TvDialogs.showNeonChoiceDialog(
            ctx = ctx,
            title = "📥 تحميل: ${item.name}",
            items = options,
            defaultIndex = 0,
            cancelLabel = "إلغاء"
        ) { which ->
            if (which == 0) {
                // التحميل المباشر داخل التطبيق: نمرّر التحكّم مباشرةً ليتسنّى إيقاف مقبس المشغّل أولاً وتوليد تصريح create_link واحد نظيف!
                val hintUrl = if (acc != null && acc.provider == ProviderType.STALKER) "" else directResolvedUrl
                onStartInternalDownload(hintUrl)
            } else {
                scope.launch {
                    val url = when {
                        acc != null && acc.provider == ProviderType.STALKER -> runCatching {
                            withContext(Dispatchers.IO) {
                                PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true)
                            }
                        }.getOrDefault("")
                        directResolvedUrl.startsWith("http://", true) || directResolvedUrl.startsWith("https://", true) -> directResolvedUrl
                        acc != null -> runCatching {
                            withContext(Dispatchers.IO) {
                                PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true)
                            }
                        }.getOrDefault("")
                        else -> PortalClient.extractDirectHttpUrl(item.cmd)
                    }
                    if (url.isBlank()) {
                        Toast.makeText(ctx, "✖ تعذّر استخراج رابط مباشر للفيلم/الحلقة من السيرفر", Toast.LENGTH_LONG).show()
                        return@launch
                    }
                    StreamRecorder.openInExternalDownloader(ctx, url, item.name)
                }
            }
        }
    }

    // ==================== 8. مكتبة تسجيلاتي وتنزيلاتي للتشغيل بدون إنترنت ====================

    fun showSavedMediaLibraryDialog(
        ctx: Context,
        onPlayOffline: (StreamItem) -> Unit
    ) {
        val outerScroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
        }
        outerScroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = "📂 مكتبة تسجيلاتي وتنزيلاتي (تشغيل مباشر بدون إنترنت)"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )

        val tvSummary = TextView(ctx).apply {
            setTextColor(Color.parseColor("#A7F3D0"))
            textSize = 12.5f
            setPadding(0, dp(ctx, 6), 0, dp(ctx, 10))
        }
        root.addView(tvSummary)

        val filesCol = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        root.addView(filesCol)

        val dlg = AlertDialog.Builder(ctx).setView(outerScroll).create()
        styleNeonDialog(dlg)
        val dfDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)

        fun renderFiles() {
            filesCol.removeAllViews()
            if (StreamRecorder.isRecording()) {
                val activeRecRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 8) }
                }
                activeRecRow.addView(
                    TextView(ctx).apply {
                        text = "🔴 جارٍ التسجيل الآن: «${StreamRecorder.activeRecTitle}»"
                        setTextColor(Color.parseColor("#FCA5A5"))
                        textSize = 13f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )
                activeRecRow.addView(
                    makeTvButton(ctx, "⏹ إيقاف وحفظ", primary = true) {
                        StreamRecorder.stopRecording()
                        Toast.makeText(ctx, "⏹ تمّ إيقاف التسجيل وحفظ الملف", Toast.LENGTH_SHORT).show()
                        filesCol.postDelayed({ renderFiles() }, 350L)
                    }
                )
                filesCol.addView(activeRecRow)
            }
            if (StreamRecorder.isDownloading()) {
                val activeDlRow = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 8) }
                }
                activeDlRow.addView(
                    TextView(ctx).apply {
                        text = "📥 جارٍ التحميل الآن: «${StreamRecorder.activeDlTitle}»"
                        setTextColor(Color.parseColor("#93C5FD"))
                        textSize = 13f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )
                activeDlRow.addView(
                    makeTvButton(ctx, "⏹ إيقاف التحميل", primary = true) {
                        StreamRecorder.stopDownload()
                        Toast.makeText(ctx, "⏹ تمّ إيقاف التحميل", Toast.LENGTH_SHORT).show()
                        filesCol.postDelayed({ renderFiles() }, 350L)
                    }
                )
                filesCol.addView(activeDlRow)
            }
            val items = StreamRecorder.listSavedMediaFiles(ctx)
            val totalBytes = items.sumOf { it.sizeBytes }
            tvSummary.text = "📦 إجمالي الملفات المحفوظة: ${items.size} ملف  ·  💾 المساحة المستخدمة: ${StreamRecorder.formatSizeMb(totalBytes)}"

            if (items.isEmpty()) {
                filesCol.addView(
                    TextView(ctx).apply {
                        text = "لا توجد تسجيلات أو أفلام محمّلة بعد.\nيمكنك التسجيل بزرّ ⏺ أثناء البثّ، أو جدولة تسجيل برنامج من دليل EPG، أو تحميل أي فيلم بزرّ 📥 تحميل!"
                        setTextColor(Color.parseColor("#8B96A8"))
                        textSize = 13f
                        setPadding(0, dp(ctx, 14), 0, dp(ctx, 14))
                    }
                )
                return
            }

            for (entry in items) {
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundResource(R.drawable.bg_tv_row)
                    setPadding(dp(ctx, 10), dp(ctx, 7), dp(ctx, 10), dp(ctx, 7))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(ctx, 5) }
                }

                val badge = if (entry.isRecording) "🔴 تسجيل" else "📥 تنزيل"
                val dt = if (entry.modifiedMs > 0L) dfDate.format(Date(entry.modifiedMs)) else ""
                val sz = StreamRecorder.formatSizeMb(entry.sizeBytes)

                row.addView(
                    TextView(ctx).apply {
                        text = "[$badge]  ${entry.title}\n💾 $sz  ·  🕒 $dt"
                        setTextColor(Color.parseColor("#E8ECF3"))
                        textSize = 12.5f
                        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    }
                )

                row.addView(
                    makeTvButton(ctx, "▶ تشغيل", primary = true) {
                        dlg.dismiss()
                        val cleanTitle = entry.title.substringBeforeLast('.')
                        onPlayOffline(
                            StreamItem(
                                id = "local_${entry.title.hashCode()}",
                                name = "📂 $cleanTitle",
                                cmd = entry.playUri,
                                kind = ItemKind.VOD
                            )
                        )
                    }
                )

                row.addView(
                    makeTvButton(ctx, "🗑 حذف") {
                        TvDialogs.showNeonChoiceDialog(
                            ctx = ctx,
                            title = "🗑 حذف «${entry.title}» (${sz}) نهائياً؟",
                            items = listOf("✔ نعم، حذف الملف وتفريغ المساحة"),
                            defaultIndex = 0,
                            cancelLabel = "إلغاء"
                        ) {
                            val ok = StreamRecorder.deleteSavedMediaFile(ctx, entry)
                            Toast.makeText(
                                ctx,
                                if (ok) "✔ تمّ حذف الملف وتفريغ المساحة" else "✖ تعذّر حذف الملف",
                                Toast.LENGTH_SHORT
                            ).show()
                            renderFiles()
                        }
                    }
                )

                filesCol.addView(row)
            }
        }
        renderFiles()

        val btnClose = makeTvButton(ctx, "إغلاق") { dlg.dismiss() }
        root.addView(
            LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(ctx, 8), 0, 0)
                addView(btnClose)
            }
        )

        dlg.show()
    }
}
