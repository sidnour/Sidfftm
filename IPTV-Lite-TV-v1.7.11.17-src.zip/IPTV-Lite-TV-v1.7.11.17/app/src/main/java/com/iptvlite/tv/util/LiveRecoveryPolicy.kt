package com.iptvlite.tv.util

/** No network probes or alternate providers. Bounded request rate, not bounded waiting time. */
object LiveRecoveryPolicy {
    fun delayMs(attempt: Int): Long = when {
        attempt <= 1 -> 2000L
        attempt == 2 -> 4000L
        attempt == 3 -> 8000L
        attempt == 4 -> 15000L
        else -> 30000L
    }
    // Refresh portal authentication periodically, not on every failed media connection.
    fun refreshSession(attempt: Int): Boolean = attempt == 2 || (attempt > 2 && attempt % 4 == 0)
}
