package com.iptvlite.tv.network

import android.os.Handler
import android.os.Looper
import com.iptvlite.tv.store.AppStore
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.security.SecureRandom

class WebSetupServer(
    private val store: AppStore,
    private val port: Int = 8765,
    private val downloadPayload: String? = null,
    private val downloadFileName: String = "iptv_playlist.m3u",
    private val onImported: (String) -> Unit
) {
    @Volatile
    private var running = false
    @Volatile private var serverSocket: ServerSocket? = null
    private val clients = java.util.Collections.synchronizedSet(HashSet<Socket>())
    private var workers: java.util.concurrent.ThreadPoolExecutor? = null
    @Volatile
    private var boundPort: Int = port
    private val uiHandler = Handler(Looper.getMainLooper())

    val accessToken: String = (100000 + SecureRandom().nextInt(900000)).toString()

    @Synchronized fun start(): String {
        stop()
        running = true
        var opened: ServerSocket? = null
        var lastErr: Throwable? = null
        for (candidate in port..(port + 10)) {
            val attempt = runCatching {
                val socket=ServerSocket()
                try { socket.reuseAddress=true;socket.bind(InetSocketAddress(candidate));socket }
                catch(e:Exception) { runCatching { socket.close() };throw e }
            }
            if (attempt.isSuccess) {
                opened = attempt.getOrThrow()
                boundPort = candidate
                break
            } else {
                lastErr = attempt.exceptionOrNull()
            }
        }
        val ss = opened ?: run { running=false;throw (lastErr ?: IllegalStateException("تعذّر حجز منفذ محلّي")) }
        serverSocket = ss
        val executor=java.util.concurrent.ThreadPoolExecutor(4,4,5L,java.util.concurrent.TimeUnit.SECONDS,
            java.util.concurrent.ArrayBlockingQueue<Runnable>(8)) { task ->
            Thread(task,"wifi-transfer-client").apply { isDaemon=true }
        }.apply { allowCoreThreadTimeOut(true) }
        workers=executor
        Thread {
            while (running && serverSocket === ss && !ss.isClosed) {
                val client = runCatching { ss.accept() }.getOrNull() ?: break
                synchronized(clients) {
                    if(!running || serverSocket !== ss) { runCatching { client.close() };return@synchronized }
                    clients.add(client)
                    try {
                        executor.execute {
                            try { runCatching { handleClient(client) } }
                            finally { clients.remove(client);runCatching { client.close() } }
                        }
                    } catch (_: java.util.concurrent.RejectedExecutionException) {
                        clients.remove(client);runCatching { client.close() }
                    }
                }
            }
        }.apply { name="wifi-transfer-accept";isDaemon = true }.start()
        return "http://${detectLanIp()}:$boundPort"
    }

    fun qrPairUrl(): String = "http://${detectLanIp()}:$boundPort/?token=$accessToken"

    @Synchronized fun stop() {
        running = false
        runCatching { serverSocket?.close() }
        serverSocket = null
        synchronized(clients) {
            clients.forEach { runCatching { it.close() } }
            clients.clear()
        }
        workers?.shutdownNow();workers=null
        uiHandler.removeCallbacksAndMessages(null)
    }

    private fun extractQueryToken(rawPath: String): String {
        val q = rawPath.substringAfter("?", "")
        if (q.isEmpty()) return ""
        return parseFormUrlEncoded(q)["token"].orEmpty().trim()
    }

    private fun readAsciiLine(inp: BufferedInputStream): String? {
        val bos = ByteArrayOutputStream(128)
        while (true) {
            val b = inp.read()
            if (b < 0) {
                return if (bos.size() == 0) null else bos.toString("UTF-8")
            }
            if (b == '\n'.code) break
            if (b != '\r'.code) bos.write(b)
            if (bos.size() > 8192) throw java.io.IOException("HTTP line exceeds limit")
        }
        return bos.toString("UTF-8")
    }

    private fun writeHttpText(sock: Socket, statusLine: String, contentType: String, bytes: ByteArray, extraHeaders: String = "") {
        val hdr = "HTTP/1.1 $statusLine\r\n" +
            "Content-Type: $contentType\r\n" +
            "Cache-Control: no-store\r\nReferrer-Policy: no-referrer\r\nX-Content-Type-Options: nosniff\r\n" +
            extraHeaders +
            "Content-Length: ${bytes.size}\r\n" +
            "Connection: close\r\n\r\n"
        val out = sock.getOutputStream()
        out.write(hdr.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }

    private fun handleClient(sock: Socket) {
        val session=serverSocket
        sock.use { s ->
            s.soTimeout = 10_000
            val inp = BufferedInputStream(s.getInputStream(), 16 * 1024)
            val reqLine = readAsciiLine(inp) ?: return
            val parts = reqLine.split(" ")
            val method = parts.getOrNull(0).orEmpty()
            val fullPath = parts.getOrNull(1).orEmpty()
            val cleanPath = fullPath.substringBefore("?")
            val queryToken = extractQueryToken(fullPath)

            var contentLength = 0
            var lengthSeen=false
            var headerBytes=0
            var headerCount=0
            while (true) {
                val h = readAsciiLine(inp) ?: return
                if (h.isEmpty()) break
                headerBytes+=h.length;headerCount++
                if(headerBytes>32768 || headerCount>100) return
                if(h.startsWith("Transfer-Encoding:",ignoreCase=true)) {
                    writeHttpText(s,"400 Bad Request","text/plain; charset=utf-8","Unsupported transfer encoding".toByteArray());return
                }
                if (h.startsWith("Content-Length:", ignoreCase = true)) {
                    val parsed=h.substringAfter(":").trim().toLongOrNull()
                    if(lengthSeen || parsed==null || parsed<0 || parsed>Int.MAX_VALUE) {
                        writeHttpText(s,"400 Bad Request","text/plain; charset=utf-8","Invalid Content-Length".toByteArray());return
                    }
                    lengthSeen=true;contentLength=parsed.toInt()
                }
            }

            if (method == "GET" && cleanPath == "/backup.json") {
                if (queryToken != accessToken) {
                    val err = buildHtmlPage(
                        notice = "✖ رمز الدخول غير صحيح — أدخِل الرمز الظاهر على شاشة التلفاز أو امسح باركود QR.",
                        isError = true,
                        prefillToken = ""
                    ).toByteArray(Charsets.UTF_8)
                    writeHttpText(s, "403 Forbidden", "text/html; charset=utf-8", err)
                    return
                }
                val json = store.exportFullBackupJson().toByteArray(Charsets.UTF_8)
                writeHttpText(
                    s,
                    "200 OK",
                    "application/json; charset=utf-8",
                    json,
                    extraHeaders = "Content-Disposition: attachment; filename=\"iptv_tv_backup.json\"\r\n"
                )
                return
            }

            if (method == "GET" && cleanPath == "/favorites.m3u") {
                if (queryToken != accessToken) {
                    val err = buildHtmlPage(
                        notice = "✖ رمز الدخول غير صحيح — أدخِل الرمز الظاهر على شاشة التلفاز أو امسح باركود QR.",
                        isError = true,
                        prefillToken = ""
                    ).toByteArray(Charsets.UTF_8)
                    writeHttpText(s, "403 Forbidden", "text/html; charset=utf-8", err)
                    return
                }
                val (_, m3uTxt) = store.exportItemsAsM3u(store.getFavorites(), "Favorites")
                val m3uBytes = m3uTxt.toByteArray(Charsets.UTF_8)
                writeHttpText(
                    s,
                    "200 OK",
                    "audio/x-mpegurl; charset=utf-8",
                    m3uBytes,
                    extraHeaders = "Content-Disposition: attachment; filename=\"iptv_favorites.m3u\"\r\n"
                )
                return
            }

            if (method == "GET" && cleanPath == "/selection.m3u") {
                if (queryToken != accessToken || downloadPayload == null) {
                    writeHttpText(s, "403 Forbidden", "text/plain; charset=utf-8", "غير مسموح".toByteArray(Charsets.UTF_8))
                    return
                }
                val fileName = downloadFileName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "iptv_playlist.m3u" }
                writeHttpText(s, "200 OK", "audio/x-mpegurl; charset=utf-8", downloadPayload.toByteArray(Charsets.UTF_8),
                    "Content-Disposition: attachment; filename=\"$fileName\"\r\n")
                return
            }

            var notice = ""
            var isErr = false
            var activeTokenForHtml = if (queryToken == accessToken) accessToken else ""
            val maxPostBytes = 18_000_000

            if (method == "POST" && contentLength > maxPostBytes) {
                writeHttpText(s,"413 Payload Too Large","text/plain; charset=utf-8","File exceeds 18 MB".toByteArray());return
            } else if (method == "POST" && contentLength in 1..maxPostBytes) {
                val rawBytes = ByteArray(contentLength)
                var readTotal = 0
                while (readTotal < contentLength) {
                    val r = inp.read(rawBytes, readTotal, contentLength - readTotal)
                    if (r <= 0) break
                    readTotal += r
                }
                if(readTotal!=contentLength) {
                    writeHttpText(s,"400 Bad Request","text/plain; charset=utf-8","Incomplete request body".toByteArray());return
                }
                val body = String(rawBytes, 0, readTotal, Charsets.UTF_8)
                val form = parseFormUrlEncoded(body)
                val submittedToken = form["token"].orEmpty().trim().ifBlank { queryToken }
                if (submittedToken != accessToken) {
                    notice = "✖ رمز الدخول غير صحيح — أدخِل الرمز المكوّن من 6 أرقام الظاهر على شاشة التلفاز."
                    isErr = true
                } else {
                    activeTokenForHtml = accessToken
                    val bulk = form["bulk"].orEmpty().trim()
                    if (bulk.isNotEmpty()) {
                        val res = store.importAnyPortalsOrBackup(bulk)
                        notice = res.message
                        if (res.accountsAdded > 0 || res.favoritesAdded > 0) {
                            uiHandler.post { if(running && serverSocket === session) onImported(res.message) }
                        }
                    } else {
                        notice = "⚠ الحقل فارغ — الصق بيانات السيرفر أو اختر ملفاً أولاً."
                        isErr = true
                    }
                }
            }

            val html = buildHtmlPage(notice, isErr, activeTokenForHtml).toByteArray(Charsets.UTF_8)
            writeHttpText(s, "200 OK", "text/html; charset=utf-8", html)
        }
    }

    private fun parseFormUrlEncoded(body: String): Map<String, String> {
        val map = HashMap<String, String>()
        for (pair in body.split("&")) {
            val eq = pair.indexOf('=')
            if (eq > 0) {
                val k = runCatching { URLDecoder.decode(pair.substring(0, eq), "UTF-8") }.getOrDefault("")
                val v = runCatching { URLDecoder.decode(pair.substring(eq + 1), "UTF-8") }.getOrDefault("")
                map[k] = v
            }
        }
        return map
    }

    private fun escapeHtml(raw: String): String = buildString(raw.length + 16) {
        for (ch in raw) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&#39;")
                else -> append(ch)
            }
        }
    }

    private fun buildHtmlPage(notice: String, isError: Boolean = false, prefillToken: String = ""): String {
        val banner = if (notice.isNotBlank()) {
            val bg = if (isError) "#7f1d1d" else "#064e3b"
            val fg = if (isError) "#fecaca" else "#a7f3d0"
            "<div style='background:$bg;color:$fg;padding:12px 14px;border-radius:12px;margin-bottom:14px;font-weight:bold;'>${escapeHtml(notice)}</div>"
        } else ""
        val safeToken = escapeHtml(prefillToken.trim())
        val selectionLink = if (downloadPayload != null) "<a class='btn sec' id='dlSelection' href='/selection.m3u?token=$safeToken'>📂 تنزيل القائمة المختارة M3U</a>" else ""
        return """
            <!DOCTYPE html>
            <html dir="rtl" lang="ar">
            <head>
              <meta charset="utf-8">
              <meta name="viewport" content="width=device-width,initial-scale=1">
              <title>IPTV Lite TV — الإرسال السريع المحميّ عبر الشبكة</title>
              <style>
                body{background:#080a0f;color:#f8fafc;font-family:system-ui,Segoe UI,Tahoma,sans-serif;max-width:720px;margin:24px auto;padding:0 16px;}
                .card{background:#10141c;border:1px solid #293548;border-radius:18px;padding:20px;margin-bottom:16px;box-shadow:0 12px 32px rgba(0,0,0,0.45);}
                h2{color:#60a5fa;margin-top:0;}
                .pin-box{display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap;}
                .pin-input{background:#0b0f17;color:#fde047;border:1.5px solid #3b82f6;border-radius:12px;padding:9px 14px;font-size:18px;font-weight:bold;width:130px;text-align:center;letter-spacing:4px;direction:ltr;}
                textarea{width:100%;box-sizing:border-box;height:200px;background:#0b0f17;color:#f8fafc;border:1px solid #293548;border-radius:12px;padding:12px;font-size:14px;direction:ltr;}
                button,.btn{display:inline-block;background:#2563eb;color:#fff;border:1px solid #60a5fa;border-radius:999px;padding:10px 20px;font-size:14.5px;font-weight:bold;cursor:pointer;text-decoration:none;margin-top:10px;margin-left:6px;}
                .sec{background:#161d2a;border:1px solid #2b384e;}
                input[type=file]{margin:8px 0;color:#94a3b8;}
              </style>
            </head>
            <body>
              <div class="card">
                <h2>📺 IPTV Lite TV — الإرسال اللاسلكي المحميّ</h2>
                $banner
                <form method="POST" action="/" accept-charset="UTF-8">
                  <div class="pin-box">
                    <label for="token"><b>🔑 رمز الدخول الظاهر على الشاشة:</b></label>
                    <input class="pin-input" type="text" id="token" name="token" maxlength="8" placeholder="••••" value="$safeToken" required>
                  </div>
                  <p style="margin:6px 0;">الصق رابط السيرفر مع عنوان <b>MAC</b>، أو روابط <b>Xtream / M3U</b>، أو اختر ملف <b>working_portals.json / iptv_backup.json / .m3u</b>:</p>
                  <input type="file" id="fpick" accept=".json,.txt,.m3u,.m3u8">
                  <textarea id="bulk" name="bulk" placeholder="http://server.com:8080/c | 00:1A:79:XX:XX:XX&#10;أو الصق محتوى الملف بالكامل هنا..."></textarea>
                  <div>
                    <button type="submit">🚀 إرسال وحفظ فوراً في التطبيق</button>
                    $selectionLink
                    <a class="btn sec" id="dlBackup" href="/backup.json?token=$safeToken">💾 تنزيل نسخة احتياطية JSON</a>
                    <a class="btn sec" id="dlFav" href="/favorites.m3u?token=$safeToken">⭐ تنزيل المفضّلة M3U</a>
                  </div>
                </form>
              </div>
              <script>
                var tk = document.getElementById('token');
                function syncLinks(){
                  var v = encodeURIComponent(tk.value.trim());
                  document.getElementById('dlBackup').href = '/backup.json?token=' + v;
                  document.getElementById('dlFav').href = '/favorites.m3u?token=' + v;
                  var sel = document.getElementById('dlSelection'); if(sel) sel.href = '/selection.m3u?token=' + v;
                }
                tk.addEventListener('input', syncLinks);
                syncLinks();
                document.getElementById('fpick').addEventListener('change', function(e){
                  var f = e.target.files[0];
                  if(!f) return;
                  var r = new FileReader();
                  r.onload = function(ev){ document.getElementById('bulk').value = ev.target.result; };
                  r.readAsText(f);
                });
              </script>
            </body>
            </html>
        """.trimIndent()
    }

    companion object {
        fun detectLanIp(): String {
            runCatching {
                val ifaces = NetworkInterface.getNetworkInterfaces()
                while (ifaces.hasMoreElements()) {
                    val nif = ifaces.nextElement()
                    if (!nif.isUp || nif.isLoopback) continue
                    val addrs = nif.inetAddresses
                    while (addrs.hasMoreElements()) {
                        val a = addrs.nextElement()
                        if (a is Inet4Address && !a.isLoopbackAddress) {
                            val ip = a.hostAddress.orEmpty()
                            if (ip.startsWith("192.168.") || ip.startsWith("10.") || ip.startsWith("172.")) {
                                return ip
                            }
                        }
                    }
                }
            }
            return "127.0.0.1"
        }
    }
}
