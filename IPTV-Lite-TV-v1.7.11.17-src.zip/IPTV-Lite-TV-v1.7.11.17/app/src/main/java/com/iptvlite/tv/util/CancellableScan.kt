package com.iptvlite.tv.util

internal object CancellableScan {
    /** One pass for combined predicates. Cooperative cancellation never returns a partial success. */
    fun <T> filter(items:List<T>,checkActive:()->Unit,predicate:(T)->Boolean):List<T> {
        val output=ArrayList<T>()
        for(i in items.indices) {
            if(i%128==0)checkActive()
            val item=items[i]
            if(predicate(item))output.add(item)
        }
        checkActive()
        return output
    }
}
