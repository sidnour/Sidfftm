package com.iptvlite.tv.util

import com.iptvlite.tv.BuildConfig

/** Debug system-trace spans only. Constant labels, no URLs, titles, accounts, logs or disk storage. */
internal object PerformanceTrace {
    inline fun <T> section(label:String,block:()->T):T {
        if(!BuildConfig.DEBUG)return block()
        android.os.Trace.beginSection(label)
        try {return block()}finally {android.os.Trace.endSection()}
    }
}
