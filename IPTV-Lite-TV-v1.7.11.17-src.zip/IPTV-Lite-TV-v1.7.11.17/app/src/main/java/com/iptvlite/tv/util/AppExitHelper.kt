package com.iptvlite.tv.util

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Process
import com.iptvlite.tv.model.PlayQueueHolder
import com.iptvlite.tv.network.PortalClient
import kotlin.system.exitProcess

object AppExitHelper {
    private val exiting=java.util.concurrent.atomic.AtomicBoolean(false)
    /** Close the window promptly; wait OFF the UI thread for file-finalization acknowledgment.
     * A 2.5s ceiling still guarantees termination if a provider/storage driver is stuck.
     * Explicit future scheduled recordings/reminders are not erased by closing the app. */
    fun terminateAppCompletely(activity:Activity) {
        if(!exiting.compareAndSet(false,true))return
        StreamRecorder.beginExit()
        val stopper=Thread({
            runCatching {StreamRecorder.stopAll()}
            runCatching {StreamRecorder.awaitFinalization(2_200L)}
        },"iptv-finalize-exit").apply {isDaemon=true;start()}
        runCatching {PlayQueueHolder.clear()}
        runCatching {com.iptvlite.tv.network.SelectedCategoryLoad.discard()}
        runCatching {LogoLoader.releaseAllForExit()}
        runCatching {PortalClient.shutdownForExit()}
        runCatching {
            val am=activity.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            am?.appTasks?.forEach {task->runCatching {task.finishAndRemoveTask()}}
        }
        runCatching {activity.finishAndRemoveTask()}
        runCatching {activity.finishAffinity()}
        Thread({
            runCatching {stopper.join(2_500L)}
            runCatching {Process.killProcess(Process.myPid())}
            exitProcess(0)
        },"iptv-exit").apply {isDaemon=true;start()}
    }
}
