package com.iptvlite.tv.util

/** Bounded, expiring negative cache; cancellation is NEVER a failure to record. */
internal class FailureBackoff(private val maxEntries:Int=512,private val ttlMs:Long=30_000,
    private val now:()->Long={android.os.SystemClock.elapsedRealtime()}) {
    private val failures=LinkedHashMap<String,Long>()
    @Synchronized fun blocked(key:String):Boolean {
        val at=failures[key] ?: return false
        if(now()-at>=ttlMs) {failures.remove(key);return false}
        return true
    }
    @Synchronized fun failed(key:String) {
        failures.remove(key);failures[key]=now()
        while(failures.size>maxEntries)failures.remove(failures.keys.first())
    }
    @Synchronized fun clear() {failures.clear()}
    @Synchronized fun size()=failures.size
}
