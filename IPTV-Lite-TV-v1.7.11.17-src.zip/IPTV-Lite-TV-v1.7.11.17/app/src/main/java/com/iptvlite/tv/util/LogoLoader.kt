package com.iptvlite.tv.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.View
import android.widget.ImageView
import com.iptvlite.tv.network.NetworkCleanup
import com.iptvlite.tv.network.PlaybackRequestScope
import com.iptvlite.tv.network.PortalClient
import okhttp3.Dispatcher
import okhttp3.Request
import java.lang.ref.WeakReference
import java.util.WeakHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** View-owned bounded image work. No activity/view retained by queued or blocked worker tasks. */
object LogoLoader {
    private val mainHandler=Handler(Looper.getMainLooper())
    private val lock=Any()
    private val requests=WeakHashMap<ImageView,LogoTask>()
    private val workQueue=LinkedBlockingQueue<Runnable>(16)
    private val pool=ThreadPoolExecutor(2,2,10L,TimeUnit.SECONDS,workQueue,
        ThreadPoolExecutor.AbortPolicy()).apply {allowCoreThreadTimeOut(true)}
    private fun enqueue(job:LogoTask) {
        try {pool.execute(job)}catch(_:java.util.concurrent.RejectedExecutionException) {
            if(pool.isShutdown) {job.retire();return}
            (workQueue.poll() as? LogoTask)?.retire()
            try {pool.execute(job)}catch(_:java.util.concurrent.RejectedExecutionException) {job.retire()}
        }
    }
    private val logoDispatcher=Dispatcher().apply {maxRequests=4;maxRequestsPerHost=2}
    private val client by lazy {
        PortalClient.rootHttp.newBuilder().dispatcher(logoDispatcher)
            .connectTimeout(3,TimeUnit.SECONDS).readTimeout(4,TimeUnit.SECONDS)
            .callTimeout(6,TimeUnit.SECONDS).retryOnConnectionFailure(false).build()
    }
    private val cache=object:LruCache<String,Bitmap>(5*1024*1024) {
        override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount
    }
    private val failures=FailureBackoff()
    @Volatile private var playbackActiveInternal=false
    private val detachListener=object:View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v:View) {}
        override fun onViewDetachedFromWindow(v:View) {if(v is ImageView)cancel(v,clear=false)}
    }
    var isPlaybackActive:Boolean
        get()=playbackActiveInternal
        set(value) {
            playbackActiveInternal=value
            if(value)retireWhere {!it.allowDuringPlayback}
            cache.resize(if(value)1024*1024 else 5*1024*1024)
        }
    private fun retireWhere(predicate:(LogoTask)->Boolean) {
        val jobs=synchronized(lock) {requests.values.toList().filter(predicate)}
        jobs.forEach {it.retire()}
    }
    fun clearPending() {retireWhere {workQueue.contains(it)}}
    fun trimMemory(clearAll:Boolean) {
        retireWhere {true}
        if(clearAll) {cache.evictAll();failures.clear()}else cache.resize(1024*1024)
    }
    fun releaseAllForExit() {
        trimMemory(true);mainHandler.removeCallbacksAndMessages(null)
        pool.shutdownNow();logoDispatcher.executorService.shutdownNow()
    }
    /** UI thread entry point. A late completion cannot affect a rebound image view. */
    fun cancel(imageView:ImageView,clear:Boolean=true) {
        val old=synchronized(lock) {requests.remove(imageView)}
        old?.retire()
        if(clear) {imageView.tag=null;imageView.setImageBitmap(null)}
    }
    fun load(url:String,imageView:ImageView,allowDuringPlayback:Boolean=false,isPoster:Boolean=false) {
        val clean=url.trim()
        val key=if(isPoster)"p|$clean" else clean
        val old=synchronized(lock) {requests[imageView]}
        if(old?.key==key && old.scope.isActive() && old.allowDuringPlayback==allowDuringPlayback)return
        cancel(imageView,clear=false)
        imageView.removeOnAttachStateChangeListener(detachListener)
        imageView.addOnAttachStateChangeListener(detachListener)
        imageView.tag=key
        if(!clean.startsWith("http://") && !clean.startsWith("https://")) {imageView.setImageBitmap(null);return}
        cache.get(key)?.let {imageView.setImageBitmap(it);return}
        imageView.setImageBitmap(null)
        if((playbackActiveInternal && !allowDuringPlayback) || failures.blocked(key))return
        val job=LogoTask(clean,key,isPoster,allowDuringPlayback,WeakReference(imageView))
        synchronized(lock) {requests[imageView]=job}
        enqueue(job)
    }
    private class LogoTask(val url:String,val key:String,val poster:Boolean,
        val allowDuringPlayback:Boolean,val target:WeakReference<ImageView>):Runnable {
        val scope=PlaybackRequestScope()
        fun retire() {
            scope.cancel {NetworkCleanup.cancel(it)}
            workQueue.remove(this)
            synchronized(lock) {target.get()?.let {if(requests[it]===this)requests.remove(it)}}
        }
        private fun current():Boolean = synchronized(lock) {
            val view=target.get()
            view!=null && requests[view]===this && scope.isActive() &&
                (!playbackActiveInternal || allowDuringPlayback)
        }
        override fun run() {
            try {
                if(!current())return
                val bmp=scope.run {fetchScaled(url,poster)}
                if(!current())return
                if(bmp==null) {failures.failed(key);return}
                cache.put(key,bmp)
                mainHandler.post {
                    if(current())target.get()?.setImageBitmap(bmp)
                    synchronized(lock) {target.get()?.let {if(requests[it]===this)requests.remove(it)}}
                }
            } catch(_:Exception) {
                // Cancellation, queue eviction and playback preemption must not poison retries.
            } finally {
                // Keep successful delivery owned until its UI callback; discard unsuccessful work.
                if(!scope.isActive() || !current())retire()
                else mainHandler.post {
                    synchronized(lock) {target.get()?.let {if(requests[it]===this)requests.remove(it)}}
                }
            }
        }
    }
    private fun fetchScaled(url:String,isPoster:Boolean):Bitmap? = PerformanceTrace.section("iptv.image.fetchDecode") {
        try {
            val req=Request.Builder().url(url).header("User-Agent","Mozilla/5.0").build()
            PlaybackRequestScope.withResponse(client,req) {resp->
                if(!resp.isSuccessful)return@withResponse null
                val body=resp.body ?: return@withResponse null
                val limit=if(isPoster)1_100_000 else 550_000
                if(body.contentLength()>limit)return@withResponse null
                val bytes=body.byteStream().use {BoundedInput.read(it,limit)}
                PlaybackRequestScope.checkCurrent()
                if(bytes.size<64)return@withResponse null
                val bounds=BitmapFactory.Options().apply {inJustDecodeBounds=true}
                BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
                if(bounds.outWidth<=0 || bounds.outHeight<=0)return@withResponse null
                val maxW=if(isPoster)200 else 112
                val maxH=if(isPoster)288 else 84
                var sample=1
                while(bounds.outWidth/sample>maxW || bounds.outHeight/sample>maxH)sample*=2
                PlaybackRequestScope.checkCurrent()
                val options=BitmapFactory.Options().apply {inSampleSize=sample;inPreferredConfig=Bitmap.Config.RGB_565}
                BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
            }
        } catch(e:java.util.concurrent.CancellationException) {throw e}
        catch(e:Exception) {PlaybackRequestScope.checkCurrent();null}
    }
}
