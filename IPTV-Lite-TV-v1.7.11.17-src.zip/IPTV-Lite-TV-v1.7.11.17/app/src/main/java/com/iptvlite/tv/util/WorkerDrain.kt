package com.iptvlite.tv.util

/** Acknowledgment follows file close/finalization, not merely a running=false flag. */
internal class WorkerDrain {
    private val lock=java.lang.Object()
    private val workers=HashMap<Thread,String>()
    fun register(thread:Thread,kind:String) {synchronized(lock) {workers[thread]=kind}}
    fun complete(thread:Thread) {synchronized(lock) {workers.remove(thread);lock.notifyAll()}}
    fun hasKind(kind:String):Boolean = synchronized(lock) {workers.containsValue(kind)}
    fun await(timeoutMs:Long):Boolean {
        val deadline=System.nanoTime()+java.util.concurrent.TimeUnit.MILLISECONDS.toNanos(timeoutMs.coerceIn(0L,10_000L))
        synchronized(lock) {
            while(workers.isNotEmpty()) {
                val left=deadline-System.nanoTime()
                if(left<=0L)return false
                java.util.concurrent.TimeUnit.NANOSECONDS.timedWait(lock,left)
            }
            return true
        }
    }
}
