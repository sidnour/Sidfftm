package com.iptvlite.tv.util

import java.io.OutputStream
import java.io.IOException

/** Worker-owned progress survives exceptions above the transfer loop. Never asserts fsync durability. */
internal class TransferOutput(private val target:OutputStream):OutputStream() {
    var bytesWritten=0L
        private set
    private var failure:Exception?=null
    private var finished=false
    private fun io(block:()->Unit) {
        try {block()} catch(e:Exception) {if(failure==null)failure=e;throw e}
    }
    override fun write(b:Int) {io {target.write(b);bytesWritten++}}
    override fun write(b:ByteArray,off:Int,len:Int) {io {target.write(b,off,len);bytesWritten+=len}}
    override fun flush() {io {target.flush()}}
    override fun close() {io {target.close()}}
    fun finish(publish:Boolean,publishFile:()->Unit,deleteFile:()->Unit):Result<Unit> {
        if(finished)return Result.failure(IOException("File already finalized"))
        finished=true
        // Always attempt close. Never publish a file whose output reported a failure.
        runCatching {close()}
        val error=failure
        if(error!=null)return Result.failure(error)
        return runCatching {if(publish)publishFile() else deleteFile()}
    }
}
