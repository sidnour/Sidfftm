package com.iptvlite.tv.util

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration

/** TV-only reading baseline. Does not change density, playback settings or phone resources. */
object TelevisionUi {
    fun isTelevision(context: Context): Boolean =
        (context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager)?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            (context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION

    fun wrap(base: Context): Context {
        if (!isTelevision(base)) return base
        val config = Configuration(base.resources.configuration)
        config.fontScale = readingScale(config.fontScale)
        return base.createConfigurationContext(config)
    }

    fun readingScale(systemScale: Float): Float = maxOf(systemScale, 1.20f)
}
