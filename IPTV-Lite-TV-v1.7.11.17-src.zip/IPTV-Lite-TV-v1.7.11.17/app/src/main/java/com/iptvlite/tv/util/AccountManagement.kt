package com.iptvlite.tv.util

import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.AccountStatusInfo
import com.iptvlite.tv.model.AccountAccess
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Locale

/** Explicit-probe evidence only; imported/legacy status text never authorizes bulk removal. */
internal object AccountManagement {
    const val FRESH_MS=30*60*1000L
    enum class Verdict(val label:String) {
        WORKING("الحساب يستجيب"),REJECTED("منتهي / مرفوض مؤكد"),UNCERTAIN("فشل مؤقت / غير مؤكد"),PENDING("جارٍ الفحص")
    }
    data class Evidence(val fingerprint:String,val attempt:String,val verdict:Verdict,val checkedAt:Long,val explicit:Boolean=true)
    fun host(account:AccountProfile):String = runCatching {
        val uri=URI(account.url.trim())
        val host=uri.host ?: return@runCatching if(uri.scheme in setOf("file","content"))"ملف محلي" else "عنوان غير محدد"
        host+if(uri.port>=0)":${uri.port}" else ""
    }.getOrDefault("عنوان غير محدد")
    fun filter(accounts:List<AccountProfile>,query:String):List<AccountProfile> {
        val q=query.trim()
        if(q.isEmpty())return accounts
        return accounts.filter {it.name.contains(q,true) || host(it).contains(q,true) ||
            runCatching {URI(it.url).rawPath.orEmpty().contains(q,true)}.getOrDefault(false)}
    }
    fun eligible(account:AccountProfile,e:Evidence?,now:Long):Boolean = e!=null &&
        e.explicit && e.verdict==Verdict.REJECTED && e.fingerprint==account.networkCacheKey() &&
        now>=e.checkedAt && now-e.checkedAt<=FRESH_MS
    fun classify(info:AccountStatusInfo,now:Long):Verdict {
        if(info.access==AccountAccess.REJECTED)return Verdict.REJECTED
        val raw=info.verifiedExpiry.takeIf {Regex("\\d{4}-\\d{2}-\\d{2}").matches(it)}
        if(raw!=null) {
            val format=SimpleDateFormat("yyyy-MM-dd",Locale.US).apply {isLenient=false}
            val expired=runCatching {format.parse(raw)!!.before(format.parse(format.format(java.util.Date(now))))}.getOrDefault(false)
            if(expired)return Verdict.REJECTED
        }
        if(info.pingMs>0 && info.access==AccountAccess.ACCEPTED)return Verdict.WORKING
        return Verdict.UNCERTAIN
    }
    fun classifyFailure(error:Throwable):Verdict =
        if(error is IllegalStateException && error.message=="بيانات دخول Xtream غير صحيحة")Verdict.REJECTED else Verdict.UNCERTAIN
}
