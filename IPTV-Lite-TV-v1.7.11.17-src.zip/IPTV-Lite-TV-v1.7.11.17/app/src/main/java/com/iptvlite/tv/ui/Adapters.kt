package com.iptvlite.tv.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.iptvlite.tv.R
import com.iptvlite.tv.model.CategoryItem
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.util.ListUpdates
import com.iptvlite.tv.util.PerformanceTrace
import com.iptvlite.tv.util.LogoLoader
import com.iptvlite.tv.util.MediaTitleFormatter
import com.iptvlite.tv.util.ThemeHelper

/**
 * تجزئة 64-بت سريعة بدون تخصيص ذاكرة (Zero-Allocation FNV-1a 64-bit)
 * تضمن ثبات المعرّف بغضّ النظر عن موضع العنصر (توافق تامّ مع عقد setHasStableIds)
 * مع منع تصادمات hashCode ذات الـ 32-بت في القوائم الضخمة (+30 ألف قناة).
 */
private fun stableId64(prefix: Int, rawId: String): Long {
    var h = -3750763034362895579L // FNV-1a 64-bit offset basis
    h = (h xor prefix.toLong()) * 1099511628211L
    for (i in 0 until rawId.length) {
        h = (h xor rawId[i].code.toLong()) * 1099511628211L
    }
    return h
}

class CategoryAdapter(
    private val onSelect: (CategoryItem, Int) -> Unit,
    private val onLongSelect: ((CategoryItem, Int) -> Unit)? = null
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    init {
        setHasStableIds(true)
    }

    private var items: List<CategoryItem> = emptyList()
    private var boundListTheme:Any?=null
    var selectedId: String = ""

    fun selectedIndex(): Int {
        val idx = items.indexOfFirst { it.id == selectedId }
        return if (idx >= 0) idx else 0
    }

    fun submit(newItemsRaw: List<CategoryItem>, activeId: String) {
        val next=ListUpdates.dedupe(newItemsRaw) {it.id}
        val oldSelection=selectedId
        val plan=ListUpdates.plan(items,next) {it.id}
        val theme=ThemeHelper.current.mode
        val themeChanged=boundListTheme!=theme
        boundListTheme=theme
        items=next
        selectedId=activeId
        if(plan.reset || themeChanged)notifyDataSetChanged()
        else {
            plan.removed?.let {notifyItemRangeRemoved(it.start,it.count)}
            plan.inserted?.let {notifyItemRangeInserted(it.start,it.count)}
            plan.changed.forEach {notifyItemRangeChanged(it.start,it.count)}
            if(oldSelection!=activeId)items.forEachIndexed {i,c->
                if(c.id==oldSelection || c.id==activeId)notifyItemChanged(i)
            }
        }
    }

    override fun getItemId(position: Int): Long {
        return stableId64(7, items[position].id)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val accentBar: View? = v.findViewById(R.id.catAccentBar)
        val tvTag: TextView? = v.findViewById(R.id.tvCatTag)
        val tvTitle: TextView = v.findViewById(R.id.tvCatTitle)
        val tvCount: TextView = v.findViewById(R.id.tvCatCount)
        var boundThemeMode: Any? = null

        init {
            ThemeHelper.attachFocusScale(v, 1.018f)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val pal = ThemeHelper.current
        val isSel = (item.id == selectedId)
        val parsed = MediaTitleFormatter.parseCategory(item.title)
        val density = holder.itemView.resources.displayMetrics.density

        holder.accentBar?.let { bar ->
            bar.setBackgroundColor(pal.accent)
            bar.visibility = if (isSel) View.VISIBLE else View.GONE
        }

        holder.tvTag?.let { tagView ->
            if (parsed.groupTag.isNotEmpty()) {
                tagView.text = parsed.groupTag
                tagView.setTextColor(pal.accent)
                tagView.visibility = View.VISIBLE
            } else {
                tagView.visibility = View.GONE
            }
        }

        val prefix = buildString {
            if (item.pinned) append("📌 ")
            if (item.locked) append("🔒 ")
        }
        holder.tvTitle.text = prefix + parsed.cleanTitle
        holder.tvTitle.setTextColor(if (isSel) pal.accent else pal.textPrimary)

        if (item.count > 0) {
            holder.tvCount.text = item.count.toString()
            holder.tvCount.setTextColor(pal.textSecondary)
            holder.tvCount.visibility = View.VISIBLE
        } else {
            holder.tvCount.visibility = View.GONE
        }

        if (holder.boundThemeMode != pal.mode) {
            holder.boundThemeMode = pal.mode
            holder.itemView.background = ThemeHelper.buildItemBackground(pal, 12f * density, density)
        }
        holder.itemView.isSelected = isSel
        holder.itemView.setOnClickListener {
            val curPos = holder.bindingAdapterPosition
            if (curPos !in items.indices) return@setOnClickListener
            val clicked = items[curPos]
            val oldPos = items.indexOfFirst { it.id == selectedId }
            selectedId = clicked.id
            if (oldPos >= 0 && oldPos != curPos) notifyItemChanged(oldPos)
            notifyItemChanged(curPos)
            onSelect(clicked, curPos)
        }
        holder.itemView.setOnLongClickListener {
            val curPos = holder.bindingAdapterPosition
            if (curPos in items.indices) {
                onLongSelect?.invoke(items[curPos], curPos)
            }
            true
        }
    }
}

class StreamAdapter(
    private val isFavFn: (String) -> Boolean,
    private val onClick: (StreamItem, Int, List<StreamItem>) -> Unit,
    private val onLongClick: ((StreamItem, Int) -> Unit)? = null,
    private val resumeBadgeFn: ((StreamItem) -> String)? = null,
    private val onItemFocused: ((Int) -> Unit)? = null
) : RecyclerView.Adapter<StreamAdapter.VH>() {

    init {
        setHasStableIds(true)
    }

    companion object {
        private const val VIEW_LIST = 0
        private const val VIEW_GRID = 1
        private val COLOR_GOLD = Color.parseColor("#FBBF24")
        private val COLOR_SKY = Color.parseColor("#38BDF8")
        private val COLOR_TAG_BLUE = Color.parseColor("#60A5FA")
        private val COLOR_MINT = Color.parseColor("#34D399")
        private val COLOR_INDIGO = Color.parseColor("#A5B4FC")
        private val COLOR_SLATE = Color.parseColor("#F8FAFC")
        private val COLOR_STAR_IDLE_GRID = Color.parseColor("#CBD5E1")
    }

    private var items: List<StreamItem> = emptyList()
    var gridMode: Boolean = false
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    fun submit(newItemsRaw: List<StreamItem>) {
        PerformanceTrace.section("iptv.streamList.update") {
            val next=ListUpdates.dedupe(newItemsRaw,ListUpdates::key)
            val plan=ListUpdates.planMatching(items,next) {a,b->a.accountId==b.accountId && a.kind==b.kind && a.id==b.id}
            items=next
            if(plan.reset)notifyDataSetChanged()
            else {
                plan.removed?.let {notifyItemRangeRemoved(it.start,it.count)}
                plan.inserted?.let {notifyItemRangeInserted(it.start,it.count)}
                plan.changed.forEach {notifyItemRangeChanged(it.start,it.count)}
            }
        }
    }

    fun currentItems(): List<StreamItem> = items

    override fun onViewDetachedFromWindow(holder:VH) {
        LogoLoader.cancel(holder.ivLogo,clear=false)
        super.onViewDetachedFromWindow(holder)
    }
    override fun onViewRecycled(holder:VH) {
        LogoLoader.cancel(holder.ivLogo)
        super.onViewRecycled(holder)
    }
    override fun onViewAttachedToWindow(holder:VH) {
        super.onViewAttachedToWindow(holder)
        val pos=holder.bindingAdapterPosition
        if(pos in items.indices)LogoLoader.load(items[pos].logo,holder.ivLogo,isPoster=gridMode)
    }

    override fun getItemViewType(position: Int): Int = if (gridMode) VIEW_GRID else VIEW_LIST

    override fun getItemId(position: Int): Long {
        val it = items[position]
        return ListUpdates.streamId(it)
    }

    inner class VH(v: View, isGridLayout: Boolean) : RecyclerView.ViewHolder(v) {
        val posterOrLogoFrame: View? = v.findViewById<View?>(R.id.posterFrame) ?: v.findViewById(R.id.logoFrame)
        val tvIndex: TextView = v.findViewById(R.id.tvIndex)
        val ivLogo: ImageView = v.findViewById(R.id.ivLogo)
        val tvTitle: TextView = v.findViewById(R.id.tvTitle)
        val tvSub: TextView = v.findViewById(R.id.tvSub)
        val tvStar: TextView = v.findViewById(R.id.tvStar)
        val tvRatingBadge: TextView? = v.findViewById(R.id.tvRatingBadge)
        val tvYearBadge: TextView? = v.findViewById(R.id.tvYearBadge)
        val tvQualityBadge: TextView? = v.findViewById(R.id.tvQualityBadge)
        val tvTagBadge: TextView? = v.findViewById(R.id.tvTagBadge)
        var boundThemeMode: Any? = null

        init {
            posterOrLogoFrame?.let { frame ->
                frame.outlineProvider = ViewOutlineProvider.BACKGROUND
                frame.clipToOutline = true
            }
            ThemeHelper.attachFocusScale(v, if (isGridLayout) 1.038f else 1.012f) { _, hasFocus ->
                if (!isGridLayout && com.iptvlite.tv.util.TelevisionUi.isTelevision(v.context)) {
                    tvTitle.isSelected = hasFocus
                    tvTitle.maxLines = if (hasFocus) 4 else 2
                }
                if (hasFocus) {
                    val curPos = bindingAdapterPosition
                    if (curPos != RecyclerView.NO_POSITION) {
                        onItemFocused?.invoke(curPos)
                    }
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val isGrid = viewType == VIEW_GRID
        val layoutRes = if (isGrid) R.layout.item_stream_grid else R.layout.item_stream
        val v = LayoutInflater.from(parent.context).inflate(layoutRes, parent, false)
        return VH(v, isGrid)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        val pal = ThemeHelper.current
        val isGrid = getItemViewType(position) == VIEW_GRID
        val density = holder.itemView.resources.displayMetrics.density
        if (holder.boundThemeMode != pal.mode) {
            holder.boundThemeMode = pal.mode
            val cardRadiusDp = if (isGrid) 16f else 13f
            holder.itemView.background = ThemeHelper.buildItemBackground(pal, cardRadiusDp * density, density)
            holder.posterOrLogoFrame?.background = ThemeHelper.buildPosterFrameBackground(
                p = pal,
                radiusDp = if (isGrid) 14f else 11f,
                density = density
            )
            holder.posterOrLogoFrame?.clipToOutline = true
        }

        val parsed = MediaTitleFormatter.parseMedia(item.name)
        val cleanRat = MediaTitleFormatter.formatRating(item.rating)
        val effectiveYear = item.year.trim().ifEmpty { parsed.extractedYear }
        val resumeBadge = resumeBadgeFn?.invoke(item).orEmpty()

        holder.tvTitle.text = parsed.cleanTitle
        holder.tvTitle.setTextColor(pal.textPrimary)

        if (isGrid) {
            val isCinemaPoster = item.kind == ItemKind.VOD || item.kind == ItemKind.SERIES || item.kind == ItemKind.EPISODE
            holder.ivLogo.scaleType = if (isCinemaPoster) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER

            when {
                parsed.qualityBadge.isNotEmpty() -> {
                    holder.tvIndex.text = parsed.qualityBadge
                    holder.tvIndex.setTextColor(if (parsed.qualityBadge == "4K") COLOR_GOLD else COLOR_SKY)
                }
                parsed.regionOrLangTag.isNotEmpty() -> {
                    holder.tvIndex.text = parsed.regionOrLangTag
                    holder.tvIndex.setTextColor(COLOR_TAG_BLUE)
                }
                else -> {
                    holder.tvIndex.text = "#${position + 1}"
                    holder.tvIndex.setTextColor(COLOR_SLATE)
                }
            }

            holder.tvRatingBadge?.let { rb ->
                when {
                    cleanRat.isNotEmpty() -> {
                        rb.text = "★ $cleanRat"
                        rb.setTextColor(COLOR_GOLD)
                        rb.visibility = View.VISIBLE
                    }
                    item.tvArchive -> {
                        rb.text = "↺ أرشيف"
                        rb.setTextColor(COLOR_MINT)
                        rb.visibility = View.VISIBLE
                    }
                    else -> rb.visibility = View.GONE
                }
            }

            holder.tvYearBadge?.let { yb ->
                if (effectiveYear.isNotEmpty()) {
                    yb.text = effectiveYear
                    yb.visibility = View.VISIBLE
                } else {
                    yb.visibility = View.GONE
                }
            }

            if (resumeBadge.isNotEmpty()) {
                holder.tvSub.text = resumeBadge
                holder.tvSub.setTextColor(COLOR_MINT)
                holder.tvSub.visibility = View.VISIBLE
            } else if (item.kind == ItemKind.VOD) {
                holder.tvSub.visibility = View.GONE
            } else {
                val subClean = MediaTitleFormatter.cleanSubtitle(item.subtitle)
                if (subClean.isNotEmpty()) {
                    holder.tvSub.text = subClean
                    holder.tvSub.setTextColor(pal.textSecondary)
                    holder.tvSub.visibility = View.VISIBLE
                } else {
                    holder.tvSub.visibility = View.GONE
                }
            }
        } else {
            holder.tvIndex.text = "${position + 1}"
            holder.tvIndex.setTextColor(pal.textSecondary)

            val subClean = MediaTitleFormatter.cleanSubtitle(item.subtitle)
            val baseSub = when {
                subClean.isNotEmpty() -> subClean
                effectiveYear.isNotEmpty() -> effectiveYear
                else -> ""
            }
            val displaySub = when {
                resumeBadge.isNotEmpty() && baseSub.isNotEmpty() && !baseSub.contains("متابعة") -> "$resumeBadge  ·  $baseSub"
                resumeBadge.isNotEmpty() -> resumeBadge
                else -> baseSub
            }
            if (displaySub.isNotEmpty()) {
                holder.tvSub.text = displaySub
                holder.tvSub.setTextColor(if (resumeBadge.isNotEmpty()) COLOR_MINT else pal.textSecondary)
                holder.tvSub.visibility = View.VISIBLE
            } else {
                holder.tvSub.visibility = View.GONE
            }

            holder.tvQualityBadge?.let { qb ->
                when {
                    parsed.qualityBadge.isNotEmpty() -> {
                        qb.text = parsed.qualityBadge
                        qb.setTextColor(
                            when (parsed.qualityBadge) {
                                "4K" -> COLOR_GOLD
                                "FHD", "50FPS", "60FPS" -> COLOR_SKY
                                else -> COLOR_INDIGO
                            }
                        )
                        qb.visibility = View.VISIBLE
                    }
                    cleanRat.isNotEmpty() -> {
                        qb.text = "★ $cleanRat"
                        qb.setTextColor(COLOR_GOLD)
                        qb.visibility = View.VISIBLE
                    }
                    else -> qb.visibility = View.GONE
                }
            }

            holder.tvTagBadge?.let { tb ->
                when {
                    item.tvArchive -> {
                        tb.text = "↺ أرشيف"
                        tb.setTextColor(COLOR_MINT)
                        tb.visibility = View.VISIBLE
                    }
                    parsed.regionOrLangTag.isNotEmpty() -> {
                        tb.text = parsed.regionOrLangTag
                        tb.setTextColor(COLOR_TAG_BLUE)
                        tb.visibility = View.VISIBLE
                    }
                    effectiveYear.isNotEmpty() && item.kind != ItemKind.LIVE -> {
                        tb.text = effectiveYear
                        tb.setTextColor(COLOR_SLATE)
                        tb.visibility = View.VISIBLE
                    }
                    else -> tb.visibility = View.GONE
                }
            }
        }

        val fav = isFavFn(item.favKey())
        holder.tvStar.text = if (fav) "★" else "☆"
        holder.tvStar.setTextColor(
            if (fav) COLOR_GOLD
            else if (isGrid) COLOR_STAR_IDLE_GRID
            else pal.textSecondary
        )
        LogoLoader.load(item.logo, holder.ivLogo, isPoster = isGrid)

        holder.itemView.isSelected = false
        holder.itemView.alpha = 1f
        holder.itemView.setOnClickListener {
            val curPos = holder.bindingAdapterPosition
            if (curPos in items.indices) {
                onClick(items[curPos], curPos, items)
            }
        }
        holder.itemView.setOnLongClickListener {
            val curPos = holder.bindingAdapterPosition
            if (curPos in items.indices) {
                onLongClick?.invoke(items[curPos], curPos)
            }
            true
        }
    }
}
