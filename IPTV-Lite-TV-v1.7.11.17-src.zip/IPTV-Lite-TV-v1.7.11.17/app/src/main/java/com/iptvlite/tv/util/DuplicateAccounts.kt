package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import java.net.URI
import java.util.Locale

/** Conservative identity: no probing, alias guessing, HTTP/HTTPS merging or portal-path rewriting. */
internal object DuplicateAccounts {
    data class Group(val members:List<AccountProfile>,val keeperId:String,val reason:String="") {
        val removable:List<AccountProfile> get()=if(reason.isEmpty())members.filterNot {it.id==keeperId}else emptyList()
    }
    data class Plan(val groups:List<Group>,val potential:List<List<AccountProfile>>) {
        val removable:List<AccountProfile> get()=groups.flatMap {it.removable}
    }
    fun mac(raw:String):String? {
        val compact=raw.trim().replace(":","").replace("-","")
        return compact.takeIf {Regex("[0-9a-fA-F]{12}").matches(it)}?.uppercase(Locale.US)
    }
    fun key(a:AccountProfile):String? = runCatching {
        val u=URI(a.url.trim())
        if(u.scheme?.lowercase(Locale.US) !in setOf("http","https") || u.host.isNullOrBlank())return null
        val identity=when(a.provider) {
            ProviderType.STALKER->mac(a.mac) ?: return null
            ProviderType.XTREAM->a.username.takeIf {it.isNotBlank()} ?: return null
            ProviderType.M3U->"playlist"
        }
        // Password/user/MAC/EPG differences are not silently discarded, including nonstandard provider fields.
        DataIdentity.digest(a.provider.name,DataIdentity.portalUrl(a.url),identity,
            if(a.provider==ProviderType.STALKER)"" else a.mac,a.username,a.password,a.epgUrl)
    }.getOrNull()
    fun plan(accounts:List<AccountProfile>,protected:Set<String>,activeId:String,unknownData:Boolean=false):Plan {
        val ids=accounts.map {it.id};val ambiguousIds=ids.size!=ids.toSet().size || ids.any {it.isBlank()}
        val groups=accounts.mapNotNull {a->key(a)?.let {it to a}}.groupBy({it.first},{it.second}).values
            .filter {it.size>1}.map {members->
                val keeper=members.firstOrNull {it.id==activeId} ?: members.minBy {it.id}
                val reason=when {
                    ambiguousIds->"معرّفات حسابات غير فريدة — يلزم مراجعة يدوية"
                    unknownData->"بيانات شخصية قديمة أو غير قابلة لتحديد المالك — حماية احترازية"
                    members.any {it.id in protected}->"توجد مفضلة أو سجل أو استئناف أو جداول مرتبطة — حماية المجموعة"
                    else->""
                }
                Group(members,keeper.id,reason)
            }
        val potential=accounts.filter {it.provider==ProviderType.STALKER && mac(it.mac)!=null && it.name.isNotBlank()}
            .groupBy {DataIdentity.digest(it.name.trim().lowercase(Locale.US),mac(it.mac)!!)}.values
            .filter {members->members.size>1 && members.map {key(it)}.distinct().size>1}
        return Plan(groups,potential)
    }
}
