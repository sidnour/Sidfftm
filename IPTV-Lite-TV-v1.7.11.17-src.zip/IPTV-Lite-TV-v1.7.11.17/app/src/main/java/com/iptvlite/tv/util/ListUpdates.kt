package com.iptvlite.tv.util

import com.iptvlite.tv.model.StreamItem

/** Linear, bounded plan. Reorders fall back to a reset; never claims append from endpoints alone. */
internal object ListUpdates {
    data class Range(val start:Int,val count:Int)
    data class Plan(val reset:Boolean=false,val changed:List<Range> = emptyList(),val inserted:Range?=null,val removed:Range?=null)
    data class StreamKey(val account:String,val kind:Int,val id:String)
    fun key(item:StreamItem)=StreamKey(item.accountId,item.kind.ordinal,item.id)
    fun streamId(item:StreamItem):Long {
        var h=-3750763034362895579L
        fun mix(v:Int) {h=(h xor v.toLong())*1099511628211L}
        mix(item.kind.ordinal+1);mix(item.accountId.length)
        for(c in item.accountId)mix(c.code)
        mix(item.id.length);for(c in item.id)mix(c.code)
        return h
    }
    fun <T,K> dedupe(items:List<T>,key:(T)->K):List<T> {
        val seen=HashSet<K>(items.size)
        return items.filter {seen.add(key(it))}
    }
    fun <T,K> plan(old:List<T>,new:List<T>,key:(T)->K):Plan = planMatching(old,new) {a,b->key(a)==key(b)}
    fun <T> planMatching(old:List<T>,new:List<T>,sameIdentity:(T,T)->Boolean):Plan {
        val common=minOf(old.size,new.size)
        val changed=ArrayList<Range>()
        var start=-1
        for(i in 0 until common) {
            if(!sameIdentity(old[i],new[i]))return Plan(reset=true)
            if(old[i]!=new[i]) {if(start<0)start=i}
            else if(start>=0) {changed.add(Range(start,i-start));start=-1}
        }
        if(start>=0)changed.add(Range(start,common-start))
        return Plan(changed=changed,
            inserted=if(new.size>old.size)Range(old.size,new.size-old.size)else null,
            removed=if(old.size>new.size)Range(new.size,old.size-new.size)else null)
    }
}
