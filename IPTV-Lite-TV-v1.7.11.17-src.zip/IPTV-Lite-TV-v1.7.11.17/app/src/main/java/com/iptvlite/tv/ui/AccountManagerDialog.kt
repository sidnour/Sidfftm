package com.iptvlite.tv.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.view.*
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iptvlite.tv.R
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.network.*
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.util.*
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentHashMap

/** Dialog-owned probes; local search; snapshot-checked deletion with a virtualized preview/list. */
internal class AccountManagerDialog(
    private val ctx:Context,private val store:AppStore,parent:CoroutineScope,
    private val onImport:()->Unit,private val onWeb:()->Unit,
    private val onLocal:(((String)->Unit)->Unit)?,private val onActivated:(AccountProfile)->Unit,
    private val onDeleted:(Set<String>)->Unit,private val onBackup:()->Unit
) {
    private val life=SupervisorJob(parent.coroutineContext[Job])
    private val scope=CoroutineScope(parent.coroutineContext+life)
    private val owners=java.util.Collections.newSetFromMap(ConcurrentHashMap<PlaybackRequestScope,Boolean>())
    private var searching:Job?=null
    private var all=emptyList<AccountProfile>()
    private var proofs=emptyMap<String,AccountManagement.Evidence>()
    private var running=false
    private var confirmation:AlertDialog?=null
    private val root=LinearLayout(ctx).apply {
        orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL
        setBackgroundResource(R.drawable.bg_dialog_surface);setPadding(dp(18),dp(14),dp(18),dp(12))
    }
    private val title=text("👤 إدارة السيرفرات",20).apply {setTypeface(typeface,Typeface.BOLD);setTextColor(Color.rgb(96,165,250))}
    private val banner=text("البحث محلي. الفحص لا يبدأ إلا بزرّ ⚡. أخطاء الشبكة ليست دليلًا على انتهاء الاشتراك.",14)
    private val search=EditText(ctx).apply {
        tag="account_search";hint="🔎 ابحث بالاسم أو عنوان السيرفر";setSingleLine(true);textSize=17f
        setTextColor(Color.WHITE);setHintTextColor(Color.rgb(203,213,225));setPadding(dp(12),dp(8),dp(12),dp(8))
        inputType=android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        contentDescription="البحث في السيرفرات"
    }
    private val count=text("",14).apply {tag="account_count"}
    private val list=RecyclerView(ctx).apply {
        tag="account_list";layoutManager=LinearLayoutManager(ctx);itemAnimator=null
        clipChildren=false;clipToPadding=false;setPadding(dp(2),dp(4),dp(2),dp(4))
    }
    private val adapter=Rows()
    private val dialog=AlertDialog.Builder(ctx).setView(root).create()
    private lateinit var probeAll:TextView
    private lateinit var deleteRejected:TextView
    private lateinit var deleteAll:TextView
    private lateinit var cleanDuplicates:TextView
    private fun dp(v:Int)=TvDialogs.dp(ctx,v)
    private fun text(value:String,size:Int)=TextView(ctx).apply {
        text=value;textSize=size.toFloat();setTextColor(Color.rgb(226,232,240));setPadding(0,dp(4),0,dp(4))
    }
    private fun button(value:String,action:()->Unit)=TvDialogs.makeTvButton(ctx,value,onClick=action).apply {textSize=16f}
    private fun busy()=LogoLoader.isPlaybackActive || StreamRecorder.isRecording() || StreamRecorder.isDownloading()
    private fun inform(message:String)=Toast.makeText(ctx,message,Toast.LENGTH_LONG).show()
    fun show():AlertDialog {
        root.addView(title);root.addView(banner);root.addView(search)
        val bar=LinearLayout(ctx).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val scroll=HorizontalScrollView(ctx).apply {isHorizontalScrollBarEnabled=false;addView(bar)}
        val add=button("➕ إضافة") {
            dialog.dismiss();TvDialogs.showAddOrEditAccountDialog(ctx,store,scope=launcherScope,
                existing=null,onPickLocalM3uFile=onLocal,onActivated=onActivated)
        }
        // Launchers below use the ACTIVITY scope supplied by the caller, not a dismissed dialog scope.
        bar.addView(add)
        bar.addView(button("📂 استيراد") {dialog.dismiss();onImport()})
        bar.addView(button("📋 لصق قائمة") {
            dialog.dismiss();TvDialogs.showBulkPasteDialog(ctx,store) {store.getActiveAccount()?.let(onActivated)}
        })
        bar.addView(button("🌐 Wi-Fi") {dialog.dismiss();onWeb()})
        bar.addView(button("🔗 جلب StbEmu") {
            dialog.dismiss();TvDialogs.showFetchStbEmuDialog(ctx,store,launcherScope,onImport,onWeb,onLocal,onActivated)
        })
        probeAll=button("⚡ فحص الكل") {launchProbes(store.getAccounts())}.apply {tag="account_probe_all"}
        bar.addView(probeAll);root.addView(scroll)
        val destructive=LinearLayout(ctx).apply {orientation=LinearLayout.HORIZONTAL}
        deleteRejected=button("🗑 حذف غير الصالحة…") {preview(store.rejectedAccounts(),true)}.apply {tag="account_delete_rejected"}
        deleteAll=button("🗑 حذف كل السيرفرات…") {preview(store.getAccounts(),false)}.apply {tag="account_delete_all"}
        cleanDuplicates=button("♻ تنظيف المكررات…") {openDuplicatePreview()}.apply {tag="account_clean_duplicates"}
        destructive.addView(cleanDuplicates);destructive.addView(deleteRejected);destructive.addView(deleteAll)
        root.addView(HorizontalScrollView(ctx).apply {isHorizontalScrollBarEnabled=false;addView(destructive)})
        root.addView(count)
        list.adapter=adapter
        root.addView(list,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
        root.addView(button("إغلاق") {dialog.dismiss()})
        search.doAfterTextChanged {filter()}
        dialog.setOnDismissListener {
            confirmation?.dismiss();confirmation=null
            owners.toList().forEach {it.cancel {call->NetworkCleanup.cancel(call)}}
            life.cancel();searching?.cancel()
        }
        life.invokeOnCompletion {
            android.os.Handler(android.os.Looper.getMainLooper()).post {if(dialog.isShowing)dialog.dismiss()}
        }
        dialog.show();dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((ctx.resources.displayMetrics.widthPixels*0.94).toInt(),(ctx.resources.displayMetrics.heightPixels*0.92).toInt())
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        refresh();add.requestFocus()
        return dialog
    }
    private val launcherScope=parent
    private fun refresh() {
        all=store.getAccounts();proofs=store.getAccountProbes()
        title.text="👤 إدارة السيرفرات (${all.size})"
        val eligible=all.count {AccountManagement.eligible(it,proofs[it.id],System.currentTimeMillis())}
        deleteRejected.text="🗑 حذف غير الصالحة ($eligible)…"
        probeAll.isEnabled=!running;deleteRejected.isEnabled=!running;deleteAll.isEnabled=!running;cleanDuplicates.isEnabled=!running
        adapter.notifyDataSetChanged();filter()
    }
    private fun filter() {
        searching?.cancel()
        val snapshot=all;val query=search.text.toString()
        searching=scope.launch {
            if(query.isNotBlank())delay(130)
            val matches=withContext(Dispatchers.Default) {AccountManagement.filter(snapshot,query)}
            if(!dialog.isShowing)return@launch
            adapter.items=matches;adapter.notifyDataSetChanged()
            count.text=if(matches.isEmpty())"لا نتائج — ${all.size} سيرفر محفوظ" else "عرض ${matches.size} من ${all.size} — الحذف الجماعي يشمل القائمة المحفوظة، لا نتائج البحث فقط"
        }
    }
    private fun launchProbes(accounts:List<AccountProfile>) {
        if(running)return
        if(accounts.isEmpty()) {inform("لا توجد سيرفرات للفحص");return}
        if(busy()) {inform("أوقف المشاهدة أو التسجيل أو التنزيل أولًا قبل فحص السيرفرات");return}
        running=true;refresh()
        scope.launch {
            var done=0
            try {
                banner.text="⏳ جارٍ الفحص الصريح لـ${accounts.size} سيرفر — حتى10 عمال…"
                // Preemption must be detected inside the pool, otherwise a busy signal from the user's
                // playback is reported as an ordinary probe failure instead of stopping the batch.
                val stopped=java.util.concurrent.atomic.AtomicBoolean(false)
                ProbeWorkPool.run(accounts,host={AccountManagement.host(it)}) {acc->
                    if(busy()) {stopped.set(true);throw CancellationException("Playback or recording started")}
                    probe(acc)
                    done++;banner.text="⏳ فُحص $done / ${accounts.size} — إغلاق النافذة يلغي الباقي"
                    if(done%10==0)refresh()
                }
                if(stopped.get())return@launch
                withContext(Dispatchers.IO) {store.sortAccountsByFastest()}
                banner.text="✔ اكتمل الفحص. الحذف يقبل الرفض/الانتهاء المؤكد خلال آخر30 دقيقة فقط؛ فشل الاتصال غير مؤكد."
            } catch(_:CancellationException) {
                if(dialog.isShowing)banner.text="توقف الفحص؛ النتائج غير المكتملة لا تدخل في الحذف الجماعي."
            } catch(_:Exception) {
                if(dialog.isShowing)banner.text="تعذّر إكمال الفحص؛ النتائج غير المكتملة لا تؤهل للحذف. يمكنك إعادة المحاولة."
            } finally {running=false;if(dialog.isShowing)refresh()}
        }
    }
    private suspend fun probe(acc:AccountProfile) {
        val token=withContext(Dispatchers.IO) {store.beginAccountProbe(acc)} ?: return
        val owner=PlaybackRequestScope();owners.add(owner)
        val expired=java.util.concurrent.atomic.AtomicBoolean(false)
        val deadline=scope.launch {
            delay(25_000L);expired.set(true);owner.cancel {NetworkCleanup.cancel(it)}
        }
        try {
            val info=withContext(Dispatchers.IO) {BrowseWork.run(owner) {PortalClient.fetchAccountStatus(acc,forceProbe=true)}}
            owner.checkActive();currentCoroutineContext().ensureActive()
            val verdict=AccountManagement.classify(info,System.currentTimeMillis())
            withContext(Dispatchers.IO) {store.finishAccountProbe(acc,token,verdict,info.expiry,info.status,
                if(verdict==AccountManagement.Verdict.WORKING)info.pingMs else -1)}
        } catch(e:Exception) {
            currentCoroutineContext().ensureActive()
            if((e is CancellationException || !owner.isActive()) && !expired.get())throw CancellationException("Probe preempted").apply {initCause(e)}
            val verdict=if(expired.get())AccountManagement.Verdict.UNCERTAIN else AccountManagement.classifyFailure(e)
            val status=if(expired.get())"انتهت مهلة الفحص — غير مؤكد" else verdict.label
            withContext(Dispatchers.IO) {store.finishAccountProbe(acc,token,verdict,"",status,-1)}
        } finally {deadline.cancel();owners.remove(owner);owner.cancel {NetworkCleanup.cancel(it)}}
    }
    private fun openDuplicatePreview() {
        if(running)return
        if(busy()) {inform("أوقف التشغيل أو التسجيل أو التنزيل قبل تنظيف المكررات");return}
        scope.launch {
            cleanDuplicates.isEnabled=false
            val plan=try {withContext(Dispatchers.IO) {store.duplicateAccountPlan()}}
                finally {if(dialog.isShowing)cleanDuplicates.isEnabled=!running}
            if(!dialog.isShowing || running)return@launch
            if(plan.groups.isEmpty() && plan.potential.isEmpty()) {inform("لا توجد مكررات مطابقة أو تشابهات تحتاج مراجعة");return@launch}
            confirmation?.dismiss()
            val lines=ArrayList<String>()
            fun label(a:AccountProfile)="${a.name.ifBlank {"بدون اسم"}} — ${AccountManagement.host(a)} [${a.provider.label}]"
            plan.groups.forEachIndexed {i,g->
                lines.add("المجموعة ${i+1} — ${g.members.size} حسابات")
                if(g.reason.isNotEmpty()) {
                    lines.add("🔒 لن تُنظّف: ${g.reason}")
                    g.members.forEach {lines.add("محفوظ: ${label(it)}")}
                } else {
                    g.members.firstOrNull {it.id==g.keeperId}?.let {lines.add("✔ الاحتفاظ: ${label(it)}${if(it.id==store.getActiveAccount()?.id)" — الحساب النشط" else ""}")}
                    g.removable.forEach {lines.add("🗑 سيُحذف: ${label(it)}")}
                }
            }
            plan.potential.forEach {members->
                lines.add("⚠ تشابه الاسم والـMAC مع اختلاف العنوان أو الإعدادات — للمراجعة فقط؛ لا دمج لهذه الاختلافات")
                members.forEach {lines.add(label(it))}
            }
            val box=LinearLayout(ctx).apply {orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(16),dp(8),dp(16),dp(8))}
            box.addView(text("تنظيف محلي دون فحص شبكة. سيُحذف ${plan.removable.size} حساب مكرر فقط من كامل القائمة المحفوظة، لا نتائج البحث وحدها. تطابق الاسم وحده لا يكفي، واختلاف بيانات الاتصال أو دليل البرامج يمنع الدمج.",15))
            box.addView(RecyclerView(ctx).apply {
                layoutManager=LinearLayoutManager(ctx)
                adapter=object:RecyclerView.Adapter<PreviewVH>() {
                    override fun getItemCount()=lines.size
                    override fun onCreateViewHolder(parent:ViewGroup,viewType:Int)=PreviewVH(text("",16))
                    override fun onBindViewHolder(holder:PreviewVH,position:Int) {holder.label.text=lines[position]}
                }
            },LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(210)))
            box.addView(text("الحساب النشط يبقى. أي مجموعة مرتبطة بمفضلة أو سجل أو استئناف أو جداول محمية بالكامل. لا نقل بيانات ولا إلغاء اشتراك لدى المزوّد. أنشئ نسخة احتياطية أولًا.",14))
            confirmation=AlertDialog.Builder(ctx).setTitle("♻ معاينة تنظيف المكررات")
                .setView(box).setNegativeButton("إلغاء",null)
                .setNeutralButton("نسخة احتياطية أولًا") {_,_->dialog.dismiss();onBackup()}
                .setPositiveButton("تنظيف ${plan.removable.size} مكرر") {_,_->
                    if(!dialog.isShowing)return@setPositiveButton
                    val result=store.deleteDuplicateAccounts(plan,isBusy={busy() || running})
                    when {
                        result.blocked->inform("أُوقف التنظيف: يوجد تشغيل أو تسجيل أو تنزيل أو فحص جارٍ")
                        result.failed->inform("تعذّر حفظ التنظيف؛ لم يُعتمد النجاح")
                        else->{
                            if(result.removed.isNotEmpty())onDeleted(result.removed)
                            banner.text="♻ نُظّف ${result.removed.size} مكرر — تم تجاوز ${result.skipped} حساب لتغيّر المجموعة أو الحماية. لم تُنقل أي بيانات شخصية."
                        }
                    }
                    confirmation=null;refresh()
                }.show()
            confirmation?.getButton(AlertDialog.BUTTON_POSITIVE)?.isEnabled=plan.removable.isNotEmpty()
            confirmation?.getButton(AlertDialog.BUTTON_NEGATIVE)?.requestFocus()
        }
    }

    private fun preview(expected:List<AccountProfile>,rejectedOnly:Boolean) {
        if(running)return
        if(busy()) {inform("أوقف التشغيل أو التسجيل أو التنزيل قبل حذف السيرفرات");return}
        if(expected.isEmpty()) {
            inform(if(rejectedOnly)"لا توجد نتائج رفض/انتهاء مؤكدة وحديثة. نفّذ فحصًا صريحًا؛ أخطاء الشبكة والسيرفرات غير المفحوصة لا تُحذف تلقائيًا." else "لا توجد سيرفرات محفوظة")
            return
        }
        confirmation?.dismiss()
        val box=LinearLayout(ctx).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(16),dp(8),dp(16),dp(8));layoutDirection=View.LAYOUT_DIRECTION_RTL}
        box.addView(text("سيُحذف ${expected.size} سيرفر من التطبيق فقط. لن تُحذف الاشتراكات لدى المزوّد. المفضلة والسجل والاستئناف والجداول تبقى بحساباتها الأصلية؛ الحساب المحذوف يحتاج إعادة ربط/استعادة صحيحة ولا يُنقل لحساب آخر.",15))
        val preview=RecyclerView(ctx).apply {layoutManager=LinearLayoutManager(ctx);adapter=Preview(expected)}
        box.addView(preview,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(200)))
        box.addView(text("يشمل الحسابات أعلاه حتى لو كانت مخفية ببحثك. أي حساب أُضيف أو تغيّر بعد المعاينة لن يُحذف. يُنصح بنسخة احتياطية أولًا.",14))
        confirmation=AlertDialog.Builder(ctx).setTitle(if(rejectedOnly)"تأكيد حذف غير الصالحة" else "تأكيد حذف السيرفرات المحددة")
            .setView(box).setNegativeButton("إلغاء",null)
            .setNeutralButton("نسخة احتياطية أولًا") {_,_->dialog.dismiss();onBackup()}
            .setPositiveButton("حذف ${expected.size} سيرفر") {_,_->
                if(!dialog.isShowing)return@setPositiveButton
                val result=store.deleteAccountsIfUnchanged(expected,rejectedOnly,isBusy={busy()})
                when {
                    result.blocked->inform("لم يُحذف شيء: يوجد تشغيل أو تسجيل أو تنزيل جارٍ")
                    result.failed->inform("تعذّر حفظ التغييرات؛ لم يُعتمد الحذف")
                    else->{
                        if(result.removed.isNotEmpty())onDeleted(result.removed)
                        banner.text="حُذف ${result.removed.size} سيرفر — تم تجاوز ${result.skipped} حساب تغيّر أو لم يعد مؤهلًا. البيانات الشخصية محفوظة."
                    }
                }
                confirmation=null;refresh()
            }.show()
        confirmation?.getButton(AlertDialog.BUTTON_NEGATIVE)?.requestFocus()
    }
    private inner class Preview(private val entries:List<AccountProfile>):RecyclerView.Adapter<PreviewVH>() {
        override fun getItemCount()=entries.size
        override fun onCreateViewHolder(parent:ViewGroup,viewType:Int)=PreviewVH(text("",16))
        override fun onBindViewHolder(holder:PreviewVH,position:Int) {
            val a=entries[position];holder.label.text="${position+1}. ${a.name.ifBlank {AccountManagement.host(a)}} — ${AccountManagement.host(a)}"
        }
    }
    private class PreviewVH(val label:TextView):RecyclerView.ViewHolder(label)
    private inner class Rows:RecyclerView.Adapter<Row>() {
        var items=emptyList<AccountProfile>()
        init {setHasStableIds(false)}
        override fun getItemCount()=items.size
        override fun onCreateViewHolder(parent:ViewGroup,viewType:Int):Row {
            val box=LinearLayout(ctx).apply {
                orientation=LinearLayout.VERTICAL;setBackgroundResource(R.drawable.bg_tv_row)
                setPadding(dp(10),dp(7),dp(10),dp(7))
                layoutParams=RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT).apply {bottomMargin=dp(6)}
            }
            val info=text("",17);box.addView(info,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
            val actions=LinearLayout(ctx).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.END}
            val p=button("⚡") {};val use=button("▶ تفعيل") {};val edit=button("✎") {};val del=button("🗑") {}
            listOf(p,use,edit,del).forEach {actions.addView(it)}
            box.addView(actions)
            return Row(box,info,p,use,edit,del)
        }
        override fun onBindViewHolder(holder:Row,position:Int) {
            val a=items[position];val e=proofs[a.id]?.takeIf {it.explicit && it.fingerprint==a.networkCacheKey()}
            val age=e?.let {System.currentTimeMillis()-it.checkedAt}
            val state=when {
                e==null->"غير مفحوص يدويًا"
                e.verdict==AccountManagement.Verdict.PENDING && !running->"فحص غير مكتمل — أعد الفحص"
                age==null || age<0 || age>AccountManagement.FRESH_MS->"نتيجة قديمة — أعد الفحص"
                else->e.verdict.label
            }
            holder.info.text="${if(store.getActiveAccount()?.id==a.id)"✔ " else ""}${a.name.ifBlank {AccountManagement.host(a)}} [${a.provider.label}]\n${AccountManagement.host(a)} · $state"
            holder.info.setTextColor(when(e?.verdict) {
                AccountManagement.Verdict.REJECTED->Color.rgb(252,165,165)
                AccountManagement.Verdict.WORKING->Color.rgb(110,231,183)
                else->Color.rgb(241,245,249)
            })
            holder.probe.isEnabled=!running;holder.del.isEnabled=!running;holder.edit.isEnabled=!running
            holder.probe.setOnClickListener {launchProbes(listOf(a))}
            holder.use.setOnClickListener {
                val current=store.getAccounts().firstOrNull {it.id==a.id} ?: return@setOnClickListener
                if(busy() && store.getActiveAccount()?.id!=a.id) {inform("أوقف التشغيل أو التسجيل أو التنزيل قبل تبديل الحساب");return@setOnClickListener}
                store.setActiveAccountId(current.id);dialog.dismiss();onActivated(current)
            }
            holder.edit.setOnClickListener {
                val current=store.getAccounts().firstOrNull {it.id==a.id} ?: return@setOnClickListener
                dialog.dismiss();TvDialogs.showAddOrEditAccountDialog(ctx,store,launcherScope,current,onLocal,onActivated)
            }
            holder.del.setOnClickListener {preview(listOf(a),false)}
        }
    }
    private class Row(view:View,val info:TextView,val probe:TextView,val use:TextView,val edit:TextView,val del:TextView):RecyclerView.ViewHolder(view)
}
