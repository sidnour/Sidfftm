package com.iptvlite.tv.util

/** Intent extras are not part of PendingIntent identity. Preserve the complete ID in data. */
object ScheduleIdentity {
    fun data(action: String, id: String): String = "iptvlite://schedule/"+
        java.net.URLEncoder.encode(action,"UTF-8")+"/"+java.net.URLEncoder.encode(id,"UTF-8")
}
