package com.iptvlite.tv.network

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/** The cancellation decision and its target always come from ONE ownership snapshot. */
internal class SessionFlight {
    internal data class Owner(val scope:PlaybackRequestScope?,val priority:Boolean)
    private class Slot {
        val lock=ReentrantLock(true)
        @Volatile var owner:Owner?=null
    }
    private val slots=ConcurrentHashMap<String,Slot>()
    internal fun preempt(snapshot:Owner?,priority:Boolean,cancel:(PlaybackRequestScope)->Unit) {
        if(priority && snapshot!=null && !snapshot.priority) snapshot.scope?.let(cancel)
    }
    fun <T> run(key:String,priority:Boolean,block:()->T):T {
        val slot=slots.getOrPut(key) {Slot()}
        while(!slot.lock.tryLock(25,TimeUnit.MILLISECONDS)) {
            PlaybackRequestScope.checkCurrent()
            preempt(slot.owner,priority) {it.cancel {call->NetworkCleanup.cancel(call)}}
        }
        val previous=slot.owner
        try {
            PlaybackRequestScope.checkCurrent()
            slot.owner=Owner(PlaybackRequestScope.currentScope(),priority)
            return block()
        } finally {slot.owner=previous;slot.lock.unlock()}
    }
}
