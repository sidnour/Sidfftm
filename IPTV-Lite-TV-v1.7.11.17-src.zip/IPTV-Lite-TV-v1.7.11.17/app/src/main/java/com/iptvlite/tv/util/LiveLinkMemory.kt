package com.iptvlite.tv.util

/** Activity-owned RAM only. Never log or persist URLs, cookies or keys. */
class LiveLinkMemory(private val capacity: Int = 16) {
    data class Link(val url: String, val userAgent: String, val headers: Map<String, String>)
    private val confirmed = object : LinkedHashMap<String, Link>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Link>?): Boolean {
            val remove = size > capacity
            if (remove) eldest?.key?.let { reuseCounts.remove(it) }
            return remove
        }
    }
    private val reuseCounts = HashMap<String, Int>()
    fun confirm(key: String, link: Link) {
        if (link.url.isBlank()) return
        confirmed[key] = link.copy(headers = link.headers.toMap())
    }
    /** Exactly two actual cached opens without sustained playback, then resolve fresh. */
    fun nextReuse(key: String): Link? {
        val link = confirmed[key] ?: return null
        val count = reuseCounts[key] ?: 0
        if (count >= 2) return null
        reuseCounts[key] = count + 1
        return link.copy(headers = link.headers.toMap())
    }
    fun reject(key: String) { confirmed.remove(key); reuseCounts.remove(key) }
    fun stable(key: String) { reuseCounts.remove(key) }
    fun clear() { confirmed.clear(); reuseCounts.clear() }
}
