package com.iptvlite.tv.network

import okhttp3.Call
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/** Socket TLS shutdown can perform network I/O. Worker expires after idle cleanup. */
object NetworkCleanup {
    private val worker=ThreadPoolExecutor(0,1,2L,TimeUnit.SECONDS,LinkedBlockingQueue<Runnable>()) { task ->
        Thread(task,"iptv-socket-cleanup").apply { isDaemon=true }
    }
    fun execute(block:()->Unit) { worker.execute { runCatching(block) } }
    private fun offMain(block:()->Unit) {
        val main=android.os.Looper.getMainLooper()
        if(main!=null && android.os.Looper.myLooper()!==main) runCatching(block)
        else execute(block)
    }
    fun evictIdle(pool: okhttp3.ConnectionPool) { offMain { pool.evictAll() } }
    fun cancel(call: Call) { offMain { call.cancel() } }
    fun cancelCurrent(dispatcher: Dispatcher) {
        // Snapshot NOW. Never let late cancellation select a newly requested channel.
        val calls=dispatcher.queuedCalls()+dispatcher.runningCalls()
        if(calls.isNotEmpty())offMain { calls.forEach { runCatching { it.cancel() } } }
    }
    /** Only for detached activity-owned clients, never for shared provider transports. */
    fun close(client: OkHttpClient?) {
        if(client==null)return
        execute {
            try { client.dispatcher.cancelAll();client.connectionPool.evictAll() }
            finally { client.dispatcher.executorService.shutdown() }
        }
    }
}
