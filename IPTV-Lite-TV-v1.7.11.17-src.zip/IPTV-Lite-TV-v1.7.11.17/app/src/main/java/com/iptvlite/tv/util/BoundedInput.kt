package com.iptvlite.tv.util

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream

/** Bounds bytes actually read, including chunked streams and misleading length headers. */
object BoundedInput {
    class TooLarge : IOException("Input exceeds size limit")
    fun read(input: InputStream, maxBytes: Int): ByteArray {
        require(maxBytes >= 0)
        val output=ByteArrayOutputStream(minOf(maxBytes,8192))
        val buffer=ByteArray(8192)
        var total=0
        while(true) {
            if(Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException("Read cancelled")
            // Read no more than the limit + one sentinel byte, even for oversized streams.
            val size=minOf(buffer.size.toLong(),maxBytes.toLong()-total+1).toInt()
            val count=input.read(buffer,0,size)
            if(count<0)break
            if(count==0) {
                val one=input.read()
                if(one<0)break
                if(total>=maxBytes)throw TooLarge()
                output.write(one);total++
                continue
            }
            if(count>maxBytes-total)throw TooLarge()
            output.write(buffer,0,count);total+=count
        }
        return output.toByteArray()
    }
}
