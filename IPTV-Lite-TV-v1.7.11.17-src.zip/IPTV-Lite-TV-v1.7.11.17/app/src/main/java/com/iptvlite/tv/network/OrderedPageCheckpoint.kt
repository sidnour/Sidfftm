package com.iptvlite.tv.network

/** Provider-driven end detection; five is a concurrency window, NEVER a catalogue/page cap. */
internal class OrderedPageCheckpoint<T>(private val identity:(T)->String) {
    data class Page<T>(val items:List<T>,val rawCount:Int,val total:Int=0,val pageSize:Int=0,val totalPages:Int=0)
    data class Snapshot<T>(val items:List<T>,val total:Int,val complete:Boolean,val error:String?=null)
    private val pages=java.util.TreeMap<Int,Page<T>>()
    private var cached:Snapshot<T>?=null
    @Synchronized fun has(page:Int)=pages.containsKey(page)
    @Synchronized fun put(page:Int,value:Page<T>) {
        require(page>0 && value.rawCount>=0 && value.total>=0 && value.pageSize>=0 && value.totalPages>=0)
        pages[page]=value;cached=null
    }
    private fun width(first:Page<T>):Int = first.pageSize.takeIf {it>0} ?: first.rawCount.takeIf {it>0} ?: 14
    private fun last(first:Page<T>):Long? {
        if(first.totalPages>0)return first.totalPages.toLong()
        if(first.total>0)return (first.total.toLong()+width(first)-1)/width(first)
        return null
    }
    @Synchronized fun snapshot():Snapshot<T> {
        cached?.let {return it}
        val first=pages[1] ?: return Snapshot(emptyList(),0,false)
        val out=ArrayList<T>();val seen=HashSet<String>()
        val total=first.total
        val end=last(first)
        fun result(complete:Boolean=false,error:String?=null):Snapshot<T> =
            Snapshot(out.toList(),total,complete,error).also {cached=it}
        var number=1L
        while(number<=Int.MAX_VALUE) {
            val p=pages[number.toInt()] ?: return result()
            if((p.total>0 && total>0 && p.total!=total) ||
                (p.totalPages>0 && first.totalPages>0 && p.totalPages!=first.totalPages))
                return result(error="تغيّر العدد المعلن أثناء التحميل؛ أعد فتح الفئة")
            val before=out.size
            p.items.forEach {if(seen.add(identity(it)))out.add(it)}
            if(total>0 && out.size>total)return result(error="عدد العناصر يتجاوز الإجمالي المعلن من السيرفر")
            if(p.rawCount>0 && out.size==before)return result(error="السيرفر يعيد صفحة مكررة أو بلا عناصر صالحة")
            if(p.rawCount==0) {
                if((total>0 && out.size<total) || (first.totalPages>0 && number<first.totalPages))
                    return result(error="أعاد السيرفر صفحة فارغة قبل اكتمال العدد المعلن")
                return result(complete=true)
            }
            if(total>0 && out.size==total) {
                if(first.totalPages>0 && number<first.totalPages)
                    return result(error="عدد الصفحات لا يطابق إجمالي العناصر المعلن")
                return result(complete=true)
            }
            if(end!=null && number>=end) {
                if(total>0 && out.size<total)return result(error="عدد الصفحات أو حجمها لا يطابق إجمالي العناصر المعلن")
                return result(complete=true)
            }
            // Unknown total: a short nonempty page is NOT sufficient proof of the end.
            number++
        }
        return result(error="رقم الصفحة خارج المجال الذي يدعمه بروتوكول الطلب")
    }
    @Synchronized fun missing(limit:Int):List<Int> {
        if(!pages.containsKey(1))return listOf(1)
        val snap=snapshot()
        snap.error?.let {throw IllegalStateException(it)}
        if(snap.complete)return emptyList()
        var first=1L
        while(first<=Int.MAX_VALUE && pages.containsKey(first.toInt()))first++
        val last=last(pages[1]!!) ?: Int.MAX_VALUE.toLong()
        if(first>last || first>Int.MAX_VALUE)throw IllegalStateException("بيانات ترقيم الصفحات غير متسقة")
        val windowEnd=minOf(last,first+4,Int.MAX_VALUE.toLong())
        return (first..windowEnd).filterNot {pages.containsKey(it.toInt())}.take(limit.coerceIn(1,5)).map {it.toInt()}
    }
}
