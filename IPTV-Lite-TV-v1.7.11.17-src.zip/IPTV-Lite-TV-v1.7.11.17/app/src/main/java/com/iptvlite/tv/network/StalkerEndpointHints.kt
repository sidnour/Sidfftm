package com.iptvlite.tv.network

import android.content.SharedPreferences
import com.iptvlite.tv.model.AccountProfile
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONObject
import java.security.MessageDigest

/** Discovery hints only, never authentication or media URLs. Failure is always non-fatal. */
internal class StalkerEndpointHints(private val prefs: SharedPreferences) {
    companion object { const val PREFERENCES="stalker_endpoint_hints_v1"; const val MAX_ENTRIES=128 }
    private fun key(acc: AccountProfile): String {
        // Exact URL path/case and account ID matter. Changed portal/MAC cannot inherit an old hint.
        val identity=listOf(acc.provider.name,acc.id,acc.url.trim().trimEnd('/'),acc.mac.trim())
            .joinToString("") { "${it.length}:$it" }
        return MessageDigest.getInstance("SHA-256").digest(identity.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 255) }
    }
    private fun safe(pair: Pair<String,String>, candidates: List<Pair<String,String>>): Boolean {
        if(pair !in candidates)return false // Exact pair from the current portal's discovery set only.
        return listOf(pair.first,pair.second).all { raw ->
            val url=raw.toHttpUrlOrNull()
            url!=null && raw.length<=2048 && url.username.isEmpty() && url.password.isEmpty() &&
                url.encodedQuery==null && url.fragment==null
        }
    }
    @Synchronized fun load(acc: AccountProfile,candidates: List<Pair<String,String>>): Pair<String,String>? = try {
        val k=key(acc)
        val value=prefs.getString(k,null)
        if(value==null)null else {
            val json=JSONObject(value)
            val pair=json.optString("endpoint") to json.optString("referer")
            if(safe(pair,candidates))pair else {prefs.edit().remove(k).commit();null}
        }
    } catch(_:Exception) { null }
    @Synchronized fun save(acc: AccountProfile,pair: Pair<String,String>,candidates: List<Pair<String,String>>) {
        try {
            if(!safe(pair,candidates))return
            val k=key(acc)
            val previous=prefs.getString(k,null)?.let { runCatching { JSONObject(it) }.getOrNull() }
            if(previous!=null && previous.optString("endpoint")==pair.first && previous.optString("referer")==pair.second)return
            val editor=prefs.edit()
            val entries=prefs.all
            if(!entries.containsKey(k) && entries.size>=MAX_ENTRIES) {
                entries.entries.sortedBy { entry ->
                    runCatching { JSONObject(entry.value as String).optLong("saved_at") }.getOrDefault(0L)
                }.take(entries.size-MAX_ENTRIES+1).forEach { editor.remove(it.key) }
            }
            val value=JSONObject().put("endpoint",pair.first).put("referer",pair.second)
                .put("saved_at",System.currentTimeMillis()).toString()
            // Called after network discovery on IO, and only for a new/changed endpoint.
            // Commit before returning so explicit exit/process death does not race an async write.
            editor.putString(k,value).commit()
        } catch(_:Exception) { /* Discovery continues normally if local storage is unavailable. */ }
    }
    @Synchronized fun forgetIfMatches(acc: AccountProfile,expected: Pair<String,String>) {
        try {
            val k=key(acc);val value=prefs.getString(k,null) ?: return
            val json=JSONObject(value)
            if(json.optString("endpoint")==expected.first && json.optString("referer")==expected.second)
                prefs.edit().remove(k).commit()
        } catch(_:Exception) { }
    }
}
