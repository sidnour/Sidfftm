package com.iptvlite.tv.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.util.ScheduleHelper

/**
 * مستقبل إقلاع الجهاز وتحديث التطبيق (مفصول أمنياً عن أوامر التسجيل الداخلية):
 * يعيد جدولة المنبّهات الدقيقة بعد إعادة تشغيل التلفاز/الهاتف على Android 5–14+.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_MY_PACKAGE_REPLACED) {
            return
        }
        val appCtx = context.applicationContext
        PortalClient.initAppContext(appCtx)
        val store = AppStore(appCtx)
        ScheduleHelper.rescheduleAll(appCtx, store)
    }
}
