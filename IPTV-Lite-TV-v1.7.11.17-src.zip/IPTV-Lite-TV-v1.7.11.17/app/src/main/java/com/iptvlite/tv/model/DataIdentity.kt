package com.iptvlite.tv.model

import java.net.URI
import java.security.MessageDigest
import java.util.Locale

/** Length-delimited hashes avoid delimiter collisions and never expose credentials in cache keys. */
internal object DataIdentity {
    fun digest(vararg fields: String): String {
        val raw=fields.joinToString("") { "${it.length}:$it" }
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(Locale.US,it.toInt() and 255) }
    }
    fun portalUrl(raw:String):String {
        val value=raw.trim()
        return runCatching {
            val u=URI(value)
            // Only HTTP scheme/host are case-insensitive; path/query and userinfo retain their case.
            if(u.scheme?.lowercase(Locale.US) !in listOf("http","https") || u.host==null) value
            else {
                val host=u.host.lowercase(Locale.US)
                val normalizedHost=if(host.contains(':') && !host.startsWith("[")) "[$host]" else host
                val port=if(u.port<0 || (u.port==80 && u.scheme.equals("http",true)) ||
                    (u.port==443 && u.scheme.equals("https",true))) "" else ":${u.port}"
                "${u.scheme.lowercase(Locale.US)}://${u.rawUserInfo?.let { "$it@" }.orEmpty()}$normalizedHost$port${u.rawPath.orEmpty()}"+
                    u.rawQuery?.let { "?$it" }.orEmpty()+u.rawFragment?.let { "#$it" }.orEmpty()
            }
        }.getOrDefault(value)
    }
    fun item(accountId:String,kind:ItemKind,id:String):String =
        if(accountId.isBlank()) "${kind.name}:$id" else "item_v2_${digest(accountId,kind.name,id)}"
}
