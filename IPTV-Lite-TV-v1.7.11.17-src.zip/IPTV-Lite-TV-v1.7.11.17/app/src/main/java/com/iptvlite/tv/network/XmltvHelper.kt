package com.iptvlite.tv.network

import com.iptvlite.tv.model.EpgProgram
import com.iptvlite.tv.model.StreamItem
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.BufferedInputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

/**
 * محلّل متدفّق خفيف الذواكر (Streaming XmlPullParser) لملفّات دليل البرامج XMLTV (.xml و .xml.gz) لاشتراكات M3U.
 */
object XmltvHelper {

    private data class CachedGuide(
        val fetchedAtMs: Long,
        val byChannelId: Map<String, List<EpgProgram>>,
        val displayNameToId: Map<String, String>
    )

    private val cache = ConcurrentHashMap<String, CachedGuide>()
    private val cacheLock=Any()
    private var cacheEpoch=0L
    private val guideFlight=java.util.concurrent.locks.ReentrantLock(true)
    private val active=HashSet<PlaybackRequestScope>()

    fun clearCache() {
        val scopes=synchronized(cacheLock) {cacheEpoch++;cache.clear();active.toList()}
        scopes.forEach {it.cancel {call->NetworkCleanup.cancel(call)}}
    }

    private fun normalizeKey(raw: String): String {
        return raw.trim()
            .lowercase(Locale.ROOT)
            .replace(Regex("""\b(fhd|uhd|4k|hd|sd|hevc|h265|ar|en|fr)\b"""), "")
            .replace(Regex("""[^\p{L}\p{N}]+"""), "")
    }

    fun getProgramsForChannel(
        xmltvUrl: String,
        ch: StreamItem,
        limit: Int = 120
    ): List<EpgProgram> {
        val url = xmltvUrl.trim()
        if (url.isEmpty() || limit<=0) return emptyList()
        val guide = ensureGuideLoaded(url) ?: return emptyList()

        val directKey = ch.tvgId.trim().lowercase(Locale.ROOT)
        val matchedList = when {
            directKey.isNotEmpty() && guide.byChannelId.containsKey(directKey) -> guide.byChannelId[directKey]
            else -> {
                val normName = normalizeKey(ch.name)
                val mappedId = guide.displayNameToId[normName]
                    ?: if (directKey.isNotEmpty()) guide.displayNameToId[normalizeKey(directKey)] else null
                if (mappedId != null) guide.byChannelId[mappedId] else guide.byChannelId[normName]
            }
        }.orEmpty()

        if (matchedList.isEmpty()) return emptyList()
        val nowSec = System.currentTimeMillis() / 1000L
        val out = ArrayList<EpgProgram>(limit.coerceAtMost(matchedList.size))
        for (p in matchedList) {
            val isNow = (p.startTs in 1..nowSec && nowSec < p.stopTs)
            if (limit <= 6 && p.stopTs <= nowSec && !isNow) continue
            out.add(if (p.isNow == isNow) p else p.copy(isNow = isNow))
            if (out.size >= limit) break
        }
        return out
    }

    private fun ensureGuideLoaded(url: String): CachedGuide? {
        PlaybackRequestScope.checkCurrent()
        val nowMs=System.currentTimeMillis()
        val owner=PlaybackRequestScope()
        val parent=PlaybackRequestScope.currentScope()
        val ticket=synchronized(cacheLock) {
            cache[url]?.let {if(nowMs-it.fetchedAtMs<3*3600_000L)return it}
            active.add(owner)
            cacheEpoch
        }
        fun check() {parent?.checkActive();owner.checkActive()}
        var locked=false
        try {
            return BrowseWork.run(owner) load@{
                while(!guideFlight.tryLock(25,java.util.concurrent.TimeUnit.MILLISECONDS))check()
                locked=true
                check()
                synchronized(cacheLock) {
                    cache[url]?.let {if(ticket==cacheEpoch && nowMs-it.fetchedAtMs<3*3600_000L)return@load it}
                }
                val req=Request.Builder().url(url).header("User-Agent",PortalClient.GENERIC_UA).build()
                PlaybackRequestScope.withResponse(PortalClient.browseHttp,req) {resp->
                    if(!resp.isSuccessful)return@withResponse null
                    val raw=resp.body?.byteStream() ?: return@withResponse null
                    val buffered=BufferedInputStream(raw,32*1024)
                    buffered.mark(4)
                    val b0=buffered.read();val b1=buffered.read();buffered.reset()
                    val gzip=(b0==0x1f && b1==0x8b) || url.substringBefore("?").endsWith(".gz",true)
                    val unpacked:InputStream=if(gzip)GZIPInputStream(buffered)else buffered
                    val parsed=GuideInput(unpacked,::check).use {parseXmltvStream(it)}
                    check()
                    synchronized(cacheLock) {
                        check()
                        if(ticket!=cacheEpoch)throw java.util.concurrent.CancellationException("Guide retired")
                        // Retain only one bounded guide; a different provider evicts the old guide.
                        cache.clear();cache[url]=parsed
                    }
                    parsed
                }
            }
        } catch(e:java.util.concurrent.CancellationException) {throw e}
        catch(e:Exception) {check();return null}
        finally {
            if(locked)guideFlight.unlock()
            synchronized(cacheLock) {active.remove(owner)}
        }
    }

    private fun boundedGuideId(raw:String?):String {
        val id=raw?.trim()?.lowercase(Locale.ROOT).orEmpty()
        if(id.length>512)throw java.io.IOException("XMLTV identifier limit")
        return id
    }

    private fun parseXmltvStream(input: InputStream): CachedGuide {
        val factory = XmlPullParserFactory.newInstance().apply { isNamespaceAware = false }
        val parser = factory.newPullParser()
        parser.setInput(input, "UTF-8")

        val byChannel = HashMap<String, ArrayList<EpgProgram>>(512)
        val nameToId = HashMap<String, String>(512)

        val nowSec = System.currentTimeMillis() / 1000L
        val minTs = nowSec - 36 * 3600L
        val maxTs = nowSec + 48 * 3600L

        var curChannelTagId = ""
        var inChannel = false
        var inProgramme = false
        var progChannel = ""
        var progStartTs = 0L
        var progStopTs = 0L
        var progStartRaw = ""
        var progTitle = ""
        var progDesc = ""
        var currentSubTag = ""
        val subTagBuf = StringBuilder(128)

        var programCount=0
        var retainedChars=0L
        var ev = parser.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            PlaybackRequestScope.checkCurrent()
            when (ev) {
                XmlPullParser.START_TAG -> {
                    when (parser.name.lowercase(Locale.US)) {
                        "channel" -> {
                            inChannel = true
                            curChannelTagId = boundedGuideId(parser.getAttributeValue(null, "id"))
                            if (curChannelTagId.isNotEmpty()) {
                                val normId = normalizeKey(curChannelTagId)
                                if(nameToId.size>=20_000)throw java.io.IOException("XMLTV name limit")
                                if (normId.isNotEmpty() && !nameToId.containsKey(normId)) {
                                    nameToId[normId] = curChannelTagId
                                }
                            }
                        }
                        "programme" -> {
                            val stRaw = parser.getAttributeValue(null, "start").orEmpty()
                            val enRaw = parser.getAttributeValue(null, "stop").orEmpty()
                            val st = parseXmltvTime(stRaw)
                            val en = parseXmltvTime(enRaw)
                            if (st in minTs..maxTs) {
                                inProgramme = true
                                progChannel = boundedGuideId(parser.getAttributeValue(null, "channel"))
                                progStartTs = st
                                progStopTs = if (en > st) en else st + 1800L
                                progStartRaw = stRaw
                                progTitle = ""
                                progDesc = ""
                            } else {
                                inProgramme = false
                            }
                        }
                        "display-name", "title", "desc" -> {
                            if (inChannel || inProgramme) {
                                currentSubTag = parser.name.lowercase(Locale.US)
                                subTagBuf.setLength(0)
                            }
                        }
                    }
                }

                XmlPullParser.TEXT -> {
                    if (currentSubTag.isNotEmpty()) {
                        val rawTxt = parser.text
                        if (!rawTxt.isNullOrEmpty()) {
                            subTagBuf.append(rawTxt)
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    when (parser.name.lowercase(Locale.US)) {
                        "channel" -> {
                            inChannel = false
                            curChannelTagId = ""
                        }
                        "programme" -> {
                            if (inProgramme && progChannel.isNotEmpty() && progTitle.isNotEmpty()) {
                                if(!byChannel.containsKey(progChannel) && byChannel.size>=10_000)throw java.io.IOException("XMLTV channel limit")
                                val list = byChannel.getOrPut(progChannel) { ArrayList(24) }
                                if (list.size < 90) {
                                    retainedChars+=progTitle.take(110).length+progDesc.take(450).length
                                    if(++programCount>60_000 || retainedChars>4_000_000L)throw java.io.IOException("XMLTV record limit")
                                    list.add(
                                        EpgProgram(
                                            name = progTitle.take(110),
                                            descr = progDesc.take(450),
                                            startTs = progStartTs,
                                            stopTs = progStopTs,
                                            startStr = progStartRaw,
                                            isNow = (progStartTs in 1..nowSec && nowSec < progStopTs),
                                            hasArchive = false
                                        )
                                    )
                                }
                            }
                            inProgramme = false
                        }
                        "display-name" -> {
                            if (inChannel && curChannelTagId.isNotEmpty()) {
                                val txt = subTagBuf.toString().trim()
                                val nk = normalizeKey(txt.take(256))
                                if(nameToId.size>=20_000 && !nameToId.containsKey(nk))throw java.io.IOException("XMLTV name limit")
                                if (nk.isNotEmpty()) nameToId[nk] = curChannelTagId
                            }
                            subTagBuf.setLength(0)
                            currentSubTag = ""
                        }
                        "title" -> {
                            if (inProgramme && progTitle.isEmpty()) {
                                val txt = subTagBuf.toString().trim()
                                if (txt.isNotEmpty()) progTitle = txt
                            }
                            subTagBuf.setLength(0)
                            currentSubTag = ""
                        }
                        "desc" -> {
                            if (inProgramme && progDesc.isEmpty()) {
                                val txt = subTagBuf.toString().trim()
                                if (txt.isNotEmpty()) progDesc = txt
                            }
                            subTagBuf.setLength(0)
                            currentSubTag = ""
                        }
                    }
                }
            }
            ev = parser.next()
        }

        val sortedMap = HashMap<String, List<EpgProgram>>(byChannel.size)
        for ((k, list) in byChannel) {
            list.sortBy { it.startTs }
            sortedMap[k] = list
        }
        return CachedGuide(
            fetchedAtMs = System.currentTimeMillis(),
            byChannelId = sortedMap,
            displayNameToId = nameToId
        )
    }

    /**
     * حساب لحظي بدون تخصيص ذاكرة (Zero-Allocation) لتوقيت XMLTV مثل "20261105200000 +0100"
     * متوافق 100% مع جميع إصدارات أندرويد دون خطأ GMT+0100 بدون نقطتين (:).
     */
    private fun parseXmltvTime(raw: String): Long {
        val s = raw.trim()
        if (s.length < 12) return 0L
        var dLen = 0
        while (dLen < s.length && dLen < 14 && s[dLen].isDigit()) dLen++
        if (dLen < 12) return 0L

        fun sliceInt(start: Int, end: Int): Int {
            var v = 0
            for (i in start until end) {
                v = v * 10 + (s[i] - '0')
            }
            return v
        }

        val year = sliceInt(0, 4)
        val month = sliceInt(4, 6)
        val day = sliceInt(6, 8)
        val hour = sliceInt(8, 10)
        val min = sliceInt(10, 12)
        val sec = if (dLen >= 14) sliceInt(12, 14) else 0
        if (month !in 1..12 || day !in 1..31 || hour !in 0..23 || min !in 0..59 || sec !in 0..60) return 0L

        // خوارزمية Howard Hinnant لتحويل التاريخ الميلادي إلى عدد الأيام منذ 1970-01-01 بدقّة تامّة
        val yAdj = if (month <= 2) year - 1 else year
        val era = (if (yAdj >= 0) yAdj else yAdj - 399) / 400
        val yoe = yAdj - era * 400
        val mp = month + (if (month > 2) -3 else 9)
        val doy = (153 * mp + 2) / 5 + day - 1
        val doe = yoe * 365 + yoe / 4 - yoe / 100 + doy
        val daysSinceEpoch = era * 146097L + doe - 719468L
        var utcSec = daysSinceEpoch * 86_400L + hour * 3600L + min * 60L + sec

        val tzPart = s.substring(dLen).trim()
        if (tzPart.length >= 5 && (tzPart[0] == '+' || tzPart[0] == '-')) {
            val sign = if (tzPart[0] == '+') 1 else -1
            val digitsOnly = tzPart.drop(1).filter { it.isDigit() }
            if (digitsOnly.length >= 4) {
                val tzH = digitsOnly.substring(0, 2).toIntOrNull() ?: 0
                val tzM = digitsOnly.substring(2, 4).toIntOrNull() ?: 0
                utcSec -= sign * (tzH * 3600L + tzM * 60L)
            }
        }
        return utcSec
    }
}
