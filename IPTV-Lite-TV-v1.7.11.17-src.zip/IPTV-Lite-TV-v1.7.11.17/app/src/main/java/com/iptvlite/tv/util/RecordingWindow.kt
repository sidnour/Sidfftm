package com.iptvlite.tv.util

object RecordingWindow {
    /** Never turn an expired alarm into a fresh 60-second recording. Clamp before Int conversion. */
    fun remainingSeconds(endSec: Long, nowSec: Long): Int {
        if(endSec<=nowSec)return 0
        val remaining=endSec-nowSec
        return if(remaining<0L)21600 else remaining.coerceAtMost(21600L).toInt()
    }
}
