package com.iptvlite.tv.util

import android.util.LruCache
import java.util.Locale

/**
 * منسّق ذكي فائق السرعة (Zero-Lag LruCache) لتنقية عناوين القنوات والأفلام والباقات
 * من رموز الزخرفة الفوضوية مثل `┃MULTI / LINGO┃` و`|AR|` واستخراج شارات الجودة (4K/FHD/HD)
 * واللغة/المنطقة والسنة وتقريب التقييمات العشرية الطويلة (مثل 5.516 -> 5.5) وإخفاء N/A.
 */
object MediaTitleFormatter {

    data class ParsedCategory(
        val groupTag: String,
        val cleanTitle: String
    )

    data class ParsedMedia(
        val cleanTitle: String,
        val regionOrLangTag: String,
        val qualityBadge: String,
        val extractedYear: String
    )

    private val catCache = LruCache<String, ParsedCategory>(1024)
    private val mediaCache = LruCache<String, ParsedMedia>(4096)

    // يطابق البادئات المحاطة بـ ┃...┃ أو |...| أو [...] أو (...) في بداية الاسم
    private val bracketPrefixRe = Regex(
        """^\s*(?:[┃|│║\[]\s*([^┃|│║\]]{1,24}?)\s*[┃|│║\]]|\(\s*([A-Za-z0-9/\-+ ]{2,14})\s*\))\s*[-_:•|┃│]*\s*(.+)$"""
    )
    // يطابق بادئة مثل "AR : Channel" أو "FR - Channel" أو "VIP | Channel"
    private val colonPrefixRe = Regex(
        """^\s*([A-Za-z]{2,6}(?:\s*/\s*[A-Za-z]{2,6})?)\s*[:|┃│\-]\s+(.+)$"""
    )
    private val decorativeWrapRe = Regex("""^[★☆•●◆◇═\-_~*|┃│\s]+|[★☆•●◆◇═\-_~*|┃│\s]+$""")
    private val multiSpaceRe = Regex("""\s{2,}""")

    private val trailingYearRe = Regex("""(?:\s*[-–—]\s*|\s+)\(?((?:19|20)\d{2})\)?\s*$""")
    private val qualityTokenRe = Regex(
        """\b(4K|UHD|2160[pP]|FHD|1080[pP]|HD|720[pP]|SD|HEVC|H\.?265|RAW|VIP|50FPS|60FPS)\b""",
        RegexOption.IGNORE_CASE
    )
    private val messyRatingInSubRe = Regex("""(?:\s*[·•|]\s*)?[★⭐]\s*(N/A|n/a|null|0(?:\.0+)?|\d+\.\d{2,})""")

    fun parseCategory(rawTitle: String): ParsedCategory {
        val key = rawTitle.trim()
        if (key.isEmpty()) return ParsedCategory("", "")
        catCache.get(key)?.let { return it }

        // الحفاظ على المجلّدات المحلّية الخاصة بالتطبيق كما هي
        if (key.startsWith("⭐") || key.startsWith("📺") || key.startsWith("🎬") ||
            key.startsWith("📚") || key.startsWith("📌") || key.startsWith("➕")
        ) {
            return ParsedCategory("", key).also { catCache.put(key, it) }
        }

        var working = key
        var tag = ""

        val m1 = bracketPrefixRe.find(working)
        if (m1 != null) {
            tag = (m1.groupValues[1].ifEmpty { m1.groupValues[2] }).trim()
            working = m1.groupValues[3].trim()
        } else {
            val m2 = colonPrefixRe.find(working)
            if (m2 != null) {
                tag = m2.groupValues[1].trim()
                working = m2.groupValues[2].trim()
            }
        }

        val cleaned = working
            .replace('┃', '|')
            .replace('│', '|')
            .replace(decorativeWrapRe, "")
            .replace(multiSpaceRe, " ")
            .trim()
            .ifEmpty { key }

        val cleanTag = tag
            .replace(decorativeWrapRe, "")
            .replace(multiSpaceRe, " ")
            .trim()
            .uppercase(Locale.US)

        return ParsedCategory(
            groupTag = if (cleanTag.length in 2..22 && !cleaned.equals(cleanTag, ignoreCase = true)) cleanTag else "",
            cleanTitle = cleaned
        ).also { catCache.put(key, it) }
    }

    fun parseMedia(rawName: String): ParsedMedia {
        val key = rawName.trim()
        if (key.isEmpty()) return ParsedMedia("", "", "", "")
        mediaCache.get(key)?.let { return it }

        var working = key
        var tag = ""

        val m1 = bracketPrefixRe.find(working)
        if (m1 != null) {
            tag = (m1.groupValues[1].ifEmpty { m1.groupValues[2] }).trim()
            working = m1.groupValues[3].trim()
        } else {
            val m2 = colonPrefixRe.find(working)
            if (m2 != null) {
                tag = m2.groupValues[1].trim()
                working = m2.groupValues[2].trim()
            }
        }

        // استخراج السنة من نهاية اسم الفيلم/المسلسل مثل "The Mongoose - 2026" أو "Movie (2025)"
        var year = ""
        val ym = trailingYearRe.find(working)
        if (ym != null) {
            val candidate = ym.groupValues[1]
            val stripped = working.substring(0, ym.range.first).trim()
            if (stripped.length >= 2) {
                year = candidate
                working = stripped
            }
        }

        // استخراج شارة الجودة الأعلى (4K > FHD > HD > HEVC > SD)
        var bestQuality = ""
        var bestRank = 0
        for (qm in qualityTokenRe.findAll(working)) {
            val tok = qm.value.uppercase(Locale.US)
            val (norm, rank) = when {
                tok == "4K" || tok == "UHD" || tok == "2160P" -> "4K" to 5
                tok == "FHD" || tok == "1080P" -> "FHD" to 4
                tok == "50FPS" || tok == "60FPS" || tok == "RAW" -> tok to 3
                tok == "HD" || tok == "720P" -> "HD" to 2
                tok.startsWith("HEVC") || tok.startsWith("H265") || tok.startsWith("H.265") -> "HEVC" to 2
                tok == "SD" -> "SD" to 1
                else -> "" to 0
            }
            if (rank > bestRank) {
                bestRank = rank
                bestQuality = norm
            }
        }

        val cleanedTitle = working
            .replace('┃', ' ')
            .replace('│', ' ')
            .replace(decorativeWrapRe, "")
            .replace(multiSpaceRe, " ")
            .trim()
            .ifEmpty { key }

        val cleanTag = tag
            .replace(decorativeWrapRe, "")
            .replace(multiSpaceRe, " ")
            .trim()
            .uppercase(Locale.US)
            .take(10)

        return ParsedMedia(
            cleanTitle = cleanedTitle,
            regionOrLangTag = cleanTag,
            qualityBadge = bestQuality,
            extractedYear = year
        ).also { mediaCache.put(key, it) }
    }

    /**
     * يقرّب التقييم إلى خانة عشرية واحدة نظيفة (مثلاً "5.516" -> "5.5"، "8.386" -> "8.4")
     * ويُرجع نصاً فارغاً للقيم الفارغة أو "0" أو "N/A".
     */
    fun formatRating(rawRating: String): String {
        val t = rawRating.trim()
        if (t.isEmpty() ||
            t.equals("N/A", ignoreCase = true) ||
            t.equals("null", ignoreCase = true) ||
            t == "0" || t == "0.0" || t == "0.00"
        ) {
            return ""
        }
        val num = t.replace(',', '.').toDoubleOrNull()
        if (num != null) {
            if (num <= 0.05) return ""
            val clamped = num.coerceAtMost(10.0)
            return String.format(Locale.US, "%.1f", clamped)
        }
        return t.take(4)
    }

    /**
     * ينقّي السطر الفرعي (مثل "2026-09-18 · ★ N/A" أو "2026-10-22 · ★ 5.516") ليظهر أنيقاً ومختصراً.
     */
    fun cleanSubtitle(rawSub: String): String {
        val t = rawSub.trim()
        if (t.isEmpty()) return ""
        val fixed = messyRatingInSubRe.replace(t) { m ->
            val v = formatRating(m.groupValues[1])
            if (v.isEmpty()) "" else " · ★ $v"
        }
        return fixed
            .replace('┃', '·')
            .replace(Regex("""^\s*[·•|]\s*|\s*[·•|]\s*$"""), "")
            .replace(Regex("""(\s*[·•|]\s*){2,}"""), " · ")
            .trim()
    }
}
