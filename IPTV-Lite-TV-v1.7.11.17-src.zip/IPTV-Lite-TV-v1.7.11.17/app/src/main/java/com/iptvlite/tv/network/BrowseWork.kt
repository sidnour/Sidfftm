package com.iptvlite.tv.network

import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/** Cancel the operation, not just a snapshot of its current sockets. */
internal object BrowseWork {
    private val active=Collections.newSetFromMap(ConcurrentHashMap<PlaybackRequestScope,Boolean>())
    fun <T> run(scope:PlaybackRequestScope=PlaybackRequestScope(), block:()->T):T {
        active.add(scope)
        try { return scope.run(block) } finally { active.remove(scope) }
    }
    fun cancelAll() { active.toList().forEach { it.cancel { call->NetworkCleanup.cancel(call) } } }
}
