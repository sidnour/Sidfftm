package com.iptvlite.tv.ui

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.os.SystemClock
import androidx.media3.exoplayer.analytics.AnalyticsListener
import com.iptvlite.tv.util.PlaybackDiagnostics
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.roundToInt
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.extractor.ts.TsExtractor
import androidx.media3.common.text.CueGroup
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iptvlite.tv.R
import com.iptvlite.tv.model.EpgProgram
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.PlayQueueHolder
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.util.AppExitHelper
import com.iptvlite.tv.util.AppUiTracker
import com.iptvlite.tv.util.LogoLoader
import com.iptvlite.tv.util.MediaTitleFormatter
import com.iptvlite.tv.util.StreamRecorder
import com.iptvlite.tv.util.ThemeHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.lang.ref.WeakReference
import java.util.Locale

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private lateinit var store: AppStore
    private var player: ExoPlayer? = null
    private var httpDataSourceFactory: OkHttpDataSource.Factory? = null

    private lateinit var playerView: PlayerView
    private lateinit var tvChannelJumpBox: TextView
    private lateinit var tvGestureHud: TextView
    private lateinit var bufferOverlay: View
    private lateinit var tvBufferMsg: TextView
    private lateinit var topOsd: View
    private lateinit var bottomOsd: View
    private lateinit var btnOsdBack: TextView
    private lateinit var tvOsdTitle: TextView
    private lateinit var tvOsdMeta: TextView
    private lateinit var tvOsdEpgNow: TextView
    private lateinit var pbOsdEpgProgress: ProgressBar
    private lateinit var seekRow: View
    private lateinit var seekBar: SeekBar
    private lateinit var tvPosTime: TextView
    private lateinit var tvDurTime: TextView
    private lateinit var btnOsdPlayPause: TextView
    private lateinit var btnOsdReload: TextView
    private lateinit var btnOsdMute: TextView
    private lateinit var btnOsdRecord: TextView
    private lateinit var btnOsdDownload: TextView
    private lateinit var btnOsdEpg: TextView
    private lateinit var btnOsdPrevCh: TextView
    private lateinit var btnOsdDrawer: TextView
    private lateinit var btnOsdAudio: TextView
    private lateinit var btnOsdSub: TextView
    private lateinit var btnOsdAspect: TextView
    private lateinit var btnOsdSpeed: TextView
    private lateinit var btnOsdStats: TextView
    private lateinit var btnOsdTimer: TextView
    private lateinit var btnOsdRotate: TextView
    private lateinit var btnOsdFav: TextView
    private lateinit var liveDrawer: LinearLayout
    private lateinit var rvDrawerChannels: RecyclerView
    private lateinit var drawerAdapter: StreamAdapter

    private val uiHandler = Handler(Looper.getMainLooper())
    private var openJob: Job? = null
    private var epgBannerJob: Job? = null
    private var currentItem: StreamItem? = null
    private var openStartMs: Long = 0L
    private var playbackOperationId = 0L
    private var playbackOperation = PlaybackDiagnostics.Operation.OPEN
    private var firstFrameMs: Long? = null
    private var urlPreparationMs: Long? = null
    private var measuringFirstFrame = false

    private fun playbackEvent(stage: PlaybackDiagnostics.Stage, errorCode: Int? = null) {
        PlaybackDiagnostics.record(playbackOperationId, playbackOperation, stage,
            SystemClock.elapsedRealtime() - openStartMs, errorCode)
    }

    private fun beginPlaybackOperation(reason: PlaybackDiagnostics.Operation) {
        PlaybackDiagnostics.configure(store.loadPrefs().diagnosticsEnabled)
        playbackOperationId++
        playbackOperation = reason
        openStartMs = SystemClock.elapsedRealtime()
        firstFrameMs = null
        urlPreparationMs = null
        measuringFirstFrame = true
        lastOpenSpeedStr = "⚡ قياس بدء الصورة…"
        playbackEvent(PlaybackDiagnostics.Stage.START)
        if (::tvOsdMeta.isInitialized) updateMetaBanner()
    }

    private val timingListener = object : AnalyticsListener {
        override fun onRenderedFirstFrame(eventTime: AnalyticsListener.EventTime, output: Any, renderTimeMs: Long) {
            if (!measuringFirstFrame || stoppedInBackground) return
            val timeline = eventTime.timeline
            if (timeline.isEmpty || eventTime.windowIndex !in 0 until timeline.windowCount) return
            val media = timeline.getWindow(eventTime.windowIndex, androidx.media3.common.Timeline.Window()).mediaItem
            if (media.mediaId != "operation-$playbackOperationId") return
            val elapsed = eventTime.realtimeMs - openStartMs
            if (elapsed < 0) return
            firstFrameMs = elapsed
            confirmCurrentLiveLink()
            measuringFirstFrame = false
            lastOpenSpeedStr = "⚡ أول صورة: ${elapsed} مللي ثانية"
            playbackEvent(PlaybackDiagnostics.Stage.FIRST_FRAME)
            bufferOverlay.visibility = View.GONE
            updateMetaBanner()
        }
    }

    private var watchTickMs: Long = 0L
    private var everPlayedCurrent: Boolean = false
    private var triedCreateLinkFallback: Boolean = false
    private var retryCount: Int = 0
    private var pendingResumeMs: Long = 0L
    private var resumeSeekApplied: Boolean = true
    private var resumeSeekAttempts: Int = 0
    private var resumeBannerShown: Boolean = false
    private var lastValidVodPosMs: Long = 0L
    private var lastValidVodDurMs: Long = 0L
    private var lastPeriodicResumeSaveMs: Long = 0L
    private var isDraggingSeek: Boolean = false
    private var aspectMode: Int = 0
    private var playbackSpeed: Float = 1.0f
    private var sleepDeadlineMs: Long = 0L
    private var sleepWarned1Min: Boolean = false
    private var stoppedInBackground: Boolean = false
    private var isPortraitLocked: Boolean = false
    private var isPlayerMuted: Boolean = false
    private var startedRecInPlayer: Boolean = false
    private var pausedStreamForInternalDownload: Boolean = false
    private var currentResolvedStreamUrl: String = ""
    private val liveLinkMemory = com.iptvlite.tv.util.LiveLinkMemory()
    private var pendingLiveLink: com.iptvlite.tv.util.LiveLinkMemory.Link? = null
    private var pendingLiveLinkKey: String? = null
    private var pendingLiveLinkOperation = -1L
    private var openingSavedLiveLink = false
    private fun liveLinkKey(item: StreamItem): String =
        listOf(item.accountId.ifBlank { (PlayQueueHolder.activeAccount ?: store.getActiveAccount())?.id.orEmpty() },
            item.kind.name, item.id, item.cmd).joinToString("\u0000")

    private fun confirmCurrentLiveLink() {
        if (currentItem?.kind != ItemKind.LIVE || pendingLiveLinkOperation != playbackOperationId) return
        val key = pendingLiveLinkKey ?: return
        if (key != currentItem?.let { liveLinkKey(it) }) return
        pendingLiveLink?.let { liveLinkMemory.confirm(key, it) }
    }

    private var originalExternalSubUri: Uri? = null
    private var externalSubUri: Uri? = null
    private var subtitleOffsetMs: Long = 0L
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var attachedAudioSessionId: Int = C.AUDIO_SESSION_ID_UNSET
    private var currentAudioBoostPct: Int = 100
    private var lastFocusedTopOsdBtn: View? = null
    private var lastFocusedBottomOsdBtn: View? = null
    private var recLiveStatusStr: String = ""
    private var lastOpenSpeedStr: String = ""
    private var lastResStr: String = ""
    private var lastCodecStr: String = ""
    private var activeEpgNowProg: EpgProgram? = null
    private var activeEpgNextProg: EpgProgram? = null

    private val extSubPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        applyExternalSubtitleUri(uri)
    }

    private val digitBuffer = StringBuilder()
    private val commitDigitsRunnable = Runnable { commitDigitJump() }
    private val hideOsdRunnable = Runnable { hideOsd() }
    private val hideHudRunnable = Runnable { tvGestureHud.visibility = View.GONE }
    private var reminderPollTick = 0

    private val immediatePlayerReminderCallback: () -> Unit = {
        if (!isFinishing && !isDestroyed) {
            checkDueRemindersInPlayer(immediate = true)
        }
    }

    private fun checkDueRemindersInPlayer(immediate: Boolean = false) {
        val nowSec = System.currentTimeMillis() / 1000L
        val cutoff = if (immediate) nowSec + 2L else nowSec
        val due = store.popDueReminders(cutoff)
        for (rem in due) {
            TvDialogs.showNeonChoiceDialog(
                ctx = this@PlayerActivity,
                title = "🔔 حان موعد «${rem.programTitle}» على «${rem.channel.name}»",
                items = listOf("▶ الانتقال للقناة الآن"),
                defaultIndex = 0,
                cancelLabel = "متابعة المشاهدة الحالية"
            ) {
                val targetAcc = store.getAccounts().firstOrNull { it.id == rem.accountId }
                    ?: PlayQueueHolder.activeAccount
                    ?: store.getActiveAccount()
                if (targetAcc != null) {
                    PlayQueueHolder.activeAccount = targetAcc
                    PlayQueueHolder.archiveSourceChannel = rem.channel
                    PlayQueueHolder.playlist = listOf(rem.channel)
                    PlayQueueHolder.currentIndex = 0
                    openStreamAtIndex(0)
                }
            }
        }
    }

    // Browse-only admission observations; does not alter the player, buffer or recovery policy.
    private val categoryBrowseTick=object:Runnable {
        override fun run() {
            if(stoppedInBackground || isFinishing || isDestroyed)return
            if(com.iptvlite.tv.network.SelectedCategoryLoad.refreshQueue(currentItem) && liveDrawer.visibility==View.VISIBLE)drawerAdapter.submit(PlayQueueHolder.playlist)
            if(!com.iptvlite.tv.network.SelectedCategoryLoad.hasPending())return
            val p=player
            val healthy=p!=null && p.isPlaying && p.playbackState==Player.STATE_READY && p.totalBufferedDuration>=8000L && firstFrameMs!=null
            com.iptvlite.tv.network.SelectedCategoryLoad.observePlayback(p?.currentPosition ?: 0L,healthy)
            uiHandler.postDelayed(this,1000)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgressAndWatchStats()
            if (store.hasActiveSchedules()) {
                reminderPollTick++
                if (reminderPollTick >= 3) {
                    reminderPollTick = 0
                    checkDueRemindersInPlayer(immediate = false)
                }
            } else {
                reminderPollTick = 0
            }
            val nextInterval = nextTickerIntervalMs()
            if (nextInterval > 0L) {
                uiHandler.postDelayed(this, nextInterval)
            }
        }
    }

    /**
     * يوقف المؤقّت تماماً (0% استهلاك معالج) أثناء مشاهدة البثّ الحيّ طالما لا يوجد مؤقّت نوم ولا تنبيهات!
     * ويعمل كلّ 1s فقط عند ظهور شريط التقديم للأفلام، أو كلّ 5s بهدوء في الخلفية عند الحاجة.
     */
    private fun nextTickerIntervalMs(): Long {
        if (isFinishing || isDestroyed || stoppedInBackground) return 0L
        val cur = currentItem
        val isVodOrCatchup = cur != null && cur.kind != ItemKind.LIVE
        if (isVodOrCatchup && bottomOsd.visibility == View.VISIBLE) {
            return 1000L
        }
        if (isVodOrCatchup || sleepDeadlineMs > 0L || store.hasActiveSchedules()) {
            return 5000L
        }
        return 0L
    }

    private fun syncProgressTicker() {
        uiHandler.removeCallbacks(progressRunnable)
        val interval = nextTickerIntervalMs()
        if (interval > 0L) {
            uiHandler.post(progressRunnable)
        }
    }

    private var activePlayStartMs: Long = 0L

    private fun syncWatchSessionState() {
        val exo = player
        val playingNow = exo != null && exo.isPlaying && exo.playbackState == Player.STATE_READY && !stoppedInBackground
        if (playingNow) {
            if (activePlayStartMs == 0L) {
                activePlayStartMs = System.currentTimeMillis()
            }
        } else {
            flushAccumulatedWatchSeconds()
        }
    }

    private fun flushAccumulatedWatchSeconds() {
        val started = activePlayStartMs
        if (started <= 0L) return
        activePlayStartMs = 0L
        val elapsedSec = ((System.currentTimeMillis() - started) / 1000L).coerceIn(0L, 28_800L)
        if (elapsedSec > 0L) {
            store.addWatchSeconds(elapsedSec)
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(com.iptvlite.tv.util.TelevisionUi.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_player)

        store = AppStore(this)
        val prefs = store.loadPrefs()
        aspectMode = prefs.aspectMode
        currentAudioBoostPct = prefs.audioBoostPct

        bindViews()
        applySubtitleStyleFromPrefs()
        updateAudioBoostButtonLabel()
        setupBackNavigation()
        LogoLoader.isPlaybackActive = true
        PortalClient.trimForPlayback()
        initPlayer(prefs.cacheMs)

        val list = PlayQueueHolder.playlist
        val idx = PlayQueueHolder.currentIndex.coerceIn(0, (list.size - 1).coerceAtLeast(0))
        if (list.isEmpty()) {
            Toast.makeText(this, "لا يوجد عنصر للتشغيل", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        watchTickMs = System.currentTimeMillis()
        openStreamAtIndex(idx)
        syncProgressTicker()
    }

    private fun bindViews() {
        playerView = findViewById(R.id.playerView)
        tvChannelJumpBox = findViewById(R.id.tvChannelJumpBox)
        tvGestureHud = findViewById(R.id.tvGestureHud)
        bufferOverlay = findViewById(R.id.bufferOverlay)
        tvBufferMsg = findViewById(R.id.tvBufferMsg)
        topOsd = findViewById(R.id.topOsd)
        bottomOsd = findViewById(R.id.bottomOsd)
        btnOsdBack = findViewById(R.id.btnOsdBack)
        tvOsdTitle = findViewById(R.id.tvOsdTitle)
        tvOsdMeta = findViewById(R.id.tvOsdMeta)
        tvOsdEpgNow = findViewById(R.id.tvOsdEpgNow)
        pbOsdEpgProgress = findViewById(R.id.pbOsdEpgProgress)
        seekRow = findViewById(R.id.seekRow)
        seekBar = findViewById(R.id.seekBar)
        tvPosTime = findViewById(R.id.tvPosTime)
        tvDurTime = findViewById(R.id.tvDurTime)
        btnOsdPlayPause = findViewById(R.id.btnOsdPlayPause)
        btnOsdReload = findViewById(R.id.btnOsdReload)
        btnOsdMute = findViewById(R.id.btnOsdMute)
        btnOsdRecord = findViewById(R.id.btnOsdRecord)
        btnOsdDownload = findViewById(R.id.btnOsdDownload)
        btnOsdEpg = findViewById(R.id.btnOsdEpg)
        btnOsdPrevCh = findViewById(R.id.btnOsdPrevCh)
        btnOsdDrawer = findViewById(R.id.btnOsdDrawer)
        btnOsdAudio = findViewById(R.id.btnOsdAudio)
        btnOsdSub = findViewById(R.id.btnOsdSub)
        btnOsdAspect = findViewById(R.id.btnOsdAspect)
        btnOsdSpeed = findViewById(R.id.btnOsdSpeed)
        btnOsdStats = findViewById(R.id.btnOsdStats)
        btnOsdTimer = findViewById(R.id.btnOsdTimer)
        btnOsdRotate = findViewById(R.id.btnOsdRotate)
        btnOsdFav = findViewById(R.id.btnOsdFav)
        liveDrawer = findViewById(R.id.liveDrawer)
        rvDrawerChannels = findViewById(R.id.rvDrawerChannels)

        applyAspectMode(aspectMode, showToast = false)
        setupTouchGestures()

        btnOsdBack.setOnClickListener {
            saveCurrentPositionIfVod()
            notifyIfRecordingContinuesOnExit()
            finish()
        }

        btnOsdPlayPause.setOnClickListener {
            // في القنوات المباشرة لا يوجد إيقاف مؤقّت ولا استئناف؛ الإيقاف والاستئناف مخصّصان للأفلام والمسلسلات والأرشيف والتسجيلات فقط
            if (currentItem?.kind == ItemKind.LIVE) {
                return@setOnClickListener
            }
            if (pausedStreamForInternalDownload) {
                if (StreamRecorder.isDownloading()) {
                    StreamRecorder.stopDownload()
                    Toast.makeText(this, "⏹ تمّ إيقاف التحميل — جارٍ استئناف المشاهدة فوراً", Toast.LENGTH_SHORT).show()
                }
                resumeStreamAfterDownloadStopped()
                scheduleOsdHide()
                return@setOnClickListener
            }
            val p = player ?: return@setOnClickListener
            if (p.mediaItemCount == 0 && currentItem != null) {
                resumeStreamAfterDownloadStopped()
                scheduleOsdHide()
                return@setOnClickListener
            }
            if (p.isPlaying) {
                p.pause()
                btnOsdPlayPause.text = "▶ استئناف"
            } else {
                p.play()
                btnOsdPlayPause.text = "⏸ إيقاف مؤقّت"
            }
            scheduleOsdHide()
        }

        btnOsdReload.setOnClickListener {
            quickReloadCurrentStream()
            scheduleOsdHide()
        }

        btnOsdMute.setOnClickListener {
            toggleInstantMute()
            scheduleOsdHide()
        }

        btnOsdRecord.setOnClickListener {
            toggleStreamRecording()
            scheduleOsdHide()
        }

        btnOsdDownload.setOnClickListener {
            promptVodDownloadFromPlayer()
        }

        btnOsdEpg.setOnClickListener {
            openEpgOrMediaFromPlayer()
        }

        btnOsdPrevCh.setOnClickListener {
            switchToPreviousChannel()
        }

        btnOsdDrawer.setOnClickListener {
            openLiveDrawer()
        }

        btnOsdAudio.setOnClickListener {
            showAudioTrackDialog()
        }

        btnOsdSub.setOnClickListener {
            showSubtitleDialog()
        }

        btnOsdAspect.setOnClickListener {
            aspectMode = (aspectMode + 1) % 6
            applyAspectMode(aspectMode, showToast = true)
            store.savePrefs(store.loadPrefs().copy(aspectMode = aspectMode))
            scheduleOsdHide()
        }

        btnOsdSpeed.setOnClickListener {
            showPlaybackSpeedDialog()
        }

        btnOsdStats.setOnClickListener {
            showStreamDiagnosticsDialog()
        }

        btnOsdTimer.setOnClickListener {
            showSleepTimerDialog()
        }

        btnOsdRotate.setOnClickListener {
            toggleScreenOrientation()
        }

        btnOsdFav.setOnClickListener {
            val cur = currentItem ?: return@setOnClickListener
            val target = if (cur.kind == ItemKind.CATCHUP) {
                PlayQueueHolder.archiveSourceChannel ?: cur
            } else cur
            val fav = store.toggleFavorite(target)
            updateFavButton(fav)
            Toast.makeText(
                this,
                if (fav) "★ أُضيفت إلى المفضّلة" else "☆ أُزيلت من المفضّلة",
                Toast.LENGTH_SHORT
            ).show()
            scheduleOsdHide()
        }

        setupOsdFocusNavigation()

        seekBar.setOnFocusChangeListener { v, hasFocus ->
            val tint = android.content.res.ColorStateList.valueOf(
                Color.parseColor(if (hasFocus) "#60A5FA" else "#3B82F6")
            )
            seekBar.thumbTintList = tint
            seekBar.progressTintList = tint
            v.animate().scaleY(if (hasFocus) 1.25f else 1.0f).setDuration(110L).start()
            if (hasFocus) scheduleOsdHide()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = player?.duration ?: 0L
                    if (dur > 0L) {
                        val target = (dur * progress) / 1000L
                        tvPosTime.text = formatMs(target)
                    }
                    scheduleOsdHide()
                }
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                isDraggingSeek = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                isDraggingSeek = false
                val p = player ?: return
                val dur = p.duration
                if (dur > 0L && sb != null) {
                    val target = (dur * sb.progress) / 1000L
                    commitManualUserSeek(target)
                }
                scheduleOsdHide()
            }
        })

        drawerAdapter = StreamAdapter(
            isFavFn = { store.isFavorite(it) },
            onClick = { _, pos, _ ->
                liveDrawer.visibility = View.GONE
                openStreamAtIndex(pos)
            }
        )
        rvDrawerChannels.layoutManager = LinearLayoutManager(this)
        rvDrawerChannels.setHasFixedSize(true)
        rvDrawerChannels.itemAnimator = null
        rvDrawerChannels.adapter = drawerAdapter
    }

    private fun openEpgOrMediaFromPlayer() {
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount() ?: return
        val cur = currentItem ?: return
        val epgCh = when (cur.kind) {
            ItemKind.LIVE -> cur
            ItemKind.CATCHUP -> PlayQueueHolder.archiveSourceChannel
            else -> null
        }
        if (epgCh != null) {
            hideOsd()
            FeatureDialogs.showEpgArchiveDialog(
                ctx = this,
                store = store,
                scope = lifecycleScope,
                acc = acc,
                ch = epgCh,
                onPlayLive = { liveCh ->
                    val existingIdx = PlayQueueHolder.playlist.indexOfFirst { it.id == liveCh.id }
                    if (existingIdx >= 0) {
                        openStreamAtIndex(existingIdx)
                    } else {
                        PlayQueueHolder.playlist = listOf(liveCh)
                        openStreamAtIndex(0)
                    }
                },
                onPlayCatchup = { catchupItem, srcCh ->
                    PlayQueueHolder.archiveSourceChannel = srcCh
                    PlayQueueHolder.playlist = listOf(catchupItem)
                    openStreamAtIndex(0)
                }
            )
        } else if (cur.kind == ItemKind.VOD || cur.kind == ItemKind.EPISODE) {
            hideOsd()
            FeatureDialogs.showMediaInfoDialog(
                ctx = this,
                store = store,
                scope = lifecycleScope,
                acc = acc,
                item = cur,
                onOpenOrPlay = { player?.play() },
                onFavChanged = { updateFavButton(store.isFavorite(cur)) },
                onDownloadVod = { promptVodDownloadFromPlayer() }
            )
        }
    }

    private fun initPlayer(cacheMs: Int) {
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
        val ua = if (acc?.provider == ProviderType.STALKER) PortalClient.MAG_UA else PortalClient.GENERIC_UA

        val am = getSystemService(ACTIVITY_SERVICE) as? android.app.ActivityManager
        val isLowRam = (am?.isLowRamDevice == true) || ((am?.memoryClass ?: 192) <= 160)

        // موازنة ذكيّة بين خفّة الذاكرة (RAM) واستمرارية سحب الحزم على مقبس TCP بدون تقطّعات:
        // نبقي minBufferMs قريباً من maxBufferMs (10s..15s على TV Box، و12s..18s على الهواتف)
        // مع سقف بايتات مضبوط لتوفير ~40 ميجابايت من الذاكرة مع الحفاظ على سحب مستمر وسلس!
        val playBuf = (cacheMs / 2).coerceIn(600, 2200)
        val rebuf = cacheMs.coerceIn(playBuf + 600, 4000)
        val minBuf = (if (isLowRam) 10_000 else 12_000).coerceAtLeast(rebuf + 3000)
        val maxBuf = (if (isLowRam) 15_000 else 18_000).coerceAtLeast(minBuf + 5000)
        val maxTargetBytes = if (isLowRam) (12 * 1024 * 1024) else (18 * 1024 * 1024)

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBuf, maxBuf, playBuf, rebuf)
            .setTargetBufferBytes(maxTargetBytes)
            .setPrioritizeTimeOverSizeThresholds(false)
            .setBackBuffer(0, false)
            .build()

        // الأولوية القصوى لفكّ التشفير العتادي (Hardware MediaCodec GPU/VPU) لتقليل استهلاك المعالج والحرارة!
        val renderersFactory = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)

        val extractors = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setConstantBitrateSeekingAlwaysEnabled(true)
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS or
                    DefaultTsPayloadReaderFactory.FLAG_IGNORE_SPLICE_INFO_STREAM
            )
            .setTsExtractorTimestampSearchBytes(3600 * TsExtractor.TS_PACKET_SIZE)

        val transport = playbackTransport ?: PortalClient.playHttp.newBuilder()
            .dispatcher(okhttp3.Dispatcher())
            .connectionPool(okhttp3.ConnectionPool(2, 30, java.util.concurrent.TimeUnit.SECONDS))
            .build().also { playbackTransport = it }
        val httpFactory = OkHttpDataSource.Factory(transport)
            .setUserAgent(ua)
            .setDefaultRequestProperties(PortalClient.getStreamRequestHeaders(acc))
        httpDataSourceFactory = httpFactory

        // تمرير بايتات البثّ الحيّ عبر LiveTapDataSource للتسجيل الفوري بدون فتح اتصال ثانٍ على السيرفر (Zero Connection Reset)
        val tappedHttpFactory = StreamRecorder.wrapWithLiveTap(httpFactory)

        // دعم كلٍّ من بثّ HTTP/HTTPS مع ترويسات البوابة المخصّصة + ملفات التسجيل والتنزيل المحلية (file:// & content://)
        val compositeDataSourceFactory = DefaultDataSource.Factory(this, tappedHttpFactory)

        val mediaSourceFactory = DefaultMediaSourceFactory(compositeDataSourceFactory, extractors)
            .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(6))

        player = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .build()
            .also { exo ->
                playerView.player = exo
                exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                    .setPreferredTextLanguages("ar", "ara")
                    .setSelectUndeterminedTextLanguage(false)
                    .build()
                exo.addListener(playerListener)
                exo.addAnalyticsListener(timingListener)
                if (exo.audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                    attachAndApplyAudioBoost(exo.audioSessionId)
                }
            }
    }

    private fun releaseLoudnessEnhancer() {
        runCatching {
            loudnessEnhancer?.enabled = false
            loudnessEnhancer?.release()
        }
        loudnessEnhancer = null
        attachedAudioSessionId = C.AUDIO_SESSION_ID_UNSET
    }

    private fun updateAudioBoostButtonLabel() {
        if (!::btnOsdAudio.isInitialized) return
        btnOsdAudio.text = if (currentAudioBoostPct > 100) "🎧 صوت ${currentAudioBoostPct}%" else "🎧 مسار الصوت"
    }

    private fun attachAndApplyAudioBoost(sessionId: Int) {
        if (currentAudioBoostPct <= 100 || sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId <= 0) {
            releaseLoudnessEnhancer()
            return
        }
        runCatching {
            if (loudnessEnhancer == null || attachedAudioSessionId != sessionId) {
                releaseLoudnessEnhancer()
                loudnessEnhancer = LoudnessEnhancer(sessionId)
                attachedAudioSessionId = sessionId
            }
            val gainMb = when {
                currentAudioBoostPct >= 200 -> 2000
                currentAudioBoostPct >= 160 -> 1400
                currentAudioBoostPct >= 130 -> 800
                else -> 0
            }
            loudnessEnhancer?.setTargetGain(gainMb)
            loudnessEnhancer?.enabled = (gainMb > 0)
        }.onFailure {
            releaseLoudnessEnhancer()
        }
    }

    private fun applySubtitleStyleFromPrefs() {
        val prefs = store.loadPrefs()
        val subView = playerView.subtitleView ?: return
        subView.setApplyEmbeddedStyles(false)
        subView.setApplyEmbeddedFontSizes(false)
        // UI readability must not silently enlarge the user's explicitly chosen subtitle size.
        val subtitlePx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
            prefs.subSizeSp.toFloat(), applicationContext.resources.displayMetrics)
        subView.setFixedTextSize(TypedValue.COMPLEX_UNIT_PX, subtitlePx)
        val fgColor = when (prefs.subColorIndex) {
            1 -> Color.parseColor("#FDE047") // أصفر سينمائي مريح
            2 -> Color.parseColor("#67E8F9") // سماوي هادئ
            else -> Color.WHITE
        }
        val bgColor = if (prefs.subBgTranslucent) Color.parseColor("#B4000000") else Color.TRANSPARENT
        subView.setStyle(
            CaptionStyleCompat(
                fgColor,
                bgColor,
                Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                Color.BLACK,
                Typeface.DEFAULT_BOLD
            )
        )
    }

    private val playerListener = object : Player.Listener {
        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            attachAndApplyAudioBoost(audioSessionId)
        }

        override fun onCues(cueGroup: CueGroup) {
            // عند اختيار تأخير موجب للترجمة المدمجة (+0.5s .. +5.0s) دون وجود ملف خارجي، نؤخّر عرض النصّ بدقّة
            if (originalExternalSubUri == null && subtitleOffsetMs > 0L) {
                val cuesCopy = cueGroup.cues
                val delay = subtitleOffsetMs
                uiHandler.post {
                    if (!isFinishing && !isDestroyed) {
                        playerView.subtitleView?.setCues(emptyList())
                    }
                }
                uiHandler.postDelayed({
                    if (!isFinishing && !isDestroyed) {
                        playerView.subtitleView?.setCues(cuesCopy)
                    }
                }, delay)
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!pausedStreamForInternalDownload && currentItem?.kind != ItemKind.LIVE) {
                btnOsdPlayPause.text = if (isPlaying) "⏸ إيقاف مؤقّت" else "▶ استئناف"
            }
            syncWatchSessionState()
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            tryApplyPendingResumeSeek()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            syncWatchSessionState()
            when (playbackState) {
                Player.STATE_BUFFERING -> {
                    com.iptvlite.tv.network.SelectedCategoryLoad.playbackStarting()
                    playbackEvent(PlaybackDiagnostics.Stage.BUFFERING)
                    bufferOverlay.visibility = View.VISIBLE
                    tvBufferMsg.text = "… جارٍ التحميل"
                }

                Player.STATE_READY -> {
                    playbackEvent(PlaybackDiagnostics.Stage.READY)
                    liveStoppedAwaitingAction = false
                    if (currentItem?.kind != ItemKind.LIVE || firstFrameMs != null) bufferOverlay.visibility = View.GONE
                    if (currentItem?.kind != ItemKind.LIVE) retryCount = 0
                    if (!everPlayedCurrent) {
                        everPlayedCurrent = true
                        val cur = currentItem
                        if (cur != null) {
                            store.incrementWatchCount(cur.kind)
                            if (cur.kind == ItemKind.LIVE) {
                                loadShortEpgBannerPostReady(cur)
                            }
                        }
                    }
                    tryApplyPendingResumeSeek()
                    if (!pausedStreamForInternalDownload && currentItem?.kind != ItemKind.LIVE) {
                        btnOsdPlayPause.text = if (player?.isPlaying == true) "⏸ إيقاف مؤقّت" else "▶ استئناف"
                    }
                }

                Player.STATE_ENDED -> {
                    bufferOverlay.visibility = View.GONE
                    val cur = currentItem
                    if (cur != null && cur.kind != ItemKind.LIVE) {
                        val isLocal = cur.cmd.startsWith("file://", true) || cur.cmd.startsWith("content://", true)
                        val dur = player?.duration?.takeIf { it != C.TIME_UNSET && it > 0L } ?: lastValidVodDurMs
                        val posNow = maxOf(player?.currentPosition ?: 0L, lastValidVodPosMs)
                        if (!isLocal && dur > 60_000L && posNow in 5_000L..(dur - 45_000L)) {
                            pendingResumeMs = posNow
                            lastValidVodPosMs = posNow
                            resumeSeekApplied = false
                            resumeSeekAttempts = 0
                            attemptReconnect("انقطع تدفّق الملف — جارٍ الاستئناف")
                            return
                        }
                        store.clearResumePos(cur)
                        if (cur.kind == ItemKind.EPISODE && store.loadPrefs().autoNextEpisode) {
                            val nextIdx = PlayQueueHolder.currentIndex + 1
                            if (nextIdx < PlayQueueHolder.playlist.size) {
                                Toast.makeText(
                                    this@PlayerActivity,
                                    "⏭ الانتقال التلقائي للحلقة التالية…",
                                    Toast.LENGTH_SHORT
                                ).show()
                                openStreamAtIndex(nextIdx)
                                return
                            }
                        }
                        showOsd(focusControls = true)
                    } else {
                        handleLiveStreamStopped()
                    }
                }

                Player.STATE_IDLE -> Unit
            }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                val badge = when {
                    videoSize.height >= 2160 || videoSize.width >= 3840 -> "4K"
                    videoSize.height >= 1080 || videoSize.width >= 1920 -> "FHD"
                    videoSize.height >= 720 || videoSize.width >= 1280 -> "HD"
                    else -> "SD"
                }
                val fps = player?.videoFormat?.frameRate?.takeIf { it > 0f }?.roundToInt()
                lastResStr = buildString {
                    append("$badge ${videoSize.width}×${videoSize.height}")
                    if (fps != null && fps > 0) append(" ${fps}fps")
                }
                lastCodecStr = shortCodecLabel(player?.videoFormat?.sampleMimeType)
                if (aspectMode in 3..5) {
                    applyAspectMode(aspectMode, showToast = false)
                }
                updateMetaBanner()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            com.iptvlite.tv.network.SelectedCategoryLoad.playbackStarting()
            playbackEvent(PlaybackDiagnostics.Stage.ERROR, error.errorCode)
            if (currentItem?.kind == ItemKind.LIVE) {
                var cause: Throwable? = error
                var depth = 0
                while (cause != null && depth++ < 12) {
                    if (cause is androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException &&
                        cause.responseCode in setOf(401, 403, 404, 410)) {
                        currentItem?.let { liveLinkMemory.reject(liveLinkKey(it)) }
                        break
                    }
                    cause = cause.cause
                }
            }
            // معالجة فورية (0ms) لتأخّر نافذة البثّ الحي في قنوات HLS دون قطع الصورة!
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                player?.let { exo ->
                    exo.seekToDefaultPosition()
                    exo.prepare()
                    exo.playWhenReady = true
                }
                return
            }
            val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
            val cur = currentItem
            if (!everPlayedCurrent &&
                !triedCreateLinkFallback &&
                acc?.provider == ProviderType.STALKER &&
                cur?.kind == ItemKind.LIVE && !openingSavedLiveLink
            ) {
                triedCreateLinkFallback = true
                PortalClient.markStalkerNeedsCreateLink(acc)
                tvBufferMsg.text = "… جلب تصريح البثّ (create_link)"
                bufferOverlay.visibility = View.VISIBLE
                openCurrentItemInternal(forceCreateLink = true)
                return
            }
            if (cur?.kind == ItemKind.LIVE) {
                handleLiveStreamStopped(error.localizedMessage ?: "")
                return
            }
            attemptReconnect(error.localizedMessage ?: "تعذّر تشغيل البثّ")
        }
    }

    /**
     * يُجلب بعد بدء الفيديو الفعلي (STATE_READY) حصراً لئلا يزاحم فتح القناة بأي ملي ثانية!
     */
    private fun loadShortEpgBannerPostReady(ch: StreamItem) {
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount() ?: return
        epgBannerJob?.cancel()
        epgBannerJob = lifecycleScope.launch {
            val list = runCatching {
                withContext(Dispatchers.IO) { PortalClient.fetchShortEpg(acc, ch, limit = 2) }
            }.getOrDefault(emptyList())
            if (currentItem?.id != ch.id || list.isEmpty()) return@launch
            activeEpgNowProg = list[0]
            activeEpgNextProg = list.getOrNull(1)
            refreshLiveEpgProgressUi()
        }
    }

    private fun refreshLiveEpgProgressUi() {
        val cur = currentItem ?: return
        if (cur.kind != ItemKind.LIVE) {
            pbOsdEpgProgress.visibility = View.GONE
            return
        }
        val nowProg = activeEpgNowProg ?: run {
            pbOsdEpgProgress.visibility = View.GONE
            return
        }
        val nextProg = activeEpgNextProg
        val nowSec = System.currentTimeMillis() / 1000L
        val durSec = nowProg.stopTs - nowProg.startTs
        val hasValidRange = nowProg.startTs > 0L && nowProg.stopTs > nowProg.startTs && nowSec in (nowProg.startTs - 60L)..(nowProg.stopTs + 120L)

        val remTxt = if (hasValidRange) {
            val remMin = ((nowProg.stopTs - nowSec).coerceAtLeast(0L) / 60L).toInt()
            if (remMin > 0) " (متبقّي $remMin د)" else " (ينتهي الآن)"
        } else ""

        tvOsdEpgNow.text = buildString {
            append("🟢 الآن: ${nowProg.name}$remTxt")
            if (nextProg != null) {
                append("   ·   ⏭ التالي: ${nextProg.name}")
            }
        }
        tvOsdEpgNow.visibility = View.VISIBLE

        if (hasValidRange && durSec > 0L) {
            val pct = (((nowSec - nowProg.startTs).toDouble() / durSec.toDouble()) * 100.0)
                .roundToInt()
                .coerceIn(2, 100)
            pbOsdEpgProgress.progress = pct
            pbOsdEpgProgress.visibility = View.VISIBLE
        } else {
            pbOsdEpgProgress.visibility = View.GONE
        }
    }

    private fun showResumeBannerOnce(resumedMs: Long) {
        if (resumeBannerShown) return
        resumeBannerShown = true
        val txt = "⏵ تم الاستئناف من ${formatMs(resumedMs)}"
        showHudBanner(txt, 2200L)
        Toast.makeText(this, txt, Toast.LENGTH_SHORT).show()
    }

    private fun tryApplyPendingResumeSeek() {
        val exo = player ?: return
        val cur = currentItem ?: return
        if (resumeSeekApplied ||
            pendingResumeMs < AppStore.MIN_RESUME_POS_MS ||
            cur.kind == ItemKind.LIVE ||
            cur.kind == ItemKind.CATCHUP
        ) {
            return
        }
        val target = pendingResumeMs
        val posNow = exo.currentPosition.coerceAtLeast(0L)
        val dur = exo.duration
        if (dur != C.TIME_UNSET && dur > 0L) {
            lastValidVodDurMs = dur
        }
        if (posNow >= target - 3_500L) {
            resumeSeekApplied = true
            lastValidVodPosMs = posNow
            showResumeBannerOnce(target)
            return
        }
        if (exo.playbackState != Player.STATE_READY) return

        val durKnownAndValid = dur != C.TIME_UNSET && dur > AppStore.MIN_RESUME_POS_MS
        if (durKnownAndValid && target >= dur - 5_000L) {
            resumeSeekApplied = true
            return
        }
        if (exo.isCurrentMediaItemSeekable || durKnownAndValid) {
            if (resumeSeekAttempts >= 3) {
                resumeSeekApplied = true
                return
            }
            resumeSeekAttempts++
            exo.seekTo(target)
            uiHandler.postDelayed({
                if (isFinishing || isDestroyed) return@postDelayed
                val p = player ?: return@postDelayed
                if (!resumeSeekApplied && p.currentPosition >= target - 3_500L) {
                    resumeSeekApplied = true
                    lastValidVodPosMs = p.currentPosition
                    showResumeBannerOnce(target)
                } else if (!resumeSeekApplied && resumeSeekAttempts < 3 && p.playbackState == Player.STATE_READY) {
                    tryApplyPendingResumeSeek()
                }
            }, 650L)
        }
    }

    private fun commitManualUserSeek(targetMs: Long) {
        val exo = player ?: return
        val safeTarget = targetMs.coerceAtLeast(0L)
        resumeSeekApplied = true
        exo.seekTo(safeTarget)
        val cur = currentItem ?: return
        if (cur.kind == ItemKind.VOD || cur.kind == ItemKind.EPISODE) {
            val dur = exo.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: lastValidVodDurMs
            if (safeTarget >= AppStore.MIN_RESUME_POS_MS) {
                lastValidVodPosMs = safeTarget
                pendingResumeMs = safeTarget
                val accId = (PlayQueueHolder.activeAccount ?: store.getActiveAccount())?.id.orEmpty()
                store.saveResumeEntry(cur, safeTarget, dur, accId)
            } else if (safeTarget < 3_000L) {
                lastValidVodPosMs = 0L
                pendingResumeMs = 0L
                store.clearResumePos(cur)
            }
        }
    }

    private var liveStoppedAwaitingAction: Boolean = false

    // One foreground-only supervisor. READY and a resolved URL are never recovery success.
    private var resolverScope: com.iptvlite.tv.network.PlaybackRequestScope? = null
    private var playbackTransport: okhttp3.OkHttpClient? = null
    private var rebuildFailedPlayer = false

    private fun cancelOwnedPlaybackRequests() {
        resolverScope?.cancel { com.iptvlite.tv.network.NetworkCleanup.cancel(it) }
        resolverScope = null
        playbackTransport?.dispatcher?.let { com.iptvlite.tv.network.NetworkCleanup.cancelCurrent(it) }
    }

    private fun resetFailedPlaybackEngine() {
        if (!rebuildFailedPlayer) return
        rebuildFailedPlayer = false
        player?.removeListener(playerListener)
        player?.removeAnalyticsListener(timingListener)
        playerView.player = null
        releaseLoudnessEnhancer()
        player?.release()
        player = null
        // Only this activity's idle sockets; no shared dispatcher/pool cancellation.
        val retiredTransport = playbackTransport
        playbackTransport = null
        com.iptvlite.tv.network.NetworkCleanup.close(retiredTransport)
        initPlayer(store.loadPrefs().cacheMs)
    }

    private var liveRecoveryAttempt = 0
    private var liveRecoveryPending = false
    private var liveLastProgressAt = 0L
    private var liveStableSince = 0L
    private var liveLastPosition = -1L
    private var liveLastFrames = -1
    private var liveAttemptStartedAt = 0L
    private val liveSupervisor = object : Runnable {
        override fun run() {
            if (stoppedInBackground || isFinishing || currentItem?.kind != ItemKind.LIVE) return
            val now = SystemClock.elapsedRealtime()
            val exo = player
            val frames = exo?.videoDecoderCounters?.renderedOutputBufferCount ?: 0
            val position = exo?.currentPosition ?: 0L
            val video = exo?.videoFormat != null
            val advanced = if (video) frames > liveLastFrames && frames > 0 else position > liveLastPosition && position > 0L
            if (!liveRecoveryPending && exo?.isPlaying == true && advanced) {
                liveLastProgressAt = now
                if (liveStableSince == 0L) liveStableSince = now
                if (now - liveStableSince >= 12_000L) {
                    liveRecoveryAttempt = 0
                    confirmCurrentLiveLink()
                    currentItem?.let { liveLinkMemory.stable(liveLinkKey(it)) }
                    bufferOverlay.visibility = View.GONE
                }
            } else {
                liveStableSince = 0L
            }
            liveLastFrames = frames
            liveLastPosition = position
            // Long grace absorbs ordinary jitter; also catches READY-without-video and hung URL opens.
            if (!liveRecoveryPending && now - maxOf(liveLastProgressAt, liveAttemptStartedAt) >= 35_000L) {
                handleLiveStreamStopped()
            }
            uiHandler.postDelayed(this, 2000L)
        }
    }

    private fun stopLiveRecovery() {
        uiHandler.removeCallbacks(liveSupervisor)
        liveRecoveryPending = false
        liveRecoveryAttempt = 0
        liveStableSince = 0L
    }

    private fun armLiveSupervisor() {
        if (currentItem?.kind != ItemKind.LIVE || stoppedInBackground) return
        (bufferOverlay.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let {
            it.gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
            it.bottomMargin = (28 * resources.displayMetrics.density).toInt()
            bufferOverlay.layoutParams = it
        }
        tvBufferMsg.textSize = 14f
        liveRecoveryPending = false
        liveAttemptStartedAt = SystemClock.elapsedRealtime()
        liveLastProgressAt = liveAttemptStartedAt
        liveStableSince = 0L
        liveLastFrames = -1
        liveLastPosition = -1L
        uiHandler.removeCallbacks(liveSupervisor)
        uiHandler.postDelayed(liveSupervisor, 2000L)
    }

    private fun handleLiveStreamStopped(errReason: String = "") {
        if (stoppedInBackground || isFinishing || currentItem?.kind != ItemKind.LIVE || liveRecoveryPending) return
        playbackEvent(PlaybackDiagnostics.Stage.LIVE_STOPPED)
        measuringFirstFrame = false
        if (firstFrameMs == null) lastOpenSpeedStr = "⚡ انتظار عودة الفيديو"
        updateMetaBanner()
        cancelPendingReconnect()
        liveRecoveryPending = true
        liveStoppedAwaitingAction = false
        liveStableSince = 0L
        liveRecoveryAttempt = (liveRecoveryAttempt + 1).coerceAtMost(1000)
        val delayMs = com.iptvlite.tv.util.LiveRecoveryPolicy.delayMs(liveRecoveryAttempt)
        val expectedOperation = playbackOperationId
        val expectedItem = currentItem
        cancelOwnedPlaybackRequests()
        openJob?.cancel()
        rebuildFailedPlayer = true
        // Close only this operation's sockets; never cancel shared work from a stale IO job.
        player?.stop()
        player?.clearMediaItems()
        bufferOverlay.visibility = View.VISIBLE
        tvBufferMsg.text = "↻ جارٍ انتظار عودة البث…"
        pendingReconnectRunnable = Runnable {
            pendingReconnectRunnable = null
            if (stoppedInBackground || isFinishing || currentItem !== expectedItem || playbackOperationId != expectedOperation) {
                liveRecoveryPending = false
                return@Runnable
            }
            liveRecoveryPending = false
            val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
            val savedLink = currentItem?.let { liveLinkMemory.nextReuse(liveLinkKey(it)) }
            openCurrentItemInternal(
                savedLiveLink = savedLink,
                forceCreateLink = savedLink == null,
                forceSessionRefresh = savedLink == null && acc?.provider == ProviderType.STALKER &&
                    com.iptvlite.tv.util.LiveRecoveryPolicy.refreshSession(liveRecoveryAttempt),
                isReconnect = true,
                reason = PlaybackDiagnostics.Operation.LIVE_RECOVERY
            )
        }.also { uiHandler.postDelayed(it, delayMs) }
    }

    private fun quickReloadCurrentStream() {
        val cur = currentItem ?: return
        stopLiveRecovery()
        beginPlaybackOperation(PlaybackDiagnostics.Operation.MANUAL_REOPEN)
        liveStoppedAwaitingAction = false
        cancelPendingReconnect()
        saveCurrentPositionIfVod()
        retryCount = 0
        triedCreateLinkFallback = false
        val isLocal = cur.cmd.startsWith("file://", true) || cur.cmd.startsWith("content://", true)
        if (cur.kind != ItemKind.LIVE && cur.kind != ItemKind.CATCHUP) {
            val bestPos = maxOf(pendingResumeMs, lastValidVodPosMs, player?.currentPosition ?: 0L)
            if (bestPos >= AppStore.MIN_RESUME_POS_MS) {
                pendingResumeMs = bestPos
                resumeSeekApplied = false
                resumeSeekAttempts = 0
            }
        }
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
        val savedLink = if (cur.kind == ItemKind.LIVE) liveLinkMemory.nextReuse(liveLinkKey(cur)) else null
        Toast.makeText(
            this,
            if (cur.kind == ItemKind.LIVE) "↻ جارٍ إعادة فتح القناة…" else "↻ جارٍ إنعاش التشغيل…",
            Toast.LENGTH_SHORT
        ).show()
        openCurrentItemInternal(
            savedLiveLink = savedLink,
            forceCreateLink = !isLocal && savedLink == null,
            forceSessionRefresh = (!isLocal && savedLink == null && acc?.provider == ProviderType.STALKER),
            isReconnect = !isLocal,
            operationAlreadyStarted = true
        )
    }

    private var pendingReconnectRunnable: Runnable? = null

    private fun cancelPendingReconnect() {
        pendingReconnectRunnable?.let { uiHandler.removeCallbacks(it) }
        pendingReconnectRunnable = null
    }

    private fun attemptReconnect(errReason: String = "") {
        cancelPendingReconnect()
        val cur = currentItem ?: return
        // Live uses its separate foreground-only verified recovery supervisor.
        if (cur.kind == ItemKind.LIVE) {
            handleLiveStreamStopped(errReason)
            return
        }
        val curCmd = cur.cmd.trim()
        if (curCmd.startsWith("file://", ignoreCase = true) || curCmd.startsWith("content://", ignoreCase = true)) {
            bufferOverlay.visibility = View.VISIBLE
            tvBufferMsg.text = "✖ هذا الملف المحلّي تالف أو غير مكتمل — يمكنك حذفه من «تسجيلاتي» وإعادة تحميله"
            showOsd(focusControls = true)
            return
        }

        saveCurrentPositionIfVod()
        val curKind = cur.kind
        if (curKind == ItemKind.VOD || curKind == ItemKind.EPISODE) {
            val bestPos = maxOf(pendingResumeMs, lastValidVodPosMs, player?.currentPosition ?: 0L)
            if (bestPos >= AppStore.MIN_RESUME_POS_MS) {
                pendingResumeMs = bestPos
                resumeSeekApplied = false
                resumeSeekAttempts = 0
            }
        }

        val prevResolved = currentResolvedStreamUrl
        openJob?.cancel()
        player?.stop()
        player?.clearMediaItems()
        lifecycleScope.launch(Dispatchers.IO) {
            PortalClient.prepareForStreamReconnect(prevResolved, curCmd)
        }

        val prefs = store.loadPrefs()
        val maxRetries = 4
        if (prefs.autoReconnect && retryCount < maxRetries) {
            retryCount++
            val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
            val needFreshToken = triedCreateLinkFallback || acc?.provider == ProviderType.STALKER
            val refreshSession = (acc?.provider == ProviderType.STALKER && retryCount >= 2)
            val delayMs = (1500L + (retryCount - 1) * 1200L).coerceAtMost(5000L)
            bufferOverlay.visibility = View.VISIBLE
            tvBufferMsg.text = "↻ جارٍ استئناف التشغيل من نفس الموضع ($retryCount/$maxRetries)…"
            val r = Runnable {
                pendingReconnectRunnable = null
                if (!isFinishing && !isDestroyed && !stoppedInBackground) {
                    openCurrentItemInternal(
                        forceCreateLink = needFreshToken,
                        forceSessionRefresh = refreshSession,
                        isReconnect = false,
                        reason = PlaybackDiagnostics.Operation.VOD_RESUME
                    )
                }
            }
            pendingReconnectRunnable = r
            uiHandler.postDelayed(r, delayMs)
        } else {
            bufferOverlay.visibility = View.VISIBLE
            tvBufferMsg.text = "✖ توقّف التشغيل ${if (errReason.isNotBlank()) "($errReason)" else ""}"
            showOsd(focusControls = true)
            btnOsdReload.requestFocus()
        }
    }

    private fun openStreamAtIndex(newIndex: Int) {
        com.iptvlite.tv.network.SelectedCategoryLoad.playbackStarting()
        cancelSubtitleReload()
        stopLiveRecovery()
        cancelOwnedPlaybackRequests()
        openJob?.cancel()
        liveStoppedAwaitingAction = false
        cancelPendingReconnect()
        val list = PlayQueueHolder.playlist
        if (list.isEmpty()) return
        val wrapped = ((newIndex % list.size) + list.size) % list.size
        flushAccumulatedWatchSeconds()
        saveCurrentPositionIfVod()

        val prev = currentItem
        val next = list[wrapped]
        if (prev != null && prev.id != next.id) {
            if (startedRecInPlayer && StreamRecorder.isRecording()) {
                StreamRecorder.stopRecording()
                startedRecInPlayer = false
                recLiveStatusStr = ""
            } else if (StreamRecorder.isTapRecordingActive()) {
                StreamRecorder.handoffLiveTapToBackgroundNetwork()
            }
        }
        if (prev != null && prev.id != next.id && prev.kind == ItemKind.LIVE) {
            PlayQueueHolder.previousItem = prev
        }
        if (next.kind == ItemKind.LIVE) {
            PlayQueueHolder.archiveSourceChannel = next
        }
        PlayQueueHolder.currentIndex = wrapped
        currentItem = next
        pausedStreamForInternalDownload = false
        currentResolvedStreamUrl = ""
        originalExternalSubUri = null
        externalSubUri = null
        subtitleOffsetMs = 0L
        everPlayedCurrent = false
        triedCreateLinkFallback = false
        retryCount = 0
        lastOpenSpeedStr = ""
        lastResStr = ""
        lastCodecStr = ""
        val savedResume = if (next.kind == ItemKind.VOD || next.kind == ItemKind.EPISODE) {
            store.getResumePos(next)
        } else 0L
        pendingResumeMs = savedResume
        resumeSeekApplied = (savedResume < AppStore.MIN_RESUME_POS_MS)
        resumeSeekAttempts = 0
        resumeBannerShown = false
        lastValidVodPosMs = savedResume
        lastValidVodDurMs = 0L
        lastPeriodicResumeSaveMs = 0L

        if (next.kind == ItemKind.LIVE && playbackSpeed != 1.0f) {
            playbackSpeed = 1.0f
            player?.setPlaybackSpeed(1.0f)
            btnOsdSpeed.text = "⏩ 1.0x"
        }

        activeEpgNowProg = null
        activeEpgNextProg = null
        pbOsdEpgProgress.visibility = View.GONE

        val isLocalOffline = next.cmd.startsWith("file://", ignoreCase = true) ||
            next.cmd.startsWith("content://", ignoreCase = true)

        if (!isLocalOffline && next.kind != ItemKind.CATCHUP) {
            store.addRecent(next)
        }
        val cleanItemTitle = MediaTitleFormatter.parseMedia(next.name).cleanTitle
        tvOsdTitle.text = if (next.kind == ItemKind.CATCHUP || isLocalOffline) {
            cleanItemTitle
        } else {
            "${wrapped + 1}. $cleanItemTitle"
        }
        if (isLocalOffline) {
            tvOsdMeta.text = "📂 محفوظ محلياً"
            tvOsdMeta.visibility = View.VISIBLE
        } else {
            tvOsdMeta.text = ""
            tvOsdMeta.visibility = View.GONE
        }
        if (next.kind == ItemKind.CATCHUP && next.subtitle.isNotBlank()) {
            tvOsdEpgNow.text = "↺ برنامج أرشيف مُعاد  ·  ${next.subtitle}  (استخدم ◀▶ للتقديم والترجيع)"
            tvOsdEpgNow.visibility = View.VISIBLE
        } else if (isLocalOffline) {
            tvOsdEpgNow.text = "📂 تشغيل مباشر من ذاكرة الجهاز بدون استهلاك إنترنت (استخدم ◀▶ للتقديم والترجيع)"
            tvOsdEpgNow.visibility = View.VISIBLE
        } else {
            tvOsdEpgNow.text = ""
            tvOsdEpgNow.visibility = View.GONE
        }

        // الإيقاف المؤقّت، شريط التقديم، وسرعة التشغيل متاحة فقط للأفلام والحلقات وبرامج الأرشيف والملفات المحلّية، ومُلغاة تماماً في البثّ المباشر!
        val isLiveKind = (next.kind == ItemKind.LIVE)
        btnOsdPlayPause.visibility = if (isLiveKind) View.GONE else View.VISIBLE
        if (isLiveKind && lastFocusedBottomOsdBtn === btnOsdPlayPause) {
            lastFocusedBottomOsdBtn = null
        }
        btnOsdReload.text = if (isLiveKind) "↻ إعادة فتح" else "↻ إنعاش"
        seekRow.visibility = if (isLiveKind) View.GONE else View.VISIBLE
        btnOsdSpeed.visibility = if (isLiveKind) View.GONE else View.VISIBLE
        val isVodOrEpisode = next.kind == ItemKind.VOD || next.kind == ItemKind.EPISODE
        btnOsdDownload.visibility =
            if (!isLocalOffline && isVodOrEpisode) View.VISIBLE else View.GONE
        btnOsdDownload.text = if (StreamRecorder.isDownloading()) "⏹ إيقاف التحميل" else "📥 تحميل"
        // زرّ التسجيل الفوري مخصّص للبثّ المباشر والأرشيف (بينما الأفلام والحلقات تُحفظ كاملةً بزرّ 📥 تحميل لضمان سلامة فهرس MP4/MKV)
        btnOsdRecord.visibility = if (isLocalOffline || isVodOrEpisode) View.GONE else View.VISIBLE
        btnOsdEpg.visibility = if (isLocalOffline) View.GONE else View.VISIBLE
        btnOsdFav.visibility = if (isLocalOffline) View.GONE else View.VISIBLE
        btnOsdRecord.text = if (StreamRecorder.isRecording()) "⏹ إيقاف" else "⏺ تسجيل"
        btnOsdEpg.text = if (next.kind == ItemKind.LIVE || next.kind == ItemKind.CATCHUP) {
            "📋 الدليل والأرشيف"
        } else {
            "🎬 بطاقة العمل"
        }
        val favRef = if (next.kind == ItemKind.CATCHUP) (PlayQueueHolder.archiveSourceChannel ?: next) else next
        updateFavButton(store.isFavorite(favRef))
        showOsd(focusControls = false)

        openCurrentItemInternal(forceCreateLink = false,
            reason = if (prev == null) PlaybackDiagnostics.Operation.OPEN else PlaybackDiagnostics.Operation.CHANNEL_SWITCH)
    }

    private fun openCurrentItemInternal(
        forceCreateLink: Boolean,
        forceSessionRefresh: Boolean = false,
        isReconnect: Boolean = false,
        reason: PlaybackDiagnostics.Operation = PlaybackDiagnostics.Operation.OPEN,
        operationAlreadyStarted: Boolean = false,
        savedLiveLink: com.iptvlite.tv.util.LiveLinkMemory.Link? = null
    ) {
        val item = currentItem ?: return
        cancelOwnedPlaybackRequests()
        openJob?.cancel()
        resetFailedPlaybackEngine()
        if (!operationAlreadyStarted) beginPlaybackOperation(reason)
        val operationId = playbackOperationId
        pendingLiveLink = null
        pendingLiveLinkKey = null
        pendingLiveLinkOperation = -1L
        openingSavedLiveLink = savedLiveLink != null && item.kind == ItemKind.LIVE
        if (item.kind == ItemKind.LIVE) playbackEvent(
            if (openingSavedLiveLink) PlaybackDiagnostics.Stage.REUSE_LINK else PlaybackDiagnostics.Stage.RESOLVE_LINK)
        armLiveSupervisor()
        if (item.kind != ItemKind.LIVE) {
            (bufferOverlay.layoutParams as? android.widget.FrameLayout.LayoutParams)?.let {
                it.gravity = android.view.Gravity.CENTER
                it.bottomMargin = 0
                bufferOverlay.layoutParams = it
            }
        }
        liveStoppedAwaitingAction = false
        val rawCmd = item.cmd.trim()
        val isLocalFile = rawCmd.startsWith("file://", ignoreCase = true) || rawCmd.startsWith("content://", ignoreCase = true)
        StreamRecorder.setLivePlayerTapStandby(
            !isLocalFile && (item.kind == ItemKind.LIVE || item.kind == ItemKind.CATCHUP)
        )

        if (isLocalFile) {
            epgBannerJob?.cancel()
            openJob?.cancel()
            urlPreparationMs = SystemClock.elapsedRealtime() - openStartMs
            playbackEvent(PlaybackDiagnostics.Stage.URL_READY)
            bufferOverlay.visibility = View.VISIBLE
            tvBufferMsg.text = "📂 جارٍ فتح الملف المحلّي: ${item.name}"
            player?.stop()
            player?.clearMediaItems()
            currentResolvedStreamUrl = rawCmd
            player?.let { exo ->
                val mediaItem = buildMediaItemWithOptionalSub(rawCmd, externalSubUri)
                val startPosMs = if (!resumeSeekApplied && pendingResumeMs >= AppStore.MIN_RESUME_POS_MS && item.kind != ItemKind.CATCHUP) {
                    pendingResumeMs
                } else {
                    C.TIME_UNSET
                }
                if (startPosMs != C.TIME_UNSET) {
                    exo.setMediaItem(mediaItem, startPosMs)
                } else {
                    exo.setMediaItem(mediaItem)
                }
                exo.volume = if (isPlayerMuted) 0f else 1f
                exo.prepare()
                exo.playWhenReady = true
            }
            return
        }

        val acc = (if (item.accountId.isNotBlank()) store.getAccounts().firstOrNull { it.id == item.accountId } else null)
            ?: PlayQueueHolder.activeAccount
            ?: store.getActiveAccount()
            ?: return
        PlayQueueHolder.activeAccount = acc

        PortalClient.preemptBrowse()
        epgBannerJob?.cancel()
        openJob?.cancel()
        bufferOverlay.visibility = View.VISIBLE
        tvBufferMsg.text = if (!resumeSeekApplied && pendingResumeMs >= AppStore.MIN_RESUME_POS_MS) {
            "⏵ جارٍ الفتح والاستئناف من ${formatMs(pendingResumeMs)}: ${item.name}"
        } else {
            "⚡ جارٍ فتح: ${item.name}"
        }
        val prevResolvedUrl = currentResolvedStreamUrl
        player?.stop()
        player?.clearMediaItems()

        val requestScope = com.iptvlite.tv.network.PlaybackRequestScope()
        resolverScope = requestScope
        openJob = lifecycleScope.launch {
            val urlRes = runCatching {
                if (openingSavedLiveLink && savedLiveLink != null) savedLiveLink.url
                else withContext(Dispatchers.IO) {
                    requestScope.run {
                    if (prevResolvedUrl.isNotBlank()) PortalClient.evictStreamRedirect(prevResolvedUrl)
                    PortalClient.resolveStreamUrl(
                        acc = acc,
                        item = item,
                        forceCreateLink = forceCreateLink,
                        forceSessionRefresh = forceSessionRefresh
                    )
                    }
                }
            }
            urlRes.onSuccess { streamUrl ->
                if (operationId != playbackOperationId || stoppedInBackground) return@onSuccess
                if (streamUrl.isBlank()) {
                    if (item.kind == ItemKind.LIVE) {
                        handleLiveStreamStopped("السيرفر لم يُرجع رابط بثّ صالحاً")
                    } else {
                        attemptReconnect("السيرفر لم يُرجع رابط بثّ صالحاً")
                    }
                    return@onSuccess
                }
                urlPreparationMs = SystemClock.elapsedRealtime() - openStartMs
                playbackEvent(PlaybackDiagnostics.Stage.URL_READY)
                currentResolvedStreamUrl = streamUrl
                // تحديث وكيل المستخدم والترويسات والكوكيز النشطة قبل بدء سحب مقاطع البثّ مباشرةً (يدعم التنقّل بين سيرفرات مختلفة في المفضّلة)
                val ua = savedLiveLink?.userAgent ?: if (acc.provider == ProviderType.STALKER) PortalClient.MAG_UA else PortalClient.GENERIC_UA
                val headers = savedLiveLink?.headers ?: PortalClient.getStreamRequestHeaders(acc).toMap()
                httpDataSourceFactory?.setUserAgent(ua)
                httpDataSourceFactory?.setDefaultRequestProperties(headers)
                if (item.kind == ItemKind.LIVE) {
                    pendingLiveLink = com.iptvlite.tv.util.LiveLinkMemory.Link(streamUrl, ua, headers.toMap())
                    pendingLiveLinkKey = liveLinkKey(item)
                    pendingLiveLinkOperation = operationId
                }
                player?.let { exo ->
                    val mediaItem = buildMediaItemWithOptionalSub(streamUrl, externalSubUri)
                    val startPosMs = if (!resumeSeekApplied && pendingResumeMs >= AppStore.MIN_RESUME_POS_MS && item.kind != ItemKind.CATCHUP) {
                        pendingResumeMs
                    } else {
                        C.TIME_UNSET
                    }
                    if (startPosMs != C.TIME_UNSET) {
                        exo.setMediaItem(mediaItem, startPosMs)
                    } else {
                        exo.setMediaItem(mediaItem)
                    }
                    exo.volume = if (isPlayerMuted) 0f else 1f
                    exo.prepare()
                    exo.playWhenReady = true
                }
            }.onFailure { err ->
                if (err is kotlinx.coroutines.CancellationException) throw err
                if (operationId != playbackOperationId || stoppedInBackground) return@onFailure
                val msg = err.message?.take(60) ?: "تعذّر تجهيز الرابط"
                if (item.kind == ItemKind.LIVE) {
                    handleLiveStreamStopped(msg)
                } else {
                    attemptReconnect(msg)
                }
            }
        }
    }

    private fun buildMediaItemWithOptionalSub(streamUrl: String, subUri: Uri?): MediaItem {
        val builder = MediaItem.Builder().setUri(streamUrl).setMediaId("operation-$playbackOperationId")
        if (subUri != null) {
            val pathLower = subUri.toString().lowercase(Locale.US)
            val mime = when {
                pathLower.contains(".vtt") -> MimeTypes.TEXT_VTT
                pathLower.contains(".ass") || pathLower.contains(".ssa") -> MimeTypes.TEXT_SSA
                else -> MimeTypes.APPLICATION_SUBRIP
            }
            val subCfg = MediaItem.SubtitleConfiguration.Builder(subUri)
                .setMimeType(mime)
                .setLanguage("ar")
                .setLabel("ترجمة خارجية (SRT)")
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT or C.SELECTION_FLAG_AUTOSELECT)
                .build()
            builder.setSubtitleConfigurations(listOf(subCfg))
        }
        return builder.build()
    }

    private fun applyExternalSubtitleUri(uri: Uri) {
        originalExternalSubUri = uri
        subtitleOffsetMs = 0L
        reloadExternalSubtitleWithOffset(uri, 0L)
        showHudBanner("💬 تمّ تفعيل ملف الترجمة الخارجي")
    }

    private var subtitleReloadJob: Job? = null
    private var subtitleReloadGeneration = 0
    private fun cancelSubtitleReload() {
        subtitleReloadGeneration++
        subtitleReloadJob?.cancel()
        subtitleReloadJob = null
    }

    private fun reloadExternalSubtitleWithOffset(baseUri: Uri, offsetMs: Long) {
        val exo = player ?: return
        val url = currentResolvedStreamUrl
        if (url.isBlank()) return
        cancelSubtitleReload()
        val expectedGeneration=subtitleReloadGeneration
        val expectedItem=currentItem
        subtitleReloadJob = lifecycleScope.launch {
            val effectiveUri = if (offsetMs == 0L) {
                baseUri
            } else {
                withContext(Dispatchers.IO) {
                    buildShiftedSubtitleFileUri(baseUri, offsetMs)
                } ?: run {
                    if(expectedGeneration==subtitleReloadGeneration && !stoppedInBackground && !isFinishing)
                        Toast.makeText(this@PlayerActivity,"تعذّر تعديل توقيت ملف الترجمة؛ قد يكون كبيراً أو غير قابل للقراءة",Toast.LENGTH_LONG).show()
                    return@launch
                }
            }
            if(expectedGeneration!=subtitleReloadGeneration || player !== exo || currentItem !== expectedItem ||
                currentResolvedStreamUrl!=url || stoppedInBackground || isFinishing || isDestroyed) return@launch
            beginPlaybackOperation(PlaybackDiagnostics.Operation.SUBTITLE_RELOAD)
            urlPreparationMs = 0L
            playbackEvent(PlaybackDiagnostics.Stage.URL_READY)
            externalSubUri = effectiveUri
            val curPos = exo.currentPosition.coerceAtLeast(0L)
            val wasPlaying = exo.playWhenReady
            exo.trackSelectionParameters = exo.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                .setPreferredTextLanguage("ar")
                .build()
            exo.setMediaItem(buildMediaItemWithOptionalSub(url, effectiveUri), curPos)
            exo.prepare()
            exo.playWhenReady = wasPlaying
        }
    }

    private fun buildShiftedSubtitleFileUri(srcUri: Uri, deltaMs: Long): Uri? {
        return runCatching {
            val rawText = contentResolver.openInputStream(srcUri)?.use { com.iptvlite.tv.util.BoundedInput.read(it,2_000_000).toString(Charsets.UTF_8) }
                ?: return null
            val isVtt = srcUri.toString().lowercase(Locale.US).contains(".vtt") || rawText.trimStart().startsWith("WEBVTT")
            val timeRe = Regex("""(\d{1,2}):(\d{2}):(\d{2})([,\.])(\d{3})""")
            val shifted = timeRe.replace(rawText) { m ->
                val hh = m.groupValues[1].toLong()
                val mm = m.groupValues[2].toLong()
                val ss = m.groupValues[3].toLong()
                val sep = m.groupValues[4]
                val ms = m.groupValues[5].toLong()
                val total = (hh * 3600_000L + mm * 60_000L + ss * 1000L + ms + deltaMs).coerceAtLeast(0L)
                val nh = total / 3600_000L
                val nm = (total % 3600_000L) / 60_000L
                val ns = (total % 60_000L) / 1000L
                val nms = total % 1000L
                String.format(Locale.US, "%02d:%02d:%02d%s%03d", nh, nm, ns, sep, nms)
            }
            val ext = if (isVtt) "vtt" else "srt"
            cacheDir.listFiles()?.filter { it.name.startsWith("shifted_sub_") && it.isFile }
                ?.sortedByDescending { it.lastModified() }?.drop(7)?.forEach { it.delete() }
            val outFile = java.io.File.createTempFile("shifted_sub_", ".$ext", cacheDir)
            outFile.writeText(shifted, Charsets.UTF_8)
            Uri.fromFile(outFile)
        }.getOrNull()
    }

    private fun appendDigitJump(digit: Char) {
        if (PlayQueueHolder.playlist.size <= 1) return
        if (digitBuffer.length >= 4) digitBuffer.clear()
        digitBuffer.append(digit)
        tvChannelJumpBox.text = "📺 $digitBuffer"
        tvChannelJumpBox.visibility = View.VISIBLE
        uiHandler.removeCallbacks(commitDigitsRunnable)
        uiHandler.postDelayed(commitDigitsRunnable, 1300L)
    }

    private fun commitDigitJump() {
        uiHandler.removeCallbacks(commitDigitsRunnable)
        tvChannelJumpBox.visibility = View.GONE
        val num = digitBuffer.toString().toIntOrNull()
        digitBuffer.clear()
        val list = PlayQueueHolder.playlist
        if (num == null || num < 1 || list.isEmpty()) return
        val targetIdx = (num - 1).coerceIn(0, list.size - 1)
        openStreamAtIndex(targetIdx)
    }

    private fun switchToPreviousChannel() {
        val prev = PlayQueueHolder.previousItem
        if (prev == null) {
            Toast.makeText(this, "لا توجد قناة سابقة في هذه الجلسة", Toast.LENGTH_SHORT).show()
            return
        }
        val idx = PlayQueueHolder.playlist.indexOfFirst { it.id == prev.id }
        if (idx >= 0) {
            openStreamAtIndex(idx)
        } else {
            val combined = listOf(prev) + PlayQueueHolder.playlist
            PlayQueueHolder.playlist = combined
            openStreamAtIndex(0)
        }
    }

    private fun openLiveDrawer() {
        com.iptvlite.tv.network.SelectedCategoryLoad.refreshQueue(currentItem)
        val list = PlayQueueHolder.playlist
        if (list.isEmpty()) return
        hideOsd()
        drawerAdapter.submit(list)
        liveDrawer.visibility = View.VISIBLE
        val curIdx = PlayQueueHolder.currentIndex.coerceIn(0, list.size - 1)
        rvDrawerChannels.scrollToPosition(curIdx)
        rvDrawerChannels.post {
            rvDrawerChannels.findViewHolderForAdapterPosition(curIdx)?.itemView?.requestFocus()
                ?: rvDrawerChannels.requestFocus()
        }
    }

    private fun showAudioTrackDialog() {
        val exo = player ?: return
        val groups = exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        // 1) مضخّم الصوت المادّي (LoudnessEnhancer: 100% .. 200%)
        for ((pct, desc) in listOf(
            100 to "100% (الصوت الأصلي الطبيعي)",
            130 to "130% (تضخيم متوسّط وواضح)",
            160 to "160% (تضخيم عالٍ للقنوات المنخفضة)",
            200 to "200% (أقصى تضخيم مضاعف)"
        )) {
            val mark = if (currentAudioBoostPct == pct) "✔ " else ""
            labels.add("${mark}🔊 مضخّم الصوت: $desc")
            actions.add {
                currentAudioBoostPct = pct
                store.savePrefs(store.loadPrefs().copy(audioBoostPct = pct))
                attachAndApplyAudioBoost(exo.audioSessionId)
                updateAudioBoostButtonLabel()
                showHudBanner("🔊 تضخيم الصوت: $pct%")
            }
        }

        // 2) المسارات الصوتية / المعلّقون في البثّ
        if (groups.isNotEmpty()) {
            labels.add("🔄 المسار الصوتي التلقائي (الافتراضي)")
            actions.add {
                exo.trackSelectionParameters = exo.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                    .build()
                Toast.makeText(this, "🎧 عاد اختيار الصوت إلى المسار التلقائي", Toast.LENGTH_SHORT).show()
            }
        }
        groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val lang = fmt.language ?: "مسار ${gIdx + 1}.${tIdx + 1}"
                val lbl = fmt.label ?: ""
                val sel = if (group.isTrackSelected(tIdx)) "✔ " else ""
                labels.add("${sel}🎧 المسار: $lang ${if (lbl.isNotBlank()) "· $lbl" else ""} (${fmt.channelCount}ch)".trim())
                actions.add {
                    exo.trackSelectionParameters = exo.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, tIdx))
                        .build()
                    Toast.makeText(this, "🎧 تم اختيار المسار: $lang", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val defaultIdx = labels.indexOfFirst { it.startsWith("✔") }.coerceAtLeast(0)
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "🎧 مضخّم الصوت والمسارات الصوتية",
            items = labels,
            defaultIndex = defaultIdx
        ) { which ->
            actions[which].invoke()
        }
    }

    private fun formatSubOffset(ms: Long): String {
        if (ms == 0L) return "0.0 ث"
        val sign = if (ms > 0) "+" else "-"
        return String.format(Locale.US, "%s%.1f ث", sign, abs(ms) / 1000.0)
    }

    private fun showSubtitleStyleDialog() {
        val cur = store.loadPrefs()
        val colorNames = listOf("أبيض ناصع", "أصفر سينمائي", "سماوي مريح")
        val bgDesc = if (cur.subBgTranslucent) "مفعّلة (خلفية داكنة شفّافة)" else "موقفة (حوافّ مظلّلة فقط)"
        val items = listOf(
            "${if (cur.subSizeSp == 18) "✔ " else ""}📏 الحجم: صغير (18sp)",
            "${if (cur.subSizeSp == 22) "✔ " else ""}📏 الحجم: متوسّط (22sp)",
            "${if (cur.subSizeSp == 28) "✔ " else ""}📏 الحجم: كبير للتلفاز (28sp)",
            "${if (cur.subSizeSp == 34) "✔ " else ""}📏 الحجم: ضخم جداً (34sp)",
            "🎨 تبديل لون الخطّ (الحالي: ${colorNames.getOrElse(cur.subColorIndex) { "أبيض" }})",
            "▪ تبديل خلفية النصّ (الحالي: $bgDesc)"
        )
        val defaultIdx = items.indexOfFirst { it.startsWith("✔") }.coerceAtLeast(0)
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "🎨 تخصيص حجم ولون الترجمة",
            items = items,
            defaultIndex = defaultIdx
        ) { which ->
            val updated = when (which) {
                0 -> cur.copy(subSizeSp = 18)
                1 -> cur.copy(subSizeSp = 22)
                2 -> cur.copy(subSizeSp = 28)
                3 -> cur.copy(subSizeSp = 34)
                4 -> cur.copy(subColorIndex = (cur.subColorIndex + 1) % 3)
                else -> cur.copy(subBgTranslucent = !cur.subBgTranslucent)
            }
            store.savePrefs(updated)
            applySubtitleStyleFromPrefs()
            showHudBanner("💬 تمّ تحديث مظهر الترجمة فوراً")
        }
    }

    private fun showSubtitleSyncDialog() {
        val deltas = listOf(
            -2000L to "⏪ تبكير الترجمة بمقدار 2.0 ثانية (-2.0s)",
            -500L to "⏪ تبكير الترجمة بمقدار 0.5 ثانية (-0.5s)",
            0L to "⟲ إعادة ضبط التوقيت الأصلي (0.0s)",
            +500L to "⏩ تأخير الترجمة بمقدار 0.5 ثانية (+0.5s)",
            +2000L to "⏩ تأخير الترجمة بمقدار 2.0 ثانية (+2.0s)"
        )
        val labels = deltas.map { it.second }
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "⏱ مزامنة توقيت الترجمة (الحالي: ${formatSubOffset(subtitleOffsetMs)})",
            items = labels,
            defaultIndex = 2
        ) { which ->
            val (step, _) = deltas[which]
            subtitleOffsetMs = if (step == 0L) 0L else (subtitleOffsetMs + step).coerceIn(-15_000L, 15_000L)
            val extBase = originalExternalSubUri
            if (extBase != null) {
                reloadExternalSubtitleWithOffset(extBase, subtitleOffsetMs)
                showHudBanner("⏱ توقيت الترجمة: ${formatSubOffset(subtitleOffsetMs)}")
            } else if (subtitleOffsetMs < 0L) {
                subtitleOffsetMs = 0L
                Toast.makeText(
                    this,
                    "التبكير بالسالب متاح لملفّات الترجمة الخارجية (.srt/.vtt)، أمّا التأخير بالموجب فيعمل على الجميع",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                showHudBanner("⏱ تأخير الترجمة: ${formatSubOffset(subtitleOffsetMs)}")
            }
        }
    }

    private fun showSubtitleDialog() {
        val exo = player ?: return
        val groups = exo.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add("📂 اختيار ملف ترجمة خارجي (.srt / .vtt) من الجهاز")
        actions.add {
            runCatching {
                extSubPickerLauncher.launch(arrayOf("*/*"))
            }.onFailure {
                Toast.makeText(this, "تعذّر فتح مستعرض الملفات على هذا الجهاز", Toast.LENGTH_SHORT).show()
            }
        }

        labels.add("🎨 تنسيق خطّ ولون وخلفية الترجمة…")
        actions.add {
            showSubtitleStyleDialog()
        }

        labels.add("⏱ مزامنة توقيت الترجمة (${formatSubOffset(subtitleOffsetMs)})…")
        actions.add {
            showSubtitleSyncDialog()
        }

        labels.add("⛔ إيقاف الترجمة")
        actions.add {
            exo.trackSelectionParameters = exo.trackSelectionParameters
                .buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            Toast.makeText(this, "⛔ تم إيقاف الترجمة", Toast.LENGTH_SHORT).show()
        }

        groups.forEachIndexed { gIdx, group ->
            for (tIdx in 0 until group.length) {
                val fmt = group.getTrackFormat(tIdx)
                val lang = fmt.language ?: "ترجمة ${gIdx + 1}"
                val lbl = fmt.label ?: ""
                val sel = if (group.isTrackSelected(tIdx)) "✔ " else ""
                val entryLabel = "$sel$lang ${if (lbl.isNotBlank()) "· $lbl" else ""}".trim()
                labels.add(entryLabel)
                actions.add {
                    exo.trackSelectionParameters = exo.trackSelectionParameters
                        .buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_TEXT)
                        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, tIdx))
                        .build()
                    Toast.makeText(this, "💬 $entryLabel", Toast.LENGTH_SHORT).show()
                }
            }
        }

        val defaultIdx = labels.indexOfFirst { it.startsWith("✔") }.coerceAtLeast(0)
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "💬 مسارات وتنسيق ومزامنة الترجمة",
            items = labels,
            defaultIndex = defaultIdx
        ) { which ->
            actions[which].invoke()
        }
    }

    private fun toggleInstantMute() {
        isPlayerMuted = !isPlayerMuted
        player?.volume = if (isPlayerMuted) 0f else 1f
        btnOsdMute.text = if (isPlayerMuted) "🔇 مكتوم" else "🔇 كتم"
        showHudBanner(if (isPlayerMuted) "🔇 تمّ كتم الصوت" else "🔊 أُعيد الصوت")
    }

    private fun toggleStreamRecording() {
        val cur = currentItem ?: return
        val rawCmd = cur.cmd.trim()
        if (rawCmd.startsWith("file://", ignoreCase = true) || rawCmd.startsWith("content://", ignoreCase = true)) {
            return
        }
        // إذا ضغط المستخدم زرّ التسجيل على الريموت أثناء مشاهدة فيلم أو حلقة، نحيله لتحميل الملف الكامل السليم!
        if (cur.kind == ItemKind.VOD || cur.kind == ItemKind.EPISODE) {
            promptVodDownloadFromPlayer()
            return
        }
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
        if (StreamRecorder.isRecording()) {
            StreamRecorder.stopRecording()
            startedRecInPlayer = false
            recLiveStatusStr = ""
            btnOsdRecord.text = "⏺ تسجيل"
            updateMetaBanner()
            showHudBanner("⏹ تمّ إيقاف التسجيل وحفظ الملف")
            return
        }

        val appCtx = applicationContext
        val selfRef = WeakReference(this)
        val freshOrDirect = if (acc?.provider == ProviderType.STALKER) "" else currentResolvedStreamUrl
        val onTickFn: (Long, Long) -> Unit = { elSec, bytes ->
            val act = selfRef.get()
            if (act != null && !act.isFinishing && !act.isDestroyed) {
                val m = elSec / 60L
                val s = elSec % 60L
                val sz = StreamRecorder.formatSizeMb(bytes)
                act.recLiveStatusStr = String.format(Locale.US, "🔴 %02d:%02d (%s)", m, s, sz)
                act.btnOsdRecord.text = String.format(Locale.US, "⏹ %02d:%02d", m, s)
                act.updateMetaBanner()
            }
        }
        val onFinishedFn: (Boolean, String, Long, String) -> Unit = { savedOk, savedPath, bytes, err ->
            val act = selfRef.get()
            if (act != null && !act.isFinishing && !act.isDestroyed) {
                act.startedRecInPlayer = false
                act.recLiveStatusStr = ""
                act.btnOsdRecord.text = "⏺ تسجيل"
                act.updateMetaBanner()
            }
            if (savedOk) {
                AppStore(appCtx).incrementRecCount()
                Toast.makeText(
                    appCtx,
                    "✔ حُفظ التسجيل (${StreamRecorder.formatSizeMb(bytes)}) في:\n$savedPath",
                    Toast.LENGTH_LONG
                ).show()
            } else if (err.isNotBlank()) {
                Toast.makeText(appCtx, "✖ تعذّر التسجيل: $err", Toast.LENGTH_LONG).show()
            }
        }

        // إذا كان البثّ يعمل داخل المشغّل الآن، نسجّل مباشرةً من مقبس ExoPlayer ذاته بدون فتح اتصال ثانٍ لمنع Connection reset!
        val useLiveTap = player != null && (cur.kind == ItemKind.LIVE || cur.kind == ItemKind.CATCHUP)
        val ok = if (useLiveTap) {
            StreamRecorder.startLiveTapRecording(
                context = appCtx,
                acc = acc,
                item = cur,
                directUrl = freshOrDirect,
                onTick = onTickFn,
                onFinished = onFinishedFn
            )
        } else {
            StreamRecorder.startRecording(
                context = appCtx,
                acc = acc,
                item = cur,
                directUrl = freshOrDirect,
                onTick = onTickFn,
                onFinished = onFinishedFn
            )
        }
        if (ok) {
            startedRecInPlayer = true
            btnOsdRecord.text = "⏹ جارٍ البدء"
            showHudBanner("🔴 بدأ التسجيل في التنزيلات", 1800L)
        }
    }

    private fun notifyIfRecordingContinuesOnExit() {
        if (StreamRecorder.isRecording()) {
            Toast.makeText(
                applicationContext,
                "🔴 يستمر التسجيل في الخلفية — يمكنك إيقافه من قائمة القناة أو مركز المهام",
                Toast.LENGTH_LONG
            ).show()
        } else if (StreamRecorder.isDownloading()) {
            Toast.makeText(
                applicationContext,
                "📥 يستمر التحميل المباشر في الخلفية حتى يكتمل الحفظ في التنزيلات",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun resumeStreamAfterDownloadStopped() {
        val cur = currentItem ?: return
        if (isFinishing || isDestroyed || stoppedInBackground) return
        pausedStreamForInternalDownload = false
        btnOsdDownload.text = "📥 تحميل"
        btnOsdPlayPause.text = "⏸ إيقاف مؤقّت"

        if (cur.kind == ItemKind.VOD || cur.kind == ItemKind.EPISODE) {
            val savedPos = maxOf(pendingResumeMs, lastValidVodPosMs, store.getResumePos(cur))
            pendingResumeMs = savedPos
            resumeSeekApplied = (savedPos < AppStore.MIN_RESUME_POS_MS)
            resumeSeekAttempts = 0
            resumeBannerShown = false
        }
        everPlayedCurrent = false
        triedCreateLinkFallback = false
        retryCount = 0
        tvBufferMsg.text = "▶ جارٍ العودة إلى البثّ واستئناف المشاهدة فوراً…"
        bufferOverlay.visibility = View.VISIBLE
        // مهلة قصيرة (220ms) تضمن وصول إغلاق مقبس التحميل للسيرفر قبل إعادة فتح مقبس البثّ في اشتراكات الخطّ الواحد!
        uiHandler.postDelayed({
            if (!isFinishing && !isDestroyed && !stoppedInBackground && !pausedStreamForInternalDownload) {
                openCurrentItemInternal(forceCreateLink = true)
            }
        }, 220L)
    }

    private fun promptVodDownloadFromPlayer() {
        val cur = currentItem ?: return
        // إذا كان المستخدم قد أوقف البثّ مؤقّتاً لأجل هذا التحميل وضغط زرّ «⏹ إيقاف التحميل»، نوقف التحميل ونستأنف المشاهدة فوراً بنقرة واحدة!
        if (pausedStreamForInternalDownload && StreamRecorder.isDownloading()) {
            StreamRecorder.stopDownload()
            Toast.makeText(this, "⏹ تمّ إيقاف التحميل — جارٍ العودة لاستئناف المشاهدة", Toast.LENGTH_SHORT).show()
            resumeStreamAfterDownloadStopped()
            return
        }

        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()
        val appCtx = applicationContext
        val selfRef = WeakReference(this)
        hideOsd()
        val freshOrDirect = if (acc?.provider == ProviderType.STALKER) "" else currentResolvedStreamUrl
        FeatureDialogs.showVodDownloadChoiceDialog(
            ctx = this,
            scope = lifecycleScope,
            acc = acc,
            item = cur,
            directResolvedUrl = freshOrDirect,
            onDownloadStopped = {
                val act = selfRef.get()
                if (act != null && !act.isFinishing && !act.isDestroyed) {
                    Toast.makeText(act, "⏹ تمّ إيقاف التحميل — جارٍ العودة لاستئناف المشاهدة", Toast.LENGTH_SHORT).show()
                    act.resumeStreamAfterDownloadStopped()
                }
            },
            onStartInternalDownload = { resolvedUrl ->
                // حفظ موضع الفيلم/الحلقة وإغلاق مقبس المشغّل النشط فوراً لمنع رفض السيرفر للاتصال الثاني في اشتراكات الخطّ الواحد!
                saveCurrentPositionIfVod()
                pausedStreamForInternalDownload = true
                cancelPendingReconnect()
                openJob?.cancel()
                player?.stop()
                player?.clearMediaItems()
                val prevUrl = currentResolvedStreamUrl
                lifecycleScope.launch(Dispatchers.IO) {
                    PortalClient.prepareForStreamReconnect(prevUrl, cur.cmd)
                }
                btnOsdDownload.text = "⏹ إيقاف التحميل"
                btnOsdPlayPause.text = "▶ استئناف المشاهدة"
                bufferOverlay.visibility = View.VISIBLE
                tvBufferMsg.text = "📥 جارٍ تجهيز التحميل المباشر لـ «${cur.name}»…\n(اضغط «⏹ إيقاف التحميل» أو «▶ استئناف المشاهدة» للعودة إلى الفيديو فوراً)"

                val started = StreamRecorder.startDownload(
                    context = appCtx,
                    acc = acc,
                    item = cur,
                    directUrl = resolvedUrl,
                    onProgress = { pct, dlBytes, totBytes ->
                        val act = selfRef.get()
                        if (act != null && !act.isFinishing && !act.isDestroyed) {
                            val dlStr = StreamRecorder.formatSizeMb(dlBytes)
                            val totStr = if (totBytes > 0L) " / ${StreamRecorder.formatSizeMb(totBytes)}" else ""
                            act.btnOsdDownload.text = if (pct >= 0) "⏹ إيقاف ($pct%)" else "⏹ إيقاف ($dlStr)"
                            act.bufferOverlay.visibility = View.VISIBLE
                            act.tvBufferMsg.text = if (pct >= 0) {
                                "📥 جارٍ التحميل المباشر: $pct% ($dlStr$totStr)\n«${cur.name}»\n(اضغط ⏹ إيقاف أو ▶ استئناف للعودة للمشاهدة فوراً، أو رجوع للإكمال بالخلفية)"
                            } else {
                                "📥 جارٍ التحميل المباشر: $dlStr\n«${cur.name}»\n(اضغط ⏹ إيقاف أو ▶ استئناف للعودة للمشاهدة فوراً، أو رجوع للإكمال بالخلفية)"
                            }
                        }
                    },
                    onFinished = { ok, savedPath, dlBytes, err ->
                        val act = selfRef.get()
                        if (ok) {
                            Toast.makeText(
                                appCtx,
                                "✔ اكتمل تحميل «${cur.name}» (${StreamRecorder.formatSizeMb(dlBytes)}) في $savedPath",
                                Toast.LENGTH_LONG
                            ).show()
                        } else if (err.isNotBlank() && err != "تمّ إيقاف التحميل") {
                            Toast.makeText(appCtx, "⚠ $err", Toast.LENGTH_LONG).show()
                        }
                        if (act != null && !act.isFinishing && !act.isDestroyed) {
                            act.btnOsdDownload.text = "📥 تحميل"
                            if (act.pausedStreamForInternalDownload) {
                                act.resumeStreamAfterDownloadStopped()
                            }
                        }
                    }
                )
                if (started) {
                    showHudBanner("📥 بدأ التحميل المباشر — اضغط ⏹ للإيقاف والاستئناف الفوري", 2400L)
                } else {
                    resumeStreamAfterDownloadStopped()
                }
            }
        )
    }

    private fun applyAspectMode(mode: Int, showToast: Boolean) {
        val contentFrame = playerView.findViewById<AspectRatioFrameLayout>(
            androidx.media3.ui.R.id.exo_content_frame
        )
        val label = when (mode) {
            1 -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                "ملء الشاشة بالكامل"
            }
            2 -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                "تكبير وقصّ الحوافّ (Zoom)"
            }
            3 -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                contentFrame?.setAspectRatio(16f / 9f)
                "16:9 عريض"
            }
            4 -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                contentFrame?.setAspectRatio(4f / 3f)
                "4:3 كلاسيكي"
            }
            5 -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                contentFrame?.setAspectRatio(21f / 9f)
                "21:9 سينمائي"
            }
            else -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                val vs = player?.videoSize
                if (vs != null && vs.width > 0 && vs.height > 0) {
                    contentFrame?.setAspectRatio((vs.width * vs.pixelWidthHeightRatio) / vs.height)
                }
                "تلقائي أصلي"
            }
        }
        if (showToast) {
            showHudBanner("📐 الأبعاد: $label")
        }
    }

    private fun updateFavButton(isFav: Boolean) {
        btnOsdFav.text = if (isFav) "★ في المفضّلة" else "☆ مفضّلة"
    }

    private fun updateMetaBanner() {
        val meta = listOf(recLiveStatusStr, lastResStr, lastCodecStr, lastOpenSpeedStr)
            .filter { it.isNotBlank() }
            .joinToString("  ·  ") { androidx.core.text.BidiFormatter.getInstance(true).unicodeWrap(it) }
        tvOsdMeta.text = meta
        tvOsdMeta.visibility = if (meta.isNotBlank()) View.VISIBLE else View.GONE
    }

    private fun shortCodecLabel(mime: String?): String {
        val m = mime?.lowercase(Locale.US).orEmpty()
        return when {
            m.contains("hevc") || m.contains("hvc") -> "HEVC"
            m.contains("avc") -> "H.264"
            m.contains("av01") -> "AV1"
            m.contains("vp9") -> "VP9"
            m.contains("mpeg2") -> "MPEG-2"
            m.contains("eac3") -> "E-AC3"
            m.contains("ac3") -> "AC3"
            m.contains("dts") -> "DTS"
            m.contains("mp4a") || m.contains("aac") -> "AAC"
            m.contains("mpeg") -> "MP2/MP3"
            else -> ""
        }
    }

    private fun showHudBanner(text: String, durationMs: Long = 1200L) {
        tvGestureHud.text = text
        tvGestureHud.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hideHudRunnable)
        uiHandler.postDelayed(hideHudRunnable, durationMs)
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchGestures() {
        val audioMgr = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var draggingVertical = false
        var startVolume = 0
        var maxVolume = 15
        var startBrightness = 0.65f

        playerView.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    draggingVertical = false
                    maxVolume = audioMgr.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    startVolume = audioMgr.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val curB = window.attributes.screenBrightness
                    startBrightness = if (curB in 0.02f..1.0f) curB else 0.6f
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (liveDrawer.visibility == View.VISIBLE) return@setOnTouchListener true
                    val dx = ev.x - downX
                    val dy = downY - ev.y // موجب عند السحب للأعلى
                    if (!draggingVertical && abs(dy) > touchSlop * 1.5f && abs(dy) > abs(dx) * 1.3f) {
                        draggingVertical = true
                    }
                    if (draggingVertical && v.height > 120) {
                        val ratio = (dy / (v.height * 0.68f)).coerceIn(-1f, 1f)
                        if (downX < v.width * 0.48f) {
                            // النصف الأيسر: السطوع
                            val nextB = (startBrightness + ratio).coerceIn(0.05f, 1.0f)
                            val lp = window.attributes
                            lp.screenBrightness = nextB
                            window.attributes = lp
                            val pct = (nextB * 100f).roundToInt()
                            showHudBanner("☀ السطوع: $pct%", 900L)
                        } else {
                            // النصف الأيمن: الصوت
                            val nextVol = (startVolume + (ratio * maxVolume).roundToInt()).coerceIn(0, maxVolume)
                            audioMgr.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                            val pct = ((nextVol * 100f) / maxVolume).roundToInt()
                            showHudBanner(if (pct == 0) "🔇 كتم الصوت" else "🔊 الصوت: $pct%", 900L)
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (!draggingVertical && abs(ev.x - downX) <= touchSlop * 2 && abs(ev.y - downY) <= touchSlop * 2) {
                        if (liveDrawer.visibility == View.VISIBLE) {
                            liveDrawer.visibility = View.GONE
                        } else if (bottomOsd.visibility == View.VISIBLE) {
                            hideOsd()
                        } else {
                            showOsd(focusControls = true)
                        }
                    }
                    draggingVertical = false
                    true
                }

                else -> false
            }
        }
    }

    private fun showPlaybackSpeedDialog() {
        val speeds = listOf(0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = speeds.map { s ->
            val tag = if (s == 1.0f) "1.0x (عادي)" else "${s}x"
            if (abs(playbackSpeed - s) < 0.02f) "✔ $tag" else tag
        }
        val defaultIdx = labels.indexOfFirst { it.startsWith("✔") }.coerceAtLeast(1)

        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "⏩ سرعة التشغيل",
            items = labels,
            defaultIndex = defaultIdx
        ) { which ->
            playbackSpeed = speeds[which]
            player?.setPlaybackSpeed(playbackSpeed)
            btnOsdSpeed.text = "⏩ ${playbackSpeed}x"
            showHudBanner("⏩ السرعة: ${playbackSpeed}x")
        }
    }

    private fun showSleepTimerDialog() {
        val minsList = listOf(0, 15, 30, 45, 60, 90, 120)
        val labels = minsList.map { m ->
            if (m == 0) "⛔ إيقاف مؤقّت النوم" else "⏲ إيقاف تلقائي بعد $m دقيقة"
        }

        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "⏲ مؤقّت النوم التلقائي",
            items = labels,
            defaultIndex = if (sleepDeadlineMs > System.currentTimeMillis()) 0 else 1
        ) { which ->
            val mins = minsList[which]
            if (mins == 0) {
                sleepDeadlineMs = 0L
                sleepWarned1Min = false
                btnOsdTimer.text = "⏲ مؤقّت"
                showHudBanner("⛔ تم إلغاء مؤقّت النوم")
            } else {
                sleepDeadlineMs = System.currentTimeMillis() + mins * 60_000L
                sleepWarned1Min = false
                btnOsdTimer.text = "⏲ ${mins}د"
                showHudBanner("⏲ إيقاف تلقائي بعد $mins دقيقة", 1800L)
            }
            syncProgressTicker()
        }
    }

    private fun toggleScreenOrientation() {
        isPortraitLocked = !isPortraitLocked
        requestedOrientation = if (isPortraitLocked) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
        showHudBanner(if (isPortraitLocked) "📱 الوضع العمودي" else "📺 الوضع الأفقي")
        scheduleOsdHide()
    }

    private fun showStreamDiagnosticsDialog() {
        val exo = player ?: return
        val vf = exo.videoFormat
        val af = exo.audioFormat
        val vc = exo.videoDecoderCounters
        val vs = exo.videoSize

        val vCodec = shortCodecLabel(vf?.sampleMimeType).ifBlank { vf?.sampleMimeType ?: "غير متاح" }
        val vRes = if (vs.width > 0) "${vs.width}×${vs.height}" else "—"
        val vFps = vf?.frameRate?.takeIf { it > 0f }?.let { String.format(Locale.US, "%.1f fps", it) } ?: "—"
        val vBitrate = vf?.bitrate?.takeIf { it > 0 }?.let { String.format(Locale.US, "%.2f Mbps", it / 1_000_000.0) } ?: "تكيّفي / غير معلن"

        val aCodec = shortCodecLabel(af?.sampleMimeType).ifBlank { af?.sampleMimeType ?: "غير متاح" }
        val aCh = af?.channelCount?.takeIf { it > 0 }?.let { "${it}ch" } ?: ""
        val aRate = af?.sampleRate?.takeIf { it > 0 }?.let { "${it / 1000} kHz" } ?: ""

        val bufSec = (exo.totalBufferedDuration.coerceAtLeast(0L)) / 1000.0
        val rendered = vc?.renderedOutputBufferCount ?: 0
        val dropped = vc?.droppedBufferCount ?: 0
        val acc = PlayQueueHolder.activeAccount ?: store.getActiveAccount()

        val report = buildString {
            append("📡 نوع المصدر: ${acc?.provider?.label ?: "—"}\n")
            append("🎬 الفيديو: $vCodec  ·  الأبعاد: $vRes  ·  الإطارات: $vFps\n")
            append("📊 معدّل البت: $vBitrate\n")
            append("🎧 الصوت: $aCodec $aCh $aRate\n")
            append("🔢 العملية #$playbackOperationId: ${playbackOperation.name}\n")
            append("🔗 تجهيز الرابط من بدء الإجراء: ${urlPreparationMs?.let { "${it}ms" } ?: "—"}\n")
            append("⚡ أول إطار من بدء الإجراء: ${firstFrameMs?.let { "${it}ms" } ?: if (measuringFirstFrame) "جارٍ القياس" else "لم يصل إطار"}\n")
            append("القياس لا يشمل انتقال ضغطة الريموت عبر النظام، وليس قياساً ضوئياً للشاشة.\n")
            append("🧺 المخزن المؤقّت الجاهز: ${String.format(Locale.US, "%.1f", bufSec)} ثانية\n")
            append("🖼 الإطارات المعروضة: $rendered  ·  الساقطة: $dropped")
        }

        AlertDialog.Builder(this)
            .setTitle("📊 تشخيص البثّ والجودة الحيّة")
            .setMessage(report)
            .setPositiveButton("حسناً", null)
            .show()
    }

    private fun updateProgressAndWatchStats() {
        val exo = player ?: return
        val now = System.currentTimeMillis()
        if (sleepDeadlineMs > 0L) {
            val remMs = sleepDeadlineMs - now
            if (remMs <= 0L) {
                sleepDeadlineMs = 0L
                flushAccumulatedWatchSeconds()
                saveCurrentPositionIfVod()
                releaseLoudnessEnhancer()
                exo.stop()
                exo.release()
                player = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                AppExitHelper.terminateAppCompletely(this)
                return
            } else {
                val remMin = ((remMs + 59_999L) / 60_000L).toInt()
                btnOsdTimer.text = "⏲ ${remMin}د"
                if (remMs <= 60_000L && !sleepWarned1Min) {
                    sleepWarned1Min = true
                    showHudBanner("⏲ سيتوقّف البثّ تلقائياً خلال دقيقة واحدة", 3000L)
                }
            }
        }
        watchTickMs = now

        val cur = currentItem ?: return
        if (cur.kind == ItemKind.LIVE || pausedStreamForInternalDownload) return
        val pos = exo.currentPosition.coerceAtLeast(0L)
        val dur = exo.duration.coerceAtLeast(0L)
        if (!isDraggingSeek && bottomOsd.visibility == View.VISIBLE) {
            tvPosTime.text = formatMs(pos)
            tvDurTime.text = if (dur > 0L) formatMs(dur) else "--:--"
            if (dur > 0L) {
                seekBar.progress = ((pos * 1000L) / dur).toInt().coerceIn(0, 1000)
            }
        }
        if (dur > 0L) {
            lastValidVodDurMs = dur
        }
        if (resumeSeekApplied && pos >= AppStore.MIN_RESUME_POS_MS && cur.kind != ItemKind.CATCHUP) {
            lastValidVodPosMs = pos
            pendingResumeMs = pos
            if (exo.isPlaying && now - lastPeriodicResumeSaveMs >= 10_000L) {
                lastPeriodicResumeSaveMs = now
                saveCurrentPositionIfVod()
            }
        }
    }

    private fun saveCurrentPositionIfVod() {
        val cur = currentItem ?: return
        if (cur.kind == ItemKind.LIVE || cur.kind == ItemKind.CATCHUP) return
        // لا نمسح أو نستبدل موضع استئناف محفوظ إن خرج المستخدم أثناء الثواني الأولى من التحميل قبل اكتمال القفز!
        if (!resumeSeekApplied && pendingResumeMs >= AppStore.MIN_RESUME_POS_MS) return
        val exoPos = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
        val exoDur = player?.duration?.takeIf { it != C.TIME_UNSET && it > 0L } ?: 0L
        val pos = if (exoPos >= AppStore.MIN_RESUME_POS_MS) exoPos else lastValidVodPosMs
        val dur = if (exoDur > 0L) exoDur else lastValidVodDurMs
        if (pos >= AppStore.MIN_RESUME_POS_MS) {
            lastValidVodPosMs = pos
            val accId = (PlayQueueHolder.activeAccount ?: store.getActiveAccount())?.id.orEmpty()
            store.saveResumeEntry(cur, pos, dur, accId)
        }
    }

    private fun isDescendantOf(child: View?, container: View): Boolean {
        var cur = child
        while (cur != null) {
            if (cur === container) return true
            cur = cur.parent as? View
        }
        return false
    }

    private fun setupOsdFocusNavigation() {
        val topButtons = listOf(btnOsdBack, btnOsdTimer, btnOsdStats, btnOsdRotate, btnOsdFav)
        val bottomButtons = listOf(
            btnOsdPlayPause, btnOsdDrawer, btnOsdPrevCh, btnOsdEpg,
            btnOsdAudio, btnOsdSub, btnOsdAspect, btnOsdSpeed,
            btnOsdRecord, btnOsdDownload, btnOsdReload, btnOsdMute
        )
        for (btn in topButtons) {
            ThemeHelper.attachFocusScale(btn, 1.05f) { v, hasFocus ->
                if (hasFocus) {
                    lastFocusedTopOsdBtn = v
                    scheduleOsdHide()
                }
            }
        }
        for (btn in bottomButtons) {
            ThemeHelper.attachFocusScale(btn, 1.05f) { v, hasFocus ->
                if (hasFocus) {
                    lastFocusedBottomOsdBtn = v
                    v.requestRectangleOnScreen(Rect(0, 0, v.width, v.height), false)
                    scheduleOsdHide()
                }
            }
        }
    }

    private fun preferredBottomOsdFocus(): View {
        val last = lastFocusedBottomOsdBtn
        if (last != null && last.visibility == View.VISIBLE && last.isEnabled) return last
        val candidates = listOf(
            btnOsdPlayPause, btnOsdDrawer, btnOsdEpg, btnOsdPrevCh,
            btnOsdReload, btnOsdAudio, btnOsdSub, btnOsdAspect, btnOsdMute
        )
        return candidates.firstOrNull { it.visibility == View.VISIBLE && it.isEnabled } ?: btnOsdDrawer
    }

    private fun preferredTopOsdFocus(): View {
        val last = lastFocusedTopOsdBtn
        return if (last != null && last.visibility == View.VISIBLE && last.isEnabled) last else btnOsdBack
    }

    private fun showOsd(focusControls: Boolean) {
        if (currentItem?.kind == ItemKind.LIVE && activeEpgNowProg != null) {
            refreshLiveEpgProgressUi()
        }
        topOsd.visibility = View.VISIBLE
        bottomOsd.visibility = View.VISIBLE
        if (focusControls) {
            preferredBottomOsdFocus().requestFocus()
        }
        syncProgressTicker()
        scheduleOsdHide()
    }

    private fun hideOsd() {
        uiHandler.removeCallbacks(hideOsdRunnable)
        topOsd.visibility = View.GONE
        bottomOsd.visibility = View.GONE
        syncProgressTicker()
    }

    private fun scheduleOsdHide() {
        uiHandler.removeCallbacks(hideOsdRunnable)
        uiHandler.postDelayed(hideOsdRunnable, 4500L)
    }

    // ==================== التحكّم الكامل بريموت التلفاز (D-Pad + أرقام القنوات) ====================

    @SuppressLint("InlinedApi")
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val drawerOpen = liveDrawer.visibility == View.VISIBLE
            val osdOpen = bottomOsd.visibility == View.VISIBLE
            val isLive = currentItem?.kind == ItemKind.LIVE

            if (drawerOpen) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_DPAD_LEFT -> {
                        liveDrawer.visibility = View.GONE
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        return true
                    }
                }
                return super.dispatchKeyEvent(event)
            }

            // أرقام الريموت 0–9 للقفز المباشر لرقم القناة
            val digitChar: Char? = when (event.keyCode) {
                in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 -> ('0'.code + (event.keyCode - KeyEvent.KEYCODE_0)).toChar()
                in KeyEvent.KEYCODE_NUMPAD_0..KeyEvent.KEYCODE_NUMPAD_9 -> ('0'.code + (event.keyCode - KeyEvent.KEYCODE_NUMPAD_0)).toChar()
                else -> null
            }
            if (digitChar != null) {
                appendDigitJump(digitChar)
                return true
            }

            when (event.keyCode) {
                KeyEvent.KEYCODE_GUIDE, KeyEvent.KEYCODE_INFO -> {
                    openEpgOrMediaFromPlayer()
                    return true
                }

                KeyEvent.KEYCODE_CHANNEL_UP -> {
                    openStreamAtIndex(PlayQueueHolder.currentIndex - 1)
                    return true
                }

                KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                    openStreamAtIndex(PlayQueueHolder.currentIndex + 1)
                    return true
                }

                KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    switchToPreviousChannel()
                    return true
                }

                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_MEDIA_PAUSE,
                KeyEvent.KEYCODE_MEDIA_PLAY,
                KeyEvent.KEYCODE_SPACE -> {
                    if (isLive) {
                        // في القنوات المباشرة لا يوجد إيقاف مؤقّت ولا استئناف؛ نكتفي بإظهار الشريط دون إيقاف البثّ!
                        showOsd(focusControls = true)
                        return true
                    }
                    when (event.keyCode) {
                        KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                            if (player?.isPlaying == true) btnOsdPlayPause.performClick()
                        }
                        KeyEvent.KEYCODE_MEDIA_PLAY -> {
                            if (player?.isPlaying != true) btnOsdPlayPause.performClick()
                        }
                        else -> btnOsdPlayPause.performClick()
                    }
                    showOsd(focusControls = false)
                    return true
                }

                KeyEvent.KEYCODE_VOLUME_MUTE, KeyEvent.KEYCODE_MUTE, KeyEvent.KEYCODE_M -> {
                    toggleInstantMute()
                    return true
                }

                KeyEvent.KEYCODE_MEDIA_RECORD, KeyEvent.KEYCODE_R -> {
                    toggleStreamRecording()
                    return true
                }

                KeyEvent.KEYCODE_PROG_YELLOW -> {
                    quickReloadCurrentStream()
                    return true
                }

                KeyEvent.KEYCODE_DPAD_UP -> {
                    if (!osdOpen) {
                        openStreamAtIndex(PlayQueueHolder.currentIndex - 1)
                        return true
                    }
                    scheduleOsdHide()
                    val focused = currentFocus
                    if (focused == null || (!isDescendantOf(focused, topOsd) && !isDescendantOf(focused, bottomOsd))) {
                        preferredBottomOsdFocus().requestFocus()
                        return true
                    }
                    if (focused === seekBar) {
                        preferredTopOsdFocus().requestFocus()
                        return true
                    }
                    if (isDescendantOf(focused, bottomOsd)) {
                        if (seekRow.visibility == View.VISIBLE && seekBar.isFocusable) {
                            seekBar.requestFocus()
                        } else {
                            preferredTopOsdFocus().requestFocus()
                        }
                        return true
                    }
                }

                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (!osdOpen) {
                        openStreamAtIndex(PlayQueueHolder.currentIndex + 1)
                        return true
                    }
                    scheduleOsdHide()
                    val focused = currentFocus
                    if (focused == null || (!isDescendantOf(focused, topOsd) && !isDescendantOf(focused, bottomOsd))) {
                        preferredBottomOsdFocus().requestFocus()
                        return true
                    }
                    if (isDescendantOf(focused, topOsd)) {
                        if (seekRow.visibility == View.VISIBLE && seekBar.isFocusable) {
                            seekBar.requestFocus()
                        } else {
                            preferredBottomOsdFocus().requestFocus()
                        }
                        return true
                    }
                    if (focused === seekBar) {
                        preferredBottomOsdFocus().requestFocus()
                        return true
                    }
                }

                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                    if (digitBuffer.isNotEmpty()) {
                        commitDigitJump()
                        return true
                    }
                    if (!osdOpen) {
                        if (isLive) {
                            if (liveStoppedAwaitingAction) {
                                quickReloadCurrentStream()
                            } else {
                                openLiveDrawer()
                            }
                        } else {
                            showOsd(focusControls = true)
                        }
                        return true
                    }
                    scheduleOsdHide()
                }

                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
                KeyEvent.KEYCODE_MEDIA_STEP_FORWARD,
                KeyEvent.KEYCODE_MEDIA_REWIND,
                KeyEvent.KEYCODE_MEDIA_STEP_BACKWARD -> {
                    if (!isLive) {
                        val isForward = event.keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
                            event.keyCode == KeyEvent.KEYCODE_MEDIA_STEP_FORWARD
                        val delta = if (isForward) 15_000L else -15_000L
                        player?.let { exo ->
                            val dur = exo.duration
                            val rawTarget = (exo.currentPosition + delta).coerceAtLeast(0L)
                            val target = if (dur > 0L) rawTarget.coerceAtMost(dur) else rawTarget
                            commitManualUserSeek(target)
                        }
                        showHudBanner(if (isForward) "⏩ +15 ث" else "⏪ -15 ث", 900L)
                        showOsd(focusControls = false)
                        return true
                    }
                }

                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (!osdOpen) {
                        if (!isLive) {
                            val isForward = event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                            val delta = if (isForward) 15_000L else -15_000L
                            player?.let { exo ->
                                val dur = exo.duration
                                val rawTarget = (exo.currentPosition + delta).coerceAtLeast(0L)
                                val target = if (dur > 0L) rawTarget.coerceAtMost(dur) else rawTarget
                                commitManualUserSeek(target)
                            }
                            showHudBanner(if (isForward) "⏩ +15 ث" else "⏪ -15 ث", 900L)
                            showOsd(focusControls = false)
                        } else {
                            showOsd(focusControls = true)
                        }
                        return true
                    }
                    scheduleOsdHide()
                    val focused = currentFocus
                    if (focused === seekBar && !isLive) {
                        val isForward = event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                        val stepSec = when {
                            event.repeatCount >= 6 -> 60L
                            event.repeatCount >= 2 -> 30L
                            else -> 15L
                        }
                        val delta = (if (isForward) 1L else -1L) * stepSec * 1000L
                        player?.let { exo ->
                            val dur = exo.duration
                            val rawTarget = (exo.currentPosition + delta).coerceAtLeast(0L)
                            val target = if (dur > 0L) rawTarget.coerceAtMost(dur) else rawTarget
                            commitManualUserSeek(target)
                            if (dur > 0L) {
                                seekBar.progress = ((target * 1000L) / dur).toInt().coerceIn(0, 1000)
                                tvPosTime.text = formatMs(target)
                            }
                        }
                        showHudBanner(if (isForward) "⏩ +${stepSec} ث" else "⏪ -${stepSec} ث", 900L)
                        return true
                    }
                    if (focused == null || (!isDescendantOf(focused, topOsd) && !isDescendantOf(focused, bottomOsd))) {
                        preferredBottomOsdFocus().requestFocus()
                        return true
                    }
                }

                KeyEvent.KEYCODE_MENU -> {
                    showOsd(focusControls = true)
                    return true
                }

                KeyEvent.KEYCODE_BACK -> {
                    handlePlayerBackPressed()
                    return true
                }
            }
        } else if (event.action == KeyEvent.ACTION_UP && currentItem?.kind == ItemKind.LIVE) {
            if (event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                event.keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE ||
                event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                event.keyCode == KeyEvent.KEYCODE_SPACE
            ) {
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handlePlayerBackPressed()
            }
        })
    }

    private fun handlePlayerBackPressed() {
        if (liveDrawer.visibility == View.VISIBLE) {
            liveDrawer.visibility = View.GONE
            return
        }
        if (digitBuffer.isNotEmpty()) {
            digitBuffer.clear()
            tvChannelJumpBox.visibility = View.GONE
            return
        }
        if (topOsd.visibility == View.VISIBLE || bottomOsd.visibility == View.VISIBLE) {
            hideOsd()
            return
        }
        saveCurrentPositionIfVod()
        notifyIfRecordingContinuesOnExit()
        finish()
    }

    override fun onStart() {
        super.onStart()
        AppUiTracker.onActivityStarted()
        if (stoppedInBackground) {
            stoppedInBackground = false
            LogoLoader.isPlaybackActive = true
            PortalClient.trimForPlayback()
            watchTickMs = System.currentTimeMillis()
            player?.audioSessionId?.let { sid ->
                if (sid != C.AUDIO_SESSION_ID_UNSET) attachAndApplyAudioBoost(sid)
            }
            if (PlayQueueHolder.playlist.isNotEmpty()) {
                openStreamAtIndex(PlayQueueHolder.currentIndex)
            }
            syncProgressTicker()
        }
    }

    override fun onResume() {
        super.onResume()
        com.iptvlite.tv.network.SelectedCategoryLoad.playbackStarting()
        uiHandler.removeCallbacks(categoryBrowseTick)
        uiHandler.post(categoryBrowseTick)
        AppUiTracker.registerReminderHandler(immediatePlayerReminderCallback)
    }

    override fun onPause() {
        saveCurrentPositionIfVod()
        AppUiTracker.unregisterReminderHandler(immediatePlayerReminderCallback)
        super.onPause()
    }

    override fun onStop() {
        uiHandler.removeCallbacks(categoryBrowseTick)
        com.iptvlite.tv.network.SelectedCategoryLoad.playerHidden()
        AppUiTracker.onActivityStopped()
        super.onStop()
        stoppedInBackground = true
        cancelSubtitleReload()
        cancelOwnedPlaybackRequests()
        stopLiveRecovery()
        measuringFirstFrame = false
        liveStoppedAwaitingAction = false
        flushAccumulatedWatchSeconds()
        saveCurrentPositionIfVod()
        // إيقاف المؤقّتات ومضخّم الصوت والبثّ الحيّ بالكامل عند ضغط زرّ الهوم أو إطفاء الشاشة لعدم استهلاك المعالج أو خطّ الاشتراك!
        uiHandler.removeCallbacks(progressRunnable)
        cancelPendingReconnect()
        epgBannerJob?.cancel()
        openJob?.cancel()
        releaseLoudnessEnhancer()
        player?.stop()
        player?.clearMediaItems()
        if (StreamRecorder.isTapRecordingActive()) {
            StreamRecorder.handoffLiveTapToBackgroundNetwork()
        } else {
            StreamRecorder.setLivePlayerTapStandby(false)
        }
        if (!AppUiTracker.isAnyUiVisible && !StreamRecorder.isRecording() && !StreamRecorder.isDownloading()) {
            PortalClient.evictIdleConnections()
        }
        LogoLoader.isPlaybackActive = false
    }

    override fun onDestroy() {
        cancelSubtitleReload()
        liveLinkMemory.clear()
        pendingLiveLink = null
        pendingLiveLinkKey = null
        cancelOwnedPlaybackRequests()
        val retiredTransport = playbackTransport
        playbackTransport = null
        com.iptvlite.tv.network.NetworkCleanup.close(retiredTransport)
        stopLiveRecovery()
        LogoLoader.isPlaybackActive = false
        liveStoppedAwaitingAction = false
        uiHandler.removeCallbacksAndMessages(null)
        epgBannerJob?.cancel()
        openJob?.cancel()
        releaseLoudnessEnhancer()
        player?.release()
        player = null
        httpDataSourceFactory = null
        super.onDestroy()
    }

    private fun formatMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%d:%02d", m, s)
        }
    }
}
