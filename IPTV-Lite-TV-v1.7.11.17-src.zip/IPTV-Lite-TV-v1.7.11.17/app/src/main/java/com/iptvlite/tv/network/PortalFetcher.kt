package com.iptvlite.tv.network

import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.ContentTab
import com.iptvlite.tv.model.ProviderType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import java.util.regex.Pattern

/**
 * جلب بوابات Stalker اليومية المحدّثة من stbemu.com.tr بدقّة تامّة من بنية HTML الفعلية،
 * مع فحص سريع ومتوازٍ للمصافحة والحالة والأقسام الفعّالة وحفظ السيرفرات الشغّالة فقط.
 */
object PortalFetcher {

    const val BASE_URL = "https://www.stbemu.com.tr"

    private val articleLinkRe = Pattern.compile(
        """href=["'](https?://www\.stbemu\.com\.tr/\d{4}/\d{2}/[^"']+\.html)["']""",
        Pattern.CASE_INSENSITIVE
    )

    // 1) البنية الفعلية لبطاقات stbemu.com.tr (<div class="portal-text">...</div> + <div class="mac-text">...</div>)
    private val htmlSmartBoxRe = Pattern.compile(
        """class=["'][^"']*portal-text[^"']*["'][^>]*>\s*(https?://[^<\s"']+)\s*<[\s\S]{1,480}?class=["'][^"']*mac-text[^"']*["'][^>]*>\s*([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})\s*<""",
        Pattern.CASE_INSENSITIVE
    )

    // 2) مطابقة الكتل المعنونة (HTML أو Markdown أو نصّ عادي) بحدّ 500 حرف لمنع القفز بين البطاقات
    private val labeledBlockRe = Pattern.compile(
        """(?:Portal(?:\s*URL)?|STBEmu\s+code[^:]*)\s*:\s*(?:<[^>]+>|\s|`)*\s*(https?://[^\s<`"']+)[\s\S]{1,500}?MAC(?:\s+Address)?\s*:\s*(?:<[^>]+>|\s|`)*\s*([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})""",
        Pattern.CASE_INSENSITIVE
    )

    // 3) صيغة السطر المباشر: http://server/c | 00:1A:79:...
    private val portalAltRe = Pattern.compile(
        """(https?://[a-zA-Z0-9.\-:_]+/(?:stalker_portal/c|c)/?)(?=[\s<"'`|]|$)\s*[|\n\r]+\s*([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})""",
        Pattern.CASE_INSENSITIVE
    )

    // 4) احتياط أخير محكوم بحدّ فاصل صريح بعد /c حتى لا يطابق روابط مثل fonts.googleapis.com/css2!
    private val strictPortalUrlRe = Pattern.compile(
        """(https?://[a-zA-Z0-9.\-:_]+/(?:stalker_portal/c|c)/?)(?=[\s<"'`|]|$)""",
        Pattern.CASE_INSENSITIVE
    )
    private val macOnlyRe = Pattern.compile(
        """\b([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})\b"""
    )

    data class PortalPair(val portal: String, val mac: String)

    data class WorkingPortal(
        val portal: String,
        val mac: String,
        val ms: Int,
        val status: String,
        val expiry: String = "",
        val maxConnections: String = "1"
    )

    data class FetchResult(
        val articleUrl: String,
        val pairsFound: Int,
        val working: List<WorkingPortal>
    )

    data class RawFetchResult(
        val articleUrl: String,
        val pairs: List<PortalPair>
    )

    fun fetchHtml(url: String): String {
        val req = Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/124.0.0.0 Mobile Safari/537.36"
            )
            .header("Accept", "text/html,application/xhtml+xml")
            .get()
            .build()
        PortalClient.browseHttp.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IllegalStateException("HTTP ${resp.code} عند جلب: $url")
            }
            return resp.body?.string().orEmpty()
        }
    }

    fun getLatestArticleUrls(baseUrl: String = BASE_URL, maxArticles: Int = 3): List<String> {
        val html = fetchHtml(baseUrl.trimEnd('/') + "/")
        val m = articleLinkRe.matcher(html)
        val seen = LinkedHashSet<String>()
        while (m.find()) {
            val href = m.group(1)?.trim().orEmpty()
            if (href.isNotBlank()) {
                seen.add(href)
                if (seen.size >= maxArticles) break
            }
        }
        if (seen.isEmpty()) {
            throw IllegalStateException("تعذّر اكتشاف أحدث مقالات من $baseUrl")
        }
        return seen.toList()
    }

    fun extractPairs(html: String): List<PortalPair> {
        val seenKeys = LinkedHashSet<String>()
        val pairs = ArrayList<PortalPair>()

        fun add(portalRaw: String, macRaw: String) {
            val portal = portalRaw.trim().trimEnd('/')
            if (portal.contains("googleapis.com", ignoreCase = true) ||
                portal.contains("blogger.com", ignoreCase = true) ||
                portal.contains("stbemu.com", ignoreCase = true)
            ) return
            val mac = macRaw.trim().uppercase(Locale.US).replace('-', ':')
            if (!mac.matches(Regex("""[0-9A-F]{2}(:[0-9A-F]{2}){5}"""))) return
            val key = "${portal.lowercase(Locale.US)}|$mac"
            if (seenKeys.add(key)) pairs.add(PortalPair(portal, mac))
        }

        val sm = htmlSmartBoxRe.matcher(html)
        while (sm.find()) add(sm.group(1).orEmpty(), sm.group(2).orEmpty())

        val lm = labeledBlockRe.matcher(html)
        while (lm.find()) add(lm.group(1).orEmpty(), lm.group(2).orEmpty())

        val am = portalAltRe.matcher(html)
        while (am.find()) add(am.group(1).orEmpty(), am.group(2).orEmpty())

        // لا نلجأ للمزاوجة الفهرسية إلا إذا كانت الصفحة نصّاً مجرّداً وتطابق العدد تماماً دون إزاحة
        if (pairs.isEmpty()) {
            val urls = ArrayList<String>()
            val um = strictPortalUrlRe.matcher(html)
            while (um.find()) urls.add(um.group(1).orEmpty())
            val macs = ArrayList<String>()
            val mm = macOnlyRe.matcher(html)
            while (mm.find()) {
                val mac = mm.group(1).orEmpty().uppercase(Locale.US).replace('-', ':')
                if (mac.matches(Regex("""[0-9A-F]{2}(:[0-9A-F]{2}){5}"""))) {
                    macs.add(mac)
                }
            }
            if (urls.size == macs.size) {
                for (i in urls.indices) add(urls[i], macs[i])
            }
        }
        return pairs
    }

    private fun isIsoDateExpired(expStr: String): Boolean {
        val m = Regex("""^(\d{4}-\d{2}-\d{2})$""").find(expStr.trim()) ?: return false
        val dateIso = m.groupValues[1]
        val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        return dateIso < todayIso
    }

    fun testHandshake(portal: String, mac: String): WorkingPortal? {
        val portalSaved = if (portal.endsWith("/c", ignoreCase = true)) {
            portal.dropLast(2).trimEnd('/')
        } else {
            portal.trimEnd('/')
        }
        val acc = PortalClient.normalizeAccountInput(
            provider = ProviderType.STALKER,
            rawName = "",
            rawUrl = portalSaved,
            rawMac = mac,
            rawUser = "",
            rawPass = ""
        )
        return try {
            val st = PortalClient.fetchAccountStatus(acc, forceProbe = true)
            val badStatus = st.pingMs <= 0 ||
                st.status.contains("محظور") ||
                st.status.contains("خطأ", ignoreCase = true) ||
                st.status.contains("fail", ignoreCase = true) ||
                st.status.contains("تعذّر", ignoreCase = true) ||
                isIsoDateExpired(st.expiry)
            if (badStatus) return null

            // التحقّق الفعلي من أن الماك يجلب أقسام القنوات المباشرة وليس مجرّد توكن وهمي فارغ!
            val cats = runCatching { PortalClient.loadCategories(acc, ContentTab.LIVE) }.getOrNull()
            val realCats = cats?.count { it.id != "*" } ?: 0
            if (realCats <= 0) return null

            WorkingPortal(
                portal = portalSaved,
                mac = mac,
                ms = st.pingMs.coerceAtLeast(1),
                status = st.status.ifBlank { "نشط ✔" },
                expiry = st.expiry,
                maxConnections = st.maxConnections.ifBlank { "1" }
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun fetchAndProbe(
        manualArticleUrl: String? = null,
        maxPairs: Int = 36,
        parallelism: Int = 5,
        onProgress: ((done: Int, total: Int, msg: String) -> Unit)? = null
    ): FetchResult = withContext(Dispatchers.IO) {
        onProgress?.invoke(0, 0, "⏳ اكتشاف أحدث مقالات StbEmu…")
        val articleUrls = if (!manualArticleUrl.isNullOrBlank()) {
            listOf(manualArticleUrl.trim())
        } else {
            getLatestArticleUrls(BASE_URL, maxArticles = 2)
        }

        val collectedMap = LinkedHashMap<String, PortalPair>()
        var primaryArticleUrl = articleUrls.first()
        for ((idx, artUrl) in articleUrls.withIndex()) {
            coroutineContext.ensureActive()
            onProgress?.invoke(0, 0, "⏳ جلب البطاقات (${idx + 1}/${articleUrls.size})…")
            val html = runCatching { fetchHtml(artUrl) }.getOrNull().orEmpty()
            for (p in extractPairs(html)) {
                val k = "${p.portal.lowercase(Locale.US)}|${p.mac}"
                collectedMap[k] = p
                if (collectedMap.size >= maxPairs.coerceAtLeast(1)) break
            }
            if (idx == 0) primaryArticleUrl = artUrl
            if (collectedMap.size >= maxPairs.coerceAtLeast(1)) break
        }

        val pairs = collectedMap.values.toList()
        if (pairs.isEmpty()) {
            onProgress?.invoke(0, 0, "⚠ لم يُعثر على بطاقات Portal/MAC صالحة في الصفحة")
            return@withContext FetchResult(primaryArticleUrl, 0, emptyList())
        }

        val total = pairs.size
        val done = AtomicInteger(0)
        val working = ArrayList<WorkingPortal>()
        val lock = Mutex()
        val batchSize = parallelism.coerceIn(1, 6)

        onProgress?.invoke(0, total, "⚡ فحص $total بوابة وحسابات MAC…")

        pairs.chunked(batchSize).forEach { batch ->
            coroutineContext.ensureActive()
            coroutineScope {
                batch.map { (portal, mac) ->
                    async(Dispatchers.IO) {
                        val wp = testHandshake(portal, mac)
                        val n = done.incrementAndGet()
                        if (wp != null) {
                            lock.withLock { working.add(wp) }
                        }
                        onProgress?.invoke(
                            n,
                            total,
                            "⚡ فُحص $n/$total — شغّال فعلياً: ${working.size}"
                        )
                    }
                }.awaitAll()
            }
        }

        val sorted = working.sortedBy { it.ms }
        onProgress?.invoke(total, total, "✔ اكتمل الفحص — ${sorted.size} بوابة شغّالة من أصل $total")
        FetchResult(articleUrl = primaryArticleUrl, pairsFound = pairs.size, working = sorted)
    }

    /**
     * جلب فوري لبطاقات Portal/MAC من stbemu.com.tr بدون أي فحص مسبق (يُترك الفحص لزرّ «⚡ فحص» المخصّص).
     */
    suspend fun fetchPairsOnly(
        manualArticleUrl: String? = null,
        maxPairs: Int = 50,
        onProgress: ((msg: String) -> Unit)? = null
    ): RawFetchResult = withContext(Dispatchers.IO) {
        onProgress?.invoke("⏳ اكتشاف أحدث مقالات StbEmu…")
        val articleUrls = if (!manualArticleUrl.isNullOrBlank()) {
            listOf(manualArticleUrl.trim())
        } else {
            getLatestArticleUrls(BASE_URL, maxArticles = 3)
        }

        val collectedMap = LinkedHashMap<String, PortalPair>()
        var primaryArticleUrl = articleUrls.first()
        for ((idx, artUrl) in articleUrls.withIndex()) {
            coroutineContext.ensureActive()
            onProgress?.invoke("⏳ سحب بطاقات السيرفرات (${idx + 1}/${articleUrls.size})…")
            val html = runCatching { fetchHtml(artUrl) }.getOrNull().orEmpty()
            for (p in extractPairs(html)) {
                val k = "${p.portal.lowercase(Locale.US)}|${p.mac}"
                collectedMap[k] = p
                if (collectedMap.size >= maxPairs.coerceAtLeast(1)) break
            }
            if (idx == 0) primaryArticleUrl = artUrl
            if (collectedMap.size >= maxPairs.coerceAtLeast(1)) break
        }
        val pairs = collectedMap.values.toList()
        RawFetchResult(articleUrl = primaryArticleUrl, pairs = pairs)
    }

    fun pairsToAccounts(pairs: List<PortalPair>): List<AccountProfile> {
        return pairs.map { (portal, mac) ->
            val portalSaved = if (portal.endsWith("/c", ignoreCase = true)) {
                portal.dropLast(2).trimEnd('/')
            } else {
                portal.trimEnd('/')
            }
            PortalClient.normalizeAccountInput(
                provider = ProviderType.STALKER,
                rawName = "",
                rawUrl = portalSaved,
                rawMac = mac,
                rawUser = "",
                rawPass = ""
            ).copy(
                expiry = "",
                status = "غير مفحوص",
                pingMs = 0
            )
        }
    }

    fun toAccounts(working: List<WorkingPortal>): List<AccountProfile> {
        return working.map { wp ->
            PortalClient.normalizeAccountInput(
                provider = ProviderType.STALKER,
                rawName = "",
                rawUrl = wp.portal,
                rawMac = wp.mac,
                rawUser = "",
                rawPass = ""
            ).copy(
                expiry = wp.expiry,
                maxConnections = wp.maxConnections,
                status = wp.status,
                pingMs = wp.ms
            )
        }
    }
}
