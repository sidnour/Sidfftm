package com.iptvlite.tv.network

import android.content.Context
import android.net.Uri
import android.util.Base64
import android.util.JsonReader
import android.util.JsonToken
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.AccountStatusInfo
import com.iptvlite.tv.model.AccountAccess
import com.iptvlite.tv.model.CategoryItem
import com.iptvlite.tv.model.ContentTab
import com.iptvlite.tv.model.EpgProgram
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.MediaDetails
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.StreamItem
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

object PortalClient {

    const val MAG_UA =
        "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"
    const val XTREAM_UA = "IPTVSmartersPro/4.0 (VLC/3.0.20 LibVLC/3.0.20)"
    const val GENERIC_UA = XTREAM_UA

    @Volatile
    private var appContext: Context? = null

    @Volatile private var endpointHints: StalkerEndpointHints? = null
    fun initAppContext(ctx: Context) {
        appContext = ctx.applicationContext
        if(endpointHints==null) synchronized(this) {
            if(endpointHints==null) endpointHints=runCatching {
                StalkerEndpointHints(ctx.applicationContext.getSharedPreferences(StalkerEndpointHints.PREFERENCES,Context.MODE_PRIVATE))
            }.getOrNull()
        }
    }

    private val ITV_SCHEMES = listOf("http://", "https://", "rtmp://", "rtsp://", "mms://", "rtp://", "udp://")
    private val ITV_PREFIXES = setOf("ffmpeg", "ffrt", "ffrt2", "ffrt3", "ffrt4", "ffm", "auto", "solution")

    private val sharedConnectionPool = ConnectionPool(6, 2, TimeUnit.MINUTES)

    private val browseDispatcher = Dispatcher().apply {
        maxRequests = 5
        maxRequestsPerHost = 2
    }

    private val playDispatcher = Dispatcher().apply {
        maxRequests = 8
        maxRequestsPerHost = 4
    }

    private val streamDispatcher = Dispatcher().apply {
        maxRequests = 8
        maxRequestsPerHost = 4
    }

    private val probeDispatcher = Dispatcher().apply {
        maxRequests = 6
        maxRequestsPerHost = 2
    }

    /**
     * عميل OkHttp جذري موحّد يشارك سياق TLS/SSL وحوض الاتصالات لتوفير عشرات الميجابايتات والخيوط!
     */
    val rootHttp: OkHttpClient = OkHttpClient.Builder()
        .dispatcher(playDispatcher)
        .connectionPool(sharedConnectionPool)
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(16, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    /**
     * عميل فوري فائق الأولوية لطلبات تصاريح التشغيل (create_link / handshake) مستقلّ عن مقبس الفيديو.
     */
    private val priorityApiHttp: OkHttpClient = rootHttp.newBuilder()
        .dispatcher(playDispatcher)
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(14, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    // ذاكرة توجيهات البثّ (تحفظ رابط التخزين النهائي بعد 302 لكي يعمل التقديم والاستئناف الداخلي بسلاسة دون إعادة استهلاك play_token أحادي المرّة)
    private val streamRedirectCache: MutableMap<String, Pair<String, Long>> = boundedLruMap(64)
    private const val REDIRECT_CACHE_TTL_MS = 20 * 60 * 1000L

    fun lookupStreamRedirect(originalUrl: String): String? {
        val entry = streamRedirectCache[originalUrl] ?: return null
        if (System.currentTimeMillis() - entry.second > REDIRECT_CACHE_TTL_MS) {
            streamRedirectCache.remove(originalUrl)
            return null
        }
        return entry.first
    }

    fun cacheStreamRedirect(originalUrl: String, finalUrl: String) {
        if (originalUrl.isNotBlank() && finalUrl.isNotBlank() && originalUrl != finalUrl) {
            streamRedirectCache[originalUrl] = finalUrl to System.currentTimeMillis()
        }
    }

    fun evictStreamRedirect(originalUrl: String) {
        streamRedirectCache.remove(originalUrl)
    }

    private fun buildRedirectedRequest(baseReq: Request, targetUrlStr: String, originHost: String): Request? {
        val parsed = targetUrlStr.toHttpUrlOrNull() ?: return null
        val b = baseReq.newBuilder().url(parsed)
        if (!parsed.host.equals(originHost, ignoreCase = true)) {
            b.removeHeader("Cookie")
            b.removeHeader("X-User-Agent")
            b.removeHeader("Authorization")
            b.removeHeader("Referer")
        }
        return b.build()
    }

    private fun proceedFollowingStreamRedirects(chain: okhttp3.Interceptor.Chain, startReq: Request, initialUrl: String): Response {
        var curReq = startReq
        val originHost = initialUrl.toHttpUrlOrNull()?.host ?: curReq.url.host
        for (hop in 0 until 6) {
            val resp = chain.proceed(curReq)
            if (resp.code !in intArrayOf(301, 302, 303, 307, 308)) {
                val landed = curReq.url.toString()
                if (landed != initialUrl) {
                    cacheStreamRedirect(initialUrl, landed)
                }
                return resp
            }
            val loc = resp.header("Location")?.trim()
            if (loc.isNullOrEmpty()) return resp
            val nextUrl = curReq.url.resolve(loc) ?: return resp
            runCatching { resp.close() }
            val nextBuilder = curReq.newBuilder().url(nextUrl)
            if (resp.code == 303 && curReq.method != "GET" && curReq.method != "HEAD") {
                nextBuilder.get()
            }
            if (!nextUrl.host.equals(originHost, ignoreCase = true)) {
                nextBuilder.removeHeader("Cookie")
                nextBuilder.removeHeader("X-User-Agent")
                nextBuilder.removeHeader("Authorization")
                nextBuilder.removeHeader("Referer")
            }
            cacheStreamRedirect(initialUrl, nextUrl.toString())
            curReq = nextBuilder.build()
        }
        return chain.proceed(curReq)
    }

    val playHttp: OkHttpClient = rootHttp.newBuilder()
        .dispatcher(streamDispatcher)
        .connectTimeout(7, TimeUnit.SECONDS)
        .readTimeout(16, TimeUnit.SECONDS)
        .followRedirects(false)
        .followSslRedirects(false)
        .addInterceptor { chain ->
            val origReq = chain.request()
            val initialUrl = origReq.url.toString()
            val cachedTarget = lookupStreamRedirect(initialUrl)
            if (cachedTarget != null) {
                val rewritten = buildRedirectedRequest(origReq, cachedTarget, origReq.url.host)
                if (rewritten != null) {
                    val cachedResp = try {
                        proceedFollowingStreamRedirects(chain, rewritten, initialUrl)
                    } catch (_: java.io.IOException) {
                        evictStreamRedirect(initialUrl)
                        null
                    }
                    if (cachedResp != null) {
                        if (cachedResp.code < 400) {
                            return@addInterceptor cachedResp
                        }
                        evictStreamRedirect(initialUrl)
                        runCatching { cachedResp.close() }
                    }
                }
            }
            proceedFollowingStreamRedirects(chain, origReq, initialUrl)
        }
        .build()

    val browseHttp: OkHttpClient = rootHttp.newBuilder()
        .dispatcher(browseDispatcher)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(16, TimeUnit.SECONDS)
        .build()

    val probeHttp: OkHttpClient = rootHttp.newBuilder()
        .dispatcher(probeDispatcher)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private fun <K, V> boundedLruMap(maxEntries: Int): MutableMap<K, V> {
        return java.util.Collections.synchronizedMap(
            object : LinkedHashMap<K, V>(maxEntries + 2, 0.75f, true) {
                override fun removeEldestEntry(eldest: MutableMap.MutableEntry<K, V>?): Boolean {
                    return size > maxEntries
                }
            }
        )
    }

    private data class StalkerSession(
        var endpoint: String = "",
        var referer: String = "",
        var token: String = "",
        var forceCreateLink: Boolean = false,
        var profileJson: JSONObject? = null,
        val extraCookies: ConcurrentHashMap<String, String> = ConcurrentHashMap()
    )

    private data class M3uParsed(
        val liveCats: List<CategoryItem>,
        val liveByCat: Map<String, List<StreamItem>>,
        val vodCats: List<CategoryItem>,
        val vodByCat: Map<String, List<StreamItem>>,
        val serCats: List<CategoryItem>,
        val serByCat: Map<String, List<StreamItem>>,
        val serEpisodes: Map<String, Map<String, List<StreamItem>>>,
        val detectedEpgUrl: String = ""
    )

    // ذاكرة مؤقّتة مقيّدة بحدّ أقصى (LRU) لمنع تضخّم الـ RAM عند التنقّل بين الأقسام والسيرفرات
    private val categoriesCache: MutableMap<String, List<CategoryItem>> = boundedLruMap(9)
    private val stalkerSessions = ConcurrentHashMap<String, StalkerSession>()
    private val stalkerAllLiveCache: MutableMap<String, List<StreamItem>> = boundedLruMap(1)
    // متوافق 100% مع API 21+ (تجنّب ConcurrentHashMap.newKeySet المضاف في API 24)
    private val stalkerBulkFailedKeys = ConcurrentHashMap<String, Boolean>()
    private val stalkerGroupFallbackCache: MutableMap<String, List<StreamItem>> = boundedLruMap(6)
    private val stalkerKnownCatIds: MutableMap<String, Set<String>> = boundedLruMap(3)

    private val xtreamAllLiveCache: MutableMap<String, List<StreamItem>> = boundedLruMap(1)
    private val xtreamStreamCache: MutableMap<String, List<StreamItem>> = boundedLruMap(6)
    private val xtreamSeriesInfoCache: MutableMap<String, JSONObject> = boundedLruMap(8)
    private val m3uCache: MutableMap<String, M3uParsed> = boundedLruMap(1)

    /**
     * الأولوية المطلقة للبثّ: إلغاء فوري لأي طلبات تصفّح قوائم أو EPG لحظة اختيار قناة للتشغيل!
     */
    fun preemptBrowse() {
        BrowseWork.cancelAll()
        NetworkCleanup.cancelCurrent(browseDispatcher)
    }

    /**
     * تخفيف استهلاك الذاكرة تلقائياً عند دخول المشغّل بملء الشاشة (إفراغ القوائم الضخمة > 4000 عنصر).
     */
    fun trimForPlayback() {
        NetworkCleanup.cancelCurrent(browseDispatcher)
        runCatching { xtreamSeriesInfoCache.clear() }
        synchronized(stalkerAllLiveCache) {
            val heavy = stalkerAllLiveCache.entries.filter { it.value.size > 4000 }.map { it.key }
            heavy.forEach { stalkerAllLiveCache.remove(it) }
        }
        synchronized(xtreamAllLiveCache) {
            val heavy = xtreamAllLiveCache.entries.filter { it.value.size > 4000 }.map { it.key }
            heavy.forEach { xtreamAllLiveCache.remove(it) }
        }
    }

    fun clearCaches() {
        categoriesCache.clear()
        streamRedirectCache.clear()
        stalkerAllLiveCache.clear()
        stalkerBulkFailedKeys.clear()
        stalkerGroupFallbackCache.clear()
        stalkerKnownCatIds.clear()
        xtreamAllLiveCache.clear()
        xtreamStreamCache.clear()
        xtreamSeriesInfoCache.clear()
        m3uCache.clear()
        XmltvHelper.clearCache()
    }

    /**
     * تنظيف فوري للمقابس العالقة وتوجيهات العقد الميّتة قبل إعادة الاتصال أو إنعاش البثّ،
     * لضمان تحرير خطّ الاشتراك الأحادي (max_connections = 1) على السيرفر وعدم العودة لعقدة متوقّفة!
     */
    fun prepareForStreamReconnect(lastResolvedUrl: String? = null, rawCmd: String? = null): Boolean {
        val hadActive = runCatching {
            streamDispatcher.runningCallsCount() + streamDispatcher.queuedCallsCount() > 0
        }.getOrDefault(false)
        NetworkCleanup.cancelCurrent(browseDispatcher)
        NetworkCleanup.cancelCurrent(streamDispatcher)
        if (!lastResolvedUrl.isNullOrBlank()) evictStreamRedirect(lastResolvedUrl)
        if (!rawCmd.isNullOrBlank()) evictStreamRedirect(extractDirectHttpUrl(rawCmd))
        runCatching { streamRedirectCache.clear() }
        NetworkCleanup.evictIdle(sharedConnectionPool)
        return hadActive
    }

    fun evictIdleConnections() {
        NetworkCleanup.cancelCurrent(browseDispatcher)
        NetworkCleanup.cancelCurrent(streamDispatcher)
        NetworkCleanup.evictIdle(sharedConnectionPool)
    }

    fun shutdownForExit() {
        BrowseWork.cancelAll()
        NetworkCleanup.cancelCurrent(browseDispatcher)
        NetworkCleanup.cancelCurrent(playDispatcher)
        NetworkCleanup.cancelCurrent(streamDispatcher)
        NetworkCleanup.cancelCurrent(probeDispatcher)
        NetworkCleanup.evictIdle(sharedConnectionPool)
        clearCaches()
        stalkerSessions.clear()
        runCatching { browseDispatcher.executorService.shutdownNow() }
        runCatching { playDispatcher.executorService.shutdownNow() }
        runCatching { streamDispatcher.executorService.shutdownNow() }
        runCatching { probeDispatcher.executorService.shutdownNow() }
    }

    fun markStalkerNeedsCreateLink(acc: AccountProfile) {
        stalkerSessions[sessionKey(acc)]?.forceCreateLink = true
    }

    /**
     * ترويسات HTTP مطابقة لأجهزة البثّ الحقيقية لمنع قطع الاتصال المفاجئ من خوادم البثّ!
     */
    fun getStreamRequestHeaders(acc: AccountProfile?): Map<String, String> {
        if (acc == null) return mapOf("User-Agent" to GENERIC_UA, "Accept" to "*/*")
        return when (acc.provider) {
            ProviderType.STALKER -> {
                val safeMac = safeMacForHeader(acc.mac)
                val sess = stalkerSessions[sessionKey(acc)]
                val cookies = ArrayList<String>(6)
                cookies.add("mac=$safeMac")
                cookies.add("stb_lang=ar")
                cookies.add("timezone=Africa/Algiers")
                if (sess != null && sess.token.isNotBlank()) {
                    cookies.add("token=${sess.token}")
                }
                sess?.extraCookies?.forEach { (k, v) -> cookies.add("$k=$v") }
                val hdrs = LinkedHashMap<String, String>()
                hdrs["User-Agent"] = MAG_UA
                hdrs["Accept"] = "*/*"
                hdrs["X-User-Agent"] = "model=MAG250;mac=$safeMac;stb_type=MAG250"
                if (sess != null && sess.referer.isNotBlank()) {
                    hdrs["Referer"] = sess.referer
                }
                hdrs["Cookie"] = cookies.joinToString("; ")
                hdrs
            }
            ProviderType.XTREAM, ProviderType.M3U -> mapOf(
                "User-Agent" to XTREAM_UA,
                "Accept" to "*/*"
            )
        }
    }

    fun normalizeAccountInput(
        provider: ProviderType,
        rawName: String,
        rawUrl: String,
        rawMac: String,
        rawUser: String,
        rawPass: String,
        existingId: String = java.util.UUID.randomUUID().toString(),
        rawEpgUrl: String = ""
    ): AccountProfile {
        var cleanUrl = rawUrl.trim()
        val isLocalM3u = cleanUrl.startsWith("content://", ignoreCase = true) ||
            cleanUrl.startsWith("file://", ignoreCase = true) ||
            cleanUrl.startsWith("/")
        if (cleanUrl.startsWith("/")) {
            cleanUrl = "file://$cleanUrl"
        }
        if (!isLocalM3u && cleanUrl.isNotEmpty() && !cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
            cleanUrl = "http://$cleanUrl"
        }
        var user = rawUser.trim()
        var pass = rawPass.trim()
        if (provider == ProviderType.XTREAM && cleanUrl.contains("username=", ignoreCase = true)) {
            cleanUrl.toHttpUrlOrNull()?.let { hu ->
                if (user.isBlank()) user = hu.queryParameter("username").orEmpty()
                if (pass.isBlank()) pass = hu.queryParameter("password").orEmpty()
                cleanUrl = "${hu.scheme}://${hu.host}" +
                    if ((hu.scheme == "http" && hu.port != 80) || (hu.scheme == "https" && hu.port != 443)) ":${hu.port}" else ""
            }
        }
        if (provider == ProviderType.XTREAM) {
            cleanUrl = cleanUrl
                .replace(Regex("/(player_api\\.php|get\\.php|c)/?$", RegexOption.IGNORE_CASE), "")
                .trimEnd('/')
        }
        val cleanMac = rawMac.trim().uppercase(Locale.US).replace('-', ':')
        val finalName = rawName.trim().ifBlank {
            cleanUrl.removePrefix("https://").removePrefix("http://").substringBefore("/").ifBlank { provider.label }
        }
        var cleanEpg = rawEpgUrl.trim()
        if (cleanEpg.isNotEmpty() && !cleanEpg.startsWith("http://", true) && !cleanEpg.startsWith("https://", true)) {
            cleanEpg = "http://$cleanEpg"
        }
        return AccountProfile(
            id = existingId,
            name = finalName,
            provider = provider,
            url = cleanUrl,
            mac = cleanMac,
            username = user,
            password = pass,
            epgUrl = cleanEpg
        )
    }

    // ==================== الأقسام والعناصر ====================

    fun loadCategories(acc: AccountProfile, tab: ContentTab, forceRefresh: Boolean = false): List<CategoryItem> {
        if(!PlaybackRequestScope.hasCurrent()) return BrowseWork.run { loadCategories(acc,tab,forceRefresh) }
        PlaybackRequestScope.checkCurrent()
        val cKey = "${sessionKey(acc)}|cat|${tab.name}"
        if (!forceRefresh) {
            categoriesCache[cKey]?.let { if (it.isNotEmpty()) return it }
        }
        val cats = when (acc.provider) {
            ProviderType.STALKER -> stalkerCategories(acc, tab)
            ProviderType.XTREAM -> xtreamCategories(acc, tab)
            ProviderType.M3U -> m3uCategories(acc, tab)
        }
        if (cats.isNotEmpty()) {
            PlaybackRequestScope.checkCurrent()
            categoriesCache[cKey] = cats
        }
        return cats
    }

    private fun ownedItems(acc: AccountProfile, items: List<StreamItem>): List<StreamItem> =
        items.map { if(it.accountId==acc.id) it else it.copy(accountId=acc.id) }

    fun loadCategoryItems(
        acc: AccountProfile,
        tab: ContentTab,
        categoryId: String,
        onPartialItems: ((List<StreamItem>) -> Unit)? = null
    ): List<StreamItem> {
        if(!PlaybackRequestScope.hasCurrent()) return BrowseWork.run { loadCategoryItems(acc,tab,categoryId,onPartialItems) }
        PlaybackRequestScope.checkCurrent()
        val partial: ((List<StreamItem>)->Unit)? = onPartialItems?.let { callback ->
            { items: List<StreamItem> -> callback(ownedItems(acc,items)) }
        }
        return ownedItems(acc,when (acc.provider) {
            ProviderType.STALKER -> stalkerCategoryItems(acc, tab, categoryId, partial)
            ProviderType.XTREAM -> xtreamCategoryItems(acc, tab, categoryId, partial)
            ProviderType.M3U -> m3uCategoryItems(acc, tab, categoryId)
        })
    }

    /**
     * البحث الشامل في السيرفر كله (عند ضغط المستخدم على «🌐 شامل» حصراً — مع استثناء الأقسام المقفولة/المخفية).
     */
    fun globalSearch(acc: AccountProfile, tab: ContentTab, rawQuery: String,
        excludedCategoryIds: Set<String> = emptySet()): List<StreamItem> =
        if(PlaybackRequestScope.hasCurrent()) ownedItems(acc,globalSearchUnowned(acc,tab,rawQuery,excludedCategoryIds))
        else BrowseWork.run { ownedItems(acc,globalSearchUnowned(acc,tab,rawQuery,excludedCategoryIds)) }

    private fun globalSearchUnowned(
        acc: AccountProfile,
        tab: ContentTab,
        rawQuery: String,
        excludedCategoryIds: Set<String> = emptySet()
    ): List<StreamItem> {
        val q = rawQuery.trim()
        if (q.isEmpty()) return emptyList()
        val targetTab = if (tab in listOf(ContentTab.LIVE, ContentTab.VOD, ContentTab.SERIES)) tab else ContentTab.LIVE

        return when (acc.provider) {
            ProviderType.M3U -> {
                val p = ensureM3u(acc)
                val map = when (targetTab) {
                    ContentTab.VOD -> p.vodByCat
                    ContentTab.SERIES -> p.serByCat
                    else -> p.liveByCat
                }
                val out = ArrayList<StreamItem>()
                for ((grp, list) in map) {
                    if (grp in excludedCategoryIds) continue
                    for (it in list) {
                        if (it.name.contains(q, ignoreCase = true)) {
                            out.add(it)
                            if (out.size >= 250) return out
                        }
                    }
                }
                out
            }

            ProviderType.XTREAM -> {
                val all = xtreamCategoryItems(acc, targetTab, "*")
                all.asSequence()
                    .filter { it.categoryId !in excludedCategoryIds && it.name.contains(q, ignoreCase = true) }
                    .take(250)
                    .toList()
            }

            ProviderType.STALKER -> {
                val out = ArrayList<StreamItem>()
                val seenIds = HashSet<String>()

                if (targetTab == ContentTab.LIVE) {
                    val sKey = sessionKey(acc)
                    val ramAll = stalkerAllLiveCache[sKey]
                    if (!ramAll.isNullOrEmpty()) {
                        for (ch in ramAll) {
                            if (ch.categoryId !in excludedCategoryIds && ch.name.contains(q, ignoreCase = true)) {
                                if (seenIds.add(ch.id)) out.add(ch)
                                if (out.size >= 250) return out
                            }
                        }
                    }
                }

                val portalType = when (targetTab) {
                    ContentTab.VOD -> "vod"
                    ContentTab.SERIES -> "series"
                    else -> "itv"
                }
                val kind = when (targetTab) {
                    ContentTab.VOD -> ItemKind.VOD
                    ContentTab.SERIES -> ItemKind.SERIES
                    else -> ItemKind.LIVE
                }
                val maxPages = if (targetTab == ContentTab.LIVE) 4 else 8
                for (page in 1..maxPages) {
                    val params = LinkedHashMap<String, String>().apply {
                        put("category", "*")
                        if (portalType == "itv") put("genre", "*")
                        put("search", q)
                        put("p", page.toString())
                        put("per_page", "14")
                    }
                    val js = runCatching { stalkerCall(acc, portalType, "get_ordered_list", params) }.getOrNull() ?: break
                    val arr = (js as? JSONObject)?.optJSONArray("data") ?: (js as? JSONArray) ?: break
                    if (arr.length() == 0) break

                    var addedPage = 0
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        val id = o.optString("id").ifBlank { o.optString("ch_id") }.trim()
                        val name = o.optString("name").ifBlank { o.optString("o_name") }.ifBlank { o.optString("title") }.trim()
                        if (id.isEmpty() || name.isEmpty()) continue
                        val cid = o.optString("category_id")
                            .ifBlank { o.optString("tv_genre_id") }
                            .ifBlank { o.optString("genre_id") }
                            .trim()
                        if (cid.isNotEmpty() && cid in excludedCategoryIds) continue
                        if (!name.contains(q, ignoreCase = true)) continue
                        if (!seenIds.add(id)) continue

                        val logoRaw = o.optString("logo").ifBlank { o.optString("screenshot_uri") }.ifBlank { o.optString("pic") }
                        val year = o.optString("year").trim()
                        val rating = o.optString("rating_imdb").ifBlank { o.optString("rating_kinopoisk") }.trim()
                        val (hasAr, arDays) = if (kind == ItemKind.LIVE) parseStalkerArchiveFlags(o) else (false to 0)
                        val sub = if (kind == ItemKind.LIVE) {
                            if (hasAr) "↺ أرشيف ${arDays}ي" else ""
                        } else {
                            listOfNotNull(
                                year.takeIf { it.isNotBlank() && it != "0" },
                                rating.takeIf { it.isNotBlank() && it != "0" }?.let { "⭐ $it" }
                            ).joinToString(" · ")
                        }
                        out.add(
                            StreamItem(
                                id = id,
                                name = name,
                                cmd = o.optString("cmd").trim(),
                                categoryId = cid,
                                logo = resolveLogoUrl(acc.url, logoRaw),
                                kind = kind,
                                subtitle = sub,
                                seriesId = if (kind == ItemKind.SERIES) id else "",
                                tvArchive = hasAr,
                                tvArchiveDays = arDays,
                                plot = o.optString("description").ifBlank { o.optString("plot") }.trim(),
                                year = year,
                                rating = rating,
                                genres = o.optString("genres_str").trim(),
                                duration = o.optString("time").trim()
                            )
                        )
                        addedPage++
                        if (out.size >= 250) return out
                    }
                    if (addedPage == 0 && arr.length() < 14) break
                }
                out
            }
        }
    }

    fun loadSeasons(acc: AccountProfile, seriesItem: StreamItem): List<StreamItem> {
        if(!PlaybackRequestScope.hasCurrent()) return BrowseWork.run { loadSeasons(acc,seriesItem) }
        PlaybackRequestScope.checkCurrent()
        return ownedItems(acc,when (acc.provider) {
            ProviderType.STALKER -> stalkerSeasons(acc, seriesItem)
            ProviderType.XTREAM -> xtreamSeasons(acc, seriesItem)
            ProviderType.M3U -> m3uSeasons(acc, seriesItem)
        })
    }

    fun loadEpisodes(acc: AccountProfile, seriesItem: StreamItem, seasonItem: StreamItem): List<StreamItem> {
        if(!PlaybackRequestScope.hasCurrent()) return BrowseWork.run { loadEpisodes(acc,seriesItem,seasonItem) }
        PlaybackRequestScope.checkCurrent()
        return ownedItems(acc,when (acc.provider) {
            ProviderType.STALKER -> stalkerEpisodes(acc, seriesItem, seasonItem)
            ProviderType.XTREAM -> xtreamEpisodes(acc, seriesItem, seasonItem)
            ProviderType.M3U -> m3uEpisodes(acc, seriesItem, seasonItem)
        })
    }

    fun resolveStreamUrl(
        acc: AccountProfile,
        item: StreamItem,
        forceCreateLink: Boolean = false,
        forceSessionRefresh: Boolean = false
    ): String {
        preemptBrowse()
        val rawCmd = item.cmd.trim()
        if (rawCmd.startsWith("file://", ignoreCase = true) || rawCmd.startsWith("content://", ignoreCase = true)) {
            return rawCmd
        }
        if (item.kind == ItemKind.CATCHUP) {
            return extractDirectHttpUrl(item.cmd)
        }
        return when (acc.provider) {
            ProviderType.XTREAM, ProviderType.M3U -> extractDirectHttpUrl(item.cmd)
            ProviderType.STALKER -> stalkerResolveUrl(acc, item, forceCreateLink, forceSessionRefresh)
        }
    }

    /** Explicit M3U export ONLY: browse priority, no playback preemption/forceCreateLink/cache mutation. */
    internal fun resolveM3uExportUrl(acc:AccountProfile,item:StreamItem):String {
        if(!PlaybackRequestScope.hasCurrent())return BrowseWork.run {resolveM3uExportUrl(acc,item)}
        PlaybackRequestScope.checkCurrent()
        com.iptvlite.tv.util.M3uExport.portableUrl(item.cmd).takeIf {it.isNotEmpty()}?.let {return it}
        if(acc.provider!=ProviderType.STALKER || item.kind !in setOf(ItemKind.LIVE,ItemKind.VOD,ItemKind.EPISODE))return ""
        val params=linkedMapOf("cmd" to item.cmd,"forced_storage" to "false","disable_ad" to "false",
            "download" to "false","force_ch_link_check" to "false")
        if(item.kind==ItemKind.EPISODE && item.containerExt.isNotBlank())params["series"]=item.containerExt
        try {
            val js=stalkerCall(acc,if(item.kind==ItemKind.LIVE)"itv" else "vod","create_link",params,highPriority=false)
            PlaybackRequestScope.checkCurrent()
            val raw=(js as? JSONObject)?.optString("cmd").orEmpty()
            if(!isUsableStalkerCreatedCmd(raw))return ""
            val created=extractDirectHttpUrl(raw)
            // Rewrite only an actual create_link response, NEVER the original virtual /ch/ command.
            if(com.iptvlite.tv.util.M3uExport.loopback(created) && com.iptvlite.tv.util.M3uExport.virtualPath(created))return ""
            return com.iptvlite.tv.util.M3uExport.portableUrl(rewriteLocalhostUrl(acc.url,created))
        } catch(e:java.util.concurrent.CancellationException) {throw e}
        catch(_:Exception) {PlaybackRequestScope.checkCurrent();return ""}
    }

    fun fetchAccountStatus(acc: AccountProfile, forceProbe: Boolean = false): AccountStatusInfo {
        val t0 = System.currentTimeMillis()
        return when (acc.provider) {
            ProviderType.XTREAM -> {
                val st = xtreamAccountStatus(acc, forceProbe)
                st.copy(pingMs = (System.currentTimeMillis() - t0).toInt().coerceAtLeast(1))
            }
            ProviderType.STALKER -> {
                val st = stalkerAccountStatus(acc, forceFresh = forceProbe)
                st.copy(pingMs = (System.currentTimeMillis() - t0).toInt().coerceAtLeast(1))
            }
            ProviderType.M3U -> {
                val parsed = ensureM3u(acc, forceRefresh = forceProbe)
                val total = parsed.liveByCat.values.sumOf { it.size } +
                    parsed.vodByCat.values.sumOf { it.size } +
                    parsed.serEpisodes.values.sumOf { seasons -> seasons.values.sumOf { it.size } }
                val dt = (System.currentTimeMillis() - t0).toInt().coerceAtLeast(1)
                AccountStatusInfo(
                    expiry = "مفتوح (M3U)",
                    maxConnections = "∞",
                    status = if(total>0)"قائمة مستجيبة ✔ ($total)" else "قائمة فارغة أو محتوى غير صالح — غير مؤكد",
                    pingMs = dt,
                    access = if(total>0)AccountAccess.ACCEPTED else AccountAccess.UNKNOWN
                )
            }
        }
    }

    // ==================== دليل البرامج (EPG) وأرشيف الإعادة (Catch-up TV) ====================

    private fun resolveEffectiveM3uEpgUrl(acc: AccountProfile): String {
        if (acc.epgUrl.isNotBlank()) return acc.epgUrl.trim()
        val parsed = runCatching { ensureM3u(acc) }.getOrNull()
        return parsed?.detectedEpgUrl?.trim().orEmpty()
    }

    /**
     * معاينة سريعة وخفيفة جداً للقناة الحالية (الآن / التالي) دون سحب جدول ضخم.
     */
    fun fetchShortEpg(acc: AccountProfile, ch: StreamItem, limit: Int = 2): List<EpgProgram> {
        if (acc.provider == ProviderType.M3U) {
            val epgUrl = resolveEffectiveM3uEpgUrl(acc)
            if (epgUrl.isBlank()) return emptyList()
            return XmltvHelper.getProgramsForChannel(epgUrl, ch, limit.coerceIn(1, 6))
        }
        return fetchShortEpg(acc, ch.id, limit)
    }

    fun fetchShortEpg(acc: AccountProfile, chId: String, limit: Int = 2): List<EpgProgram> {
        if (chId.isBlank() || acc.provider == ProviderType.M3U) return emptyList()
        val lim = limit.coerceIn(1, 6)
        return runCatching {
            when (acc.provider) {
                ProviderType.XTREAM -> {
                    val root = JSONObject(
                        xtreamApiCall(acc, "get_short_epg", mapOf("stream_id" to chId, "limit" to lim.toString()))
                    )
                    val arr = root.optJSONArray("epg_listings") ?: return emptyList()
                    val out = ArrayList<EpgProgram>()
                    val nowSec = System.currentTimeMillis() / 1000L
                    for (i in 0 until minOf(arr.length(), lim)) {
                        val o = arr.optJSONObject(i) ?: continue
                        val nm = decodeBase64IfNeeded(o.optString("title").ifBlank { o.optString("name") }).trim()
                        if (nm.isEmpty()) continue
                        val st = parseUnixTs(o.optString("start_timestamp"), o.optString("start"))
                        val en = parseUnixTs(o.optString("stop_timestamp"), o.optString("end"))
                        val isNow = o.optInt("now_playing", 0) == 1 || (st in 1..nowSec && nowSec < en)
                        out.add(
                            EpgProgram(
                                epgId = o.optString("id"),
                                name = nm.take(80),
                                startTs = st,
                                stopTs = en,
                                startStr = o.optString("start"),
                                isNow = isNow
                            )
                        )
                    }
                    out
                }

                ProviderType.STALKER -> {
                    val js = stalkerCall(acc, "itv", "get_short_epg", mapOf("ch_id" to chId, "size" to lim.toString()))
                    val arr = when (js) {
                        is JSONObject -> js.optJSONArray("data")
                        is JSONArray -> js
                        else -> null
                    } ?: return emptyList()
                    val out = ArrayList<EpgProgram>()
                    val nowSec = System.currentTimeMillis() / 1000L
                    for (i in 0 until minOf(arr.length(), lim)) {
                        val o = arr.optJSONObject(i) ?: continue
                        val nm = o.optString("name").ifBlank { o.optString("title") }.trim()
                        if (nm.isEmpty()) continue
                        val st = parseUnixTs(o.optString("start_timestamp"), o.optString("time"))
                        val en = parseUnixTs(o.optString("stop_timestamp"), o.optString("time_to"))
                        val isNow = o.optInt("mark_playing", 0) == 1 || (st in 1..nowSec && nowSec < en)
                        out.add(
                            EpgProgram(
                                epgId = o.optString("id"),
                                name = nm.take(80),
                                startTs = st,
                                stopTs = en,
                                startStr = o.optString("time"),
                                isNow = isNow
                            )
                        )
                    }
                    out
                }

                else -> emptyList()
            }
        }.getOrDefault(emptyList())
    }

    /**
     * مطابق لـ Portal.epg_archive() في iptv_app.py: يجلب جدول البرامج والأرشيف عند فتح نافذة الدليل فقط!
     */
    fun fetchFullEpgAndArchive(acc: AccountProfile, ch: StreamItem): List<EpgProgram> {
        if (acc.provider == ProviderType.M3U) {
            val epgUrl = resolveEffectiveM3uEpgUrl(acc)
            if (epgUrl.isBlank()) return emptyList()
            val list = XmltvHelper.getProgramsForChannel(epgUrl, ch, limit = 120)
            if (!ch.tvArchive || ch.catchupTag.isBlank()) return list
            val nowSec = System.currentTimeMillis() / 1000L
            val maxAgeSec = (ch.tvArchiveDays.takeIf { it > 0 } ?: 3) * 86_400L
            return list.map { p ->
                val isPast = p.stopTs in (nowSec - maxAgeSec)..nowSec
                p.copy(hasArchive = isPast)
            }
        }
        if (ch.id.isBlank()) return emptyList()
        val nowSec = System.currentTimeMillis() / 1000L
        val maxAgeSec = (ch.tvArchiveDays.takeIf { it > 0 } ?: 7) * 86_400L

        return when (acc.provider) {
            ProviderType.XTREAM -> {
                val arr: JSONArray = runCatching {
                    JSONObject(xtreamApiCall(acc, "get_simple_data_table", mapOf("stream_id" to ch.id)))
                        .optJSONArray("epg_listings")
                }.getOrNull()?.takeIf { it.length() > 0 }
                    ?: runCatching {
                        JSONObject(xtreamApiCall(acc, "get_short_epg", mapOf("stream_id" to ch.id, "limit" to "120")))
                            .optJSONArray("epg_listings")
                    }.getOrNull()
                    ?: return emptyList()

                val startIdx = (arr.length() - 250).coerceAtLeast(0)
                val out = ArrayList<EpgProgram>()
                for (i in startIdx until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val nm = decodeBase64IfNeeded(o.optString("title").ifBlank { o.optString("name") }).trim()
                    if (nm.isEmpty()) continue
                    val dsc = decodeBase64IfNeeded(o.optString("description").ifBlank { o.optString("descr") }).trim()
                    val sStr = o.optString("start").trim()
                    val eStr = o.optString("end").ifBlank { o.optString("stop") }.trim()
                    val st = parseUnixTs(o.optString("start_timestamp"), sStr)
                    val en = parseUnixTs(o.optString("stop_timestamp"), eStr)
                    val isNow = o.optInt("now_playing", 0) == 1 || (st in 1..nowSec && nowSec < en)
                    val hasArFlag = o.optString("has_archive").trim() in setOf("1", "true", "True")
                    val isPast = (en in 1..nowSec) || (st in 1 until (nowSec - 300) && !isNow)
                    val canArch = hasArFlag || (ch.tvArchive && isPast && st > 0 && (nowSec - st) <= maxAgeSec)

                    out.add(
                        EpgProgram(
                            epgId = o.optString("id").ifBlank { o.optString("epg_id") },
                            name = nm.take(110),
                            descr = dsc.take(500),
                            startTs = st,
                            stopTs = en,
                            startStr = sStr,
                            isNow = isNow,
                            hasArchive = canArch
                        )
                    )
                }
                out.sortedBy { it.startTs }
            }

            ProviderType.STALKER -> {
                val collected = ArrayList<EpgProgram>()
                val seen = HashSet<String>()
                val dfDay = SimpleDateFormat("yyyy-MM-dd", Locale.US)

                fun appendRows(arr: JSONArray?) {
                    if (arr == null) return
                    for (i in 0 until minOf(arr.length(), 250)) {
                        val o = arr.optJSONObject(i) ?: continue
                        val nm = o.optString("name").ifBlank { o.optString("title") }.trim()
                        if (nm.isEmpty()) continue
                        val sStr = o.optString("time").ifBlank { o.optString("start") }.trim()
                        val eStr = o.optString("time_to").ifBlank { o.optString("stop") }.trim()
                        val st = parseUnixTs(o.optString("start_timestamp"), sStr)
                        val en = parseUnixTs(o.optString("stop_timestamp"), eStr)
                        val sig = "${if (st > 0) st else sStr}|$nm"
                        if (!seen.add(sig)) continue

                        val isNow = o.optInt("mark_playing", 0) == 1 || (st in 1..nowSec && nowSec < en)
                        val markAr = o.optString("mark_archive").ifBlank { o.optString("has_archive") } in setOf("1", "true", "True")
                        val isPast = (en in 1..nowSec) || (st in 1 until (nowSec - 300) && !isNow)
                        val canArch = markAr || (ch.tvArchive && isPast && st > 0 && (nowSec - st) <= maxAgeSec)

                        collected.add(
                            EpgProgram(
                                epgId = o.optString("id").ifBlank { o.optString("real_id") },
                                name = nm.take(110),
                                descr = o.optString("descr").ifBlank { o.optString("description") }.trim().take(500),
                                startTs = st,
                                stopTs = en,
                                startStr = sStr,
                                cmd = o.optString("cmd").trim(),
                                isNow = isNow,
                                hasArchive = canArch
                            )
                        )
                    }
                }

                for (dayOff in listOf(-1L, 0L)) {
                    val dStr = dfDay.format(Date((nowSec + dayOff * 86_400L) * 1000L))
                    runCatching {
                        val js = stalkerCall(
                            acc,
                            "epg",
                            "get_simple_data_table",
                            mapOf("ch_id" to ch.id, "date" to dStr, "p" to "1")
                        )
                        val arr = (js as? JSONObject)?.optJSONArray("data") ?: (js as? JSONArray)
                        appendRows(arr)
                    }
                }

                runCatching {
                    val js = stalkerCall(acc, "itv", "get_short_epg", mapOf("ch_id" to ch.id, "size" to "40"))
                    val arr = (js as? JSONObject)?.optJSONArray("data") ?: (js as? JSONArray)
                    appendRows(arr)
                }

                collected.sortedBy { it.startTs }
            }

            else -> emptyList()
        }
    }

    /**
     * مطابق تماماً لـ Portal.catchup_link() في iptv_app.py: يولّد رابط تشغيل برنامج الأرشيف (Catch-up TV).
     */
    fun resolveCatchupUrl(acc: AccountProfile, ch: StreamItem, prog: EpgProgram): String {
        val stTs = prog.startTs
        val enTs = prog.stopTs
        val durSec = if (enTs > stTs && stTs > 0L) (enTs - stTs).coerceAtLeast(60L) else 3600L
        val durMin = ((durSec + 59L) / 60L).coerceAtLeast(1L)
        val nowSec = System.currentTimeMillis() / 1000L

        return when (acc.provider) {
            ProviderType.XTREAM -> {
                val base = acc.url.trim().trimEnd('/')
                val uEnc = URLEncoder.encode(acc.username, "UTF-8")
                val pEnc = URLEncoder.encode(acc.password, "UTF-8")
                val sRaw = prog.startStr.trim()
                val startFmt = if (sRaw.length >= 16 && sRaw[4] == '-' && (sRaw[10] == ' ' || sRaw[10] == ':')) {
                    "${sRaw.substring(0, 10)}:${sRaw.substring(11, 13)}-${sRaw.substring(14, 16)}"
                } else if (stTs > 0L) {
                    SimpleDateFormat("yyyy-MM-dd:HH-mm", Locale.US).format(Date(stTs * 1000L))
                } else {
                    return ""
                }
                "$base/timeshift/$uEnc/$pEnc/$durMin/$startFmt/${ch.id}.ts"
            }

            ProviderType.M3U -> {
                if (stTs <= 0L) return ""
                val baseU = extractDirectHttpUrl(ch.cmd)
                val tag = ch.catchupTag
                var mode = "default"
                var tmpl = ""
                if (tag.startsWith("m3u_cu|")) {
                    val pts = tag.split("|", limit = 4)
                    mode = pts.getOrNull(1)?.lowercase(Locale.US) ?: "default"
                    tmpl = pts.getOrNull(3).orEmpty()
                }
                fun rep(s: String): String = s
                    .replace("\${start}", stTs.toString())
                    .replace("{start}", stTs.toString())
                    .replace("\${utc}", stTs.toString())
                    .replace("{utc}", stTs.toString())
                    .replace("\${timestamp}", nowSec.toString())
                    .replace("\${lutc}", nowSec.toString())
                    .replace("{lutc}", nowSec.toString())
                    .replace("\${duration}", durSec.toString())
                    .replace("{duration}", durSec.toString())
                    .replace("\${end}", (stTs + durSec).toString())
                    .replace("{end}", (stTs + durSec).toString())

                if (tmpl.isNotBlank()) {
                    val outU = rep(tmpl)
                    return if (outU.contains("://")) outU else "${baseU.trimEnd('/')}/${outU.trimStart('/')}"
                }
                if (baseU.isBlank()) return ""
                if (mode == "flussonic" || baseU.contains("/index.m3u8") || baseU.contains("/mono.m3u8")) {
                    for (tok in listOf("/index.m3u8", "/mono.m3u8")) {
                        if (baseU.contains(tok)) {
                            return baseU.replace(tok, "/index-$stTs-$durSec.m3u8")
                        }
                    }
                }
                val sep = if (baseU.contains("?")) "&" else "?"
                "$baseU${sep}utc=$stTs&lutc=$nowSec"
            }

            ProviderType.STALKER -> {
                val cands = ArrayList<String>()
                if (prog.cmd.isNotBlank()) cands.add(prog.cmd)
                if (prog.epgId.isNotBlank()) cands.add("auto /media/${prog.epgId}.mpg")

                for (cTry in cands) {
                    val params = mapOf(
                        "cmd" to cTry,
                        "forced_storage" to "undefined",
                        "disable_ad" to "0",
                        "download" to "false"
                    )
                    val js = runCatching { stalkerCall(acc, "tv_archive", "create_link", params, highPriority = true) }.getOrNull()
                    val rawCreated = (js as? JSONObject)?.optString("cmd").orEmpty()
                    val u = rewriteLocalhostUrl(acc.url, extractDirectHttpUrl(rawCreated))
                    if (u.isNotBlank() && !u.contains("stream=.")) {
                        return u
                    }
                }

                // ارتداد Flussonic / UTC إن كان البورتال يبثّ الأرشيف على مجرى القناة المباشرة
                if (stTs > 0L) {
                    val liveU = runCatching { stalkerResolveUrl(acc, ch, forceCreateLink = true) }.getOrDefault("")
                    if (liveU.isNotBlank()) {
                        for (tok in listOf("/index.m3u8", "/mono.m3u8")) {
                            if (liveU.contains(tok)) {
                                return liveU.replace(tok, "/index-$stTs-$durSec.m3u8")
                            }
                        }
                        val sep = if (liveU.contains("?")) "&" else "?"
                        return "$liveU${sep}utc=$stTs&lutc=$nowSec"
                    }
                }
                ""
            }
        }
    }

    // ==================== بطاقة السينما الغنيّة (Media Info) ====================

    fun fetchMediaDetails(acc: AccountProfile, item: StreamItem): MediaDetails {
        var out = MediaDetails(
            plot = item.plot,
            rating = item.rating,
            year = item.year,
            genres = item.genres,
            duration = item.duration,
            poster = item.logo
        )
        if (item.id.isBlank() || acc.provider == ProviderType.M3U) return out

        return when (acc.provider) {
            ProviderType.XTREAM -> {
                val inf = runCatching {
                    val root = if (item.kind == ItemKind.SERIES || item.kind == ItemKind.SEASON) {
                        getXtreamSeriesInfoJson(acc, item.id)
                    } else {
                        JSONObject(xtreamApiCall(acc, "get_vod_info", mapOf("vod_id" to item.id)))
                    }
                    root.optJSONObject("info")
                }.getOrNull() ?: return out

                val rel = inf.optString("releasedate").ifBlank { inf.optString("releaseDate") }.ifBlank { inf.optString("year") }.trim()
                val img = inf.optString("movie_image").ifBlank { inf.optString("cover_big") }.ifBlank { inf.optString("cover") }.trim()
                out.copy(
                    plot = inf.optString("plot").ifBlank { inf.optString("description") }.ifBlank { out.plot }.trim(),
                    rating = inf.optString("rating").ifBlank { out.rating }.trim(),
                    year = if (rel.length >= 4 && rel.take(4).all { it.isDigit() }) rel.take(4) else rel.ifBlank { out.year },
                    genres = inf.optString("genre").ifBlank { out.genres }.trim(),
                    duration = inf.optString("duration").ifBlank { inf.optString("episode_run_time") }.ifBlank { out.duration }.trim(),
                    director = inf.optString("director").trim(),
                    actors = inf.optString("cast").ifBlank { inf.optString("actors") }.trim(),
                    country = inf.optString("country").trim(),
                    poster = img.ifBlank { out.poster }
                )
            }

            ProviderType.STALKER -> {
                val type = if (item.kind == ItemKind.SERIES || item.kind == ItemKind.SEASON) "series" else "vod"
                runCatching {
                    val cid = item.categoryId.ifBlank { "*" }
                    val js = stalkerCall(
                        acc,
                        type,
                        "get_ordered_list",
                        mapOf("category" to cid, "search" to item.name.take(36), "p" to "1")
                    )
                    val arr = (js as? JSONObject)?.optJSONArray("data") ?: return@runCatching
                    var hit: JSONObject? = null
                    for (i in 0 until arr.length()) {
                        val o = arr.optJSONObject(i) ?: continue
                        if (o.optString("id") == item.id) {
                            hit = o
                            break
                        }
                    }
                    if (hit == null && arr.length() > 0) hit = arr.optJSONObject(0)
                    hit?.let { h ->
                        val tm = h.optString("time").trim()
                        val durFmt = if (tm.isNotEmpty() && tm.all { it.isDigit() }) "$tm د" else tm
                        val img = resolveLogoUrl(acc.url, h.optString("screenshot_uri").ifBlank { h.optString("pic") })
                        out = out.copy(
                            plot = h.optString("description").ifBlank { h.optString("plot") }.ifBlank { out.plot }.trim(),
                            rating = h.optString("rating_imdb").ifBlank { h.optString("rating_kinopoisk") }.ifBlank { out.rating }.trim(),
                            year = h.optString("year").ifBlank { out.year }.take(10),
                            genres = h.optString("genres_str").ifBlank { out.genres }.trim(),
                            duration = durFmt.ifBlank { out.duration },
                            director = h.optString("director").trim(),
                            actors = h.optString("actors").trim(),
                            country = h.optString("country").trim(),
                            poster = img.ifBlank { out.poster }
                        )
                    }
                }
                out
            }

            else -> out
        }
    }

    // ==================== 1. STALKER MAC ENGINE ====================

    private fun sessionKey(acc: AccountProfile): String = acc.networkCacheKey()

    private fun safeMacForHeader(rawMac: String): String {
        val sb = StringBuilder()
        for (ch in rawMac.trim()) {
            if ((ch in 'A'..'Z') || (ch in 'a'..'z') || (ch in '0'..'9') || ch == ':' || ch == '-' || ch == '_' || ch == '.') {
                sb.append(ch)
            } else {
                sb.append(URLEncoder.encode(ch.toString(), "UTF-8"))
            }
        }
        return sb.toString()
    }

    private fun stalkerHeaders(acc: AccountProfile, sess: StalkerSession, includeAuth: Boolean = true): Map<String, String> {
        val safeMac = safeMacForHeader(acc.mac)
        val cookies = ArrayList<String>()
        cookies.add("mac=$safeMac")
        cookies.add("stb_lang=ar")
        cookies.add("timezone=Africa/Algiers")
        if (includeAuth && sess.token.isNotBlank()) {
            cookies.add("token=${sess.token}")
        }
        sess.extraCookies.forEach { (k, v) -> cookies.add("$k=$v") }

        val map = LinkedHashMap<String, String>()
        map["User-Agent"] = MAG_UA
        map["Accept"] = "application/json, text/javascript, */*"
        map["X-User-Agent"] = "model=MAG250;mac=$safeMac;stb_type=MAG250"
        if (sess.referer.isNotBlank()) {
            map["Referer"] = sess.referer
        }
        map["Cookie"] = cookies.joinToString("; ")
        if (includeAuth && sess.token.isNotBlank()) {
            map["Authorization"] = "Bearer ${sess.token}"
        }
        return map
    }

    private fun captureStalkerCookies(resp: Response, sess: StalkerSession) {
        runCatching {
            for (sc in resp.headers("Set-Cookie")) {
                val pair = sc.substringBefore(";").trim()
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    val k = pair.substring(0, eq).trim()
                    val v = pair.substring(eq + 1).trim()
                    if (k.isNotEmpty() && k.lowercase(Locale.US) !in setOf("mac", "token", "stb_lang", "timezone")) {
                        sess.extraCookies[k] = v
                    }
                }
            }
        }
    }

    private fun stalkerCandidateEndpoints(rawUrl: String): List<Pair<String, String>> {
        val base = rawUrl.trim().trimEnd('/')
        val u = runCatching { URI(base) }.getOrNull() ?: return emptyList()
        val hostBase = "${u.scheme ?: "http"}://${u.authority}"
        val path = (u.path ?: "").trimEnd('/')
        val out = LinkedHashSet<Pair<String, String>>()

        if (path.endsWith(".php", ignoreCase = true)) {
            val ref = base.substringBeforeLast("/") + "/c/"
            out.add(base to ref)
        } else {
            val pref = if (path.endsWith("/c", ignoreCase = true)) path.dropLast(2).trimEnd('/') else path
            if (pref.isNotEmpty()) {
                out.add("$hostBase$pref/server/load.php" to "$hostBase$pref/c/")
                out.add("$hostBase$pref/portal.php" to "$hostBase$pref/c/")
            }
        }
        out.add("$hostBase/server/load.php" to "$hostBase/c/")
        out.add("$hostBase/portal.php" to "$hostBase/c/")
        out.add("$hostBase/stalker_portal/server/load.php" to "$hostBase/stalker_portal/c/")
        out.add("$hostBase/c/portal.php" to "$hostBase/c/")
        out.add("$hostBase/c/server/load.php" to "$hostBase/c/")
        return out.toList()
    }

    private val sessionFlight=SessionFlight()
    private fun ensureStalkerSession(
        acc:AccountProfile,highPriority:Boolean=false,forceFresh:Boolean=false,fastProbe:Boolean=false,
        expectedSession:StalkerSession?=null
    ):StalkerSession {
        if(!PlaybackRequestScope.hasCurrent()) return PlaybackRequestScope().run {
            ensureStalkerSession(acc,highPriority,forceFresh,fastProbe,expectedSession)
        }
        PlaybackRequestScope.checkCurrent()
        val key=sessionKey(acc)
        val observed=expectedSession ?: stalkerSessions[key]
        val initial=stalkerSessions[key]
        if(!forceFresh && initial!=null && initial.token.isNotBlank())return initial
        return sessionFlight.run(key,highPriority) {
            val current=stalkerSessions[key]
            if(current!=null && current.token.isNotBlank() && (!forceFresh || current!==observed)) current
            else discoverStalkerSession(acc,highPriority,true,fastProbe)
        }
    }

    private fun discoverStalkerSession(
        acc: AccountProfile,
        highPriority: Boolean = false,
        forceFresh: Boolean = false,
        fastProbe: Boolean = false
    ): StalkerSession {
        val key = sessionKey(acc)
        val existing = stalkerSessions[key]
        if (!forceFresh && existing != null && existing.endpoint.isNotBlank() && existing.token.isNotBlank()) {
            return existing
        }
        val client = when {
            fastProbe -> probeHttp
            highPriority -> priorityApiHttp
            else -> browseHttp
        }
        val baseCandidates = stalkerCandidateEndpoints(acc.url)
        val remembered = endpointHints?.load(acc,baseCandidates)
        val preferred = if(existing!=null && existing.endpoint.isNotBlank()) existing.endpoint to existing.referer else remembered
        val candidates = if(preferred!=null) listOf(preferred)+baseCandidates.filter { it.first!=preferred.first } else baseCandidates
        var lastErr = "تعذّر الوصول إلى البورتال"

        for ((ep, ref) in candidates) {
            PlaybackRequestScope.checkCurrent()
            val fromRemembered = remembered == (ep to ref)
            var succeeded=false
            try {
                val sess = StalkerSession(
                    endpoint = ep,
                    referer = ref,
                    forceCreateLink = existing?.forceCreateLink ?: false
                )
                val hsUrl = ep.toHttpUrlOrNull()?.newBuilder()
                    ?.addQueryParameter("type", "stb")
                    ?.addQueryParameter("action", "handshake")
                    ?.addQueryParameter("token", "")
                    ?.addQueryParameter("JsHttpRequest", "1-xml")
                    ?.build() ?: continue

                val reqBuilder = Request.Builder().url(hsUrl)
                stalkerHeaders(acc, sess, includeAuth = false).forEach { (k, v) -> reqBuilder.header(k, v) }
                val body = PlaybackRequestScope.execute(client, reqBuilder.build()) { resp ->
                    captureStalkerCookies(resp, sess)
                    if (!resp.isSuccessful) {
                        lastErr = "HTTP ${resp.code}"
                        null
                    } else {
                        resp.body?.string()
                    }
                } ?: continue

                val jsObj = parseStalkerJs(body) ?: continue
                val tok = (jsObj as? JSONObject)?.optString("token").orEmpty()
                if (tok.isNotBlank()) {
                    sess.token = tok
                    stalkerWarmupProfile(acc, sess, client)
                    PlaybackRequestScope.checkCurrent()
                    stalkerSessions[key] = sess
                    succeeded=true
                    endpointHints?.save(acc,ep to ref,baseCandidates)
                    return sess
                }
            } catch (e: java.net.UnknownHostException) {
                lastErr = "النطاق غير موجود"
                if(!fromRemembered) break
            } catch (e: java.net.ConnectException) {
                lastErr = "السيرفر يرفض الاتصال"
                if(!fromRemembered) break
            } catch (e: java.net.SocketTimeoutException) {
                lastErr = "انتهت مهلة الاتصال"
                if (fastProbe && !fromRemembered) break
            } catch (e: Exception) {
                lastErr = e.message ?: "خطأ شبكة"
            } finally {
                if(fromRemembered && !succeeded) endpointHints?.forgetIfMatches(acc,ep to ref)
            }
        }
        throw IllegalStateException("فشل مصافحة Stalker: $lastErr")
    }

    private fun stalkerWarmupProfile(acc: AccountProfile, sess: StalkerSession, client: OkHttpClient) {
        runCatching {
            val sn = md5Hex(acc.mac).uppercase(Locale.US).take(13)
            val devId = sha256Hex(acc.mac).uppercase(Locale.US)
            val u = sess.endpoint.toHttpUrlOrNull()?.newBuilder()
                ?.addQueryParameter("type", "stb")
                ?.addQueryParameter("action", "get_profile")
                ?.addQueryParameter("hd", "1")
                ?.addQueryParameter("stb_type", "MAG250")
                ?.addQueryParameter("sn", sn)
                ?.addQueryParameter("device_id", devId)
                ?.addQueryParameter("device_id2", devId)
                ?.addQueryParameter("JsHttpRequest", "1-xml")
                ?.build() ?: return
            val rb = Request.Builder().url(u)
            stalkerHeaders(acc, sess, includeAuth = true).forEach { (k, v) -> rb.header(k, v) }
            val txt = PlaybackRequestScope.execute(client, rb.build()) { resp ->
                captureStalkerCookies(resp, sess)
                if(!resp.isSuccessful)return@execute null
                resp.body?.string().orEmpty()
            }
            sess.profileJson = parseStalkerJs(txt.orEmpty()) as? JSONObject
        }
    }

    private fun stalkerCall(
        acc: AccountProfile,
        type: String,
        action: String,
        params: Map<String, String> = emptyMap(),
        highPriority: Boolean = false,
        clientOverride: OkHttpClient? = null
    ): Any? {
        PlaybackRequestScope.checkCurrent()
        val client = clientOverride ?: if (highPriority) priorityApiHttp else browseHttp
        var sess = ensureStalkerSession(acc, highPriority = highPriority, forceFresh = false)

        for (attempt in 0..1) {
            PlaybackRequestScope.checkCurrent()
            val hb = sess.endpoint.toHttpUrlOrNull()?.newBuilder()
                ?.addQueryParameter("type", type)
                ?.addQueryParameter("action", action)
            params.forEach { (k, v) -> hb?.addQueryParameter(k, v) }
            hb?.addQueryParameter("JsHttpRequest", "1-xml")
            val url = hb?.build() ?: throw IllegalStateException("عنوان البورتال غير صالح")

            val rb = Request.Builder().url(url)
            stalkerHeaders(acc, sess, includeAuth = true).forEach { (k, v) -> rb.header(k, v) }

            val txt = PlaybackRequestScope.execute(client, rb.build()) { resp ->
                captureStalkerCookies(resp, sess)
                if (resp.code == 401 || resp.code == 403) {
                    null
                } else if (!resp.isSuccessful) {
                    throw IllegalStateException("HTTP ${resp.code}")
                } else {
                    resp.body?.string().orEmpty()
                }
            }
            if (txt == null || txt.take(96).contains("Authorization failed", ignoreCase = true)) {
                if (attempt == 0) {
                    sess = ensureStalkerSession(acc, highPriority = highPriority, forceFresh = true, expectedSession = sess)
                    continue
                }
                throw IllegalStateException("انتهت صلاحية الجلسة أو الماك غير مقبول")
            }
            return parseStalkerJs(txt)
        }
        return null
    }

    private fun parseStalkerJs(raw: String): Any? {
        val trimmed = raw.trim().removePrefix("\uFEFF")
        if (trimmed.isEmpty()) return null
        return runCatching {
            val root = JSONObject(trimmed)
            if (root.has("js")) root.get("js") else root
        }.getOrElse {
            runCatching { JSONArray(trimmed) }.getOrNull()
        }
    }

    private fun stalkerCategories(acc: AccountProfile, tab: ContentTab): List<CategoryItem> {
        val type = when (tab) {
            ContentTab.LIVE -> "itv"
            ContentTab.VOD -> "vod"
            ContentTab.SERIES -> "series"
            else -> return emptyList()
        }
        val tries: List<Pair<String, Map<String, String>>> = if (type == "itv") {
            listOf(
                "get_genres" to emptyMap(),
                "get_categories" to mapOf("category_id" to "*"),
                "get_genres" to mapOf("category_id" to "*"),
                "get_categories" to emptyMap()
            )
        } else {
            listOf(
                "get_categories" to mapOf("category_id" to "*"),
                "get_genres" to emptyMap(),
                "get_genres" to mapOf("category_id" to "*"),
                "get_categories" to emptyMap()
            )
        }

        val out = ArrayList<CategoryItem>()
        for ((action, extra) in tries) {
            val js = runCatching { stalkerCall(acc, type, action, extra) }.getOrNull() ?: continue
            val arr = when (js) {
                is JSONArray -> js
                is JSONObject -> js.optJSONArray("data")
                else -> null
            } ?: continue

            for (i in 0 until arr.length()) {
                val elem = arr.opt(i)
                when (elem) {
                    is JSONObject -> {
                        val id = elem.optString("id").ifBlank { elem.optString("category_id") }.trim()
                        val title = elem.optString("title")
                            .ifBlank { elem.optString("name") }
                            .ifBlank { elem.optString("alias") }
                            .trim()
                        if (id.isEmpty() || title.isEmpty()) continue
                        if (id == "*" || title.equals("All", ignoreCase = true)) continue
                        val rawPid = elem.optString("parent_id").trim()
                        val pid = if (rawPid in setOf("", "0", "*", "null", "None")) "" else rawPid
                        out.add(CategoryItem(id = id, title = title, parentId = pid))
                    }
                    is JSONArray -> {
                        val id = elem.optString(0).trim()
                        val title = elem.optString(1, id).trim()
                        if (id.isNotEmpty() && id != "*" && !title.equals("All", ignoreCase = true)) {
                            out.add(CategoryItem(id = id, title = title))
                        }
                    }
                }
            }
            if (out.isNotEmpty()) break
        }

        if (tab == ContentTab.LIVE) {
            PlaybackRequestScope.checkCurrent()
            stalkerKnownCatIds[sessionKey(acc)] = out.map { it.id }.toSet()
            out.add(0, CategoryItem(id = "*", title = "🌐 جميع القنوات"))
        }
        return out
    }

    private fun filterStalkerRamChannels(sKey: String, all: List<StreamItem>, categoryId: String): List<StreamItem> {
        val known = stalkerKnownCatIds[sKey].orEmpty()
        return if (categoryId == "__ungrouped__") {
            all.filter { it.categoryId.isEmpty() || (known.isNotEmpty() && it.categoryId !in known) }
        } else {
            all.filter { it.categoryId == categoryId }
        }
    }

    private fun stalkerCategoryItems(
        acc: AccountProfile,
        tab: ContentTab,
        categoryId: String,
        onPartialItems: ((List<StreamItem>) -> Unit)? = null
    ): List<StreamItem> {
        val sKey = sessionKey(acc)
        if (tab == ContentTab.LIVE) {
            // 1) حالة قسم محدّد (99% من الاستخدام): الجلب المباشر الفوري دون تحميل قائمة الـ 30MB كاملةً!
            if (categoryId.isNotBlank() && categoryId != "*") {
                val fbKey = "$sKey|itv|$categoryId"
                stalkerGroupFallbackCache[fbKey]?.let { if (it.isNotEmpty()) return it }

                // إذا كانت القائمة الكاملة محمّلة مسبقاً في الذاكرة فنُصفّيها خلال 1ms
                stalkerAllLiveCache[sKey]?.let { ramAll ->
                    if (ramAll.isNotEmpty()) {
                        val ramHit = filterStalkerRamChannels(sKey, ramAll, categoryId)
                        if (ramHit.isNotEmpty()) {
                            PlaybackRequestScope.checkCurrent()
                            stalkerGroupFallbackCache[fbKey] = ramHit
                            return ramHit
                        }
                    }
                }

                // جلب صفحات القسم مباشرةً مع إظهار أول 14 قناة فوراً خلال ~0.25 ثانية!
                val fetched = stalkerFetchOrderedPages(
                    acc = acc,
                    type = "itv",
                    categoryId = categoryId,
                    kind = ItemKind.LIVE,
                    onPartialItems = onPartialItems
                )
                if (fetched.isNotEmpty()) {
                    PlaybackRequestScope.checkCurrent()
                    stalkerGroupFallbackCache[fbKey] = fetched
                    return fetched
                }

                // احتياط ذكي فقط للسيرفرات النادرة التي لا تدعم فلترة get_ordered_list بالأقسام
                if (!stalkerBulkFailedKeys.containsKey(sKey)) {
                    val bulk = stalkerLoadAllChannelsStreaming(acc, null)
                    if (bulk.isNotEmpty()) {
                        PlaybackRequestScope.checkCurrent()
                        stalkerAllLiveCache[sKey] = bulk
                        val hit = filterStalkerRamChannels(sKey, bulk, categoryId)
                        if (hit.isNotEmpty()) {
                            PlaybackRequestScope.checkCurrent()
                            stalkerGroupFallbackCache[fbKey] = hit
                        }
                        return hit
                    } else {
                        PlaybackRequestScope.checkCurrent()
                        stalkerBulkFailedKeys[sKey] = true
                    }
                }
                return emptyList()
            }

            // 2) حالة «جميع القنوات (*)»: تحليل متدفّق عبر JsonReader دون استهلاك الذاكرة أو التجميد
            stalkerAllLiveCache[sKey]?.let { if (it.isNotEmpty()) return it }
            if (!stalkerBulkFailedKeys.containsKey(sKey)) {
                val bulk = stalkerLoadAllChannelsStreaming(acc, onPartialItems)
                if (bulk.isNotEmpty()) {
                    PlaybackRequestScope.checkCurrent()
                    stalkerAllLiveCache[sKey] = bulk
                    return bulk
                }
                PlaybackRequestScope.checkCurrent()
                stalkerBulkFailedKeys[sKey] = true
            }
            return stalkerFetchOrderedPages(
                acc = acc,
                type = "itv",
                categoryId = "*",
                kind = ItemKind.LIVE,
                onPartialItems = onPartialItems
            )
        }

        val kind = if (tab == ContentTab.VOD) ItemKind.VOD else ItemKind.SERIES
        val type = if (tab == ContentTab.VOD) "vod" else "series"
        val vodCacheKey = "$sKey|$type|$categoryId"
        stalkerGroupFallbackCache[vodCacheKey]?.let { if (it.isNotEmpty()) return it }

        val items = stalkerFetchOrderedPages(
            acc = acc,
            type = type,
            categoryId = categoryId,
            kind = kind,
            onPartialItems = onPartialItems
        )
        if (items.isNotEmpty()) {
            PlaybackRequestScope.checkCurrent()
            stalkerGroupFallbackCache[vodCacheKey] = items
        }
        return items
    }

    private fun parseStalkerArchiveFlags(o: JSONObject): Pair<Boolean, Int> {
        val rawFlag = o.optString("enable_tv_archive").ifBlank { o.optString("tv_archive") }.trim()
        val hasAr = rawFlag in setOf("1", "true", "True")
        if (!hasAr) return false to 0
        val durRaw = o.optString("tv_archive_duration").trim().toIntOrNull() ?: 3
        val days = if (durRaw > 30) ((durRaw + 23) / 24).coerceAtLeast(1) else durRaw.coerceAtLeast(1)
        return true to days
    }

    private fun jsonNextScalar(r: JsonReader): String {
        return when (r.peek()) {
            JsonToken.STRING -> r.nextString()
            JsonToken.NUMBER -> r.nextString()
            JsonToken.BOOLEAN -> if (r.nextBoolean()) "1" else "0"
            JsonToken.NULL -> {
                r.nextNull()
                ""
            }
            else -> {
                r.skipValue()
                ""
            }
        }
    }

    private fun readStalkerChannelObject(r: JsonReader, baseUrl: String): StreamItem? {
        var id = ""
        var chId = ""
        var name = ""
        var title = ""
        var cmd = ""
        var tvGenre = ""
        var genreId = ""
        var catId = ""
        var logo = ""
        var screenUri = ""
        var arFlag = ""
        var arDur = ""

        r.beginObject()
        while (r.hasNext()) {
            PlaybackRequestScope.checkCurrent()
            when (r.nextName()) {
                "id" -> id = jsonNextScalar(r).trim()
                "ch_id" -> chId = jsonNextScalar(r).trim()
                "name" -> name = jsonNextScalar(r).trim()
                "title" -> title = jsonNextScalar(r).trim()
                "cmd" -> cmd = jsonNextScalar(r).trim()
                "tv_genre_id" -> tvGenre = jsonNextScalar(r).trim()
                "genre_id" -> genreId = jsonNextScalar(r).trim()
                "category_id" -> catId = jsonNextScalar(r).trim()
                "logo" -> logo = jsonNextScalar(r)
                "screenshot_uri" -> screenUri = jsonNextScalar(r)
                "enable_tv_archive", "tv_archive" -> if (arFlag.isEmpty()) arFlag = jsonNextScalar(r).trim() else r.skipValue()
                "tv_archive_duration" -> arDur = jsonNextScalar(r).trim()
                else -> r.skipValue()
            }
        }
        r.endObject()

        val finalId = id.ifEmpty { chId }
        val finalName = name.ifEmpty { title }
        if (finalId.isEmpty() || (finalName.isEmpty() && cmd.isEmpty())) return null
        val genre = tvGenre.ifEmpty { genreId }.ifEmpty { catId }
        val hasAr = arFlag in setOf("1", "true", "True")
        val durNum = arDur.toIntOrNull() ?: 3
        val arDays = if (!hasAr) 0 else if (durNum > 30) ((durNum + 23) / 24).coerceAtLeast(1) else durNum.coerceAtLeast(1)

        return StreamItem(
            id = finalId,
            name = finalName.ifEmpty { "Channel $finalId" },
            cmd = cmd,
            categoryId = genre,
            logo = resolveLogoUrl(baseUrl, logo.ifEmpty { screenUri }),
            kind = ItemKind.LIVE,
            subtitle = if (hasAr) "↺ أرشيف ${arDays}ي" else "",
            tvArchive = hasAr,
            tvArchiveDays = arDays
        )
    }

    private fun parseStalkerChannelArrayStream(
        r: JsonReader,
        baseUrl: String,
        out: ArrayList<StreamItem>,
        onPartialItems: ((List<StreamItem>) -> Unit)?
    ) {
        var lastEmitTime = System.currentTimeMillis()
        r.beginArray()
        while (r.hasNext()) {
            PlaybackRequestScope.checkCurrent()
            if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException("Browse interrupted")
            if (r.peek() != JsonToken.BEGIN_OBJECT) {
                r.skipValue()
                continue
            }
            val item = readStalkerChannelObject(r, baseUrl) ?: continue
            out.add(item)
            if (onPartialItems != null) {
                val now = System.currentTimeMillis()
                if (out.size == 150 || (out.size % 900 == 0 && now - lastEmitTime >= 350L)) {
                    lastEmitTime = now
                    onPartialItems(ArrayList(out))
                }
            }
        }
        r.endArray()
    }

    private fun stalkerLoadAllChannelsStreaming(
        acc: AccountProfile,
        onPartialItems: ((List<StreamItem>) -> Unit)? = null
    ): List<StreamItem> {
        return try {
            var sess = ensureStalkerSession(acc, highPriority = false, forceFresh = false)
            for (attempt in 0..1) {
                val url = sess.endpoint.toHttpUrlOrNull()?.newBuilder()
                    ?.addQueryParameter("type", "itv")
                    ?.addQueryParameter("action", "get_all_channels")
                    ?.addQueryParameter("JsHttpRequest", "1-xml")
                    ?.build() ?: return emptyList()

                val rb = Request.Builder().url(url)
                stalkerHeaders(acc, sess, includeAuth = true).forEach { (k, v) -> rb.header(k, v) }

                val out = ArrayList<StreamItem>(512)
                var needReauth = false

                PlaybackRequestScope.withResponse(browseHttp,rb.build()) { resp ->
                    captureStalkerCookies(resp, sess)
                    if (resp.code == 401 || resp.code == 403) {
                        needReauth = true
                    } else if (resp.isSuccessful) {
                        val charStream = resp.body?.charStream() ?: return emptyList()
                        val jr = JsonReader(charStream.buffered(16 * 1024)).apply { isLenient = true }
                        when (jr.peek()) {
                            JsonToken.BEGIN_ARRAY -> parseStalkerChannelArrayStream(jr, acc.url, out, onPartialItems)
                            JsonToken.BEGIN_OBJECT -> {
                                jr.beginObject()
                                while (jr.hasNext()) {
                                    PlaybackRequestScope.checkCurrent()
                                    when (jr.nextName()) {
                                        "js" -> when (jr.peek()) {
                                            JsonToken.BEGIN_ARRAY -> parseStalkerChannelArrayStream(jr, acc.url, out, onPartialItems)
                                            JsonToken.BEGIN_OBJECT -> {
                                                jr.beginObject()
                                                while (jr.hasNext()) {
                                                    PlaybackRequestScope.checkCurrent()
                                                    when (jr.nextName()) {
                                                        "data" -> if (jr.peek() == JsonToken.BEGIN_ARRAY) {
                                                            parseStalkerChannelArrayStream(jr, acc.url, out, onPartialItems)
                                                        } else jr.skipValue()
                                                        else -> jr.skipValue()
                                                    }
                                                }
                                                jr.endObject()
                                            }
                                            else -> jr.skipValue()
                                        }
                                        "data" -> if (jr.peek() == JsonToken.BEGIN_ARRAY) {
                                            parseStalkerChannelArrayStream(jr, acc.url, out, onPartialItems)
                                        } else jr.skipValue()
                                        else -> jr.skipValue()
                                    }
                                }
                                jr.endObject()
                            }
                            else -> Unit
                        }
                    }
                }
                if (needReauth && attempt == 0) {
                    sess = ensureStalkerSession(acc, highPriority = false, forceFresh = true, expectedSession = sess)
                    continue
                }
                return out
            }
            emptyList()
        } catch (e: Exception) {
            PlaybackRequestScope.checkCurrent()
            if(e is java.util.concurrent.CancellationException)throw e
            // Malformed/truncated data must not turn a displayed partial list into success.
            throw IncompleteListException()
        }
    }

    private fun stalkerFetchOrderedPages(
        acc:AccountProfile,type:String,categoryId:String,kind:ItemKind,
        onPartialItems:((List<StreamItem>)->Unit)?=null
    ):List<StreamItem> {
        if(SelectedCategoryLoad.active()) {
            return SelectedCategoryLoad.ordered("$type|$categoryId|${kind.name}") {page->
                stalkerOrderedPage(acc,type,categoryId,kind,page)
            }
        }
        // Same provider-driven end policy for callers outside the selected parallel loader.
        val checkpoint=OrderedPageCheckpoint<StreamItem> {it.id+"|"+it.cmd}
        var lastEmitMs=0L
        while(true) {
            PlaybackRequestScope.checkCurrent()
            val snap=checkpoint.snapshot()
            val now=System.currentTimeMillis()
            if(onPartialItems!=null && (snap.items.isNotEmpty() || snap.complete || snap.error!=null) && (lastEmitMs==0L || snap.complete || snap.error!=null || now-lastEmitMs>=380L)) {
                lastEmitMs=now;onPartialItems(snap.items)
            }
            if(snap.error!=null)throw IncompleteListException()
            if(snap.complete)return snap.items
            val page=checkpoint.missing(1).single()
            checkpoint.put(page,stalkerOrderedPage(acc,type,categoryId,kind,page))
        }
    }

    private fun stalkerOrderedPage(acc:AccountProfile,type:String,categoryId:String,kind:ItemKind,page:Int):OrderedPageCheckpoint.Page<StreamItem> {
        PlaybackRequestScope.checkCurrent()
        val cid=categoryId.ifBlank {"*"}
        val js=stalkerCall(acc,type,"get_ordered_list",mapOf("category" to cid,"genre" to cid,"p" to page.toString(),"per_page" to "14"))
            ?: throw IncompleteListException()
        val data=when(js) {
            is JSONObject->js.optJSONArray("data") ?: throw IncompleteListException()
            is JSONArray->js
            else->throw IncompleteListException()
        }
        val total=(js as? JSONObject)?.optInt("total_items",0) ?: 0
        val width=(js as? JSONObject)?.optInt("max_page_items",0) ?: 0
        val totalPages=(js as? JSONObject)?.optInt("total_pages",0) ?: 0
        val out=ArrayList<StreamItem>()
        val seenIds=HashSet<String>()
            for (i in 0 until data.length()) {
                val o = data.optJSONObject(i) ?: continue
                val id = o.optString("id").ifBlank { o.optString("ch_id") }.trim()
                val name = o.optString("name")
                    .ifBlank { o.optString("o_name") }
                    .ifBlank { o.optString("title") }
                    .trim()
                if (id.isEmpty() || name.isEmpty()) continue
                val dedupKey = "$id|${o.optString("cmd")}"
                if (!seenIds.add(dedupKey)) continue

                val logoRaw = o.optString("logo")
                    .ifBlank { o.optString("screenshot_uri") }
                    .ifBlank { o.optString("pic") }
                val year = o.optString("year").trim()
                val rating = o.optString("rating_imdb").ifBlank { o.optString("rating_kinopoisk") }.trim()
                val (hasAr, arDays) = if (kind == ItemKind.LIVE) parseStalkerArchiveFlags(o) else (false to 0)
                val sub = if (kind == ItemKind.LIVE) {
                    if (hasAr) "↺ أرشيف ${arDays}ي" else ""
                } else {
                    listOfNotNull(
                        year.takeIf { it.isNotBlank() && it != "0" },
                        rating.takeIf { it.isNotBlank() && it != "0" }?.let { "⭐ $it" }
                    ).joinToString(" · ")
                }
                out.add(
                    StreamItem(
                        id = id,
                        name = name,
                        cmd = o.optString("cmd").trim(),
                        categoryId = cid,
                        logo = resolveLogoUrl(acc.url, logoRaw),
                        kind = kind,
                        subtitle = sub,
                        seriesId = if (kind == ItemKind.SERIES) id else "",
                        tvArchive = hasAr,
                        tvArchiveDays = arDays,
                        plot = o.optString("description").ifBlank { o.optString("plot") }.trim(),
                        year = year,
                        rating = rating,
                        genres = o.optString("genres_str").trim(),
                        duration = o.optString("time").trim()
                    )
                )
            }

        PlaybackRequestScope.checkCurrent()
        return OrderedPageCheckpoint.Page(out,data.length(),total.coerceAtLeast(0),width.coerceAtLeast(0),totalPages.coerceAtLeast(0))
    }

    private fun stalkerOlistAllPages(acc: AccountProfile, type: String, baseParams: Map<String, String>): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        val seen = HashSet<String>()
        var page = 1
        var total = 0
        while (page <= 40) {
            val p = LinkedHashMap<String, String>(baseParams)
            p["p"] = page.toString()
            PlaybackRequestScope.checkCurrent()
            val js=stalkerCall(acc,type,"get_ordered_list",p) ?: throw IncompleteListException()
            val arr = when (js) {
                is JSONObject -> {
                    if (page == 1) total = js.optInt("total_items", 0)
                    js.optJSONArray("data") ?: throw IncompleteListException()
                }
                is JSONArray -> js
                else -> throw IncompleteListException()
            }
            if(arr.length()==0) {if(total>out.size)throw IncompleteListException();break}
            var added = 0
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val sig = "${o.optString("id")}|${o.optString("cmd")}"
                if (seen.add(sig)) {
                    out.add(o)
                    added++
                }
            }
            if(added==0) {if(total>out.size)throw IncompleteListException();break}
            if(total>0 && out.size>=total)break
            if(total<=0 && arr.length()<14)break
            if(page==40)throw IncompleteListException()
            page++
        }
        PlaybackRequestScope.checkCurrent()
        return out
    }

    private fun stalkerSeasons(acc: AccountProfile, seriesItem: StreamItem): List<StreamItem> {
        val params = mapOf(
            "movie_id" to seriesItem.id,
            "season_id" to "0",
            "episode_id" to "0"
        )
        val rows = stalkerOlistAllPages(acc, "series", params)
            .ifEmpty { stalkerOlistAllPages(acc, "vod", params) }
        return rows.mapIndexed { idx, o ->
            val sid = o.optString("id").trim().ifBlank { "s_${idx + 1}" }
            val name = o.optString("name").ifBlank { "الموسم ${idx + 1}" }
            val epArr = o.optJSONArray("series")
            val epIds = if (epArr != null && epArr.length() > 0) {
                (0 until epArr.length()).map { epArr.optString(it) }.joinToString(",")
            } else ""
            StreamItem(
                id = sid,
                name = name,
                cmd = o.optString("cmd").ifBlank { epIds },
                logo = seriesItem.logo,
                kind = ItemKind.SEASON,
                subtitle = if (epArr != null && epArr.length() > 0) "${epArr.length()} حلقة" else "",
                seriesId = seriesItem.id,
                seasonId = sid,
                containerExt = epIds
            )
        }
    }

    private fun stalkerEpisodes(acc: AccountProfile, seriesItem: StreamItem, seasonItem: StreamItem): List<StreamItem> {
        if (seasonItem.containerExt.isNotBlank()) {
            val nums = seasonItem.containerExt.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val baseCmd = if (seasonItem.cmd.contains(" ") || seasonItem.cmd.startsWith("/") || seasonItem.cmd.length > 20) {
                seasonItem.cmd
            } else {
                "/media/file_${seasonItem.id}.mpg"
            }
            return nums.map { epNum ->
                StreamItem(
                    id = "${seriesItem.id}_${seasonItem.id}_$epNum",
                    name = "${seriesItem.name} - الحلقة $epNum",
                    cmd = baseCmd,
                    logo = seriesItem.logo,
                    kind = ItemKind.EPISODE,
                    seriesId = seriesItem.id,
                    seasonId = seasonItem.id,
                    containerExt = epNum
                )
            }
        }
        val params = mapOf(
            "movie_id" to seriesItem.id,
            "season_id" to seasonItem.id,
            "episode_id" to "0"
        )
        val rows = stalkerOlistAllPages(acc, "series", params)
            .ifEmpty { stalkerOlistAllPages(acc, "vod", params) }
        return rows.mapIndexed { idx, o ->
            val eid = o.optString("id").ifBlank { "${idx + 1}" }
            val epNum = o.optString("series_number").ifBlank { "${idx + 1}" }
            val name = o.optString("name").ifBlank { "الحلقة $epNum" }
            StreamItem(
                id = "${seriesItem.id}_${seasonItem.id}_$eid",
                name = name,
                cmd = o.optString("cmd").ifBlank { "/media/file_$eid.mpg" },
                logo = seriesItem.logo,
                kind = ItemKind.EPISODE,
                seriesId = seriesItem.id,
                seasonId = seasonItem.id
            )
        }
    }

    private fun isUsableStalkerCreatedCmd(rawCreated: String): Boolean {
        val t = rawCreated.trim()
        if (t.isEmpty()) return false
        val low = t.lowercase(Locale.US)
        if (low == "false" || low == "null" ||
            low.contains("nothing_to_play") ||
            low.contains("playback_limit") ||
            low.contains("limit_reached") ||
            low.contains("access_denied")
        ) {
            return false
        }
        return extractDirectHttpUrl(t).isNotBlank()
    }

    private fun stalkerResolveUrl(
        acc: AccountProfile,
        item: StreamItem,
        forceCreateLink: Boolean,
        forceSessionRefresh: Boolean = false
    ): String {
        val sess = ensureStalkerSession(acc, highPriority = true, forceFresh = forceSessionRefresh)
        val direct = extractDirectHttpUrl(item.cmd)
        val isLocalhost = runCatching {URI(direct).host?.lowercase(Locale.US) in setOf("localhost","127.0.0.1","::1","[::1]")}.getOrDefault(false)

        if (item.kind == ItemKind.LIVE && !forceCreateLink && !sess.forceCreateLink && direct.isNotBlank() && !isLocalhost) {
            return direct
        }

        val portalType = if (item.kind == ItemKind.LIVE) "itv" else "vod"
        val params = LinkedHashMap<String, String>()
        params["cmd"] = item.cmd
        if (item.kind == ItemKind.EPISODE && item.containerExt.isNotBlank()) {
            params["series"] = item.containerExt
        }
        params["forced_storage"] = "false"
        params["disable_ad"] = "false"
        params["download"] = "false"
        params["force_ch_link_check"] = "false"

        var js = runCatching {
            stalkerCall(acc, portalType, "create_link", params, highPriority = true)
        }.getOrNull()
        var rawCreated = (js as? JSONObject)?.optString("cmd").orEmpty()

        // إذا انتهت صلاحية الجلسة بصمت أثناء المشاهدة (أرجع البورتال cmd فارغاً أو nothing_to_play بدون كود 401)،
        // نُجري مصافحة جديدة فورية (handshake + get_profile) ونعيد طلب create_link للحصول على play_token حيّ 100%!
        if (!isUsableStalkerCreatedCmd(rawCreated) && !forceSessionRefresh) {
            val refreshed = runCatching {
                ensureStalkerSession(acc, highPriority = true, forceFresh = true)
            }.getOrNull()
            if (refreshed != null) {
                js = runCatching {
                    stalkerCall(acc, portalType, "create_link", params, highPriority = true)
                }.getOrNull()
                rawCreated = (js as? JSONObject)?.optString("cmd").orEmpty()
            }
        }

        val createdUrl = if (isUsableStalkerCreatedCmd(rawCreated)) extractDirectHttpUrl(rawCreated) else ""
        if (createdUrl.isNotBlank() && forceCreateLink) {
            stalkerSessions[sessionKey(acc)]?.forceCreateLink = true
        }
        PlaybackRequestScope.checkCurrent()
        val resolved = createdUrl.ifBlank { direct }
        return rewriteLocalhostUrl(acc.url, resolved)
    }

    private fun stalkerAccountStatus(acc: AccountProfile, forceFresh: Boolean): AccountStatusInfo {
        val sess = ensureStalkerSession(acc, highPriority = false, forceFresh = forceFresh, fastProbe = forceFresh)
        val mainJs = runCatching { stalkerCall(acc, "account_info", "get_main_info", clientOverride=if(forceFresh)probeHttp else browseHttp) }.getOrNull() as? JSONObject
        val infoObj = mainJs?.optJSONObject("info")
        val profJs = sess.profileJson

        fun pickField(vararg keys: String): String {
            for (k in keys) {
                val v1 = infoObj?.optString(k).orEmpty().trim()
                if (v1.isNotEmpty() && v1 !in setOf("0", "null", "None", "0000-00-00")) return v1
                val v2 = mainJs?.optString(k).orEmpty().trim()
                if (v2.isNotEmpty() && v2 !in setOf("0", "null", "None", "0000-00-00")) return v2
                val v3 = profJs?.optString(k).orEmpty().trim()
                if (v3.isNotEmpty() && v3 !in setOf("0", "null", "None", "0000-00-00")) return v3
            }
            return ""
        }

        val exp = pickField("end_date", "expire_billing_date", "tariff_expired_date", "expire_date", "exp_date")
        val date = Regex("""^\d{4}-\d{2}-\d{2}$""").matchEntire(exp)?.value.orEmpty()
        val maxC = pickField("max_connections", "playback_limit", "storages").ifBlank { "غير متوفر" }
        fun state(o:JSONObject?):AccountAccess {
            if(o==null)return AccountAccess.UNKNOWN
            if(o.optString("blocked").trim().lowercase(Locale.US) in setOf("1","true","yes"))return AccountAccess.REJECTED
            return when(o.optString("status").trim().lowercase(Locale.US)) {
                "expired","disabled","banned","blocked","inactive"->AccountAccess.REJECTED
                "1","active"->AccountAccess.ACCEPTED
                else->if(o.optLong("id",0)>0 || o.optLong("account_id",0)>0)AccountAccess.ACCEPTED else AccountAccess.UNKNOWN
            }
        }
        val states=listOf(state(infoObj),state(mainJs),if(forceFresh)state(profJs) else AccountAccess.UNKNOWN)
        val access=when {
            AccountAccess.REJECTED in states->AccountAccess.REJECTED
            AccountAccess.ACCEPTED in states->AccountAccess.ACCEPTED
            else->AccountAccess.UNKNOWN
        }
        return AccountStatusInfo(expiry=exp.ifBlank {"غير متوفر"},maxConnections=maxC,
            status=when(access) {
                AccountAccess.ACCEPTED->"نشط ✔"
                AccountAccess.REJECTED->"مرفوض من المزوّد"
                else->"معلومات الحساب غير مكتملة — غير مؤكد"
            },access=access,verifiedExpiry=if(access!=AccountAccess.UNKNOWN)date else "")
    }

    // ==================== 2. XTREAM CODES ENGINE ====================

    private fun xtreamApiCall(acc: AccountProfile, action: String, extra: Map<String, String> = emptyMap(), http:OkHttpClient=browseHttp): String {
        val base = acc.url.trim().trimEnd('/')
        val hb = "$base/player_api.php".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("username", acc.username)
            ?.addQueryParameter("password", acc.password)
        if (action.isNotBlank()) {
            hb?.addQueryParameter("action", action)
        }
        extra.forEach { (k, v) -> hb?.addQueryParameter(k, v) }
        val url = hb?.build() ?: throw IllegalStateException("رابط Xtream غير صالح")
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", XTREAM_UA)
            .header("Accept", "application/json, */*")
            .build()
        PlaybackRequestScope.withResponse(http,req) { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            return resp.body?.string().orEmpty()
        }
    }

    private fun getXtreamSeriesInfoJson(acc: AccountProfile, seriesId: String): JSONObject {
        val ck = "${sessionKey(acc)}|ser|$seriesId"
        xtreamSeriesInfoCache[ck]?.let { return it }
        val obj = JSONObject(xtreamApiCall(acc, "get_series_info", mapOf("series_id" to seriesId)))
        if (xtreamSeriesInfoCache.size > 50) xtreamSeriesInfoCache.clear()
        PlaybackRequestScope.checkCurrent()
        xtreamSeriesInfoCache[ck] = obj
        return obj
    }

    private fun xtreamCategories(acc: AccountProfile, tab: ContentTab): List<CategoryItem> {
        val action = when (tab) {
            ContentTab.LIVE -> "get_live_categories"
            ContentTab.VOD -> "get_vod_categories"
            ContentTab.SERIES -> "get_series_categories"
            else -> return emptyList()
        }
        val arr = JSONArray(xtreamApiCall(acc, action))
        val out = ArrayList<CategoryItem>(arr.length() + 1)
        if (tab == ContentTab.LIVE) {
            out.add(CategoryItem(id = "*", title = "🌐 جميع القنوات"))
        }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val cid = o.optString("category_id").ifBlank { o.optString("id") }.trim()
            val name = o.optString("category_name")
                .ifBlank { o.optString("title") }
                .ifBlank { o.optString("name") }
                .trim()
            if (cid.isNotEmpty() && name.isNotEmpty()) {
                out.add(CategoryItem(id = cid, title = name))
            }
        }
        return out
    }

    private fun xtreamStreamLiveItems(
        acc: AccountProfile,
        categoryId: String,
        onPartialItems: ((List<StreamItem>) -> Unit)? = null
    ): List<StreamItem> {
        val base = acc.url.trim().trimEnd('/')
        val uEnc = URLEncoder.encode(acc.username, "UTF-8")
        val pEnc = URLEncoder.encode(acc.password, "UTF-8")
        val isAll = categoryId == "*" || categoryId.isBlank()
        val hb = "$base/player_api.php".toHttpUrlOrNull()?.newBuilder()
            ?.addQueryParameter("username", acc.username)
            ?.addQueryParameter("password", acc.password)
            ?.addQueryParameter("action", "get_live_streams")
        if (!isAll) {
            hb?.addQueryParameter("category_id", categoryId)
        }
        val url = hb?.build() ?: return emptyList()
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", XTREAM_UA)
            .header("Accept", "application/json, */*")
            .build()

        val out = ArrayList<StreamItem>(if (isAll) 512 else 96)
        var lastEmitMs = System.currentTimeMillis()

        PlaybackRequestScope.withResponse(browseHttp,req) { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            val cs = resp.body?.charStream() ?: return emptyList()
            val jr = JsonReader(cs.buffered(16 * 1024)).apply { isLenient = true }
            if (jr.peek() != JsonToken.BEGIN_ARRAY) return emptyList()
            jr.beginArray()
            while (jr.hasNext()) {
                PlaybackRequestScope.checkCurrent()
                if (Thread.currentThread().isInterrupted) throw java.util.concurrent.CancellationException("Browse interrupted")
                if (jr.peek() != JsonToken.BEGIN_OBJECT) {
                    jr.skipValue()
                    continue
                }
                var sid = ""
                var altId = ""
                var name = ""
                var cid = ""
                var icon = ""
                var arFlag = ""
                var arDur = ""
                jr.beginObject()
                while (jr.hasNext()) {
                    PlaybackRequestScope.checkCurrent()
                    when (jr.nextName()) {
                        "stream_id" -> sid = jsonNextScalar(jr).trim()
                        "id" -> altId = jsonNextScalar(jr).trim()
                        "name" -> name = jsonNextScalar(jr).trim()
                        "category_id" -> cid = jsonNextScalar(jr).trim()
                        "stream_icon" -> icon = jsonNextScalar(jr)
                        "tv_archive" -> arFlag = jsonNextScalar(jr).trim()
                        "tv_archive_duration" -> arDur = jsonNextScalar(jr).trim()
                        else -> jr.skipValue()
                    }
                }
                jr.endObject()

                val finalId = sid.ifEmpty { altId }
                if (finalId.isEmpty()) continue
                val hasAr = arFlag in setOf("1", "true", "True")
                val arDays = arDur.toIntOrNull()?.takeIf { it > 0 } ?: if (hasAr) 3 else 0
                out.add(
                    StreamItem(
                        id = finalId,
                        name = name.ifEmpty { "Channel $finalId" },
                        cmd = "$base/live/$uEnc/$pEnc/$finalId.ts",
                        categoryId = cid.ifEmpty { if (isAll) "" else categoryId },
                        logo = icon,
                        kind = ItemKind.LIVE,
                        subtitle = if (hasAr) "↺ أرشيف ${arDays}ي" else "",
                        tvArchive = hasAr,
                        tvArchiveDays = arDays
                    )
                )
                if (onPartialItems != null) {
                    val now = System.currentTimeMillis()
                    if (out.size == 150 || (out.size % 800 == 0 && now - lastEmitMs >= 350L)) {
                        lastEmitMs = now
                        onPartialItems(ArrayList(out))
                    }
                }
            }
            jr.endArray()
        }
        return out
    }

    private fun xtreamCategoryItems(
        acc: AccountProfile,
        tab: ContentTab,
        categoryId: String,
        onPartialItems: ((List<StreamItem>) -> Unit)? = null
    ): List<StreamItem> {
        val base = acc.url.trim().trimEnd('/')
        val uEnc = URLEncoder.encode(acc.username, "UTF-8")
        val pEnc = URLEncoder.encode(acc.password, "UTF-8")
        val sKey = sessionKey(acc)

        return when (tab) {
            ContentTab.LIVE -> {
                // 1) قسم محدّد: الجلب المباشر الفوري للقسم فقط (حجم صغير جداً ~15KB بدل 25MB!)
                if (categoryId.isNotBlank() && categoryId != "*") {
                    val cKey = "$sKey|live|$categoryId"
                    xtreamStreamCache[cKey]?.let { if (it.isNotEmpty()) return it }

                    xtreamAllLiveCache[sKey]?.let { ramAll ->
                        if (ramAll.isNotEmpty()) {
                            val ramHit = ramAll.filter { it.categoryId == categoryId }
                            if (ramHit.isNotEmpty()) {
                                PlaybackRequestScope.checkCurrent()
                                xtreamStreamCache[cKey] = ramHit
                                return ramHit
                            }
                        }
                    }

                    val out = xtreamStreamLiveItems(acc, categoryId, onPartialItems)
                    if (out.isNotEmpty()) {
                        PlaybackRequestScope.checkCurrent()
                        xtreamStreamCache[cKey] = out
                    }
                    return out
                }

                // 2) جميع القنوات (*): تحليل متدفّق عبر JsonReader مع إظهار أول دفعة فوراً
                xtreamAllLiveCache[sKey]?.let { if (it.isNotEmpty()) return it }
                val all = xtreamStreamLiveItems(acc, "*", onPartialItems)
                if (all.isNotEmpty()) {
                    PlaybackRequestScope.checkCurrent()
                    xtreamAllLiveCache[sKey] = all
                }
                all
            }

            ContentTab.VOD -> {
                val cKey = "$sKey|vod|$categoryId"
                xtreamStreamCache[cKey]?.let { if (it.isNotEmpty()) return it }
                val extra = if (categoryId == "*" || categoryId.isBlank()) emptyMap() else mapOf("category_id" to categoryId)
                val arr = JSONArray(xtreamApiCall(acc, "get_vod_streams", extra))
                val out = ArrayList<StreamItem>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val sid = o.optString("stream_id").trim()
                    val name = o.optString("name").ifBlank { o.optString("title") }.trim()
                    if (sid.isEmpty() || name.isEmpty()) continue
                    val ext = o.optString("container_extension", "mp4").trim().trimStart('.').ifBlank { "mp4" }
                    val rating = o.optString("rating").trim()
                    val year = o.optString("year").take(4)
                    val streamUrl = "$base/movie/$uEnc/$pEnc/$sid.$ext"
                    val sub = listOfNotNull(
                        year.takeIf { it.isNotBlank() && it != "0" },
                        rating.takeIf { it.isNotBlank() && it != "0" }?.let { "⭐ $it" }
                    ).joinToString(" · ")
                    out.add(
                        StreamItem(
                            id = sid,
                            name = name,
                            cmd = streamUrl,
                            categoryId = o.optString("category_id").ifBlank { categoryId },
                            logo = o.optString("stream_icon"),
                            kind = ItemKind.VOD,
                            subtitle = sub,
                            containerExt = ext,
                            year = year,
                            rating = rating
                        )
                    )
                }
                PlaybackRequestScope.checkCurrent()
                if (out.isNotEmpty()) xtreamStreamCache[cKey] = out
                out
            }

            ContentTab.SERIES -> {
                val cKey = "$sKey|series|$categoryId"
                xtreamStreamCache[cKey]?.let { if (it.isNotEmpty()) return it }
                val extra = if (categoryId == "*" || categoryId.isBlank()) emptyMap() else mapOf("category_id" to categoryId)
                val arr = JSONArray(xtreamApiCall(acc, "get_series", extra))
                val out = ArrayList<StreamItem>(arr.length())
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val sid = o.optString("series_id").trim()
                    val name = o.optString("name").ifBlank { o.optString("title") }.trim()
                    if (sid.isEmpty() || name.isEmpty()) continue
                    val rating = o.optString("rating").trim()
                    val year = o.optString("releaseDate").ifBlank { o.optString("year") }.take(4)
                    val sub = listOfNotNull(
                        year.takeIf { it.isNotBlank() && it != "0" },
                        rating.takeIf { it.isNotBlank() && it != "0" }?.let { "⭐ $it" }
                    ).joinToString(" · ")
                    out.add(
                        StreamItem(
                            id = sid,
                            name = name,
                            categoryId = o.optString("category_id").ifBlank { categoryId },
                            logo = o.optString("cover"),
                            kind = ItemKind.SERIES,
                            subtitle = sub,
                            seriesId = sid,
                            plot = o.optString("plot"),
                            year = year,
                            rating = rating,
                            genres = o.optString("genre")
                        )
                    )
                }
                PlaybackRequestScope.checkCurrent()
                if (out.isNotEmpty()) xtreamStreamCache[cKey] = out
                out
            }

            else -> emptyList()
        }
    }

    private fun xtreamSeasons(acc: AccountProfile, seriesItem: StreamItem): List<StreamItem> {
        val root = getXtreamSeriesInfoJson(acc, seriesItem.id)
        val epObj = root.optJSONObject("episodes") ?: return emptyList()
        val keys = ArrayList<String>()
        val iter = epObj.keys()
        while (iter.hasNext()) keys.add(iter.next())
        keys.sortBy { it.toIntOrNull() ?: 999 }
        return keys.map { sKey ->
            val count = epObj.optJSONArray(sKey)?.length() ?: 0
            StreamItem(
                id = "${seriesItem.id}_s_$sKey",
                name = "الموسم $sKey",
                logo = seriesItem.logo,
                kind = ItemKind.SEASON,
                subtitle = "$count حلقة",
                seriesId = seriesItem.id,
                seasonId = sKey
            )
        }
    }

    private fun xtreamEpisodes(acc: AccountProfile, seriesItem: StreamItem, seasonItem: StreamItem): List<StreamItem> {
        val base = acc.url.trim().trimEnd('/')
        val uEnc = URLEncoder.encode(acc.username, "UTF-8")
        val pEnc = URLEncoder.encode(acc.password, "UTF-8")
        val root = getXtreamSeriesInfoJson(acc, seriesItem.id)
        val epArr = root.optJSONObject("episodes")?.optJSONArray(seasonItem.seasonId) ?: return emptyList()
        val out = ArrayList<StreamItem>(epArr.length())
        for (i in 0 until epArr.length()) {
            val o = epArr.optJSONObject(i) ?: continue
            val epId = o.optString("id").trim()
            if (epId.isEmpty()) continue
            val epNum = o.optString("episode_num").ifBlank { "${i + 1}" }
            val ext = o.optString("container_extension", "mp4").trim().trimStart('.').ifBlank { "mp4" }
            val title = o.optString("title").ifBlank { "الحلقة $epNum" }
            val url = "$base/series/$uEnc/$pEnc/$epId.$ext"
            out.add(
                StreamItem(
                    id = epId,
                    name = title,
                    cmd = url,
                    logo = seriesItem.logo,
                    kind = ItemKind.EPISODE,
                    seriesId = seriesItem.id,
                    seasonId = seasonItem.seasonId,
                    containerExt = ext
                )
            )
        }
        return out
    }

    private fun xtreamAccountStatus(acc: AccountProfile,forceProbe:Boolean): AccountStatusInfo {
        val root = JSONObject(xtreamApiCall(acc, "",http=if(forceProbe)probeHttp else browseHttp))
        val ui = root.optJSONObject("user_info") ?: JSONObject()
        if (ui.optString("auth") == "0") {
            throw IllegalStateException("بيانات دخول Xtream غير صحيحة")
        }
        val stRaw = ui.optString("status").trim()
        val maxC = ui.optString("max_connections", "1")
        val actC = ui.optString("active_cons", "0")
        val expSec = ui.optString("exp_date").toLongOrNull()?.takeIf {it in 1L..253402300799L}
        val expFormatted = if (expSec != null && expSec > 0L) {
            val df = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val days = ((expSec * 1000L - System.currentTimeMillis()) / 86_400_000L).toInt()
            "${df.format(Date(expSec * 1000L))} (${days}ي)"
        } else {
            "مفتوح ∞"
        }
        val authenticated=ui.optString("auth")=="1"
        val access=when {
            !authenticated->AccountAccess.UNKNOWN
            stRaw.lowercase(Locale.US) in setOf("expired","disabled","banned","blocked","inactive")->AccountAccess.REJECTED
            stRaw.equals("Active",true)->AccountAccess.ACCEPTED
            else->AccountAccess.UNKNOWN
        }
        val st=when(access) {
            AccountAccess.ACCEPTED->"نشط ✔"
            AccountAccess.REJECTED->stRaw
            else->"معلومات الحساب غير مكتملة — غير مؤكد"
        }
        return AccountStatusInfo(
            expiry = expFormatted,
            maxConnections = "$actC/$maxC",
            status = st,
            access=access,
            verifiedExpiry=if(authenticated && expSec!=null && expSec>0)SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(expSec*1000L)) else ""
        )
    }

    // ==================== 3. M3U / M3U8 ENGINE ====================

    private fun ensureM3u(acc: AccountProfile,forceRefresh:Boolean=false): M3uParsed {
        val key = sessionKey(acc)
        if(!forceRefresh)m3uCache[key]?.let { return it }

        val targetUrl = acc.url.trim()
        val isLocalUri = targetUrl.startsWith("content://", ignoreCase = true) ||
            targetUrl.startsWith("file://", ignoreCase = true)

        val liveMap = LinkedHashMap<String, MutableList<StreamItem>>()
        val vodMap = LinkedHashMap<String, MutableList<StreamItem>>()
        val serCatMap = LinkedHashMap<String, MutableMap<String, StreamItem>>()
        val serEpMap = LinkedHashMap<String, MutableMap<String, MutableList<StreamItem>>>()

        val grpRe = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE)
        val logoRe = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
        val tvgIdRe = Regex("""tvg-id="([^"]*)"""", RegexOption.IGNORE_CASE)
        val headerEpgRe = Regex("""(?:url-tvg|x-tvg-url)="([^"]+)"""", RegexOption.IGNORE_CASE)
        val cuTypeRe = Regex("""catchup="([^"]*)"""", RegexOption.IGNORE_CASE)
        val cuDaysRe = Regex("""catchup-days="(\d+)"""", RegexOption.IGNORE_CASE)
        val cuSrcRe = Regex("""catchup-source="([^"]*)"""", RegexOption.IGNORE_CASE)
        val epRe = Regex("""^(.*?)\s*[Ss](\d{1,2})[Ee](\d{1,3}).*$""")

        var detectedHeaderEpg = ""
        var curTitle = ""
        var curGroup = "عام"
        var curLogo = ""
        var curTvgId = ""
        var curCuTag = ""
        var curCuDays = 0
        var idx = 0

        fun consumeM3uSequence(seq: Sequence<String>) {
            for (rawLine in seq) {
                PlaybackRequestScope.checkCurrent()
                val line = rawLine.trim()
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTM3U", ignoreCase = true)) {
                    if (detectedHeaderEpg.isEmpty()) {
                        val rawUrls = headerEpgRe.find(line)?.groupValues?.getOrNull(1).orEmpty()
                        detectedHeaderEpg = rawUrls.split(",")
                            .map { it.trim() }
                            .firstOrNull { it.startsWith("http://", true) || it.startsWith("https://", true) }
                            .orEmpty()
                    }
                } else if (line.startsWith("#EXTINF", ignoreCase = true)) {
                    curGroup = grpRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty().ifBlank { "عام" }
                    curLogo = logoRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                    curTvgId = tvgIdRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                    val cuMode = cuTypeRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                    val cuSrc = cuSrcRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
                    curCuDays = cuDaysRe.find(line)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                    curCuTag = if (cuMode.isNotEmpty() || cuSrc.isNotEmpty() || curCuDays > 0) {
                        "m3u_cu|${cuMode.ifBlank { "default" }}|${if (curCuDays > 0) curCuDays else 3}|$cuSrc"
                    } else ""
                    curTitle = line.substringAfterLast(",").trim()
                } else if (!line.startsWith("#") && ITV_SCHEMES.any { line.startsWith(it, ignoreCase = true) }) {
                    idx++
                    val name = curTitle.ifBlank { "قناة $idx" }
                    val cleanPath = line.substringBefore("?").lowercase(Locale.US)
                    val epMatch = epRe.matchEntire(name)
                    if (epMatch != null) {
                        val serName = epMatch.groupValues[1].trim().trim('-', '.', '_').ifBlank { name }
                        val sNum = epMatch.groupValues[2].toIntOrNull()?.toString() ?: "1"
                        val serId = "m3u_ser_${md5Hex(serName).take(10)}"
                        val serItem = StreamItem(
                            id = serId,
                            name = serName,
                            categoryId = curGroup,
                            logo = curLogo,
                            kind = ItemKind.SERIES,
                            seriesId = serId
                        )
                        serCatMap.getOrPut(curGroup) { LinkedHashMap() }[serId] = serItem
                        val epKeyHash = md5Hex("${serId}_${sNum}_${line.substringBefore("?").ifBlank { name }}").take(12)
                        serEpMap.getOrPut(serId) { LinkedHashMap() }
                            .getOrPut(sNum) { ArrayList() }
                            .add(
                                StreamItem(
                                    id = "m3u_ep_$epKeyHash",
                                    name = name,
                                    cmd = line,
                                    categoryId = curGroup,
                                    logo = curLogo,
                                    kind = ItemKind.EPISODE,
                                    seriesId = serId,
                                    seasonId = sNum
                                )
                            )
                    } else if (cleanPath.endsWith(".mp4") || cleanPath.endsWith(".mkv") || cleanPath.endsWith(".avi")) {
                        val vodKeyHash = md5Hex(line.substringBefore("?").ifBlank { name }).take(12)
                        vodMap.getOrPut(curGroup) { ArrayList() }.add(
                            StreamItem(
                                id = "m3u_vod_$vodKeyHash",
                                name = name,
                                cmd = line,
                                categoryId = curGroup,
                                logo = curLogo,
                                kind = ItemKind.VOD
                            )
                        )
                    } else {
                        val hasCu = curCuTag.isNotEmpty()
                        val days = if (hasCu) (curCuDays.takeIf { it > 0 } ?: 3) else 0
                        liveMap.getOrPut(curGroup) { ArrayList() }.add(
                            StreamItem(
                                id = "m3u_live_$idx",
                                name = name,
                                cmd = line,
                                categoryId = curGroup,
                                logo = curLogo,
                                kind = ItemKind.LIVE,
                                subtitle = if (hasCu) "↺ أرشيف ${days}ي" else "",
                                tvArchive = hasCu,
                                tvArchiveDays = days,
                                catchupTag = curCuTag,
                                tvgId = curTvgId
                            )
                        )
                    }
                    curTitle = ""
                    curLogo = ""
                    curTvgId = ""
                    curCuTag = ""
                    curCuDays = 0
                }
            }
        }

        if (isLocalUri) {
            val stream = if (targetUrl.startsWith("content://", ignoreCase = true)) {
                val ctx = appContext ?: throw IllegalStateException("تعذّر الوصول لنظام الملفات")
                ctx.contentResolver.openInputStream(Uri.parse(targetUrl))
            } else {
                val path = Uri.parse(targetUrl).path ?: targetUrl.removePrefix("file://")
                java.io.FileInputStream(java.io.File(path))
            } ?: throw IllegalStateException("تعذّر فتح ملف M3U المحلّي")
            stream.bufferedReader(Charsets.UTF_8).useLines { seq ->
                consumeM3uSequence(seq)
            }
        } else {
            val req = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", XTREAM_UA)
                .build()
            PlaybackRequestScope.withResponse(if(forceRefresh)probeHttp else browseHttp,req) { resp ->
                if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
                val reader = resp.body?.charStream()?.buffered(32 * 1024) ?: throw IncompleteListException()
                reader.useLines { seq ->
                    consumeM3uSequence(seq)
                }
            }
        }

        val parsed = M3uParsed(
            liveCats = listOf(CategoryItem("*", "🌐 جميع القنوات", liveMap.values.sumOf { it.size })) +
                liveMap.map { (k, v) -> CategoryItem(k, k, v.size) },
            liveByCat = liveMap,
            vodCats = vodMap.map { (k, v) -> CategoryItem(k, k, v.size) },
            vodByCat = vodMap,
            serCats = serCatMap.map { (k, v) -> CategoryItem(k, k, v.size) },
            serByCat = serCatMap.mapValues { it.value.values.toList() },
            serEpisodes = serEpMap,
            detectedEpgUrl = detectedHeaderEpg
        )
        PlaybackRequestScope.checkCurrent()
        val hasItems=liveMap.values.any {it.isNotEmpty()} || vodMap.values.any {it.isNotEmpty()} || serCatMap.values.any {it.isNotEmpty()}
        // A failed/empty explicit refresh must not replace a good browsing snapshot.
        if(!forceRefresh || hasItems)m3uCache[key] = parsed
        return parsed
    }

    private fun m3uCategories(acc: AccountProfile, tab: ContentTab): List<CategoryItem> {
        val p = ensureM3u(acc)
        return when (tab) {
            ContentTab.LIVE -> p.liveCats
            ContentTab.VOD -> p.vodCats
            ContentTab.SERIES -> p.serCats
            else -> emptyList()
        }
    }

    private fun m3uCategoryItems(acc: AccountProfile, tab: ContentTab, categoryId: String): List<StreamItem> {
        val p = ensureM3u(acc)
        return when (tab) {
            ContentTab.LIVE -> if (categoryId == "*" || categoryId.isBlank()) {
                p.liveByCat.values.flatten()
            } else {
                p.liveByCat[categoryId].orEmpty()
            }
            ContentTab.VOD -> p.vodByCat[categoryId].orEmpty()
            ContentTab.SERIES -> p.serByCat[categoryId].orEmpty()
            else -> emptyList()
        }
    }

    private fun m3uSeasons(acc: AccountProfile, seriesItem: StreamItem): List<StreamItem> {
        val p = ensureM3u(acc)
        val map = p.serEpisodes[seriesItem.id] ?: return emptyList()
        return map.entries.sortedBy { it.key.toIntOrNull() ?: 99 }.map { (sNum, eps) ->
            StreamItem(
                id = "${seriesItem.id}_s_$sNum",
                name = "الموسم $sNum",
                logo = seriesItem.logo,
                kind = ItemKind.SEASON,
                subtitle = "${eps.size} حلقة",
                seriesId = seriesItem.id,
                seasonId = sNum
            )
        }
    }

    private fun m3uEpisodes(acc: AccountProfile, seriesItem: StreamItem, seasonItem: StreamItem): List<StreamItem> {
        val p = ensureM3u(acc)
        return p.serEpisodes[seriesItem.id]?.get(seasonItem.seasonId).orEmpty()
    }

    // ==================== أدوات مساعدة ====================

    fun extractDirectHttpUrl(rawCmd: String): String {
        val raw = rawCmd.trim().replace("&amp;", "&")
        if (raw.isEmpty()) return ""
        if (ITV_SCHEMES.any { raw.startsWith(it, ignoreCase = true) }) {
            return raw.substringBefore(" ")
        }
        val parts = raw.split(Regex("\\s+"), limit = 2)
        if (parts.size == 2 && parts[0].lowercase(Locale.US) in ITV_PREFIXES) {
            val cand = parts[1].trim()
            if (ITV_SCHEMES.any { cand.startsWith(it, ignoreCase = true) }) {
                return cand.substringBefore(" ")
            }
        }
        for (tok in raw.split(Regex("\\s+"))) {
            if (ITV_SCHEMES.any { tok.startsWith(it, ignoreCase = true) }) {
                return tok
            }
        }
        return ""
    }

    private fun rewriteLocalhostUrl(portalUrl: String, url: String): String =
        PortalLocalhost.rewrite(portalUrl,url)

    private fun decodeBase64IfNeeded(raw: String): String {
        val s = raw.trim()
        // النصوص العادية التي تحوي مسافات أو لا تطابق مضاعفات Base64 القياسية تبقى كما هي دون تشويه!
        if (s.length < 8 || s.length % 4 != 0) return s
        if (!s.all { it in 'A'..'Z' || it in 'a'..'z' || it in '0'..'9' || it == '+' || it == '/' || it == '=' }) {
            return s
        }
        // إذا كانت مجرّد كلمة إنجليزية عادية قصيرة بلا رموز Base64 (= أو + أو /) ولا أرقام مختلطة فنحذر من فكّها خطأً
        val hasB64Signal = '=' in s || '+' in s || '/' in s || s.length >= 16
        if (!hasB64Signal) return s

        return runCatching {
            val bytes = Base64.decode(s, Base64.NO_WRAP)
            val decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
            val str = decoder.decode(java.nio.ByteBuffer.wrap(bytes)).toString()
            if (str.isNotBlank() && '\uFFFD' !in str && str.all { it.code >= 32 || it == '\n' || it == '\r' || it == '\t' }) {
                str.trim()
            } else s
        }.getOrDefault(s)
    }

    private fun parseUnixTs(rawTs: String, fallbackDt: String): Long {
        rawTs.trim().toLongOrNull()?.let { v ->
            if (v > 10_000_000_000L) return v / 1000L
            if (v > 100_000L) return v
        }
        val dt = fallbackDt.trim()
        if (dt.length >= 16 && dt[4] == '-') {
            return runCatching {
                val fmt = SimpleDateFormat(if (dt.length >= 19) "yyyy-MM-dd HH:mm:ss" else "yyyy-MM-dd HH:mm", Locale.US)
                (fmt.parse(dt.take(19))?.time ?: 0L) / 1000L
            }.getOrDefault(0L)
        }
        return 0L
    }

    private fun resolveLogoUrl(portalUrl: String, logo: String): String {
        val l = logo.trim()
        if (l.isEmpty()) return ""
        if (l.startsWith("http://") || l.startsWith("https://")) return l
        val u = runCatching { URI(portalUrl.trim()) }.getOrNull() ?: return ""
        val hostBase = "${u.scheme ?: "http"}://${u.authority}"
        return if (l.startsWith("/")) "$hostBase$l" else "$hostBase/$l"
    }

    private fun md5Hex(s: String): String = hashHex("MD5", s)
    private fun sha256Hex(s: String): String = hashHex("SHA-256", s)

    private fun hashHex(algo: String, input: String): String {
        val bytes = MessageDigest.getInstance(algo).digest(input.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }
}
