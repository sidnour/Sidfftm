package com.iptvlite.tv.network

import java.io.FilterInputStream
import java.io.InputStream
import java.io.IOException

/** Limits DECOMPRESSED bytes and lexical spans before XmlPullParser can allocate a huge token. */
internal class GuideInput(input:InputStream,private val check:()->Unit,
    private val maxBytes:Long=96L*1024*1024,private val maxSpan:Int=256*1024):FilterInputStream(input) {
    private var total=0L
    private var span=0
    private var state=0 // text, tag, comment, CDATA
    private var quote=0
    private var tail=0
    private val prefix=StringBuilder(9)
    private fun accept(b:Int) {
        if(++total>maxBytes)throw IOException("XMLTV exceeds size limit")
        if(++span>maxSpan)throw IOException("XMLTV token exceeds limit")
        tail=((tail shl 8) or b) and 0xffffff
        when(state) {
            0->if(b==60) {state=1;span=1;prefix.setLength(0);prefix.append('<')}
            1->{
                if(prefix.length<9)prefix.append(b.toChar())
                when {
                    prefix.length==4 && prefix.toString()=="<!--"->{state=2;span=0}
                    prefix.length==9 && b==91 && prefix.toString()=="<![CDATA["->{state=3;span=0}
                    quote!=0->{if(b==quote)quote=0}
                    b==34 || b==39->quote=b
                    b==62->{state=0;span=0}
                }
            }
            2->if(tail==0x2d2d3e) {state=0;span=0}
            3->if(tail==0x5d5d3e) {state=0;span=0}
        }
    }
    override fun read():Int {check();val b=`in`.read();if(b>=0)accept(b);return b}
    override fun read(b:ByteArray,off:Int,len:Int):Int {
        check()
        val n=`in`.read(b,off,minOf(len,8192))
        for(i in 0 until n)accept(b[off+i].toInt() and 255)
        return n
    }
    override fun skip(n:Long):Long {
        var left=n.coerceAtLeast(0);val buffer=ByteArray(8192)
        while(left>0) {val c=read(buffer,0,minOf(left,buffer.size.toLong()).toInt());if(c<0)break;left-=c}
        return n.coerceAtLeast(0)-left
    }
}
