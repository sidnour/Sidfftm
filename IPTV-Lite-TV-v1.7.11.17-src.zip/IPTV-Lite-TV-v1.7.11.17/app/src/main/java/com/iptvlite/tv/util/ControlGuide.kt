package com.iptvlite.tv.util

/**
 * Content of the «دليل التحكّم» (control guide) window.
 *
 * Scope is strictly input: remote buttons, touch gestures and where recordings are saved.
 * Release notes and feature marketing deliberately do NOT live here; they belong to About.
 * Sections are data so the ordering, wording and non-duplication can be unit-tested.
 */
object ControlGuide {
    data class Section(val title: String, val rows: List<String>)

    val TV_BUTTONS: Section = Section(
        "ريموت التلفاز",
        listOf(
            "الأرقام 0–9: انتقال مباشر إلى رقم القناة",
            "▲ / ▼ أو CH+ / CH−: تقليب القنوات أثناء المشاهدة",
            "OK: درج القنوات في البثّ المباشر · شريط التحكّم في الأفلام",
            "ضغط مطوّل على OK: خيارات العنصر (مفضّلة · دليل · تحميل · قفل)",
            "▶ / ◀ أو ⏩ / ⏪: تقديم أو إرجاع 15 ثانية",
            "MENU / GUIDE: قائمة القنوات الجانبية · دليل البرامج",
            "MUTE: كتم الصوت",
            "BACK: رجوع · وفي الشاشة الرئيسية تأكيد الخروج"
        )
    )

    val TOUCH_GESTURES: Section = Section(
        "إيماءات اللمس",
        listOf(
            "سحب عمودي على يمين الشاشة: مستوى الصوت",
            "سحب عمودي على يسار الشاشة: سطوع الشاشة",
            "لمسة على الفيديو: إظهار أو إخفاء شريط التحكّم",
            "ضغط مطوّل على عنصر: خياراته السريعة"
        )
    )

    val SEARCH_NOTES: Section = Section(
        "ملاحظات",
        listOf(
            "المسافة بين الأقسام تحفظ موضع التركيز عند الرجوع",
            "تثبيت القنوات والأقسام من ضغط OK المطوّل"
        )
    )

    val STORAGE: Section = Section(
        "مجلّدات الحفظ",
        listOf(
            "التسجيلات: Downloads/IPTVLite_Recordings",
            "التنزيلات: Downloads/IPTVLite_Downloads"
        )
    )

    val SECTIONS: List<Section> = listOf(TV_BUTTONS, TOUCH_GESTURES, SEARCH_NOTES, STORAGE)
}
