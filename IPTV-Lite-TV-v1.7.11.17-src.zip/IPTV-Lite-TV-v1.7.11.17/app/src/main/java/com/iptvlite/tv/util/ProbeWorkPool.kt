package com.iptvlite.tv.util

import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.ArrayDeque

/** Work-conserving and host-fair: waiting for one origin never occupies another worker slot. */
internal object ProbeWorkPool {
    const val MAX_WORKERS=10
    /**
     * `supervisorScope` keeps one worker's failure from cancelling its siblings behind the pool's back:
     * results are reported only through [finished] so the drain loop decides what to surface, while the
     * supervisor still makes every worker a child of the caller (external cancellation stops the pool).
     */
    suspend fun <T> run(items:List<T>,limit:Int=MAX_WORKERS,host:(T)->String,block:suspend (T)->Unit)=supervisorScope {
        val pending=LinkedHashMap<String,ArrayDeque<T>>()
        items.forEach {item->pending.getOrPut(host(item)) {ArrayDeque()}.addLast(item)}
        val active=HashSet<String>()
        data class Completion(val host:String,val failure:Exception?)
        val finished=Channel<Completion>(Channel.UNLIMITED)
        try {
            while(pending.isNotEmpty() || active.isNotEmpty()) {
                currentCoroutineContext().ensureActive()
                while(active.size<limit.coerceIn(1,MAX_WORKERS)) {
                    val key=pending.keys.firstOrNull {it !in active} ?: break
                    val queue=pending.remove(key)!!
                    val item=queue.removeFirst()
                    if(queue.isNotEmpty())pending[key]=queue // Rotate the origin to the back.
                    active.add(key)
                    launch {
                        var failure:Exception?=null
                        try {block(item)} catch(e:Exception) {failure=e}
                        finally {finished.trySend(Completion(key,failure))}
                    }
                }
                if(active.isNotEmpty()) {
                    // receive() throws on external cancellation, so a lost worker can never hang the drain.
                    val done=finished.receive()
                    active.remove(done.host)
                    done.failure?.let {failure->throw failure}
                }
            }
        } finally {finished.close()}
    }
}
