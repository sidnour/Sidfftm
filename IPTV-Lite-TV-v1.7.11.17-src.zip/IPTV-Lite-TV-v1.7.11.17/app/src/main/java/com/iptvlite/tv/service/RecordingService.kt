package com.iptvlite.tv.service

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.util.AppUiTracker
import com.iptvlite.tv.util.NotificationHelper
import com.iptvlite.tv.util.StreamRecorder
import java.util.Locale

/**
 * خدمة تسجيل أمامية خفيفة (Foreground Service):
 * تعمل فقط أثناء التسجيل المجدول الفعلي، وفور انتهاء وقت البرنامج تغلق نفسها وتفرغ الاتصالات ليصبح استهلاك الخلفية 0%.
 */
class RecordingService : Service() {

    companion object {
        private const val EXTRA_REC_ID = "extra_rec_id"
        private const val FG_NOTIF_ID = 7740

        fun start(context: Context, recId: String) {
            val appCtx = context.applicationContext
            val i = Intent(appCtx, RecordingService::class.java).apply {
                putExtra(EXTRA_REC_ID, recId)
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appCtx.startForegroundService(i)
                } else {
                    appCtx.startService(i)
                }
            }
        }
    }

    private var activeRecordingId:String?=null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        PortalClient.initAppContext(applicationContext)
        val recId = intent?.getStringExtra(EXTRA_REC_ID).orEmpty()
        val store = AppStore(applicationContext)
        val rec = store.getScheduledRecs().firstOrNull { it.id == recId }

        // A duplicate/overlapping command must never tear down the owner's foreground service.
        val owner=activeRecordingId
        if(owner!=null) {
            if(recId!=owner && rec!=null && rec.state=="pending") {
                store.updateScheduledRecState(rec.id,"error")
                NotificationHelper.notifyEvent(this,
                    (rec.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(2000),
                    "⚠ تعذّر بدء التسجيل المجدول", "يوجد تسجيل مجدول آخر جارٍ؛ لم يتم إيقافه.")
            }
            return START_NOT_STICKY
        }

        val initNotif = NotificationHelper.buildRecordingForegroundNotification(
            this,
            "🔴 تجهيز التسجيل المجدول…",
            rec?.let { "${it.channelName} — ${it.progName}" } ?: "جارٍ الاتصال بالسيرفر"
        )
        if(!startFgCompat(initNotif)) {
            if(rec!=null)store.updateScheduledRecState(rec.id,"error")
            stopSelfSafely()
            return START_NOT_STICKY
        }

        if (rec == null || (rec.state != "pending" && rec.state != "recording")) {
            stopSelfSafely()
            return START_NOT_STICKY
        }

        if (StreamRecorder.isRecording()) {
            store.updateScheduledRecState(rec.id, "error")
            NotificationHelper.notifyEvent(
                this,
                notifId = (rec.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(2000),
                title = "⚠ تعذّر بدء التسجيل المجدول",
                body = "يوجد تسجيل آخر جارٍ حالياً أثناء موعد «${rec.progName}»."
            )
            stopSelfSafely()
            return START_NOT_STICKY
        }

        val nowSec = System.currentTimeMillis() / 1000L
        val endSec = rec.startTs + rec.durationMin * 60L
        val remainingSec = com.iptvlite.tv.util.RecordingWindow.remainingSeconds(endSec,nowSec)
        if(remainingSec==0) {
            store.updateScheduledRecState(rec.id,"missed")
            stopSelfSafely()
            return START_NOT_STICKY
        }

        val acc=store.getAccounts().firstOrNull {it.id==rec.accountId}
        if(acc==null) {
            store.updateScheduledRecState(rec.id,"error")
            NotificationHelper.notifyEvent(this,
                (rec.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(2000),
                "✖ تعذّر التسجيل المجدول", "حساب هذا التسجيل غير موجود؛ أعد جدولة البرنامج من حسابه الصحيح.")
            stopSelfSafely()
            return START_NOT_STICKY
        }
        activeRecordingId=rec.id
        acquireBoundedWakeLock((remainingSec + 120) * 1000L)
        store.updateScheduledRecState(rec.id, "recording")

        val recStreamItem = rec.channel.copy(name = "${rec.channelName}_${rec.progName}")

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        var lastNotifUpdateSec = -5L

        val started = runCatching {StreamRecorder.startRecording(
            context = applicationContext,
            acc = acc,
            item = recStreamItem,
            maxDurationSec = remainingSec,
            onTick = { elSec, bytes ->
                if (activeRecordingId==rec.id && elSec - lastNotifUpdateSec >= 3L) {
                    lastNotifUpdateSec = elSec
                    val m = elSec / 60L
                    val s = elSec % 60L
                    val sub = String.format(
                        Locale.US,
                        "%s  ·  %02d:%02d  ·  %s",
                        rec.channelName,
                        m,
                        s,
                        StreamRecorder.formatSizeMb(bytes)
                    )
                    val updated = NotificationHelper.buildRecordingForegroundNotification(
                        this,
                        "🔴 يُسجّل الآن: ${rec.progName}",
                        sub
                    )
                    runCatching { nm?.notify(FG_NOTIF_ID, updated) }
                }
            },
            onFinished = finished@{ ok, savedPath, bytes, err ->
                if(activeRecordingId!=rec.id)return@finished
                if (ok) {
                    store.incrementRecCount()
                    store.updateScheduledRecState(rec.id, "done", savedPath)
                    NotificationHelper.notifyEvent(
                        this,
                        notifId = (rec.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(2000),
                        title = "✔ حُفظ التسجيل المجدول",
                        body = "حُفظ «${rec.progName}» (${StreamRecorder.formatSizeMb(bytes)}) في:\n$savedPath"
                    )
                } else {
                    store.updateScheduledRecState(rec.id, "error")
                    NotificationHelper.notifyEvent(
                        this,
                        notifId = (rec.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(2000),
                        title = "✖ لم يكتمل التسجيل المجدول",
                        body = "«${rec.progName}»: ${err.ifBlank { "انقطع اتصال السيرفر" }}"
                    )
                }
                stopSelfSafely()
            }
        )}.getOrDefault(false)

        if (!started) {
            store.updateScheduledRecState(rec.id, "error")
            stopSelfSafely()
        }

        return START_NOT_STICKY
    }

    private fun startFgCompat(notif: android.app.Notification):Boolean =
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(FG_NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(FG_NOTIF_ID, notif)
            }
        }.isSuccess

    private fun acquireBoundedWakeLock(timeoutMs: Long) {
        releaseWakeLock()
        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "IPTVLite:ScheduledRec").apply {
                setReferenceCounted(false)
                acquire(timeoutMs)
            }
        }
    }

    private fun releaseWakeLock() {
        runCatching {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        }
        wakeLock = null
    }

    private fun stopSelfSafely() {
        activeRecordingId=null
        releaseWakeLock()
        if (!AppUiTracker.isAnyUiVisible) {
            PortalClient.evictIdleConnections()
        }
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
        stopSelf()
    }

    override fun onDestroy() {
        releaseWakeLock()
        super.onDestroy()
    }
}
