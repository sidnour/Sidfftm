package com.iptvlite.tv.model

enum class ProviderType(val label: String) {
    STALKER("Stalker MAC"),
    XTREAM("Xtream Codes"),
    M3U("M3U / M3U8")
}

enum class ContentTab(val code: String, val titleAr: String) {
    LIVE("itv", "البثّ المباشر"),
    VOD("vod", "الأفلام"),
    SERIES("series", "المسلسلات"),
    FAV("fav", "المفضّلة"),
    RECENT("recent", "الأخير")
}

enum class ItemKind {
    LIVE,
    VOD,
    SERIES,
    SEASON,
    EPISODE,
    CATCHUP
}

enum class SortMode(val labelAr: String, val shortLabel: String) {
    DEFAULT("الترتيب الأصلي للسيرفر", "⇅ أصلي"),
    RECENT_ADDED("المضاف حديثاً 🆕", "⇅ حديث"),
    NAME_ASC("أبجدياً (أ – ي / A – Z)", "⇅ أ–ي"),
    YEAR_DESC("الأحدث إنتاجاً (السنة 📅)", "⇅ الأحدث"),
    RATING_DESC("الأعلى تقييماً (IMDb ⭐)", "⇅ التقييم")
}

enum class AppThemeMode(val code: String, val labelAr: String) {
    DARK("dark", "داكن كلاسيكي (Dark)"),
    NIGHT("night", "ليلي عميق OLED (Night)"),
    LIGHT("light", "فاتح عالي التباين (Light)");

    companion object {
        fun fromCode(c: String): AppThemeMode =
            entries.firstOrNull { it.code.equals(c.trim(), ignoreCase = true) } ?: DARK
    }
}

data class AccountProfile(
    val id: String,
    val name: String,
    val provider: ProviderType,
    val url: String,
    val mac: String = "",
    val username: String = "",
    val password: String = "",
    val epgUrl: String = "",
    val expiry: String = "",
    val maxConnections: String = "",
    val status: String = "",
    val pingMs: Int = 0
) {
    fun displayHost(): String {
        val u = url.trim()
        if (u.startsWith("content://", ignoreCase = true) || u.startsWith("file://", ignoreCase = true)) {
            val tail = u.substringAfterLast('/').substringBefore('?').take(28)
            return if (tail.isNotBlank()) "ملف محلّي ($tail)" else "ملف M3U محلّي"
        }
        return u
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
            .ifBlank { u.take(36) }
    }

    // Legacy preferences namespace: retain it so category locks/pins and last category survive upgrades.
    fun cacheKey(): String = "${provider.name}|${url.trim().trimEnd('/').lowercase()}|${mac.trim().uppercase()}|${username.trim().lowercase()}"

    fun networkCacheKey(): String {
        return "account_v2_" + DataIdentity.digest(id, provider.name, DataIdentity.portalUrl(url),
            mac.trim().uppercase(java.util.Locale.US), username, password)
    }

    /** True when two profile snapshots still refer to the same transport/account credentials. */
    fun hasSameNetworkIdentity(other: AccountProfile?): Boolean =
        other != null && id == other.id && networkCacheKey() == other.networkCacheKey()
}

data class CatPref(
    val pinned: Boolean = false,
    val hidden: Boolean = false,
    val locked: Boolean = false
)

data class CategoryItem(
    val id: String,
    val title: String,
    val count: Int = 0,
    val parentId: String = "",
    val pinned: Boolean = false,
    val hidden: Boolean = false,
    val locked: Boolean = false
)

data class StreamItem(
    val id: String,
    val name: String,
    val cmd: String = "",
    val categoryId: String = "",
    val logo: String = "",
    val kind: ItemKind = ItemKind.LIVE,
    val subtitle: String = "",
    val seriesId: String = "",
    val seasonId: String = "",
    val containerExt: String = "",
    val tvArchive: Boolean = false,
    val tvArchiveDays: Int = 0,
    val catchupTag: String = "",
    val plot: String = "",
    val year: String = "",
    val rating: String = "",
    val genres: String = "",
    val duration: String = "",
    val tvgId: String = "",
    val accountId: String = ""
) {
    fun favKey(): String = DataIdentity.item(accountId, kind, id)
}

data class EpgProgram(
    val epgId: String = "",
    val name: String,
    val descr: String = "",
    val startTs: Long = 0L,
    val stopTs: Long = 0L,
    val startStr: String = "",
    val cmd: String = "",
    val isNow: Boolean = false,
    val hasArchive: Boolean = false
)

data class MediaDetails(
    val plot: String = "",
    val rating: String = "",
    val year: String = "",
    val genres: String = "",
    val duration: String = "",
    val director: String = "",
    val actors: String = "",
    val country: String = "",
    val poster: String = ""
)

data class ProgramReminder(
    val id: String,
    val channelId: String,
    val channelName: String,
    val channelCmd: String,
    val progName: String,
    val startTs: Long,
    val remindAtTs: Long,
    val accountId: String = ""
) {
    val programTitle: String get() = progName
    val channel: StreamItem
        get() = StreamItem(
            id = channelId,
            name = channelName,
            cmd = channelCmd,
            kind = ItemKind.LIVE,
            accountId = accountId
        )
}

data class ResumeEntry(
    val item: StreamItem,
    val posMs: Long,
    val durMs: Long = 0L,
    val accountId: String = "",
    val updatedEpochSec: Long = 0L
)

data class ScheduledRecording(
    val id: String,
    val accountId: String,
    val channelId: String,
    val channelName: String,
    val channelCmd: String,
    val progName: String,
    val startTs: Long,
    val durationMin: Int,
    val state: String = "pending",
    val filePath: String = ""
) {
    val channel: StreamItem
        get() = StreamItem(
            id = channelId,
            name = channelName,
            cmd = channelCmd,
            kind = ItemKind.LIVE,
            accountId = accountId
        )
}

data class AppPrefs(
    val cacheMs: Int = 2500,
    val autoNextEpisode: Boolean = true,
    val autoReconnect: Boolean = true,
    val aspectMode: Int = 0,
    val themeMode: String = "dark",
    val autoPlayLastOnStart: Boolean = false,
    val audioBoostPct: Int = 100,
    val subSizeSp: Int = 22,
    val subColorIndex: Int = 0,
    val subBgTranslucent: Boolean = true,
    val diagnosticsEnabled: Boolean = false
)

enum class AccountAccess { UNKNOWN, ACCEPTED, REJECTED }

data class AccountStatusInfo(
    val expiry: String,
    val maxConnections: String,
    val status: String,
    val pingMs: Int = 0,
    val access: AccountAccess = AccountAccess.UNKNOWN,
    // Exact provider subscription date only; display text is NEVER deletion evidence.
    val verifiedExpiry: String = ""
)

data class ImportSummary(
    val accountsAdded: Int,
    val favoritesAdded: Int,
    val message: String
)

object PlayQueueHolder {
    @Volatile
    var playlist: List<StreamItem> = emptyList()

    @Volatile
    var currentIndex: Int = 0

    @Volatile
    var previousItem: StreamItem? = null

    @Volatile
    var activeAccount: AccountProfile? = null

    // يحتفظ بالقناة الأصلية عند تشغيل برنامج من الأرشيف للعودة للبث المباشر بسهولة
    @Volatile
    var archiveSourceChannel: StreamItem? = null

    fun clear() {
        playlist = emptyList()
        currentIndex = 0
        previousItem = null
        activeAccount = null
        archiveSourceChannel = null
    }
}
