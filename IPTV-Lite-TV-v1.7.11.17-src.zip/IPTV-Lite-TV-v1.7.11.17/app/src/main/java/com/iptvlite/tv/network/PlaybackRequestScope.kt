package com.iptvlite.tv.network

import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.util.concurrent.CancellationException

/** Owns blocking calls. Cancellation is terminal, including subsequent fallback calls. */
class PlaybackRequestScope {
    private val calls=HashSet<Call>()
    private var cancelled=false
    @Synchronized fun checkActive() {
        if(cancelled || Thread.currentThread().isInterrupted) throw CancellationException("Network operation cancelled")
    }
    @Synchronized fun isActive():Boolean = !cancelled
    @Synchronized fun cancel(cancelCall:(Call)->Unit={it.cancel()}) {
        cancelled=true
        calls.forEach(cancelCall);calls.clear()
    }
    @PublishedApi internal fun register(call:Call) { synchronized(this) {checkActive();calls.add(call)} }
    @PublishedApi internal fun remove(call:Call) { synchronized(this) {calls.remove(call)} }
    fun execute(client:OkHttpClient,request:Request,consume:(Response)->String?):String? =
        withResponse(client,request,consume)
    fun <T> run(block:()->T):T {
        val previous=current.get();current.set(this)
        try {checkActive();return block().also {checkActive()}} finally {current.set(previous)}
    }
    companion object {
        private val current=ThreadLocal<PlaybackRequestScope?>()
        @PublishedApi internal fun currentScope():PlaybackRequestScope? = current.get()
        fun hasCurrent():Boolean = current.get()!=null
        fun checkCurrent() {current.get()?.checkActive()}
        inline fun <T> withResponse(client:OkHttpClient,request:Request,consume:(Response)->T):T {
            val owner=currentScope()
            owner?.checkActive()
            val call=client.newCall(request)
            owner?.register(call)
            try {
                return call.execute().use {response->
                    owner?.checkActive()
                    consume(response).also {owner?.checkActive()}
                }
            } finally {owner?.remove(call)}
        }
        fun execute(client:OkHttpClient,request:Request,consume:(Response)->String?):String? =
            withResponse(client,request,consume)
    }
}
