package com.iptvlite.tv.network

/** No media controls here: only a browse admission budget driven by playback observations. */
internal class BrowsePlaybackGate(private val now:()->Long={System.nanoTime()/1_000_000}) {
    private enum class Mode { HIDDEN, BROWSE, PLAYBACK }
    private var mode=Mode.HIDDEN
    private var healthySince:Long?=null
    private var lastPosition:Long?=null
    private var lastObservation=0L
    @Synchronized fun browsing() {mode=Mode.BROWSE;healthySince=null;lastPosition=null}
    @Synchronized fun playback() {mode=Mode.PLAYBACK;healthySince=null;lastPosition=null}
    @Synchronized fun hidden() {mode=Mode.HIDDEN;healthySince=null;lastPosition=null}
    @Synchronized fun observe(position:Long,healthy:Boolean) {
        if(mode!=Mode.PLAYBACK)return
        val t=now();val prior=lastPosition
        if(!healthy || prior==null || position<=prior || t-lastObservation>3000)healthySince=null
        else if(healthySince==null)healthySince=t
        lastPosition=position;lastObservation=t
    }
    @Synchronized fun budget():Int = when(mode) {
        Mode.HIDDEN->0
        Mode.BROWSE->5
        Mode.PLAYBACK->if(healthySince!=null && now()-healthySince!!>=8000 && now()-lastObservation<=2500)1 else 0
    }
    @Synchronized fun isBrowsing()=mode==Mode.BROWSE
}
