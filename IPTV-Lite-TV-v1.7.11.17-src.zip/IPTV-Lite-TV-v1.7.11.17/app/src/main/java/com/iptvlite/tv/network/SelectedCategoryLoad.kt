package com.iptvlite.tv.network

import com.iptvlite.tv.model.*
import java.util.concurrent.*

/** Process-local, single selected category. No Activity, View, callback or persistent credentials retained. */
internal object SelectedCategoryLoad {
    data class Status(val items:List<StreamItem> = emptyList(),val total:Int=0,val complete:Boolean=false,
        val paused:Boolean=false,val failed:Boolean=false,val revision:Long=0,val error:String="")
    private class Selection(val account:AccountProfile,val tab:ContentTab,val category:String) {
        @Volatile var alive=true
        @Volatile var status=Status()
        var checkpoint:OrderedPageCheckpoint<StreamItem>?=null
        var spec=""
        @Volatile var queueBound=false
        val scopes=HashSet<PlaybackRequestScope>()
    }
    private val lock=Any()
    private val gate=BrowsePlaybackGate()
    @Volatile private var selected:Selection?=null
    private val local=ThreadLocal<Selection?>()
    private val coordinator=Executors.newSingleThreadExecutor {r->Thread(r,"selected-category").apply {isDaemon=true}}
    private val workers=Executors.newFixedThreadPool(5) {r->Thread(r,"category-page").apply {isDaemon=true}}
    fun matches(acc:AccountProfile,tab:ContentTab,category:String):Boolean {
        val s=selected ?: return false
        return s.alive && s.account.hasSameNetworkIdentity(acc) && s.tab==tab && s.category==category
    }
    fun start(acc:AccountProfile,tab:ContentTab,category:String) {
        discard()
        val s=Selection(acc,tab,category)
        synchronized(lock) {selected=s;gate.browsing()}
        coordinator.execute {run(s)}
    }
    /** Opt-in only for an unfiltered default-order Live category queue. Never widens favourites/search/parental views. */
    fun bindQueue(acc:AccountProfile,playlist:List<StreamItem>,allowed:Boolean) {
        val s=selected ?: return
        s.queueBound=allowed && s.account.hasSameNetworkIdentity(acc) && s.tab==ContentTab.LIVE && s.category!="*" && playlist.isNotEmpty() && playlist==s.status.items.take(playlist.size)
    }
    fun refreshQueue(current:StreamItem?):Boolean {
        val s=selected ?: return false
        if(!s.alive || !s.queueBound || current==null || !s.account.hasSameNetworkIdentity(PlayQueueHolder.activeAccount))return false
        val old=PlayQueueHolder.playlist;val next=s.status.items
        if(next.size<=old.size)return false
        if(old!=next.take(old.size)) {s.queueBound=false;return false}
        val index=next.indexOfFirst {it.accountId==current.accountId && it.kind==current.kind && it.id==current.id}
        if(index<0)return false
        PlayQueueHolder.playlist=next;PlayQueueHolder.currentIndex=index
        return true
    }
    fun status():Status?=selected?.let {s->s.status.copy(paused=gate.budget()==0 && !s.status.complete && !s.status.failed)}
    fun hasPending()=selected?.let {it.alive && !it.status.complete && !it.status.failed}==true
    fun browsing() {synchronized(lock) {gate.browsing()}}
    fun browserHidden() {if(gate.isBrowsing())suspendHidden()}
    fun playerHidden() {if(!gate.isBrowsing())suspendHidden()}
    fun playbackStarting() {synchronized(lock) {gate.playback()};cancelScopes()}
    fun suspendHidden() {synchronized(lock) {gate.hidden()};cancelScopes()}
    fun observePlayback(position:Long,healthy:Boolean) {
        synchronized(lock) {gate.observe(position,healthy)}
        if(gate.budget()==0)cancelScopes()
    }
    private fun cancelScopes(owner:Selection?=selected,except:PlaybackRequestScope?=null) {
        val scopes=synchronized(lock) {owner?.scopes?.filter {it!==except}.orEmpty()}
        scopes.forEach {it.cancel {c->NetworkCleanup.cancel(c)}}
    }
    fun discard() {
        val old=synchronized(lock) {val s=selected;selected=null;s?.alive=false;s}
        old?.let {s->val scopes=synchronized(lock) {s.scopes.toList()};scopes.forEach {it.cancel {c->NetworkCleanup.cancel(c)}}}
    }
    private fun check(s:Selection) {if(!s.alive || selected!==s)throw CancellationException("Retired category")}
    private fun <T> owned(s:Selection,block:()->T):T {
        val scope=PlaybackRequestScope()
        synchronized(lock) {
            check(s)
            if(gate.budget()==0)throw CancellationException("Browse suspended for playback")
            s.scopes.add(scope)
        }
        try {return BrowseWork.run(scope,block)} catch(e:Exception) {scope.checkActive();throw e} finally {synchronized(lock) {s.scopes.remove(scope)}}
    }
    private fun run(s:Selection) {
        while(s.alive && selected===s) {
            try {
                if(gate.budget()==0) {Thread.sleep(100);continue}
                local.set(s)
                val result=owned(s) {PortalClient.loadCategoryItems(s.account,s.tab,s.category) {items->publish(s,items)}}
                check(s)
                s.status=Status(result,s.status.total,true,revision=s.status.revision+1)
                return
            } catch(_:CancellationException) {
                // Terminal scopes are never reused. Checkpoints contain only successfully consumed pages.
                if(s.alive)Thread.sleep(100)
            } catch(_:Exception) {
                if(s.alive && selected===s)s.status=s.status.copy(failed=true,revision=s.status.revision+1,error=s.checkpoint?.snapshot()?.error ?: "تعذّر جلب إحدى الصفحات؛ أعد فتح الفئة للمحاولة")
                return
            } finally {local.remove()}
        }
    }
    private fun publish(s:Selection,items:List<StreamItem>,total:Int=s.status.total) {
        check(s);s.status=Status(items,total,revision=s.status.revision+1)
    }
    fun active()=local.get()!=null
    fun ordered(spec:String,fetch:(Int)->OrderedPageCheckpoint.Page<StreamItem>):List<StreamItem> {
        val s=local.get() ?: error("No selected-category owner")
        if(s.spec!=spec) {s.spec=spec;s.checkpoint=OrderedPageCheckpoint {it.id+"|"+it.cmd}}
        val checkpoint=s.checkpoint!!
        while(true) {
            check(s);PlaybackRequestScope.checkCurrent()
            val snap=checkpoint.snapshot()
            publish(s,snap.items.map {it.copy(accountId=s.account.id)},snap.total)
            snap.error?.let {throw IllegalStateException(it)}
            if(snap.complete)return snap.items
            val budget=gate.budget()
            if(budget==0)throw CancellationException("Browse suspended")
            val pages=checkpoint.missing(budget)
            val parentScope=PlaybackRequestScope.currentScope()
            val futures=pages.map {page->workers.submit(Callable {
                owned(s) {
                    val value=fetch(page)
                    PlaybackRequestScope.checkCurrent();check(s)
                    checkpoint.put(page,value)
                }
            })}
            try {
                for(f in futures) {
                    if(checkpoint.snapshot().complete)break
                    while(true) {
                        check(s);PlaybackRequestScope.checkCurrent()
                        if(gate.budget()==0)throw CancellationException("Browse suspended")
                        try {f.get(50,TimeUnit.MILLISECONDS);break}catch(_:TimeoutException) {}
                        catch(e:ExecutionException) {throw (e.cause ?: e)}
                    }
                }
            } catch(e:Exception) {
                check(s)
                val available=checkpoint.snapshot()
                publish(s,available.items.map {it.copy(accountId=s.account.id)},available.total)
                throw e
            } finally {
                // f.cancel interrupts the worker; scope-owned socket cancellation also covers blocking I/O.
                if(futures.any {!it.isDone}) {
                    cancelScopes(s,except=parentScope);futures.forEach {it.cancel(true)}
                }
            }
            if(gate.budget()==1)Thread.sleep(500)
        }
    }
}
