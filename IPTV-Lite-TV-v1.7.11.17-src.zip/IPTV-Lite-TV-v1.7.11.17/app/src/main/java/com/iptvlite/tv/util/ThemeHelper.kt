package com.iptvlite.tv.util

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.StateSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import com.iptvlite.tv.model.AppThemeMode

/**
 * محرّك المظاهر اللونية الاحترافي (Neon Studio Skin v1.7.3):
 * - الفضاء الداكن النيون (Deep Space Dark)
 * - ليلي عميق لشاشات OLED (Night)
 * - فاتح عالي التباين والوضوح (Light)
 */
object ThemeHelper {

    private val focusInterpolator = DecelerateInterpolator()

    data class Palette(
        val mode: AppThemeMode,
        val bgMain: Int,
        val bgRail: Int,
        val bgPanel: Int,
        val bgHeader: Int,
        val bgCard: Int,
        val bgSelected: Int,
        val bgFocused: Int,
        val borderSubtle: Int,
        val borderAccent: Int,
        val textPrimary: Int,
        val textSecondary: Int,
        val accent: Int
    )

    @Volatile
    var current: Palette = paletteFor(AppThemeMode.DARK)
        private set

    fun setMode(code: String): Palette {
        val p = paletteFor(AppThemeMode.fromCode(code))
        current = p
        return p
    }

    fun paletteFor(mode: AppThemeMode): Palette = when (mode) {
        AppThemeMode.DARK -> Palette(
            mode = AppThemeMode.DARK,
            bgMain = Color.parseColor("#080A0F"),
            bgRail = Color.parseColor("#0C1017"),
            bgPanel = Color.parseColor("#10141C"),
            bgHeader = Color.parseColor("#121822"),
            bgCard = Color.parseColor("#171E2C"),
            bgSelected = Color.parseColor("#1B3154"),
            bgFocused = Color.parseColor("#1E293B"),
            borderSubtle = Color.parseColor("#293548"),
            borderAccent = Color.parseColor("#60A5FA"),
            textPrimary = Color.parseColor("#F8FAFC"),
            textSecondary = Color.parseColor("#94A3B8"),
            accent = Color.parseColor("#3B82F6")
        )
        AppThemeMode.NIGHT -> Palette(
            mode = AppThemeMode.NIGHT,
            bgMain = Color.parseColor("#020408"),
            bgRail = Color.parseColor("#060911"),
            bgPanel = Color.parseColor("#080C15"),
            bgHeader = Color.parseColor("#0A101B"),
            bgCard = Color.parseColor("#0E1525"),
            bgSelected = Color.parseColor("#162B4D"),
            bgFocused = Color.parseColor("#1E3863"),
            borderSubtle = Color.parseColor("#1B283E"),
            borderAccent = Color.parseColor("#60A5FA"),
            textPrimary = Color.parseColor("#F8FAFC"),
            textSecondary = Color.parseColor("#8E9BB0"),
            accent = Color.parseColor("#60A5FA")
        )
        AppThemeMode.LIGHT -> Palette(
            mode = AppThemeMode.LIGHT,
            bgMain = Color.parseColor("#EDF2F7"),
            bgRail = Color.parseColor("#E2E8F0"),
            bgPanel = Color.parseColor("#FFFFFF"),
            bgHeader = Color.parseColor("#F1F5F9"),
            bgCard = Color.parseColor("#F8FAFC"),
            bgSelected = Color.parseColor("#DBEAFE"),
            bgFocused = Color.parseColor("#BFDBFE"),
            borderSubtle = Color.parseColor("#CBD5E1"),
            borderAccent = Color.parseColor("#2563EB"),
            textPrimary = Color.parseColor("#0F172A"),
            textSecondary = Color.parseColor("#475569"),
            accent = Color.parseColor("#2563EB")
        )
    }

    private fun dpPx(density: Float, dpVal: Float): Int =
        (dpVal * density + 0.5f).toInt().coerceAtLeast(1)

    fun buildItemBackground(
        p: Palette = current,
        radiusPx: Float = 26f,
        density: Float = 2f
    ): StateListDrawable {
        val focusStroke = dpPx(density, 2.2f)
        val selStroke = dpPx(density, 1.5f)
        val idleStroke = dpPx(density, 1f)
        val idleFill = if (p.mode == AppThemeMode.LIGHT) p.bgCard else Color.argb(135, Color.red(p.bgCard), Color.green(p.bgCard), Color.blue(p.bgCard))
        val idleBorder = if (p.mode == AppThemeMode.LIGHT) p.borderSubtle else Color.argb(115, Color.red(p.borderSubtle), Color.green(p.borderSubtle), Color.blue(p.borderSubtle))

        fun shape(fill: Int, strokeColor: Int, strokeW: Int): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setColor(fill)
                if (strokeW > 0) setStroke(strokeW, strokeColor)
            }
        }
        return StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                shape(p.bgFocused, p.borderAccent, focusStroke)
            )
            addState(
                intArrayOf(android.R.attr.state_selected),
                shape(p.bgSelected, p.accent, selStroke)
            )
            addState(
                intArrayOf(android.R.attr.state_pressed),
                shape(p.bgFocused, p.accent, selStroke)
            )
            addState(
                StateSet.WILD_CARD,
                shape(idleFill, idleBorder, idleStroke)
            )
        }
    }

    fun buildPillButtonBackground(
        p: Palette = current,
        density: Float = 2f,
        primary: Boolean = false
    ): StateListDrawable {
        val radiusPx = 20f * density
        val focusStroke = dpPx(density, 2.3f)
        val idleStroke = dpPx(density, 1f)

        fun shape(fill: Int, strokeColor: Int, strokeW: Int): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setColor(fill)
                if (strokeW > 0) setStroke(strokeW, strokeColor)
            }
        }

        return if (primary) {
            StateListDrawable().apply {
                addState(
                    intArrayOf(android.R.attr.state_focused),
                    shape(p.accent, Color.WHITE, focusStroke)
                )
                addState(
                    intArrayOf(android.R.attr.state_pressed),
                    shape(p.borderAccent, Color.WHITE, idleStroke)
                )
                addState(
                    StateSet.WILD_CARD,
                    shape(p.accent, p.borderAccent, idleStroke)
                )
            }
        } else {
            StateListDrawable().apply {
                addState(
                    intArrayOf(android.R.attr.state_focused),
                    shape(p.bgFocused, p.borderAccent, focusStroke)
                )
                addState(
                    intArrayOf(android.R.attr.state_selected),
                    shape(p.bgSelected, p.accent, focusStroke)
                )
                addState(
                    intArrayOf(android.R.attr.state_pressed),
                    shape(p.bgFocused, p.accent, idleStroke)
                )
                addState(
                    StateSet.WILD_CARD,
                    shape(p.bgCard, p.borderSubtle, idleStroke)
                )
            }
        }
    }

    fun buildInputBackground(p: Palette = current, density: Float = 2f): StateListDrawable {
        val radiusPx = 20f * density
        val focusStroke = dpPx(density, 2.2f)
        val idleStroke = dpPx(density, 1f)
        fun shape(fill: Int, strokeColor: Int, strokeW: Int): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setColor(fill)
                setStroke(strokeW, strokeColor)
            }
        }
        return StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused),
                shape(p.bgFocused, p.borderAccent, focusStroke)
            )
            addState(
                StateSet.WILD_CARD,
                shape(p.bgCard, p.borderSubtle, idleStroke)
            )
        }
    }

    fun buildChipBackground(p: Palette = current, radiusPx: Float = 40f, density: Float = 2f): StateListDrawable {
        val focusStroke = dpPx(density, 2.3f)
        val idleStroke = dpPx(density, 1f)
        fun shape(fill: Int, strokeColor: Int, strokeW: Int): GradientDrawable {
            return GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = radiusPx
                setColor(fill)
                if (strokeW > 0) setStroke(strokeW, strokeColor)
            }
        }
        return StateListDrawable().apply {
            addState(
                intArrayOf(android.R.attr.state_focused, android.R.attr.state_selected),
                shape(p.accent, Color.WHITE, focusStroke)
            )
            addState(
                intArrayOf(android.R.attr.state_focused),
                shape(p.bgFocused, p.borderAccent, focusStroke)
            )
            addState(
                intArrayOf(android.R.attr.state_selected),
                shape(p.accent, p.borderAccent, idleStroke)
            )
            addState(
                intArrayOf(android.R.attr.state_pressed),
                shape(p.bgFocused, p.borderAccent, idleStroke)
            )
            addState(
                StateSet.WILD_CARD,
                shape(Color.TRANSPARENT, Color.TRANSPARENT, 0)
            )
        }
    }

    fun buildPosterFrameBackground(p: Palette = current, radiusDp: Float = 14f, density: Float = 2f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * density
            setColor(p.bgCard)
            setStroke(dpPx(density, 1f), p.borderSubtle)
        }
    }

    fun buildDialogSurface(p: Palette = current, radiusPx: Float = 36f): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setColor(p.bgPanel)
            setStroke(2, p.borderSubtle)
        }
    }

    /**
     * حركة تكبير وبروز ناعمة وخفيفة جدّاً على معالج الرسوميّات (GPU) عند الوقوف بالريموت (بأسلوب Netflix / TiviMate).
     */
    fun attachFocusScale(
        view: View,
        focusedScale: Float = 1.032f,
        extraListener: ((View, Boolean) -> Unit)? = null
    ) {
        view.setOnFocusChangeListener { v, hasFocus ->
            val target = if (hasFocus) focusedScale else 1f
            v.animate().cancel()
            v.animate()
                .scaleX(target)
                .scaleY(target)
                .translationZ(if (hasFocus) 6f else 0f)
                .setDuration(110L)
                .setInterpolator(focusInterpolator)
                .start()
            extraListener?.invoke(v, hasFocus)
        }
    }
}
