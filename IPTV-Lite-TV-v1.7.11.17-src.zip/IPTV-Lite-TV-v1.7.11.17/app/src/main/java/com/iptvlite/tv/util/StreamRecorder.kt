package com.iptvlite.tv.util

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.network.PortalClient
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ProtocolException
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.LinkedHashSet
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * محرّك التسجيل الفوري والمجدول (⏺ / ⏰) وتحميل الأفلام والحلقات (📥) بدون إعادة ترميز (Zero-CPU Copy).
 * مزوّد باستكمال تلقائي للتحميل (HTTP Range Auto-Resume) عند انقطاع السيرفر (unexpected end of stream)،
 * وتجديد تلقائي لتصاريح Stalker (create_link)، وفحص البايتات السحرية (Magic Bytes) ومحاذاة حزم MPEG-TS (0x47).
 */
object StreamRecorder {

    private val mainHandler = Handler(Looper.getMainLooper())

    private val transferDispatcher = Dispatcher().apply {
        maxRequests = 4
        maxRequestsPerHost = 2
    }

    // حوض مستقلّ بمُهل مريحة لتحميل الملفات الكبيرة والتسجيل المستمر دون تأثّر باتصالات التصفّح
    private val transferHttp: OkHttpClient by lazy {
        PortalClient.rootHttp.newBuilder()
            .dispatcher(transferDispatcher)
            .connectionPool(ConnectionPool(2, 30, TimeUnit.SECONDS))
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .build()
    }

    // عميل تتبّع التوجيهات يدوياً للتحميل المباشر: يحذف الكوكيز والترويسات الخاصّة بالبورتال عند التحويل لخادم تخزين خارجي (CDN)
    private val transferStepHttp: OkHttpClient by lazy {
        transferHttp.newBuilder()
            .followRedirects(false)
            .followSslRedirects(false)
            .build()
    }

    private const val EXTERNAL_DL_UA =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
    private const val VLC_DL_UA = "VLC/3.0.20 LibVLC/3.0.20"
    private val VALID_VIDEO_EXTS = setOf("mp4", "mkv", "ts", "avi", "m4v", "webm", "flv", "mov", "mpg", "mpeg")

    private const val PRE_TAP_RING_BYTES = 512 * 1024
    private val TAP_POISON_PILL = ByteArray(0)
    private val tapLock = Any()
    @Volatile
    private var tapStandbyEnabled: Boolean = false
    private var tapPreRing: ByteArray? = null
    private var tapPreWritePos: Int = 0
    private var tapPreFilled: Int = 0
    @Volatile
    private var tapActive: Boolean = false
    @Volatile
    private var tapHandedOffToNetwork: Boolean = false
    @Volatile
    private var tapQueue: LinkedBlockingQueue<ByteArray>? = null

    private val recRunning = AtomicBoolean(false)
    @Volatile
    private var recThread: Thread? = null
    @Volatile
    private var activeRecCall: okhttp3.Call? = null
    @Volatile
    var activeRecTitle: String = ""
        private set

    private val dlRunning = AtomicBoolean(false)
    @Volatile
    private var dlThread: Thread? = null
    @Volatile
    private var activeDlCall: okhttp3.Call? = null
    @Volatile
    var activeDlTitle: String = ""
        private set

    fun isRecording(): Boolean = recRunning.get()
    fun isDownloading(): Boolean = dlRunning.get()
    fun isTapRecordingActive(): Boolean = recRunning.get() && tapActive

    /**
     * تفعيل/إيقاف وضع الاستعداد لالتقاط البثّ الحيّ من داخل ExoPlayer نفسه بدون فتح اتصال ثانٍ على السيرفر.
     * عند الإيقاف (في onStop أو عند تشغيل VOD) تُحرّر الذاكرة الدائرية المؤقّتة (512KB) بالكامل إلى صفر.
     */
    fun setLivePlayerTapStandby(enabled: Boolean) {
        synchronized(tapLock) {
            tapStandbyEnabled = enabled
            if (enabled) {
                if (tapPreRing == null) {
                    tapPreRing = ByteArray(PRE_TAP_RING_BYTES)
                }
                tapPreWritePos = 0
                tapPreFilled = 0
            } else {
                tapPreRing = null
                tapPreWritePos = 0
                tapPreFilled = 0
            }
        }
    }

    /**
     * عند خروج المستخدم من شاشة المشغّل بينما التسجيل لا يزال نشطاً، وبعد إغلاق اتصال ExoPlayer،
     * يُسلَّم التسجيل بسلاسة إلى خيط الشبكة الخلفي على نفس الملف المفتوح دون انقطاع.
     */
    fun handoffLiveTapToBackgroundNetwork() {
        synchronized(tapLock) {
            tapStandbyEnabled = false
            tapPreRing = null
            tapPreWritePos = 0
            tapPreFilled = 0
            if (tapActive && recRunning.get()) {
                tapActive = false
                tapHandedOffToNetwork = true
                tapQueue?.offer(TAP_POISON_PILL)
            }
        }
    }

    internal fun onPlayerMediaChunkRead(buf: ByteArray, offset: Int, len: Int) {
        if (len <= 0 || (!tapActive && !tapStandbyEnabled)) return
        synchronized(tapLock) {
            if (tapActive) {
                val q = tapQueue
                if (q != null) {
                    q.offer(buf.copyOfRange(offset, offset + len))
                }
                return
            }
            if (!tapStandbyEnabled) return
            val ring = tapPreRing ?: return
            if (len >= PRE_TAP_RING_BYTES) {
                System.arraycopy(buf, offset + len - PRE_TAP_RING_BYTES, ring, 0, PRE_TAP_RING_BYTES)
                tapPreWritePos = 0
                tapPreFilled = PRE_TAP_RING_BYTES
            } else {
                val firstPart = minOf(len, PRE_TAP_RING_BYTES - tapPreWritePos)
                System.arraycopy(buf, offset, ring, tapPreWritePos, firstPart)
                val rem = len - firstPart
                if (rem > 0) {
                    System.arraycopy(buf, offset + firstPart, ring, 0, rem)
                }
                tapPreWritePos = (tapPreWritePos + len) % PRE_TAP_RING_BYTES
                tapPreFilled = minOf(PRE_TAP_RING_BYTES, tapPreFilled + len)
            }
        }
    }

    private fun snapshotAndActivateTapQueue(): LinkedBlockingQueue<ByteArray> {
        synchronized(tapLock) {
            val q = LinkedBlockingQueue<ByteArray>(512)
            val ring = tapPreRing
            val filled = tapPreFilled
            if (ring != null && filled > 0) {
                val snap = if (filled < PRE_TAP_RING_BYTES) {
                    ring.copyOfRange(0, filled)
                } else {
                    ByteArray(PRE_TAP_RING_BYTES).also { dst ->
                        val tailLen = PRE_TAP_RING_BYTES - tapPreWritePos
                        System.arraycopy(ring, tapPreWritePos, dst, 0, tailLen)
                        if (tapPreWritePos > 0) {
                            System.arraycopy(ring, 0, dst, tailLen, tapPreWritePos)
                        }
                    }
                }
                if (snap.isNotEmpty()) {
                    q.offer(snap)
                }
            }
            tapPreWritePos = 0
            tapPreFilled = 0
            tapQueue = q
            tapHandedOffToNetwork = false
            tapActive = true
            return q
        }
    }

    @OptIn(UnstableApi::class)
    fun wrapWithLiveTap(upstreamFactory: DataSource.Factory): DataSource.Factory {
        return DataSource.Factory { LiveTapDataSource(upstreamFactory.createDataSource()) }
    }

    @OptIn(UnstableApi::class)
    private class LiveTapDataSource(
        private val upstream: DataSource
    ) : DataSource {
        private var currentOpenIsMedia: Boolean = false
        private var checkedMagicOnOpen: Boolean = false

        override fun addTransferListener(transferListener: TransferListener) {
            upstream.addTransferListener(transferListener)
        }

        override fun open(dataSpec: DataSpec): Long {
            val len = upstream.open(dataSpec)
            val effUri = (upstream.uri ?: dataSpec.uri)?.toString().orEmpty()
            val cleanPath = effUri.substringBefore('?').substringBefore('#').lowercase(Locale.US)
            val headers = upstream.responseHeaders
            val ct = (headers["Content-Type"] ?: headers["content-type"])
                ?.firstOrNull().orEmpty().lowercase(Locale.US)
            val isManifestOrText = cleanPath.endsWith(".m3u8") ||
                cleanPath.endsWith(".m3u") ||
                cleanPath.endsWith(".mpd") ||
                cleanPath.endsWith(".vtt") ||
                cleanPath.endsWith(".srt") ||
                cleanPath.endsWith(".key") ||
                ct.contains("mpegurl") ||
                ct.contains("dash+xml") ||
                ct.startsWith("text/") ||
                ct.contains("application/json")
            currentOpenIsMedia = !isManifestOrText
            checkedMagicOnOpen = false
            return len
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            val n = upstream.read(buffer, offset, length)
            if (n > 0 && currentOpenIsMedia && (tapActive || tapStandbyEnabled)) {
                if (!checkedMagicOnOpen) {
                    checkedMagicOnOpen = true
                    val peekLen = minOf(n, 24)
                    val headAscii = String(buffer, offset, peekLen, Charsets.ISO_8859_1)
                        .trimStart()
                        .lowercase(Locale.US)
                    if (headAscii.startsWith("#extm3u") ||
                        headAscii.startsWith("<?xml") ||
                        headAscii.startsWith("<!doctype") ||
                        headAscii.startsWith("<html") ||
                        headAscii.startsWith("{\"")
                    ) {
                        currentOpenIsMedia = false
                        return n
                    }
                }
                onPlayerMediaChunkRead(buffer, offset, n)
            }
            return n
        }

        override fun getUri(): Uri? = upstream.uri

        override fun getResponseHeaders(): Map<String, List<String>> = upstream.responseHeaders

        override fun close() {
            currentOpenIsMedia = false
            checkedMagicOnOpen = false
            upstream.close()
        }
    }

    private val finalizers=WorkerDrain()
    private val exiting=java.util.concurrent.atomic.AtomicBoolean(false)
    @Synchronized fun beginExit() {exiting.set(true)}
    fun awaitFinalization(timeoutMs:Long):Boolean = finalizers.await(timeoutMs)

    @Synchronized fun stopRecording() {
        recRunning.set(false)
        synchronized(tapLock) {
            tapActive = false
            tapHandedOffToNetwork = false
            tapQueue?.offer(TAP_POISON_PILL)
            tapQueue = null
        }
        runCatching { activeRecCall?.cancel() }
        activeRecCall = null
        recThread?.interrupt()
        recThread = null
    }

    @Synchronized fun stopDownload() {
        dlRunning.set(false)
        runCatching { activeDlCall?.cancel() }
        activeDlCall = null
        dlThread?.interrupt()
        dlThread = null
    }

    fun stopAll() {
        stopRecording()
        stopDownload()
    }

    private class OutputSink(
        stream: OutputStream,
        val displayPath: String,
        val finalizeSink: () -> Unit,
        val deleteSink: () -> Unit
    ) {
        val stream=TransferOutput(stream)
        fun finish(publish:Boolean)=stream.finish(publish,finalizeSink,deleteSink)
    }

    /**
     * تنظيف صارم لاسم الملف يزيل رموز الزخرفة مثل ┃ و│ و% و# والأقواس لضمان سلامة روابط file:// على كل الأنظمة.
     */
    private fun sanitizeFileName(raw: String): String {
        val clean = raw
            .replace(Regex("""[^\p{L}\p{N}._\-]+"""), "_")
            .replace(Regex("""_+"""), "_")
            .trim('_', '.', '-')
        return clean.take(60).ifBlank { "IPTV_Media" }
    }

    private fun mimeForExt(ext: String): String = when (ext.lowercase(Locale.US)) {
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        "avi" -> "video/x-msvideo"
        "flv" -> "video/x-flv"
        else -> "video/mp2t"
    }

    /**
     * قراءة أوّل دفعة بايتات للتحقّق من أنّ الردّ فيديو حقيقي وليس صفحة خطأ نصّية/HTML من البورتال،
     * واكتشاف الحاوية الفعلية (mp4 / mkv / ts / flv / avi).
     */
    private fun readInitialHeaderChunk(input: InputStream, maxWaitBytes: Int = 8192): ByteArray {
        val buf = ByteArray(maxWaitBytes)
        var filled = 0
        while (filled < 1024) {
            val n = input.read(buf, filled, buf.size - filled)
            if (n <= 0) break
            filled += n
        }
        return if (filled == buf.size) buf else buf.copyOf(filled)
    }

    private fun looksLikeErrorTextOrHtml(head: ByteArray, contentType: String): String? {
        if (head.isEmpty()) return "السيرفر أغلق الاتصال بدون إرسال أي بيانات فيديو"
        val ct = contentType.lowercase(Locale.US)
        if (ct.contains("text/html") || ct.contains("application/json")) {
            val preview = String(head, 0, minOf(head.size, 240), Charsets.UTF_8).trim()
            return if (preview.contains("token", true) || preview.contains("denied", true) || preview.contains("limit", true)) {
                "السيرفر رفض فتح اتصال إضافي (تحقّق من عدد الخطوط المسموحة للاشتراك)"
            } else {
                "ردّ السيرفر صفحة خطأ بدلاً من ملف الفيديو"
            }
        }
        val sample = String(head, 0, minOf(head.size, 180), Charsets.ISO_8859_1).trimStart()
        val low = sample.lowercase(Locale.US)
        if (low.startsWith("<!doctype") ||
            low.startsWith("<html") ||
            low.startsWith("{\"js\"") ||
            low.startsWith("{\"error") ||
            low.startsWith("error") ||
            low.startsWith("access denied") ||
            low.startsWith("file not found") ||
            low.startsWith("invalid token") ||
            low.startsWith("nothing")
        ) {
            return "رفض السيرفر رابط التحميل/التسجيل (انتهت صلاحية التصريح أو الحدّ الأقصى للاتصالات)"
        }
        return null
    }

    private fun detectContainerExtension(
        head: ByteArray,
        contentType: String,
        url: String,
        fallbackExt: String
    ): String {
        if (head.size >= 12) {
            // Matroska / WebM: 1A 45 DF A3
            if (head[0] == 0x1A.toByte() && head[1] == 0x45.toByte() &&
                head[2] == 0xDF.toByte() && head[3] == 0xA3.toByte()
            ) {
                return "mkv"
            }
            // MP4 / MOV: ....ftyp
            if (head[4] == 'f'.code.toByte() && head[5] == 't'.code.toByte() &&
                head[6] == 'y'.code.toByte() && head[7] == 'p'.code.toByte()
            ) {
                return "mp4"
            }
            // FLV: "FLV"
            if (head[0] == 'F'.code.toByte() && head[1] == 'L'.code.toByte() && head[2] == 'V'.code.toByte()) {
                return "flv"
            }
            // AVI: "RIFF"...."AVI "
            if (head[0] == 'R'.code.toByte() && head[1] == 'I'.code.toByte() &&
                head[2] == 'F'.code.toByte() && head[3] == 'F'.code.toByte() &&
                head[8] == 'A'.code.toByte() && head[9] == 'V'.code.toByte() && head[10] == 'I'.code.toByte()
            ) {
                return "avi"
            }
            // MPEG-TS sync byte (0x47 every 188 bytes)
            if (findMpegTsSyncOffset(head) >= 0) {
                return "ts"
            }
        }
        val ct = contentType.lowercase(Locale.US)
        if (ct.contains("matroska")) return "mkv"
        if (ct.contains("mp4")) return "mp4"
        if (ct.contains("mp2t")) return "ts"
        val cleanPath = url.substringBefore("?").lowercase(Locale.US)
        return when {
            cleanPath.endsWith(".mkv") -> "mkv"
            cleanPath.endsWith(".mp4") || cleanPath.endsWith(".m4v") -> "mp4"
            cleanPath.endsWith(".avi") -> "avi"
            cleanPath.endsWith(".ts") -> "ts"
            else -> fallbackExt
        }
    }

    /**
     * يجد أوّل بايت تزامن MPEG-TS حقيقي (0x47 يتكرّر كلّ 188 بايت) لضمان بدء ملف التسجيل بحزمة سليمة 100%.
     */
    private fun findMpegTsSyncOffset(buf: ByteArray, len: Int = buf.size): Int {
        if (len < 377) {
            for (i in 0 until len) {
                if (buf[i] == 0x47.toByte()) return i
            }
            return -1
        }
        val limit = minOf(len - 376, 564)
        for (i in 0 until limit) {
            if (buf[i] == 0x47.toByte() &&
                buf[i + 188] == 0x47.toByte() &&
                buf[i + 376] == 0x47.toByte()
            ) {
                return i
            }
        }
        return -1
    }

    private fun openDownloadsSink(
        context: Context,
        subFolder: String,
        fileName: String,
        mimeType: String
    ): OutputSink {
        val appCtx = context.applicationContext
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = appCtx.contentResolver
            val relPath = "${Environment.DIRECTORY_DOWNLOADS}/$subFolder"
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, relPath)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = runCatching { resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) }.getOrNull()
            if (uri != null) {
                val os = runCatching { resolver.openOutputStream(uri) }.getOrNull()
                if (os != null) {
                    return OutputSink(
                        stream = BufferedOutputStream(os, 128 * 1024),
                        displayPath = "Downloads/$subFolder/$fileName",
                        finalizeSink = {
                            val doneCv = ContentValues().apply {
                                put(MediaStore.MediaColumns.IS_PENDING, 0)
                            }
                            if(resolver.update(uri, doneCv, null, null)<=0)throw IOException("تعذّر نشر الملف في التخزين")
                        },
                        deleteSink = {
                            runCatching { resolver.delete(uri, null, null) }
                        }
                    )
                } else {
                    runCatching { resolver.delete(uri, null, null) }
                }
            }
        }

        // على Android 5..9 (مثل NoxPlayer) نختبر فتح الملف فعلياً في Downloads العام، وإن رُفضت الصلاحية نحفظ في مجلد التطبيق الخارجي المضمون دائماً!
        runCatching {
            val pub = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val dir = File(pub, subFolder)
            if (!dir.exists()) dir.mkdirs()
            val candidateFile = File(dir, fileName)
            val fos = FileOutputStream(candidateFile)
            return OutputSink(
                stream = BufferedOutputStream(fos, 128 * 1024),
                displayPath = candidateFile.absolutePath,
                finalizeSink = {},
                deleteSink = { runCatching { if (candidateFile.exists()) candidateFile.delete() } }
            )
        }

        val fallbackBase = appCtx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appCtx.filesDir
        val fallbackDir = File(fallbackBase, subFolder).apply { mkdirs() }
        val outFile = File(fallbackDir, fileName)
        return OutputSink(
            stream = BufferedOutputStream(FileOutputStream(outFile), 128 * 1024),
            displayPath = outFile.absolutePath,
            finalizeSink = {},
            deleteSink = { runCatching { if (outFile.exists()) outFile.delete() } }
        )
    }

    private fun resolveFreshTransferUrl(
        acc: AccountProfile?,
        item: StreamItem,
        directUrl: String,
        forceNewLink: Boolean = false
    ): String {
        if (!forceNewLink && (directUrl.startsWith("http://", true) || directUrl.startsWith("https://", true))) {
            return directUrl
        }
        if (acc != null) {
            val fresh = runCatching { PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true) }.getOrDefault("")
            if (fresh.isNotBlank()) return fresh
        }
        return when {
            directUrl.startsWith("http://", true) || directUrl.startsWith("https://", true) -> directUrl
            else -> PortalClient.extractDirectHttpUrl(item.cmd)
        }
    }

    /**
     * تسجيل فوري للبثّ الحيّ من داخل المشغّل مباشرةً عبر التقاط بايتات البثّ من اتصال ExoPlayer القائم (LiveTapDataSource)
     * دون فتح اتصال ثانٍ على السيرفر — يمنع خطأ `Connection reset` نهائياً على اشتراكات خطّ واحد (`max_connections = 1`)!
     * وعند خروج المستخدم من المشغّل قبل إيقاف التسجيل، ينتقل التسجيل تلقائياً لاتصال الشبكة الخلفي على نفس الملف.
     */
    @Synchronized
    fun startLiveTapRecording(
        context: Context,
        acc: AccountProfile?,
        item: StreamItem,
        directUrl: String = "",
        maxDurationSec: Int = 0,
        onTick: (elapsedSec: Long, bytesWritten: Long) -> Unit = { _, _ -> },
        onFinished: (success: Boolean, savedPath: String, bytesWritten: Long, errorMsg: String) -> Unit = { _, _, _, _ -> }
    ): Boolean {
        if(exiting.get() || finalizers.hasKind("rec"))return false
        if (!recRunning.compareAndSet(false, true)) return false
        val appCtx = context.applicationContext
        activeRecTitle = item.name
        val queue = snapshotAndActivateTapQueue()

        val worker = Thread({
            var totalBytes = 0L
            var savedLocation = ""
            var errText = ""
            var sink: OutputSink? = null
            val startMs = System.currentTimeMillis()
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val base = sanitizeFileName(item.name)

            try {
                var alignedFirstChunk = false
                var lastTickMs = 0L

                while (recRunning.get() && !Thread.currentThread().isInterrupted) {
                    if (!tapActive && tapHandedOffToNetwork && queue.isEmpty()) {
                        break
                    }
                    val chunk = queue.poll(500, TimeUnit.MILLISECONDS)
                    if (chunk != null) {
                        if (chunk === TAP_POISON_PILL || chunk.isEmpty()) {
                            if (!tapActive) break
                            continue
                        }
                        if (sink == null) {
                            val opened = openDownloadsSink(
                                appCtx,
                                "IPTVLite_Recordings",
                                "${base}_$stamp.ts",
                                "video/mp2t"
                            )
                            sink = opened
                            savedLocation = opened.displayPath
                        }
                        val outStream = sink!!.stream
                        var startOff = 0
                        if (!alignedFirstChunk) {
                            alignedFirstChunk = true
                            val tsSync = findMpegTsSyncOffset(chunk)
                            if (tsSync > 0) startOff = tsSync
                        }
                        val writeLen = chunk.size - startOff
                        if (writeLen > 0) {
                            outStream.write(chunk, startOff, writeLen)
                            totalBytes += writeLen
                        }
                    }

                    val now = System.currentTimeMillis()
                    val elapsedSec = ((now - startMs) / 1000L).coerceAtLeast(0L)
                    if (now - lastTickMs >= 950L) {
                        lastTickMs = now
                        val snapBytes = totalBytes
                        mainHandler.post { onTick(elapsedSec, snapBytes) }
                    }
                    if (maxDurationSec > 0 && elapsedSec >= maxDurationSec) {
                        recRunning.set(false)
                        break
                    }
                }

                // إذا أغلق المستخدم شاشة المشغّل بينما التسجيل لا يزال نشطاً، نواصل التسجيل عبر الشبكة الخلفية!
                if (recRunning.get() && tapHandedOffToNetwork && !Thread.currentThread().isInterrupted) {
                    tapHandedOffToNetwork = false
                    totalBytes = streamNetworkLiveIntoSink(
                        appCtx = appCtx,
                        acc = acc,
                        item = item,
                        directUrl = directUrl,
                        base = base,
                        stamp = stamp,
                        startMs = startMs,
                        initialBytes = totalBytes,
                        existingSink = sink,
                        onSinkReady = { opened ->
                            sink = opened
                            savedLocation = opened.displayPath
                        },
                        maxDurationSec = maxDurationSec,
                        onTick = onTick
                    )
                }

                runCatching { sink?.stream?.flush() }
            } catch (_: InterruptedException) {
                // إيقاف يدوي طبيعي من المستخدم
            } catch (e: Exception) {
                if (recRunning.get() && totalBytes < 16_384L) {
                    errText = e.message ?: "انقطع اتصال التسجيل"
                }
            } finally {
                synchronized(tapLock) {
                    tapActive = false
                    tapHandedOffToNetwork = false
                    tapQueue = null
                }
                activeRecCall = null
                totalBytes=sink?.stream?.bytesWritten ?: totalBytes
                val sinkResult=sink?.finish(totalBytes>=16_384L)
                if(sinkResult?.isFailure==true)errText="تعذّر إنهاء حفظ الملف؛ تحقق من التخزين والمساحة"
                if (totalBytes < 16_384L) {
                    if (errText.isEmpty() && totalBytes in 1L..16_383L) {
                        errText = "لم يُستلم بثّ فيديو كافٍ من القناة بعد"
                    } else if (errText.isEmpty() && totalBytes == 0L) {
                        errText = "لم تبدأ القناة بإرسال حزم الفيديو بعد — انتظر ظهور الصورة ثم اضغط تسجيل"
                    }
                }
                activeRecTitle = ""
                recRunning.set(false)
                recThread = null
                finalizers.complete(Thread.currentThread())
                val ok = totalBytes >= 16_384L && sinkResult?.isSuccess==true
                val finalLoc = savedLocation
                val finalBytes = totalBytes
                val finalErr = errText
                mainHandler.post {
                    onFinished(ok, finalLoc, finalBytes, finalErr)
                }
            }
        }, "iptv-tap-recorder")

        recThread = worker
        finalizers.register(worker,"rec")
        try {worker.start()} catch(error:Throwable) {
            recRunning.set(false);recThread=null;finalizers.complete(worker);throw error
        }
        return true
    }

    private fun openSteppedLiveResponseWithFallback(
        streamUrl: String,
        acc: AccountProfile?,
        item: StreamItem
    ): Pair<Response, String> {
        var curUrl = streamUrl
        var lastErr: Exception? = null
        for (profile in 0..2) {
            if (!recRunning.get() || Thread.currentThread().isInterrupted) {
                throw InterruptedException()
            }
            try {
                val hdrs = buildHeadersForDownloadProfile(acc, profile)
                val (resp, landedUrl) = openSteppedDownloadResponse(
                    startUrl = curUrl,
                    headers = hdrs,
                    rangeOffset = 0L,
                    forRecording = true
                )
                if (resp.isSuccessful) {
                    return resp to landedUrl
                }
                val code = resp.code
                runCatching { resp.close() }
                lastErr = IllegalStateException("رفض السيرفر الاتصال (HTTP $code)")
                if (acc != null && profile == 0 && code in intArrayOf(401, 403, 404, 410, 458)) {
                    val fresh = runCatching { PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true) }.getOrDefault("")
                    if (fresh.isNotBlank()) curUrl = fresh
                }
            } catch (e: IOException) {
                lastErr = e
                if (acc != null && profile == 0) {
                    val fresh = runCatching { PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true) }.getOrDefault("")
                    if (fresh.isNotBlank()) curUrl = fresh
                }
                runCatching { Thread.sleep(250L) }
            }
        }
        throw (lastErr ?: IOException("تعذّر فتح اتصال التسجيل مع السيرفر"))
    }

    private fun streamNetworkLiveIntoSink(
        appCtx: Context,
        acc: AccountProfile?,
        item: StreamItem,
        directUrl: String,
        base: String,
        stamp: String,
        startMs: Long,
        initialBytes: Long,
        existingSink: OutputSink?,
        onSinkReady: (OutputSink) -> Unit,
        maxDurationSec: Int,
        onTick: (elapsedSec: Long, bytesWritten: Long) -> Unit
    ): Long {
        var totalBytes = initialBytes
        var sink = existingSink
        var streamUrl = resolveFreshTransferUrl(
            acc = acc,
            item = item,
            directUrl = directUrl,
            forceNewLink = (acc?.provider == ProviderType.STALKER)
        )
        if (streamUrl.isBlank()) {
            throw IllegalStateException("تعذّر استخراج رابط البثّ للتسجيل")
        }

        val headers = PortalClient.getStreamRequestHeaders(acc)
        if (isLikelyHlsUrl(streamUrl)) {
            if (sink == null) {
                val opened = openDownloadsSink(appCtx, "IPTVLite_Recordings", "${base}_$stamp.ts", "video/mp2t")
                sink = opened
                onSinkReady(opened)
            }
            totalBytes += recordHlsStream(
                playlistUrl = streamUrl,
                headers = headers,
                out = sink!!.stream,
                startMs = startMs,
                maxDurationSec = maxDurationSec,
                onTick = { elapsed, segBytes -> onTick(elapsed, initialBytes + segBytes) }
            )
            return totalBytes
        }

        var dropRetries = 0
        var detectedExt = "ts"

        while (recRunning.get() && !Thread.currentThread().isInterrupted) {
            try {
                val (resp, landedUrl) = openSteppedLiveResponseWithFallback(streamUrl, acc, item)
                resp.use { r ->
                    val cType = r.header("Content-Type").orEmpty().lowercase(Locale.US)
                    if (cType.contains("mpegurl") || cType.contains("m3u")) {
                        val playlistBody = r.body?.string().orEmpty()
                        if (sink == null) {
                            val opened = openDownloadsSink(appCtx, "IPTVLite_Recordings", "${base}_$stamp.ts", "video/mp2t")
                            sink = opened
                            onSinkReady(opened)
                        }
                        val baseBeforeHls = totalBytes
                        totalBytes += recordHlsStream(
                            playlistUrl = landedUrl,
                            initialBody = playlistBody,
                            headers = headers,
                            out = sink!!.stream,
                            startMs = startMs,
                            maxDurationSec = maxDurationSec,
                            onTick = { elapsed, segBytes -> onTick(elapsed, baseBeforeHls + segBytes) }
                        )
                        return totalBytes
                    }

                    val body = r.body ?: throw IllegalStateException("لا توجد بيانات بثّ")
                    body.byteStream().use { input ->
                        val head = readInitialHeaderChunk(input)
                        val badErr = looksLikeErrorTextOrHtml(head, cType)
                        if (badErr != null) {
                            throw IllegalStateException(badErr)
                        }

                        if (sink == null) {
                            detectedExt = detectContainerExtension(head, cType, landedUrl, "ts")
                            val fileName = "${base}_$stamp.$detectedExt"
                            val opened = openDownloadsSink(
                                appCtx,
                                "IPTVLite_Recordings",
                                fileName,
                                mimeForExt(detectedExt)
                            )
                            sink = opened
                            onSinkReady(opened)
                        }

                        val outStream = sink!!.stream
                        val startOffset = if (detectedExt == "ts") {
                            findMpegTsSyncOffset(head).coerceAtLeast(0)
                        } else 0
                        if (head.size > startOffset) {
                            val writeLen = head.size - startOffset
                            outStream.write(head, startOffset, writeLen)
                            totalBytes += writeLen
                            dropRetries = 0
                        }

                        val buf = ByteArray(64 * 1024)
                        var lastTickMs = 0L
                        while (recRunning.get() && !Thread.currentThread().isInterrupted) {
                            val n = input.read(buf)
                            if (n < 0) break
                            if (n > 0) {
                                outStream.write(buf, 0, n)
                                totalBytes += n
                            }
                            val now = System.currentTimeMillis()
                            val elapsedSec = ((now - startMs) / 1000L).coerceAtLeast(0L)
                            if (now - lastTickMs >= 950L) {
                                lastTickMs = now
                                val snapBytes = totalBytes
                                mainHandler.post { onTick(elapsedSec, snapBytes) }
                            }
                            if (maxDurationSec > 0 && elapsedSec >= maxDurationSec) {
                                recRunning.set(false)
                                break
                            }
                        }
                    }
                }

                val elapsedSec = ((System.currentTimeMillis() - startMs) / 1000L).coerceAtLeast(0L)
                if (!recRunning.get() || (maxDurationSec > 0 && elapsedSec >= maxDurationSec)) {
                    break
                }
                if (detectedExt == "ts" && dropRetries < 5) {
                    dropRetries++
                    Thread.sleep(700L)
                    if (acc != null) {
                        val refreshed = runCatching {
                            PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true)
                        }.getOrDefault("")
                        if (refreshed.isNotBlank()) streamUrl = refreshed
                    }
                    continue
                }
                break
            } catch (ioe: IOException) {
                if (!recRunning.get() || Thread.currentThread().isInterrupted) break
                if (totalBytes > 0L && detectedExt == "ts" && dropRetries < 5) {
                    dropRetries++
                    runCatching { Thread.sleep(800L) }
                    if (acc != null) {
                        val refreshed = runCatching {
                            PortalClient.resolveStreamUrl(acc, item, forceCreateLink = true)
                        }.getOrDefault("")
                        if (refreshed.isNotBlank()) streamUrl = refreshed
                    }
                    continue
                }
                throw ioe
            }
        }
        return totalBytes
    }

    /**
     * بدء تسجيل البثّ الحيّ عبر الشبكة الخلفية (للتسجيل المجدول أو من خارج شاشة المشغّل)
     * مع تتبّع توجيهات CDN وتنقية الترويسات ودعم أنماط User-Agent البديلة.
     */
    @Synchronized
    fun startRecording(
        context: Context,
        acc: AccountProfile?,
        item: StreamItem,
        directUrl: String = "",
        maxDurationSec: Int = 0,
        onTick: (elapsedSec: Long, bytesWritten: Long) -> Unit = { _, _ -> },
        onFinished: (success: Boolean, savedPath: String, bytesWritten: Long, errorMsg: String) -> Unit = { _, _, _, _ -> }
    ): Boolean {
        if(exiting.get() || finalizers.hasKind("rec"))return false
        if (!recRunning.compareAndSet(false, true)) return false
        val appCtx = context.applicationContext
        activeRecTitle = item.name

        val worker = Thread({
            var totalBytes = 0L
            var savedLocation = ""
            var errText = ""
            var sink: OutputSink? = null
            try {
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val base = sanitizeFileName(item.name)
                val startMs = System.currentTimeMillis()
                totalBytes = streamNetworkLiveIntoSink(
                    appCtx = appCtx,
                    acc = acc,
                    item = item,
                    directUrl = directUrl,
                    base = base,
                    stamp = stamp,
                    startMs = startMs,
                    initialBytes = 0L,
                    existingSink = null,
                    onSinkReady = { opened ->
                        sink = opened
                        savedLocation = opened.displayPath
                    },
                    maxDurationSec = maxDurationSec,
                    onTick = onTick
                )
                runCatching { sink?.stream?.flush() }
            } catch (_: InterruptedException) {
                // إيقاف يدوي طبيعي من المستخدم
            } catch (e: Exception) {
                if (recRunning.get() && totalBytes < 32_768L) {
                    errText = e.message ?: "انقطع اتصال التسجيل"
                }
            } finally {
                activeRecCall = null
                totalBytes=sink?.stream?.bytesWritten ?: totalBytes
                val sinkResult=sink?.finish(totalBytes>=32_768L)
                if(sinkResult?.isFailure==true)errText="تعذّر إنهاء حفظ الملف؛ تحقق من التخزين والمساحة"
                if (totalBytes < 32_768L) {
                    if (errText.isEmpty() && totalBytes in 1L..32_767L) {
                        errText = "لم يُستلم بثّ فيديو كافٍ من السيرفر (أقلّ من ثانية)"
                    }
                }
                activeRecTitle = ""
                recRunning.set(false)
                recThread = null
                finalizers.complete(Thread.currentThread())
                val ok = totalBytes >= 32_768L && sinkResult?.isSuccess==true
                val finalLoc = savedLocation
                val finalBytes = totalBytes
                val finalErr = errText
                mainHandler.post {
                    onFinished(ok, finalLoc, finalBytes, finalErr)
                }
            }
        }, "iptv-stream-recorder")

        recThread = worker
        finalizers.register(worker,"rec")
        try {worker.start()} catch(error:Throwable) {
            recRunning.set(false);recThread=null;finalizers.complete(worker);throw error
        }
        return true
    }

    private fun isLikelyHlsUrl(url: String): Boolean {
        val clean = url.substringBefore("?").lowercase(Locale.US)
        return clean.endsWith(".m3u8") || url.contains(".m3u8?", ignoreCase = true)
    }

    private fun resolveRelativeUrl(baseUrl: String, ref: String): String {
        val trimmed = ref.trim()
        if (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true)) return trimmed
        return runCatching { URI(baseUrl).resolve(trimmed).toString() }.getOrDefault(trimmed)
    }

    private fun recordHlsStream(
        playlistUrl: String,
        initialBody: String = "",
        headers: Map<String, String>,
        out: OutputStream,
        startMs: Long,
        maxDurationSec: Int,
        onTick: (elapsedSec: Long, bytesWritten: Long) -> Unit
    ): Long {
        var activePlaylistUrl = playlistUrl
        var firstFetchBody = initialBody
        val seenSegments = LinkedHashSet<String>()
        var wroteInitMap = false
        var totalBytes = 0L
        var lastTickMs = 0L

        while (recRunning.get() && !Thread.currentThread().isInterrupted) {
            val text = if (firstFetchBody.isNotEmpty()) {
                val tmp = firstFetchBody
                firstFetchBody = ""
                tmp
            } else {
                val req = Request.Builder().url(activePlaylistUrl).apply {
                    header("Accept-Encoding", "identity")
                    headers.forEach { (k, v) -> header(k, v) }
                }.build()
                transferHttp.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) throw IllegalStateException("HLS HTTP ${resp.code}")
                    activePlaylistUrl = resp.request.url.toString()
                    resp.body?.string().orEmpty()
                }
            }

            val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }
            if (isMaster) {
                val variantLine = lines.firstOrNull { !it.startsWith("#") }
                    ?: throw IllegalStateException("قائمة HLS الرئيسية فارغة")
                activePlaylistUrl = resolveRelativeUrl(activePlaylistUrl, variantLine)
                continue
            }

            if (!wroteInitMap) {
                val mapLine = lines.firstOrNull { it.startsWith("#EXT-X-MAP:", ignoreCase = true) }
                if (mapLine != null) {
                    val uriMatch = Regex("""URI="([^"]+)"""").find(mapLine)?.groupValues?.getOrNull(1)
                    if (!uriMatch.isNullOrBlank()) {
                        val mapUrl = resolveRelativeUrl(activePlaylistUrl, uriMatch)
                        totalBytes += downloadSingleSegment(mapUrl, headers, out)
                        wroteInitMap = true
                    }
                }
            }

            val segRefs = lines.filter { !it.startsWith("#") }
            val endList = lines.any { it.startsWith("#EXT-X-ENDLIST", ignoreCase = true) }
            var newSegCount = 0

            for (ref in segRefs) {
                if (!recRunning.get() || Thread.currentThread().isInterrupted) break
                val segUrl = resolveRelativeUrl(activePlaylistUrl, ref)
                val segKey = segUrl.substringBefore("?").ifBlank { segUrl }
                if (!seenSegments.add(segKey)) continue
                if (seenSegments.size > 600) {
                    val it = seenSegments.iterator()
                    if (it.hasNext()) {
                        it.next()
                        it.remove()
                    }
                }
                newSegCount++
                totalBytes += downloadSingleSegment(segUrl, headers, out)

                val now = System.currentTimeMillis()
                val elapsedSec = ((now - startMs) / 1000L).coerceAtLeast(0L)
                if (now - lastTickMs >= 900L) {
                    lastTickMs = now
                    val snap = totalBytes
                    mainHandler.post { onTick(elapsedSec, snap) }
                }
                if (maxDurationSec > 0 && elapsedSec >= maxDurationSec) {
                    return totalBytes
                }
            }

            if (endList) break

            val elapsedSec = ((System.currentTimeMillis() - startMs) / 1000L).coerceAtLeast(0L)
            if (maxDurationSec > 0 && elapsedSec >= maxDurationSec) break

            val sleepMs = if (newSegCount == 0) 1500L else 600L
            try {
                Thread.sleep(sleepMs)
            } catch (_: InterruptedException) {
                break
            }
        }
        return totalBytes
    }

    private fun downloadSingleSegment(url: String, headers: Map<String, String>, out: OutputStream): Long {
        val req = Request.Builder().url(url).apply {
            header("Accept-Encoding", "identity")
            headers.forEach { (k, v) -> header(k, v) }
        }.build()
        var written = 0L
        runCatching {
            transferHttp.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return 0L
                val body = resp.body ?: return 0L
                body.byteStream().use { input ->
                    val buf = ByteArray(32 * 1024)
                    while (recRunning.get() && !Thread.currentThread().isInterrupted) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) {
                            out.write(buf, 0, n)
                            written += n
                        }
                    }
                }
            }
        }
        return written
    }

    private fun parseTotalBytesFromContentRange(contentRange: String?): Long {
        if (contentRange.isNullOrBlank()) return -1L
        // صيغة: bytes 1048576-99999999/100000000
        val slash = contentRange.substringAfterLast('/', "").trim()
        return slash.toLongOrNull()?.takeIf { it > 0L } ?: -1L
    }

    private fun buildHeadersForDownloadProfile(acc: AccountProfile?, profile: Int): Map<String, String> {
        return when (profile) {
            // النمط 0: ترويسات البوابة الأصلية على المضيف الأوّل (مع تنقيتها تلقائياً عند التحويل لخادم CDN خارجي)
            0 -> PortalClient.getStreamRequestHeaders(acc)
            // النمط 1: مطابق 100% لمدير التحميل الخارجي / متصفّح أندرويد الحديث (بدون كوكيز أو X-User-Agent)
            1 -> mapOf(
                "User-Agent" to EXTERNAL_DL_UA,
                "Accept" to "*/*"
            )
            // النمط 2: وضع VLC/LibVLC القياسي لخوادم الوسائط المتشدّدة
            else -> mapOf(
                "User-Agent" to VLC_DL_UA,
                "Accept" to "*/*"
            )
        }
    }

    /**
     * يفتح اتصال التحميل مع تتبّع التوجيهات (301/302/303/307/308) حتّى 8 قفزات،
     * وحذف كوكيز وترويسات البورتال عند الانتقال إلى سيرفر تخزين CDN خارجي، وإرجاع الرابط النهائي الفعلي!
     */
    private fun openSteppedDownloadResponse(
        startUrl: String,
        headers: Map<String, String>,
        rangeOffset: Long,
        forRecording: Boolean = false
    ): Pair<Response, String> {
        var curUrl = startUrl
        val originHost = startUrl.toHttpUrlOrNull()?.host.orEmpty()
        for (hop in 0 until 8) {
            val parsed = curUrl.toHttpUrlOrNull() ?: throw IllegalStateException("رابط تحميل غير صالح")
            val sameHostAsOrigin = originHost.isEmpty() || parsed.host.equals(originHost, ignoreCase = true)
            val rb = Request.Builder()
                .url(parsed)
                .header("Accept-Encoding", "identity")
                .header("Accept", "*/*")

            headers.forEach { (k, v) ->
                val isPortalAuthHeader = k.equals("Cookie", ignoreCase = true) ||
                    k.equals("X-User-Agent", ignoreCase = true) ||
                    k.equals("Authorization", ignoreCase = true) ||
                    k.equals("Referer", ignoreCase = true)
                if (sameHostAsOrigin || !isPortalAuthHeader) {
                    rb.header(k, v)
                }
            }
            if (rangeOffset > 0L) {
                rb.header("Range", "bytes=$rangeOffset-")
            }

            val call = transferStepHttp.newCall(rb.build())
            if (forRecording) {
                activeRecCall = call
            } else {
                activeDlCall = call
            }
            val resp = call.execute()
            if (resp.code !in intArrayOf(301, 302, 303, 307, 308)) {
                return resp to curUrl
            }
            val loc = resp.header("Location")?.trim()
            runCatching { resp.close() }
            if (loc.isNullOrEmpty()) {
                throw IOException("ردّ توجيه فارغ من السيرفر (HTTP ${resp.code})")
            }
            val resolvedNext = parsed.resolve(loc)?.toString() ?: resolveRelativeUrl(curUrl, loc)
            PortalClient.cacheStreamRedirect(startUrl, resolvedNext)
            curUrl = resolvedNext
        }
        throw ProtocolException("عدد كبير جدّاً من توجيهات HTTP")
    }

    private fun downloadHlsVodToSink(
        appCtx: Context,
        item: StreamItem,
        playlistUrl: String,
        initialText: String,
        headers: Map<String, String>,
        onSinkOpened: (OutputSink) -> Unit,
        onProgress: (percent: Int, downloadedBytes: Long, totalBytes: Long) -> Unit
    ): Long {
        var activeUrl = playlistUrl
        var bodyText = initialText
        // فكّ القائمة الرئيسية (Master Playlist) لاختيار أعلى جودة متاحة
        for (round in 0 until 3) {
            if (bodyText.isBlank()) {
                val (resp, landedUrl) = openSteppedDownloadResponse(activeUrl, headers, 0L)
                resp.use { r ->
                    if (!r.isSuccessful) throw IllegalStateException("HLS HTTP ${r.code}")
                    activeUrl = landedUrl
                    bodyText = r.body?.string().orEmpty()
                }
            }
            val lines = bodyText.lines().map { it.trim() }.filter { it.isNotEmpty() }
            val isMaster = lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }
            if (!isMaster) break

            var bestBw = -1L
            var bestVariant = ""
            for (i in lines.indices) {
                val ln = lines[i]
                if (ln.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                    val bw = Regex("""BANDWIDTH=(\d+)""", RegexOption.IGNORE_CASE)
                        .find(ln)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
                    val nextUri = lines.drop(i + 1).firstOrNull { !it.startsWith("#") }.orEmpty()
                    if (nextUri.isNotEmpty() && bw >= bestBw) {
                        bestBw = bw
                        bestVariant = nextUri
                    }
                }
            }
            val chosen = bestVariant.ifEmpty { lines.firstOrNull { !it.startsWith("#") }.orEmpty() }
            if (chosen.isEmpty()) throw IllegalStateException("قائمة HLS للفيلم فارغة")
            activeUrl = resolveRelativeUrl(activeUrl, chosen)
            bodyText = ""
        }

        val lines = bodyText.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val mapLine = lines.firstOrNull { it.startsWith("#EXT-X-MAP:", ignoreCase = true) }
        val mapUri = mapLine?.let {
            Regex("""URI="([^"]+)"""").find(it)?.groupValues?.getOrNull(1)
        }
        val segRefs = lines.filter { !it.startsWith("#") }
        if (segRefs.isEmpty()) throw IllegalStateException("لم يُعثر على مقاطع فيديو داخل قائمة HLS")

        val ext = if (!mapUri.isNullOrBlank()) "mp4" else "ts"
        val fileName = "${sanitizeFileName(item.name)}.$ext"
        val sink = openDownloadsSink(appCtx, "IPTVLite_Downloads", fileName, mimeForExt(ext))
        onSinkOpened(sink)

        var totalWritten = 0L
        val out = sink.stream
        if (!mapUri.isNullOrBlank()) {
            val resolvedMap = resolveRelativeUrl(activeUrl, mapUri)
            totalWritten += downloadVodSegmentStrict(resolvedMap, headers, out)
        }

        var lastUiMs = 0L
        for ((idx, ref) in segRefs.withIndex()) {
            if (!dlRunning.get() || Thread.currentThread().isInterrupted) break
            val segUrl = resolveRelativeUrl(activeUrl, ref)
            var segBytes = 0L
            for (attempt in 0 until 3) {
                if (!dlRunning.get() || Thread.currentThread().isInterrupted) break
                segBytes = runCatching { downloadVodSegmentStrict(segUrl, headers, out) }.getOrDefault(0L)
                if (segBytes > 0L) break
                runCatching { Thread.sleep(400L * (attempt + 1)) }
            }
            totalWritten += segBytes
            val now = System.currentTimeMillis()
            if (now - lastUiMs >= 450L || idx == segRefs.lastIndex) {
                lastUiMs = now
                val pct = (((idx + 1) * 100L) / segRefs.size.toLong()).toInt().coerceIn(0, 100)
                val snapBytes = totalWritten
                mainHandler.post { onProgress(pct, snapBytes, -1L) }
            }
        }
        out.flush()
        return totalWritten
    }

    private fun downloadVodSegmentStrict(segUrl: String, headers: Map<String, String>, out: OutputStream): Long {
        val (resp, _) = openSteppedDownloadResponse(segUrl, headers, 0L)
        var written = 0L
        resp.use { r ->
            if (!r.isSuccessful) throw IOException("Segment HTTP ${r.code}")
            val body = r.body ?: return 0L
            body.byteStream().use { input ->
                val buf = ByteArray(64 * 1024)
                while (dlRunning.get() && !Thread.currentThread().isInterrupted) {
                    val n = input.read(buf)
                    if (n < 0) break
                    if (n > 0) {
                        out.write(buf, 0, n)
                        written += n
                    }
                }
            }
        }
        return written
    }

    /**
     * تحميل فيلم أو حلقة مسلسل مباشرةً إلى مجلد `Downloads/IPTVLite_Downloads`
     * مع استئناف تلقائي ذكي (HTTP Range Resume)، وتنقية ترويسات الكوكيز عند التحويل لخوادم CDN،
     * والتبديل التلقائي لوضع مدير التحميل الخارجي (Chrome/VLC) ودعم قوائم HLS VOD!
     */
    @Synchronized
    fun startDownload(
        context: Context,
        acc: AccountProfile?,
        item: StreamItem,
        directUrl: String = "",
        onProgress: (percent: Int, downloadedBytes: Long, totalBytes: Long) -> Unit = { _, _, _ -> },
        onFinished: (success: Boolean, savedPath: String, downloadedBytes: Long, errorMsg: String) -> Unit = { _, _, _, _ -> }
    ): Boolean {
        if(exiting.get() || finalizers.hasKind("download"))return false
        if (!dlRunning.compareAndSet(false, true)) return false
        val appCtx = context.applicationContext
        activeDlTitle = item.name

        val worker = Thread({
            var downloaded = 0L
            var expectedTotalBytes = -1L
            var savedLocation = ""
            var errText = ""
            var sink: OutputSink? = null
            var completedCleanly = false
            try {
                val initialOriginUrl = resolveFreshTransferUrl(acc, item, directUrl, forceNewLink = false)
                if (initialOriginUrl.isBlank()) {
                    throw IllegalStateException("تعذّر استخراج رابط التحميل من السيرفر")
                }
                var originPortalUrl = initialOriginUrl
                var currentUrl = initialOriginUrl

                val candExt = item.containerExt.trim().trim('.').lowercase(Locale.US)
                val fallbackExt = if (candExt in VALID_VIDEO_EXTS) candExt else "mp4"

                mainHandler.post { onProgress(0, 0L, -1L) }

                var headerProfile = 0
                var stallRetries = 0
                val maxStallRetries = 10
                var nonRangeResetUsed = false

                // إن كان الرابط ينتهي صراحةً بـ .m3u8 نحمّله كقائمة HLS كاملة مباشرةً
                if (isLikelyHlsUrl(currentUrl)) {
                    val hlsHeaders = buildHeadersForDownloadProfile(acc, 0)
                    downloaded = downloadHlsVodToSink(
                        appCtx = appCtx,
                        item = item,
                        playlistUrl = currentUrl,
                        initialText = "",
                        headers = hlsHeaders,
                        onSinkOpened = { opened ->
                            sink = opened
                            savedLocation = opened.displayPath
                        },
                        onProgress = onProgress
                    )
                    completedCleanly = dlRunning.get() && !Thread.currentThread().isInterrupted && downloaded >= 64 * 1024L
                }

                while (!completedCleanly && dlRunning.get() && !Thread.currentThread().isInterrupted) {
                    val bytesBeforeAttempt = downloaded
                    try {
                        val activeHeaders = buildHeadersForDownloadProfile(acc, headerProfile)
                        val (resp, landedUrl) = openSteppedDownloadResponse(currentUrl, activeHeaders, downloaded)
                        // تثبيت رابط خادم التخزين النهائي بعد 302 حتى يعمل الاستكمال Range مباشرةً دون لمس play_token مرّة أخرى!
                        if (landedUrl.isNotBlank() && landedUrl != currentUrl) {
                            currentUrl = landedUrl
                        }
                        var hitCleanStreamEnd = false
                        var switchToHlsText: String? = null

                        resp.use { r ->
                            if (r.code in setOf(400, 401, 403, 404, 406, 410, 416, 429, 458)) {
                                if (r.code == 416 && expectedTotalBytes > 0L && downloaded >= expectedTotalBytes) {
                                    completedCleanly = true
                                    return@use
                                }
                                // عند بداية التحميل (0 بايت): نبدّل تلقائياً إلى وضع مدير التحميل الخارجي (النمط 1 ثم النمط 2) مع تجديد الرابط إن لزم!
                                if (downloaded == 0L && headerProfile < 2) {
                                    headerProfile++
                                    if (acc?.provider == ProviderType.STALKER) {
                                        val fresh = resolveFreshTransferUrl(acc, item, "", forceNewLink = true)
                                        if (fresh.isNotBlank()) {
                                            originPortalUrl = fresh
                                            currentUrl = fresh
                                        }
                                    } else {
                                        currentUrl = originPortalUrl
                                    }
                                    throw IOException("تبديل نمط التحميل المتوافق ($headerProfile)")
                                }
                                if (acc != null && stallRetries < maxStallRetries) {
                                    val fresh = resolveFreshTransferUrl(acc, item, "", forceNewLink = true)
                                    if (fresh.isNotBlank() && fresh != originPortalUrl) {
                                        originPortalUrl = fresh
                                        currentUrl = fresh
                                        throw IOException("تجديد تصريح التحميل")
                                    }
                                }
                                throw IllegalStateException("رفض السيرفر التحميل (HTTP ${r.code}) — تأكّد من عدم تجاوز عدد الخطوط المسموحة")
                            }
                            if (!r.isSuccessful) {
                                if (downloaded == 0L && headerProfile < 2) {
                                    headerProfile++
                                    currentUrl = originPortalUrl
                                    throw IOException("إعادة المحاولة بنمط التحميل البديل")
                                }
                                throw IllegalStateException("فشل التحميل من السيرفر (HTTP ${r.code})")
                            }

                            val cType = r.header("Content-Type").orEmpty()
                            val body = r.body ?: throw IllegalStateException("ردّ السيرفر فارغ")

                            if (downloaded > 0L && r.code == 200) {
                                if (nonRangeResetUsed) {
                                    throw IOException("السيرفر قطع التحميل ولا يدعم الاستئناف الجزئي (Range)")
                                }
                                nonRangeResetUsed = true
                                if(sink?.finish(false)?.isFailure==true)throw IllegalStateException("تعذّر إنهاء الملف السابق؛ تحقق من التخزين")
                                sink = null
                                downloaded = 0L
                            }

                            val rangeTotal = parseTotalBytesFromContentRange(r.header("Content-Range"))
                            val bodyLen = body.contentLength()
                            if (rangeTotal > 0L) {
                                expectedTotalBytes = rangeTotal
                            } else if (downloaded == 0L && bodyLen > 0L) {
                                expectedTotalBytes = bodyLen
                            } else if (r.code == 206 && bodyLen > 0L && expectedTotalBytes <= 0L) {
                                expectedTotalBytes = downloaded + bodyLen
                            }

                            body.byteStream().use byteLoop@{ input ->
                                if (downloaded == 0L) {
                                    val head = readInitialHeaderChunk(input)
                                    val headPreview = if (head.isNotEmpty()) {
                                        String(head, 0, minOf(head.size, 64), Charsets.ISO_8859_1).trimStart()
                                    } else ""
                                    // فحص إن كان السيرفر قد أعاد قائمة HLS (#EXTM3U) بدلاً من ملف مباشر!
                                    if (headPreview.startsWith("#EXTM3U", ignoreCase = true) ||
                                        cType.contains("mpegurl", ignoreCase = true)
                                    ) {
                                        val restBytes = input.readBytes()
                                        val fullBytes = ByteArray(head.size + restBytes.size)
                                        System.arraycopy(head, 0, fullBytes, 0, head.size)
                                        System.arraycopy(restBytes, 0, fullBytes, head.size, restBytes.size)
                                        switchToHlsText = String(fullBytes, Charsets.UTF_8)
                                        return@byteLoop
                                    }

                                    val badErr = looksLikeErrorTextOrHtml(head, cType)
                                    if (badErr != null) {
                                        if (headerProfile < 2) {
                                            headerProfile++
                                            if (acc?.provider == ProviderType.STALKER) {
                                                val fresh = resolveFreshTransferUrl(acc, item, "", forceNewLink = true)
                                                if (fresh.isNotBlank()) {
                                                    originPortalUrl = fresh
                                                    currentUrl = fresh
                                                }
                                            } else {
                                                currentUrl = originPortalUrl
                                            }
                                            throw IOException("تبديل ترويسات التحميل لتفادي صفحة الخطأ")
                                        }
                                        throw IllegalStateException(badErr)
                                    }

                                    val realExt = detectContainerExtension(head, cType, currentUrl, fallbackExt)
                                    if (sink == null) {
                                        val fileName = "${sanitizeFileName(item.name)}.$realExt"
                                        val opened = openDownloadsSink(
                                            appCtx,
                                            "IPTVLite_Downloads",
                                            fileName,
                                            mimeForExt(realExt)
                                        )
                                        sink = opened
                                        savedLocation = opened.displayPath
                                    }
                                    if (head.isNotEmpty()) {
                                        sink!!.stream.write(head, 0, head.size)
                                        downloaded += head.size
                                    }
                                    val initPct = if (expectedTotalBytes > 0L) {
                                        ((downloaded * 100L) / expectedTotalBytes).toInt().coerceIn(0, 100)
                                    } else 0
                                    val snapDl0 = downloaded
                                    val snapTot0 = expectedTotalBytes
                                    mainHandler.post { onProgress(initPct, snapDl0, snapTot0) }
                                }

                                val outStream = sink?.stream ?: throw IllegalStateException("تعذّر فتح ملف الحفظ")
                                val buf = ByteArray(64 * 1024)
                                var lastUiMs = 0L
                                while (dlRunning.get() && !Thread.currentThread().isInterrupted) {
                                    val n = input.read(buf)
                                    if (n < 0) {
                                        hitCleanStreamEnd = true
                                        break
                                    }
                                    if (n > 0) {
                                        outStream.write(buf, 0, n)
                                        downloaded += n
                                    }
                                    val now = System.currentTimeMillis()
                                    if (now - lastUiMs >= 500L) {
                                        lastUiMs = now
                                        val pct = if (expectedTotalBytes > 0L) {
                                            ((downloaded * 100L) / expectedTotalBytes).toInt().coerceIn(0, 100)
                                        } else -1
                                        val snapDl = downloaded
                                        val snapTot = expectedTotalBytes
                                        mainHandler.post { onProgress(pct, snapDl, snapTot) }
                                    }
                                }
                            }
                        }

                        if (switchToHlsText != null) {
                            downloaded = downloadHlsVodToSink(
                                appCtx = appCtx,
                                item = item,
                                playlistUrl = currentUrl,
                                initialText = switchToHlsText!!,
                                headers = activeHeaders,
                                onSinkOpened = { opened ->
                                    sink = opened
                                    savedLocation = opened.displayPath
                                },
                                onProgress = onProgress
                            )
                            completedCleanly = dlRunning.get() && !Thread.currentThread().isInterrupted && downloaded >= 64 * 1024L
                            break
                        }

                        if (!dlRunning.get() || Thread.currentThread().isInterrupted) break
                        if (completedCleanly) break

                        if (expectedTotalBytes > 0L) {
                            if (downloaded >= expectedTotalBytes) {
                                completedCleanly = true
                                break
                            }
                            throw ProtocolException("انقطع الدفق عند ${formatSizeMb(downloaded)} من ${formatSizeMb(expectedTotalBytes)}")
                        } else if (hitCleanStreamEnd && downloaded >= 64 * 1024L) {
                            completedCleanly = true
                            break
                        } else {
                            throw EOFException("انقطع الدفق مبكّراً")
                        }
                    } catch (recoverable: IOException) {
                        if (!dlRunning.get() || Thread.currentThread().isInterrupted) break
                        if (downloaded > bytesBeforeAttempt) {
                            stallRetries = 0
                        } else {
                            stallRetries++
                        }
                        if (stallRetries > maxStallRetries) {
                            throw IllegalStateException(
                                if (downloaded > 0L) {
                                    "انقطع السيرفر مراراً وتوقّف الاستكمال عند ${formatSizeMb(downloaded)}"
                                } else {
                                    "تعذّر بدء التحميل المباشر من السيرفر (تحقّق من عدم انشغال خطّ الاشتراك)"
                                }
                            )
                        }
                        runCatching { sink?.stream?.flush() }
                        runCatching { Thread.sleep((650L * stallRetries.coerceIn(1, 4))) }
                        if (acc != null && stallRetries >= 3 && downloaded == 0L) {
                            val refreshed = resolveFreshTransferUrl(acc, item, "", forceNewLink = true)
                            if (refreshed.isNotBlank()) {
                                originPortalUrl = refreshed
                                currentUrl = refreshed
                            }
                        }
                    }
                }
                runCatching { sink?.stream?.flush() }
            } catch (_: InterruptedException) {
                // أُلغي بواسطة المستخدم
            } catch (e: Exception) {
                if (dlRunning.get()) {
                    errText = e.message ?: "انقطع التحميل"
                }
            } finally {
                activeDlCall = null
                val wasCancelled = !dlRunning.get() && errText.isEmpty() && !completedCleanly
                val isValidComplete = completedCleanly && !wasCancelled && errText.isEmpty() && downloaded >= 64 * 1024L
                val sinkResult=sink?.finish(isValidComplete)
                if(sinkResult?.isFailure==true)errText="تعذّر إنهاء حفظ الملف؛ تحقق من التخزين والمساحة"
                activeDlTitle = ""
                dlRunning.set(false)
                dlThread = null
                finalizers.complete(Thread.currentThread())
                val finalLoc = savedLocation
                val finalDl = downloaded
                val finalErr = if(errText.isNotEmpty())errText else if(wasCancelled) "تمّ إيقاف التحميل" else ""
                mainHandler.post {
                    onFinished(isValidComplete && sinkResult?.isSuccess==true, finalLoc, finalDl, finalErr)
                }
            }
        }, "iptv-vod-downloader")

        dlThread = worker
        finalizers.register(worker,"download")
        try {worker.start()} catch(error:Throwable) {
            dlRunning.set(false);dlThread=null;finalizers.complete(worker);throw error
        }
        return true
    }

    fun openInExternalDownloader(context: Context, url: String, title: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse(url)
                putExtra(Intent.EXTRA_TITLE, title)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "فتح الرابط في مدير تحميل أو متصفّح"))
        } catch (_: Exception) {
            Toast.makeText(context, "لا يوجد متصفّح أو مدير تحميل خارجي مثبّت على الجهاز", Toast.LENGTH_LONG).show()
        }
    }

    fun formatSizeMb(bytes: Long): String {
        val mb = bytes.toDouble() / (1024.0 * 1024.0)
        return when {
            mb >= 1024.0 -> String.format(Locale.US, "%.2f GB", mb / 1024.0)
            mb >= 0.1 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%d KB", (bytes / 1024L).coerceAtLeast(1L))
        }
    }

    data class SavedMediaEntry(
        val title: String,
        val playUri: String,
        val sizeBytes: Long,
        val modifiedMs: Long,
        val isRecording: Boolean,
        val rawFile: File? = null,
        val mediaStoreUri: Uri? = null
    )

    /**
     * يستخرج جميع التسجيلات والأفلام المحمّلة السليمة (`>= 32 KB`) على الجهاز (`IPTVLite_Recordings` و`IPTVLite_Downloads`).
     */
    fun listSavedMediaFiles(context: Context): List<SavedMediaEntry> {
        val appCtx = context.applicationContext
        val results = ArrayList<SavedMediaEntry>()
        val seenNames = HashSet<String>()
        val mediaExts = setOf("ts", "mp4", "mkv", "avi", "m4v", "webm", "flv", "mp3", "aac")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            runCatching {
                val resolver = appCtx.contentResolver
                val proj = arrayOf(
                    MediaStore.MediaColumns._ID,
                    MediaStore.MediaColumns.DISPLAY_NAME,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.DATE_MODIFIED,
                    MediaStore.MediaColumns.RELATIVE_PATH
                )
                val sel = "(${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ? OR ${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?) AND ${MediaStore.MediaColumns.IS_PENDING} = 0"
                val args = arrayOf("%IPTVLite_Recordings%", "%IPTVLite_Downloads%")
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    proj,
                    sel,
                    args,
                    "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
                )?.use { cur ->
                    val idCol = cur.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                    val nameCol = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    val sizeCol = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                    val dateCol = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)
                    val pathCol = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                    while (cur.moveToNext()) {
                        val id = cur.getLong(idCol)
                        val name = cur.getString(nameCol).orEmpty()
                        val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
                        if (name.isBlank() || ext !in mediaExts) continue
                        val sz = cur.getLong(sizeCol)
                        if (sz < 16_384L) continue
                        val modSec = cur.getLong(dateCol)
                        val rel = cur.getString(pathCol).orEmpty()
                        val isRec = rel.contains("IPTVLite_Recordings", ignoreCase = true)
                        val cUri = ContentUris.withAppendedId(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                            id
                        )
                        if (seenNames.add(name.lowercase(Locale.ROOT))) {
                            results.add(
                                SavedMediaEntry(
                                    title = name,
                                    playUri = cUri.toString(),
                                    sizeBytes = sz,
                                    modifiedMs = modSec * 1000L,
                                    isRecording = isRec,
                                    mediaStoreUri = cUri
                                )
                            )
                        }
                    }
                }
            }
        }

        val candidateDirs = LinkedHashSet<Pair<File, Boolean>>()
        runCatching {
            val pubDl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            candidateDirs.add(File(pubDl, "IPTVLite_Recordings") to true)
            candidateDirs.add(File(pubDl, "IPTVLite_Downloads") to false)
        }
        runCatching {
            val appDl = appCtx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appCtx.filesDir
            candidateDirs.add(File(appDl, "IPTVLite_Recordings") to true)
            candidateDirs.add(File(appDl, "IPTVLite_Downloads") to false)
        }

        for ((dir, isRec) in candidateDirs) {
            val files = runCatching { dir.listFiles() }.getOrNull() ?: continue
            for (f in files) {
                if (!f.isFile || f.length() < 16_384L) continue
                val ext = f.extension.lowercase(Locale.US)
                if (ext !in mediaExts) continue
                if (seenNames.add(f.name.lowercase(Locale.ROOT))) {
                    results.add(
                        SavedMediaEntry(
                            title = f.name,
                            playUri = Uri.fromFile(f).toString(),
                            sizeBytes = f.length(),
                            modifiedMs = f.lastModified(),
                            isRecording = isRec,
                            rawFile = f
                        )
                    )
                }
            }
        }

        return results.sortedByDescending { it.modifiedMs }
    }

    fun deleteSavedMediaFile(context: Context, entry: SavedMediaEntry): Boolean {
        return runCatching {
            var deleted = false
            entry.mediaStoreUri?.let { uri ->
                deleted = context.applicationContext.contentResolver.delete(uri, null, null) > 0
            }
            if (!deleted && entry.rawFile != null && entry.rawFile.exists()) {
                deleted = entry.rawFile.delete()
            }
            deleted
        }.getOrDefault(false)
    }
}
