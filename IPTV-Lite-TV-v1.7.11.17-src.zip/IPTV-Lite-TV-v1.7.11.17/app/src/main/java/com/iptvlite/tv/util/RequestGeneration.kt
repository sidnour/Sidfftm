package com.iptvlite.tv.util

/** UI-owned request identity; A→B→A never makes the first A current again. */
internal class RequestGeneration {
    private var value=0L
    @Synchronized fun next():Long {value++;return value}
    @Synchronized fun current():Long=value
    @Synchronized fun accepts(ticket:Long):Boolean=ticket==value
}
