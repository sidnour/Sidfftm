package com.iptvlite.tv.util

import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicInteger

/**
 * يتتبّع عدد واجهات التطبيق المرئية حالياً (`MainActivity` + `PlayerActivity`) بدقّة،
 * ويمرّر تنبيهات البرامج اللحظية فوراً للواجهة النشطة (سواء أثناء التصفّح أو المشاهدة بملء الشاشة).
 */
object AppUiTracker {
    private val startedCount = AtomicInteger(0)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var activeReminderHandler: (() -> Unit)? = null

    val isAnyUiVisible: Boolean
        get() = startedCount.get() > 0

    fun onActivityStarted() {
        startedCount.incrementAndGet()
    }

    fun onActivityStopped() {
        while (true) {
            val cur = startedCount.get()
            val next = (cur - 1).coerceAtLeast(0)
            if (startedCount.compareAndSet(cur, next)) break
        }
    }

    fun registerReminderHandler(handler: () -> Unit) {
        activeReminderHandler = handler
    }

    fun unregisterReminderHandler(handler: () -> Unit) {
        if (activeReminderHandler === handler) {
            activeReminderHandler = null
        }
    }

    fun dispatchImmediateReminderCheck(): Boolean {
        val h = activeReminderHandler ?: return false
        mainHandler.post { h.invoke() }
        return true
    }
}
