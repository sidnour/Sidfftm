package com.iptvlite.tv.network

import java.net.URI

internal object PortalLocalhost {
    /** Keep media scheme/path/query/fragment/explicit port; inherit portal port only if missing. */
    fun rewrite(portal:String,media:String):String = runCatching {
        val m=URI(media)
        if(m.host?.lowercase(java.util.Locale.US) !in setOf("localhost","127.0.0.1","::1","[::1]"))return media
        val p=URI(portal.trim())
        val host=p.host ?: return media
        if(p.scheme?.lowercase(java.util.Locale.US) !in setOf("http","https"))return media
        val normalized=if(host.contains(':') && !host.startsWith("["))"[$host]" else host
        val port=if(m.port>=0)m.port else p.port
        val authority=m.rawUserInfo?.let {"$it@"}.orEmpty()+normalized+if(port>=0)":$port" else ""
        "${m.scheme}://$authority${m.rawPath.orEmpty()}"+
            m.rawQuery?.let {"?$it"}.orEmpty()+m.rawFragment?.let {"#$it"}.orEmpty()
    }.getOrDefault(media)
}

internal class IncompleteListException:java.io.IOException("لم يكتمل تحميل القائمة؛ أعد فتح القسم للمحاولة")
