package com.iptvlite.tv.util

import com.iptvlite.tv.model.*
import com.iptvlite.tv.network.PortalClient
import java.net.URI
import java.util.Locale

/** Export-only policy. Never mutates items/caches or guesses virtual Stalker URLs. */
internal object M3uExport {
    data class Result(val payload:String,val exported:Int,val skipped:Int,val resolved:Int)
    private fun networkUrl(raw:String):String {
        val url=PortalClient.extractDirectHttpUrl(raw)
        if(url.any {it.isWhitespace() || it.code<32 || it.code==127})return ""
        val uri=runCatching {URI(url)}.getOrNull() ?: return ""
        if(uri.scheme?.lowercase(Locale.US) !in setOf("http","https","rtmp","rtsp","mms","rtp","udp"))return ""
        return url.takeIf {uri.host!=null}.orEmpty()
    }
    fun loopback(url:String):Boolean {
        val host=runCatching {URI(url).host}.getOrNull()?.lowercase(Locale.US)?.trim('[',']')?.trimEnd('.') ?: return true
        return host=="localhost" || host.endsWith(".localhost") || host=="0.0.0.0" || host=="::" || host=="::1" ||
            host.startsWith("127.") || host.startsWith("::ffff:127.") || host=="[::1]"
    }
    fun virtualPath(url:String):Boolean = runCatching {URI(url).path.orEmpty().startsWith("/ch/",ignoreCase=true)}.getOrDefault(true)
    fun portableUrl(raw:String):String {
        val url=networkUrl(raw)
        return url.takeIf {it.isNotEmpty() && !loopback(it)}.orEmpty()
    }
    private fun text(raw:String)=raw.replace('\n',' ').replace('\r',' ').replace('\u0000',' ').trim()
    private fun attribute(raw:String)=text(raw).replace('"','\'')
    private fun render(entries:List<Pair<StreamItem,String>>,group:String):String = buildString {
        append("#EXTM3U\n")
        for((item,url) in entries) {
            append("#EXTINF:-1")
            val logo=attribute(item.logo)
            if(logo.isNotEmpty())append(" tvg-logo=\"").append(logo).append('"')
            append(" group-title=\"").append(attribute(group).ifBlank {"IPTV Lite"}).append("\",")
            append(text(item.name)).append('\n').append(url).append('\n')
        }
    }
    fun direct(items:List<StreamItem>,group:String):Pair<Int,String> {
        val entries=items.mapNotNull {item->portableUrl(item.cmd).takeIf {it.isNotEmpty()}?.let {item to it}}
        return entries.size to render(entries,group)
    }
    /** Sequential, explicit user action. Account snapshots prevent wrong-account fallback on deletion/switch. */
    fun prepare(items:List<StreamItem>,accounts:List<AccountProfile>,activeAccountId:String?,group:String,
        checkActive:()->Unit,onProgress:(Int,Int)->Unit,
        resolve:(AccountProfile,StreamItem)->String):Result {
        val byId=accounts.associateBy {it.id}
        val entries=ArrayList<Pair<StreamItem,String>>()
        var resolved=0
        for((index,item) in items.withIndex()) {
            checkActive()
            var url=""
            if(item.kind!=ItemKind.SERIES && item.kind!=ItemKind.SEASON) {
                url=portableUrl(item.cmd)
                if(url.isEmpty()) {
                    val owner=if(item.accountId.isNotBlank())byId[item.accountId] else activeAccountId?.let {byId[it]}
                    if(owner?.provider==ProviderType.STALKER && item.kind!=ItemKind.CATCHUP) {
                        url=try {portableUrl(resolve(owner,item))}
                        catch(e:java.util.concurrent.CancellationException) {throw e}
                        catch(_:Exception) {checkActive();""}
                        checkActive()
                        if(url.isNotEmpty())resolved++
                    }
                }
            }
            if(url.isNotEmpty())entries.add(item to url)
            onProgress(index+1,items.size)
        }
        checkActive()
        return Result(render(entries,group),entries.size,items.size-entries.size,resolved)
    }
}
