package com.iptvlite.tv.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.iptvlite.tv.R
import com.iptvlite.tv.receiver.ScheduleReceiver
import com.iptvlite.tv.ui.MainActivity

/**
 * مدير الإشعارات الذكي للتنبيهات المجدولة (🔔) وخدمة التسجيل في الخلفية (🔴).
 */
object NotificationHelper {

    const val ALERTS_CHANNEL_ID = "iptv_lite_alerts_v1"
    const val REC_FG_CHANNEL_ID = "iptv_lite_recording_fg_v1"

    const val EXTRA_AUTO_OPEN_ACC_ID = "extra_auto_open_acc_id"
    const val EXTRA_AUTO_OPEN_CH_ID = "extra_auto_open_ch_id"
    const val EXTRA_AUTO_OPEN_CH_NAME = "extra_auto_open_ch_name"
    const val EXTRA_AUTO_OPEN_CH_CMD = "extra_auto_open_ch_cmd"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val alertsChannel = NotificationChannel(
            ALERTS_CHANNEL_ID,
            "تنبيهات البرامج واكتمال التسجيل",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "إشعارات بدء البرامج المفضّلة وحفظ التسجيلات المجدولة"
        }

        val recChannel = NotificationChannel(
            REC_FG_CHANNEL_ID,
            "التسجيل المجدول الجاري",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "متابعة حالة التسجيل المجدول وحجمه بالميغابايت"
            setSound(null, null)
        }

        nm.createNotificationChannel(alertsChannel)
        nm.createNotificationChannel(recChannel)
    }

    fun notifyEvent(
        context: Context,
        notifId: Int,
        title: String,
        body: String,
        openIntent: Intent? = null
    ) {
        val appCtx = context.applicationContext
        ensureChannels(appCtx)
        val nm = appCtx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        val launch = openIntent ?: Intent(appCtx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        val contentPi = PendingIntent.getActivity(appCtx, notifId, launch, piFlags)

        val notif = NotificationCompat.Builder(appCtx, ALERTS_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_tv)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentPi)
            .build()

        runCatching { nm.notify(notifId, notif) }
    }

    fun buildRecordingForegroundNotification(
        context: Context,
        title: String,
        subText: String
    ): Notification {
        val appCtx = context.applicationContext
        ensureChannels(appCtx)

        val piFlags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

        val openAppIntent = Intent(appCtx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(appCtx, 9901, openAppIntent, piFlags)

        // بثّ صريح (Explicit Broadcast) يعمل 100% على جميع إصدارات Android 8–14+
        val stopIntent = Intent(appCtx, ScheduleReceiver::class.java).apply {
            action = ScheduleHelper.ACTION_STOP_RECORDING
        }
        val stopPi = PendingIntent.getBroadcast(appCtx, 9902, stopIntent, piFlags)

        return NotificationCompat.Builder(appCtx, REC_FG_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_tv)
            .setContentTitle(title)
            .setContentText(subText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPi)
            .addAction(0, "⏹ إيقاف وحفظ الآن", stopPi)
            .build()
    }
}
