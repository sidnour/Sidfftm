package com.iptvlite.tv.store

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.AppPrefs
import com.iptvlite.tv.model.CatPref
import com.iptvlite.tv.model.CategoryItem
import com.iptvlite.tv.model.ContentTab
import com.iptvlite.tv.model.ImportSummary
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.ProgramReminder
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.ResumeEntry
import com.iptvlite.tv.model.ScheduledRecording
import com.iptvlite.tv.model.SortMode
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.util.DuplicateAccounts
import com.iptvlite.tv.util.AccountManagement
import com.iptvlite.tv.util.ScheduleHelper
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class AppStore(context: Context) {
    private val appCtx: Context = context.applicationContext
    private val stores: Pair<SharedPreferences, SharedPreferences> = obtainStores(appCtx)
    // مخزن مشفّر AES-256 مخصّص حصرياً لبيانات الاشتراكات الحسّاسة والرمز العائلي PIN (خفيف جدّاً < 4 KB)
    private val secretSp: SharedPreferences = stores.first
    // مخزن سريع بدون عبء تشفير للقراءة والكتابة المتكرّرة (الإعدادات، المفضّلة، السجلّ، مواضع المتابعة، الإحصائيات)
    private val sp: SharedPreferences = stores.second

    companion object {
        private val accountsLock = Any()
        private val personalDataLock = Any()
        private val schedulesLock = Any()
        private const val PLAIN_PREFS_NAME = "iptv_lite_tv_store"
        private const val ENC_PREFS_NAME = "iptv_lite_tv_store_enc"
        private const val FAST_PREFS_NAME = "iptv_lite_tv_fast_v166"

        private val SECRET_KEYS = setOf(
            "accounts_json",
            "parental_pin_sha256",
            "parental_pin_salt",
            "__migrated_from_plain_v160__"
        )

        private val ADULT_RE = Regex(
            """(\b18\+|\+18\b|\bxxx\b|\badult\b|\bporn\b|\berotic\b|للكبار|اباحي|إباحي)""",
            RegexOption.IGNORE_CASE
        )

        @Volatile
        private var sharedStores: Pair<SharedPreferences, SharedPreferences>? = null

        @Volatile
        private var cachedPrefs: AppPrefs? = null

        @Volatile
        private var cachedAccounts: List<AccountProfile>? = null

        @Volatile
        private var cachedFavorites: List<StreamItem>? = null

        @Volatile
        private var cachedFavIds: Set<String>? = null

        @Volatile
        private var cachedRecent: List<StreamItem>? = null

        @Volatile
        private var cachedReminders: List<ProgramReminder>? = null

        @Volatile
        private var cachedScheduledRecs: List<ScheduledRecording>? = null

        @Volatile
        private var cachedResumeEntries: List<ResumeEntry>? = null

        private val resumePosRamCache = ConcurrentHashMap<String, Long>()
        private val catPrefsRamCache = ConcurrentHashMap<String, Map<String, CatPref>>()

        const val MIN_RESUME_POS_MS: Long = 5_000L

        fun formatResumeTime(ms: Long): String {
            val totalSec = (ms / 1000L).coerceAtLeast(0L)
            val h = totalSec / 3600L
            val m = (totalSec % 3600L) / 60L
            val s = totalSec % 60L
            return if (h > 0L) {
                String.format(Locale.US, "%d:%02d:%02d", h, m, s)
            } else {
                String.format(Locale.US, "%d:%02d", m, s)
            }
        }

        fun isAdultCategoryTitle(title: String): Boolean {
            return ADULT_RE.containsMatchIn(title)
        }

        @Synchronized
        private fun obtainStores(ctx: Context): Pair<SharedPreferences, SharedPreferences> {
            sharedStores?.let { return it }
            val legacyPlain = ctx.getSharedPreferences(PLAIN_PREFS_NAME, Context.MODE_PRIVATE)
            val fast = ctx.getSharedPreferences(FAST_PREFS_NAME, Context.MODE_PRIVATE)
            val secret = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                try {
                    val enc = Api23EncryptedPrefs.open(ctx, ENC_PREFS_NAME)
                    migratePlainToEncrypted(legacyPlain, enc)
                    enc
                } catch (_: Throwable) {
                    legacyPlain
                }
            } else {
                legacyPlain
            }
            migrateNonSecretOutOfSecretStore(secret, fast)
            val pair = secret to fast
            sharedStores = pair
            return pair
        }

        @RequiresApi(Build.VERSION_CODES.M)
        private object Api23EncryptedPrefs {
            fun open(ctx: Context, fileName: String): SharedPreferences {
                val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
                return EncryptedSharedPreferences.create(
                    fileName,
                    masterKeyAlias,
                    ctx,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }
        }

        private fun copyAnyPrefValue(ed: SharedPreferences.Editor, k: String, v: Any?) {
            when (v) {
                is String -> ed.putString(k, v)
                is Int -> ed.putInt(k, v)
                is Long -> ed.putLong(k, v)
                is Boolean -> ed.putBoolean(k, v)
                is Float -> ed.putFloat(k, v)
                is Set<*> -> {
                    @Suppress("UNCHECKED_CAST")
                    (v as? Set<String>)?.let { ed.putStringSet(k, it) }
                }
            }
        }

        private fun migratePlainToEncrypted(plain: SharedPreferences, enc: SharedPreferences) {
            if (enc.getBoolean("__migrated_from_plain_v160__", false)) return
            val allPlain = plain.all
            if (allPlain.isNotEmpty()) {
                val ed = enc.edit()
                for ((k, v) in allPlain) copyAnyPrefValue(ed, k, v)
                ed.putBoolean("__migrated_from_plain_v160__", true)
                ed.apply()
                plain.edit().clear().apply()
            } else {
                enc.edit().putBoolean("__migrated_from_plain_v160__", true).apply()
            }
        }

        /**
         * ترحيل لمرّة واحدة ينقل المفاتيح غير الحسّاسة (الإعدادات، الإحصائيات، المفضّلة، السجلّ)
         * من EncryptedSharedPreferences الثقيل إلى المخزن السريع، ويبقي السيرفرات والـ PIN مشفّرة بالكامل!
         */
        private fun migrateNonSecretOutOfSecretStore(secret: SharedPreferences, fast: SharedPreferences) {
            if (fast.getBoolean("__migrated_fast_v166__", false)) return
            runCatching {
                val allSecret = secret.all
                val fastEd = fast.edit()
                val secCleanEd = secret.edit()
                var movedAny = false
                for ((k, v) in allSecret) {
                    if (k !in SECRET_KEYS) {
                        copyAnyPrefValue(fastEd, k, v)
                        secCleanEd.remove(k)
                        movedAny = true
                    }
                }
                fastEd.putBoolean("__migrated_fast_v166__", true)
                fastEd.apply()
                if (movedAny && secret !== fast) {
                    secCleanEd.apply()
                }
            }
        }
    }

    // ==================== التفضيلات العامة (قراءة فورية O(1) من الذاكرة) ====================
    fun loadPrefs(): AppPrefs {
        cachedPrefs?.let { return it }
        val cache = sp.getInt("cache_ms", 2500).coerceIn(200, 15000)
        val autoNext = sp.getBoolean("auto_next_ep", true)
        val autoRec = sp.getBoolean("auto_reconnect", true)
        val aspect = sp.getInt("aspect_mode", 0).coerceIn(0, 5)
        val theme = sp.getString("theme_mode", "dark")?.trim()?.lowercase(Locale.ROOT) ?: "dark"
        val validTheme = if (theme in setOf("dark", "night", "light")) theme else "dark"
        val autoPlayStart = sp.getBoolean("auto_play_last_start", false)
        val boost = sp.getInt("audio_boost_pct", 100).coerceIn(100, 200)
        val subSize = sp.getInt("sub_size_sp", 22).coerceIn(14, 42)
        val subCol = sp.getInt("sub_color_idx", 0).coerceIn(0, 3)
        val subBg = sp.getBoolean("sub_bg_trans", true)
        return AppPrefs(
            cacheMs = cache,
            autoNextEpisode = autoNext,
            autoReconnect = autoRec,
            aspectMode = aspect,
            themeMode = validTheme,
            autoPlayLastOnStart = autoPlayStart,
            audioBoostPct = boost,
            subSizeSp = subSize,
            subColorIndex = subCol,
            subBgTranslucent = subBg,
            diagnosticsEnabled = sp.getBoolean("playback_diagnostics", false)
        ).also { cachedPrefs = it }
    }

    fun savePrefs(prefs: AppPrefs) {
        val validTheme = prefs.themeMode.trim().lowercase(Locale.ROOT).let {
            if (it in setOf("dark", "night", "light")) it else "dark"
        }
        val clean = AppPrefs(
            cacheMs = prefs.cacheMs.coerceIn(200, 15000),
            autoNextEpisode = prefs.autoNextEpisode,
            autoReconnect = prefs.autoReconnect,
            aspectMode = prefs.aspectMode.coerceIn(0, 5),
            themeMode = validTheme,
            autoPlayLastOnStart = prefs.autoPlayLastOnStart,
            audioBoostPct = prefs.audioBoostPct.coerceIn(100, 200),
            subSizeSp = prefs.subSizeSp.coerceIn(14, 42),
            subColorIndex = prefs.subColorIndex.coerceIn(0, 3),
            subBgTranslucent = prefs.subBgTranslucent,
            diagnosticsEnabled = prefs.diagnosticsEnabled
        )
        cachedPrefs = clean
        com.iptvlite.tv.util.PlaybackDiagnostics.configure(clean.diagnosticsEnabled)
        sp.edit()
            .putInt("cache_ms", clean.cacheMs)
            .putBoolean("auto_next_ep", clean.autoNextEpisode)
            .putBoolean("auto_reconnect", clean.autoReconnect)
            .putInt("aspect_mode", clean.aspectMode)
            .putString("theme_mode", clean.themeMode)
            .putBoolean("auto_play_last_start", clean.autoPlayLastOnStart)
            .putInt("audio_boost_pct", clean.audioBoostPct)
            .putInt("sub_size_sp", clean.subSizeSp)
            .putInt("sub_color_idx", clean.subColorIndex)
            .putBoolean("sub_bg_trans", clean.subBgTranslucent)
            .putBoolean("playback_diagnostics", clean.diagnosticsEnabled)
            .apply()
    }

    fun isViewGridMode(tab: ContentTab): Boolean {
        val defaultGrid = (tab == ContentTab.VOD || tab == ContentTab.SERIES)
        return sp.getBoolean("view_grid_v2_${tab.code}", defaultGrid)
    }

    fun saveViewGridMode(tab: ContentTab, isGrid: Boolean) {
        sp.edit().putBoolean("view_grid_v2_${tab.code}", isGrid).apply()
    }

    // ==================== الاشتراكات والبوابات (محفوظة في المخزن المشفّر AES-256) ====================
    fun getAccounts(): List<AccountProfile> {
        synchronized(accountsLock) {
        cachedAccounts?.let { return it }
        val raw = secretSp.getString("accounts_json", null) ?: run {
            cachedAccounts = emptyList()
            return emptyList()
        }
        val parsed = try {
            val arr = JSONArray(raw)
            val list = ArrayList<AccountProfile>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val prov = runCatching {
                    ProviderType.valueOf(o.optString("provider", "STALKER"))
                }.getOrDefault(ProviderType.STALKER)
                list.add(
                    AccountProfile(
                        id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                        name = o.optString("name"),
                        provider = prov,
                        url = o.optString("url"),
                        mac = o.optString("mac"),
                        username = o.optString("username"),
                        password = o.optString("password"),
                        epgUrl = o.optString("epgUrl"),
                        expiry = o.optString("expiry"),
                        maxConnections = o.optString("maxConnections"),
                        status = o.optString("status"),
                        pingMs = o.optInt("pingMs", 0)
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
        val effective=parsed.map {overlayStatus(it)}
        cachedAccounts = effective
        return effective
    
        }
    }

    fun saveAccounts(list: List<AccountProfile>) {
        synchronized(accountsLock) {
        cachedAccounts = list.toList()
        val arr = JSONArray()
        for (a in list) {
            arr.put(
                JSONObject().apply {
                    put("id", a.id)
                    put("name", a.name)
                    put("provider", a.provider.name)
                    put("url", a.url)
                    put("mac", a.mac)
                    put("username", a.username)
                    put("password", a.password)
                    put("epgUrl", a.epgUrl)
                    put("expiry", a.expiry)
                    put("maxConnections", a.maxConnections)
                    put("status", a.status)
                    put("pingMs", a.pingMs)
                }
            )
        }
        secretSp.edit().putString("accounts_json", arr.toString()).apply()
    
        }
    }

    fun upsertAccount(acc: AccountProfile): AccountProfile {
        synchronized(accountsLock) {
        val all = getAccounts().toMutableList()
        val idx = all.indexOfFirst {
            it.id == acc.id || (
                it.provider == acc.provider &&
                    com.iptvlite.tv.model.DataIdentity.portalUrl(it.url) == com.iptvlite.tv.model.DataIdentity.portalUrl(acc.url) &&
                    it.mac.equals(acc.mac, ignoreCase = true) &&
                    it.username == acc.username
                )
        }
        val finalAcc = if (idx >= 0) {
            val existing = all[idx]
            val merged = acc.copy(
                id = existing.id,
                name = acc.name.ifBlank { existing.name },
                epgUrl = acc.epgUrl.ifBlank { existing.epgUrl },
                expiry = acc.expiry.ifBlank { existing.expiry },
                maxConnections = acc.maxConnections.ifBlank { existing.maxConnections },
                status = acc.status.ifBlank { existing.status },
                pingMs = if (acc.pingMs > 0) acc.pingMs else existing.pingMs
            )
            all[idx] = merged
            merged
        } else {
            all.add(0, acc)
            acc
        }
        saveAccounts(all)
        return finalAcc
    
        }
    }

    fun updateAccountStatus(id: String, expiry: String, status: String, pingMs: Int) {
        synchronized(accountsLock) {
        val all = getAccounts().map { acc ->
            if (acc.id == id) {
                acc.copy(
                    expiry = expiry.ifBlank { acc.expiry },
                    status = status.ifBlank { acc.status },
                    pingMs = pingMs
                )
            } else acc
        }
        secretSp.edit().remove(probeKey(id)).apply()
        saveAccounts(all)
    
        }
    }

    fun sortAccountsByFastest() {
        synchronized(accountsLock) {
        val all = getAccounts().sortedWith(
            compareBy<AccountProfile> {
                if (it.status.contains("✖") || it.status.contains("خطأ")) 1 else 0
            }.thenBy {
                if (it.pingMs > 0) it.pingMs else 99_999
            }
        )
        saveAccounts(all)
    
        }
    }

    fun deleteAccount(id: String) {
        synchronized(accountsLock) {
        val all = getAccounts().filterNot { it.id == id }
        saveAccounts(all)
        secretSp.edit().remove(probeKey(id)).apply()
        if (getActiveAccountId() == id) {
            setActiveAccountId(all.firstOrNull()?.id ?: "")
        }
    
        }
    }

    // Version198 invalidates legacy text-derived deletion evidence. One bounded record per live account.
    private fun probeKey(id:String)="account_check_v198_"+com.iptvlite.tv.model.DataIdentity.digest(id)
    private fun readProbe(id:String):JSONObject? = runCatching {
        secretSp.getString(probeKey(id),null)?.let {JSONObject(it)}
    }.getOrNull()
    private fun evidence(value:JSONObject?):AccountManagement.Evidence? = value?.let {o->runCatching {
        AccountManagement.Evidence(o.getString("fingerprint"),o.getString("attempt"),
            AccountManagement.Verdict.valueOf(o.getString("verdict")),o.getLong("checkedAt"),o.optBoolean("explicit",false))
    }.getOrNull()}
    private fun overlayStatus(a:AccountProfile):AccountProfile {
        val o=readProbe(a.id) ?: return a
        if(o.optString("fingerprint")!=a.networkCacheKey())return a
        val d=o.optJSONObject("display") ?: return a
        return a.copy(expiry=d.optString("expiry",a.expiry),status=d.optString("status",a.status),pingMs=d.optInt("pingMs",a.pingMs))
    }
    internal fun getAccountProbe(id:String):AccountManagement.Evidence? = synchronized(accountsLock) {evidence(readProbe(id))}
    internal fun getAccountProbes():Map<String,AccountManagement.Evidence> = synchronized(accountsLock) {
        getAccounts().mapNotNull {a->evidence(readProbe(a.id))?.let {a.id to it}}.toMap()
    }
    private fun beginCheck(expected:AccountProfile,explicit:Boolean,now:Long):String? = synchronized(accountsLock) {
        val current=getAccounts().firstOrNull {it.id==expected.id} ?: return@synchronized null
        if(current.networkCacheKey()!=expected.networkCacheKey())return@synchronized null
        val token=UUID.randomUUID().toString()
        val record=JSONObject().put("fingerprint",current.networkCacheKey()).put("attempt",token)
            .put("explicit",explicit).put("verdict",AccountManagement.Verdict.PENDING.name).put("checkedAt",now)
            .put("display",JSONObject().put("expiry",current.expiry).put("status",current.status).put("pingMs",current.pingMs))
        val key=probeKey(current.id)
        if(secretSp.edit().putString(key,record.toString()).commit())token else {
            secretSp.edit().remove(key).apply() // commit(false) may still have changed SharedPreferences RAM.
            null
        }
    }
    internal fun beginAccountProbe(expected:AccountProfile,now:Long=System.currentTimeMillis()):String?=beginCheck(expected,true,now)
    internal fun beginAccountStatusRefresh(expected:AccountProfile,now:Long=System.currentTimeMillis()):String?=beginCheck(expected,false,now)
    private fun encodeAccountList(accounts:List<AccountProfile>):String = JSONArray().apply {
        accounts.forEach {a->put(JSONObject().put("id",a.id).put("name",a.name).put("provider",a.provider.name)
            .put("url",a.url).put("mac",a.mac).put("username",a.username).put("password",a.password)
            .put("epgUrl",a.epgUrl).put("expiry",a.expiry).put("maxConnections",a.maxConnections)
            .put("status",a.status).put("pingMs",a.pingMs))}
    }.toString()
    private fun finishCheck(expected:AccountProfile,attempt:String,explicit:Boolean,verdict:AccountManagement.Verdict,
        expiry:String,status:String,ping:Int,now:Long):Boolean = synchronized(accountsLock) {
        val accounts=getAccounts();val current=accounts.firstOrNull {it.id==expected.id} ?: return@synchronized false
        val o=readProbe(current.id) ?: return@synchronized false
        val prior=evidence(o) ?: return@synchronized false
        if(prior.attempt!=attempt || prior.explicit!=explicit || prior.fingerprint!=expected.networkCacheKey() ||
            current.networkCacheKey()!=expected.networkCacheKey() || verdict==AccountManagement.Verdict.PENDING)return@synchronized false
        val safeVerdict=if(!explicit && verdict==AccountManagement.Verdict.REJECTED)AccountManagement.Verdict.UNCERTAIN else verdict
        val next=current.copy(expiry=expiry.ifBlank {current.expiry},status=status,pingMs=ping)
        o.put("verdict",safeVerdict.name).put("checkedAt",now)
            .put("display",JSONObject().put("expiry",next.expiry).put("status",next.status).put("pingMs",next.pingMs))
        val ok=secretSp.edit().putString(probeKey(current.id),o.toString()).commit()
        if(ok)cachedAccounts=accounts.map {if(it.id==current.id)next else it}
        else secretSp.edit().remove(probeKey(current.id)).apply() // Fail closed: never authorize unpersisted rejection.
        ok
    }
    internal fun finishAccountProbe(expected:AccountProfile,attempt:String,verdict:AccountManagement.Verdict,
        expiry:String,status:String,ping:Int,now:Long=System.currentTimeMillis()):Boolean =
        finishCheck(expected,attempt,true,verdict,expiry,status,ping,now)
    internal fun finishAccountStatusRefresh(expected:AccountProfile,attempt:String,info:com.iptvlite.tv.model.AccountStatusInfo,
        now:Long=System.currentTimeMillis()):Boolean = finishCheck(expected,attempt,false,AccountManagement.classify(info,now),
            info.expiry,info.status,info.pingMs,now)

    /** Lock order matches account restore: accounts -> personal -> schedules; no network work. */
    internal fun duplicateAccountPlan():DuplicateAccounts.Plan = synchronized(accountsLock) {
        synchronized(personalDataLock) {synchronized(schedulesLock) {duplicatePlanLocked()}}
    }
    private fun duplicatePlanLocked():DuplicateAccounts.Plan {
        val owners=HashSet<String>();val knownPositions=HashSet<String>();var unknown=false
        val snapshot=sp.all
        for((key,ownerField) in listOf("favorites_json" to "accountId","recent_json" to "accountId",
            "resume_entries_json" to "accId","reminders_json" to "accId","scheduled_recs_json" to "accId")) {
            try {
                val raw=snapshot[key] ?: continue
                val arr=JSONArray(raw as String)
                for(i in 0 until arr.length()) {
                    val o=arr.getJSONObject(i);val owner=o.optString(ownerField)
                    if(owner.isBlank())unknown=true else owners.add(owner)
                    if(key=="resume_entries_json") {
                        val kind=ItemKind.valueOf(o.getString("kind"));val id=o.getString("id")
                        knownPositions.add(resumeSpKey(id,kind,owner))
                        val item=StreamItem(id,o.optString("name"),kind=kind,accountId=owner,
                            seriesId=o.optString("seriesId"),seasonId=o.optString("seasonId"))
                        resumeFallbackKey(item).takeIf {it.isNotEmpty()}?.let {knownPositions.add(it)}
                    }
                }
            } catch(_:Exception) {unknown=true}
        }
        // A standalone/legacy position hash cannot safely be attributed to an account.
        if((snapshot.keys+resumePosRamCache.keys).any {it.startsWith("pos_") && it !in knownPositions})unknown=true
        return DuplicateAccounts.plan(getAccounts(),owners,getActiveAccount()?.id.orEmpty(),unknown)
    }
    internal fun deleteDuplicateAccounts(expected:DuplicateAccounts.Plan,isBusy:()->Boolean={false}):AccountDeletion = synchronized(accountsLock) {
        synchronized(personalDataLock) {synchronized(schedulesLock) {
            val fresh=duplicatePlanLocked()
            val permitted=fresh.groups.filter {it.reason.isEmpty()}.associateBy {DuplicateAccounts.key(it.members.first())}
            val approved=expected.groups.filter {old->old.reason.isEmpty() &&
                permitted[DuplicateAccounts.key(old.members.first())]?.let {now->
                    now.keeperId==old.keeperId && now.members.toSet()==old.members.toSet()
                }==true}.flatMap {it.removable}
            val result=deleteAccountsIfUnchanged(approved,false,isBusy=isBusy)
            result.copy(skipped=expected.removable.size-result.removed.size)
        }}
    }

    internal fun rejectedAccounts(now:Long=System.currentTimeMillis()):List<AccountProfile> = synchronized(accountsLock) {
        getAccounts().filter {AccountManagement.eligible(it,evidence(readProbe(it.id)),now)}
    }
    internal data class AccountDeletion(val removed:Set<String>,val skipped:Int,val blocked:Boolean=false,val failed:Boolean=false)
    /** Snapshot-checked, one account-list write. Personal data remains owned by its original account IDs. */
    internal fun deleteAccountsIfUnchanged(expected:List<AccountProfile>,requireRejected:Boolean,
        now:Long=System.currentTimeMillis(),isBusy:()->Boolean={false}):AccountDeletion = synchronized(accountsLock) {
        if(isBusy())return@synchronized AccountDeletion(emptySet(),expected.size,blocked=true)
        val current=getAccounts();val wanted=expected.associateBy {it.id}
        val removed=current.filter {a->wanted[a.id]==a && (!requireRejected ||
            AccountManagement.eligible(a,evidence(readProbe(a.id)),now))}.map {it.id}.toSet()
        if(removed.isEmpty())return@synchronized AccountDeletion(emptySet(),wanted.size)
        val next=current.filterNot {it.id in removed}
        val oldJson=secretSp.getString("accounts_json",null)
        val oldRecords=removed.associateWith {secretSp.getString(probeKey(it),null)}
        val editor=secretSp.edit().putString("accounts_json",encodeAccountList(next))
        removed.forEach {editor.remove(probeKey(it))}
        val ok=editor.commit()
        if(!ok) {
            // Android updates preferences RAM before disk commit; restore the preimage on failure.
            val restore=secretSp.edit().putString("accounts_json",oldJson)
            oldRecords.forEach {(id,raw)->restore.putString(probeKey(id),raw)}
            restore.apply()
            return@synchronized AccountDeletion(emptySet(),wanted.size,failed=true)
        }
        cachedAccounts=next
        if(getActiveAccountId() in removed)setActiveAccountId(next.firstOrNull()?.id.orEmpty())
        AccountDeletion(removed,wanted.size-removed.size)
    }

    fun getActiveAccountId(): String = sp.getString("active_account_id", "") ?: ""

    fun setActiveAccountId(id: String) {
        synchronized(accountsLock) {sp.edit().putString("active_account_id", id).apply()}
    }

    fun getActiveAccount(): AccountProfile? {
        val all = getAccounts()
        if (all.isEmpty()) return null
        val activeId = getActiveAccountId()
        return all.firstOrNull { it.id == activeId } ?: all.first()
    }

    // ==================== الرقابة الأبوية وإدارة الأقسام ====================
    fun hasParentalPin(): Boolean {
        return !secretSp.getString("parental_pin_sha256", "").isNullOrBlank()
    }

    fun hasPin(): Boolean = hasParentalPin()
    fun setPin(rawPin: String) = setParentalPin(rawPin)
    fun clearPin() = setParentalPin("")
    fun verifyPin(rawPin: String): Boolean = verifyParentalPin(rawPin)
    fun isAutoLockAdult(): Boolean = getAutoLockAdult()

    fun setParentalPin(rawPin: String) {
        val p = rawPin.trim()
        if (p.isEmpty()) {
            secretSp.edit()
                .remove("parental_pin_sha256")
                .remove("parental_pin_salt")
                .apply()
        } else {
            val saltBytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val saltHex = saltBytes.joinToString("") { "%02x".format(it) }
            secretSp.edit()
                .putString("parental_pin_salt", saltHex)
                .putString("parental_pin_sha256", sha256("$saltHex:$p"))
                .apply()
        }
    }

    fun verifyParentalPin(rawPin: String): Boolean {
        val saved = secretSp.getString("parental_pin_sha256", "") ?: ""
        if (saved.isBlank()) return true
        val salt = secretSp.getString("parental_pin_salt", "") ?: ""
        val clean = rawPin.trim()
        return if (salt.isNotBlank()) {
            sha256("$salt:$clean") == saved
        } else {
            // توافق سلس مع الرمز المحفوظ قبل الترقية ثم ترقيته تلقائياً بملح التشفير
            val ok = (sha256(clean) == saved)
            if (ok && clean.isNotEmpty()) setParentalPin(clean)
            ok
        }
    }

    fun getAutoLockAdult(): Boolean = sp.getBoolean("parental_auto_18", true)

    fun setAutoLockAdult(enabled: Boolean) {
        sp.edit().putBoolean("parental_auto_18", enabled).apply()
    }

    fun getCatPrefs(accKey: String, tabCode: String): Map<String, CatPref> {
        val spKey = "cat_prefs_${sha256("$accKey|$tabCode").take(14)}"
        catPrefsRamCache[spKey]?.let { return it }
        val raw = sp.getString(spKey, null) ?: run {
            catPrefsRamCache[spKey] = emptyMap()
            return emptyMap()
        }
        val parsed = try {
            val obj = JSONObject(raw)
            val out = HashMap<String, CatPref>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val cid = keys.next()
                val o = obj.optJSONObject(cid) ?: continue
                out[cid] = CatPref(
                    pinned = o.optBoolean("p", false),
                    hidden = o.optBoolean("h", false),
                    locked = o.optBoolean("l", false)
                )
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
        catPrefsRamCache[spKey] = parsed
        return parsed
    }

    fun setCatPref(
        accKey: String,
        tabCode: String,
        categoryId: String,
        pinned: Boolean? = null,
        hidden: Boolean? = null,
        locked: Boolean? = null
    ) {
        val cur = getCatPrefs(accKey, tabCode).toMutableMap()
        val old = cur[categoryId] ?: CatPref()
        val next = CatPref(
            pinned = pinned ?: old.pinned,
            hidden = hidden ?: old.hidden,
            locked = locked ?: old.locked
        )
        if (!next.pinned && !next.hidden && !next.locked) {
            cur.remove(categoryId)
        } else {
            cur[categoryId] = next
        }
        saveCatPrefsMap(accKey, tabCode, cur)
    }

    fun unhideAllCategories(accKey: String, tabCode: String) {
        val cur = getCatPrefs(accKey, tabCode).mapValues { (_, v) ->
            v.copy(hidden = false)
        }.filterValues { it.pinned || it.locked }
        saveCatPrefsMap(accKey, tabCode, cur)
    }

    fun getCategoryPrefsMap(acc: AccountProfile, tab: ContentTab): Map<String, CatPref> =
        getCatPrefs(acc.cacheKey(), tab.code)

    fun updateCategoryPref(
        acc: AccountProfile,
        tab: ContentTab,
        categoryId: String,
        transform: (CatPref) -> CatPref
    ) {
        val cur = getCatPrefs(acc.cacheKey(), tab.code).toMutableMap()
        val next = transform(cur[categoryId] ?: CatPref())
        if (!next.pinned && !next.hidden && !next.locked) {
            cur.remove(categoryId)
        } else {
            cur[categoryId] = next
        }
        saveCatPrefsMap(acc.cacheKey(), tab.code, cur)
    }

    fun unhideAllCategories(acc: AccountProfile, tab: ContentTab) =
        unhideAllCategories(acc.cacheKey(), tab.code)

    fun applyCategoryPrefs(
        acc: AccountProfile,
        tab: ContentTab,
        raw: List<CategoryItem>
    ): List<CategoryItem> {
        val map = getCatPrefs(acc.cacheKey(), tab.code)
        val autoAdult = getAutoLockAdult()
        val decorated = ArrayList<CategoryItem>(raw.size)
        for (c in raw) {
            if (c.id == "*") {
                decorated.add(c)
                continue
            }
            val p = map[c.id]
            if (p?.hidden == true) continue
            val isLocked = (p?.locked == true) || (autoAdult && isAdultCategoryTitle(c.title))
            decorated.add(
                c.copy(
                    pinned = p?.pinned == true,
                    hidden = false,
                    locked = isLocked
                )
            )
        }
        return decorated.sortedWith(
            compareBy<CategoryItem> {
                when {
                    it.id == "*" -> 0
                    it.pinned -> 1
                    else -> 2
                }
            }
        )
    }

    private fun saveCatPrefsMap(accKey: String, tabCode: String, map: Map<String, CatPref>) {
        val key = "cat_prefs_${sha256("$accKey|$tabCode").take(14)}"
        catPrefsRamCache[key] = map.toMap()
        if (map.isEmpty()) {
            sp.edit().remove(key).apply()
            return
        }
        val obj = JSONObject()
        map.forEach { (cid, p) ->
            obj.put(
                cid,
                JSONObject().apply {
                    put("p", p.pinned)
                    put("h", p.hidden)
                    put("l", p.locked)
                }
            )
        }
        sp.edit().putString(key, obj.toString()).apply()
    }

    // ==================== المفضّلة (⭐) والأخير (🕘) — ذاكرة فورية O(1) بلا تصادم معرّفات ====================
    fun getFavorites(): List<StreamItem> {
        synchronized(personalDataLock) {
        cachedFavorites?.let { return it }
        val loaded = readStreamList("favorites_json")
        cachedFavorites = loaded
        migrateFavoriteFolders(loaded)
        cachedFavIds = loaded.mapTo(HashSet(loaded.size * 2 + 1)) { it.favKey() }
        return loaded
    
        }
    }

    fun isFavorite(item: StreamItem): Boolean = isFavorite(item.favKey())

    fun isFavorite(keyOrId: String): Boolean {
        synchronized(personalDataLock) {
        val ids = cachedFavIds ?: run {
            getFavorites()
            cachedFavIds
        } ?: return false
        if (keyOrId.startsWith("item_v2_") || ':' in keyOrId) return ids.contains(keyOrId)
        return ids.contains("LIVE:$keyOrId") || ids.contains("VOD:$keyOrId") ||
            ids.contains("SERIES:$keyOrId") || ids.contains("EPISODE:$keyOrId")
    
        }
    }

    fun toggleFavorite(item: StreamItem): Boolean {
        synchronized(personalDataLock) {
        val stamped = item // Unowned legacy data stays unassigned; fetched items are stamped by PortalClient.
        val cur = getFavorites().toMutableList()
        val idx = cur.indexOfFirst { it.favKey() == stamped.favKey() }
        val nowFav = if (idx >= 0) {
            cur.removeAt(idx)
            setFavoriteItemFolder(stamped, "")
            false
        } else {
            cur.add(0, stamped)
            true
        }
        val capped = cur.take(400)
        cachedFavorites = capped
        cachedFavIds = capped.mapTo(HashSet(capped.size * 2 + 1)) { it.favKey() }
        writeStreamList("favorites_json", capped)
        return nowFav
    
        }
    }

    // ==================== مجلّدات المفضّلة المخصّصة (📂 Custom Favorite Folders) ====================
    private val defaultFavFolders = listOf(
        "⚽ رياضة",
        "🎬 أفلام وسهرة",
        "🧸 أطفال وعائلة",
        "📰 أخبار ووثائقي"
    )

    fun getFavoriteFolderNames(): List<String> {
        val out = LinkedHashSet<String>(defaultFavFolders)
        val raw = sp.getString("fav_custom_folders_json", null)
        if (!raw.isNullOrBlank()) {
            runCatching {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val nm = arr.optString(i).trim()
                    if (nm.isNotEmpty()) out.add(nm)
                }
            }
        }
        return out.toList()
    }

    fun addCustomFavoriteFolder(rawName: String): String {
        val clean = rawName.trim().take(28)
        if (clean.isEmpty()) return ""
        val custom = LinkedHashSet<String>()
        val existingRaw = sp.getString("fav_custom_folders_json", null)
        if (!existingRaw.isNullOrBlank()) {
            runCatching {
                val arr = JSONArray(existingRaw)
                for (i in 0 until arr.length()) {
                    val s = arr.optString(i).trim()
                    if (s.isNotEmpty()) custom.add(s)
                }
            }
        }
        val finalName = if (clean.first().code > 0x2000 || clean in defaultFavFolders) clean else "📂 $clean"
        if (finalName !in defaultFavFolders) {
            custom.add(finalName)
            val arr = JSONArray()
            custom.forEach { arr.put(it) }
            sp.edit().putString("fav_custom_folders_json", arr.toString()).apply()
        }
        return finalName
    }

    fun isDefaultFavoriteFolder(folderName: String): Boolean = folderName in defaultFavFolders

    fun deleteCustomFavoriteFolder(folderName: String): Boolean {
        if (folderName in defaultFavFolders) return false
        val existingRaw = sp.getString("fav_custom_folders_json", null) ?: return false
        val custom = ArrayList<String>()
        runCatching {
            val arr = JSONArray(existingRaw)
            for (i in 0 until arr.length()) {
                val s = arr.optString(i).trim()
                if (s.isNotEmpty() && s != folderName) custom.add(s)
            }
        }
        val arr = JSONArray()
        custom.forEach { arr.put(it) }
        sp.edit().putString("fav_custom_folders_json", arr.toString()).apply()

        val map = getFavoriteFolderMap().toMutableMap()
        val removedKeys = map.filterValues { it == folderName }.keys
        if (removedKeys.isNotEmpty()) {
            removedKeys.forEach { map.remove(it) }
            saveFavoriteFolderMap(map)
        }
        return true
    }

    /** One-time lazy migration from mappings whose original favorite owner is known.
     * Ambiguous/orphan keys remain in storage; they are never inherited by a new account. */
    private fun migrateFavoriteFolders(items: List<StreamItem>) {
        val raw=sp.getString("fav_item_folders_json",null) ?: return
        val obj=runCatching { JSONObject(raw) }.getOrNull() ?: return
        var changed=false
        val originalKeys=obj.keys().asSequence().toList()
        for(key in originalKeys) {
            if(key.startsWith("item_v2_")) continue
            val matches=items.filter { "${it.kind.name}:${it.id}"==key || it.id==key }
            if(matches.size!=1) continue
            val target=matches.single().favKey()
            if(target!=key) {
                if(!obj.has(target)) obj.put(target,obj.get(key))
                obj.remove(key);changed=true
            }
        }
        if(changed) sp.edit().putString("fav_item_folders_json",obj.toString()).apply()
    }

    fun getFavoriteFolderMap(): Map<String, String> {
        synchronized(personalDataLock) {
        getFavorites() // Migrate mappings only against the original saved owners before any read/write.
        val raw = sp.getString("fav_item_folders_json", null) ?: return emptyMap()
        return try {
            val obj = JSONObject(raw)
            val out = HashMap<String, String>(obj.length())
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = obj.optString(k).trim()
                if (k.isNotEmpty() && v.isNotEmpty()) out[k] = v
            }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    
        }
    }

    private fun saveFavoriteFolderMap(map: Map<String, String>) {
        synchronized(personalDataLock) {
        if (map.isEmpty()) {
            sp.edit().remove("fav_item_folders_json").apply()
            return
        }
        val obj = JSONObject()
        map.forEach { (k, v) ->
            if (k.isNotBlank() && v.isNotBlank()) obj.put(k, v)
        }
        sp.edit().putString("fav_item_folders_json", obj.toString()).apply()
    
        }
    }

    fun getFavoriteItemFolder(item: StreamItem): String {
        synchronized(personalDataLock) {
        val map = getFavoriteFolderMap()
        return map[item.favKey()].orEmpty()
    
        }
    }

    fun getFavoriteItemFolder(itemId: String): String {
        synchronized(personalDataLock) {
        if (itemId.isBlank()) return ""
        return getFavoriteFolderMap()[itemId].orEmpty()
    
        }
    }

    fun setFavoriteItemFolder(item: StreamItem, folderName: String) {
        synchronized(personalDataLock) {
        if (folderName.isNotBlank() && !isFavorite(item)) {
            toggleFavorite(item)
        }
        val map = getFavoriteFolderMap().toMutableMap()
        // Old ambiguous mappings are retained, never applied to another account.
        if (folderName.isBlank()) {
            map.remove(item.favKey())
        } else {
            map[item.favKey()] = folderName.trim()
        }
        saveFavoriteFolderMap(map)
    
        }
    }

    fun setFavoriteItemFolder(itemId: String, folderName: String) {
        synchronized(personalDataLock) {
        if (itemId.isBlank()) return
        val map = getFavoriteFolderMap().toMutableMap()
        if (folderName.isBlank()) {
            if (map.remove(itemId) != null) saveFavoriteFolderMap(map)
        } else {
            map[itemId] = folderName.trim()
            saveFavoriteFolderMap(map)
        }
    
        }
    }

    fun getFavoriteCategories(): List<CategoryItem> {
        synchronized(personalDataLock) {
        val allFavs = getFavorites()
        val folderMap = getFavoriteFolderMap()
        val folders = getFavoriteFolderNames()
        val counts = HashMap<String, Int>()
        for (it in allFavs) {
            val f = folderMap[it.favKey()].orEmpty()
            if (f.isNotEmpty()) counts[f] = (counts[f] ?: 0) + 1
        }
        val cats = ArrayList<CategoryItem>(folders.size + 2)
        cats.add(CategoryItem(id = "*", title = "⭐ كل المفضّلة", count = allFavs.size))
        for (f in folders) {
            cats.add(CategoryItem(id = f, title = f, count = counts[f] ?: 0))
        }
        cats.add(CategoryItem(id = "__new_fav_folder__", title = "➕ إنشاء مجلّد جديد…", count = 0))
        return cats
    
        }
    }

    fun getFavoritesInFolder(folderId: String): List<StreamItem> {
        synchronized(personalDataLock) {
        val all = getFavorites()
        if (folderId.isBlank() || folderId == "*") return all
        val map = getFavoriteFolderMap()
        return all.filter { map[it.favKey()] == folderId }
    
        }
    }

    fun getRecent(): List<StreamItem> {
        synchronized(personalDataLock) {
        cachedRecent?.let { return it }
        val loaded = readStreamList("recent_json")
        cachedRecent = loaded
        return loaded
    
        }
    }

    fun addRecent(item: StreamItem) {
        synchronized(personalDataLock) {
        if (item.kind == ItemKind.SEASON || item.kind == ItemKind.CATCHUP) return
        val stamped = item // Unowned legacy data stays unassigned; fetched items are stamped by PortalClient.
        val cur = getRecent().toMutableList()
        cur.removeAll { it.favKey() == stamped.favKey() }
        cur.add(0, stamped)
        val capped = cur.take(50)
        cachedRecent = capped
        writeStreamList("recent_json", capped)
    
        }
    }

    fun removeRecentItem(item: StreamItem) = removeRecentItem(item.id,item.kind,item.accountId)

    fun removeRecentItem(itemId: String, kind: ItemKind? = null, accountId: String = getActiveAccountId()) {
        synchronized(personalDataLock) {
        if(itemId.isBlank()) return
        val cur=getRecent().filterNot { it.accountId==accountId && it.id==itemId && (kind==null || it.kind==kind) }
        cachedRecent=cur
        writeStreamList("recent_json",cur)
        clearResumePos(itemId,kind,accountId)
    
        }
    }

    fun clearRecent() {
        synchronized(personalDataLock) {
        cachedRecent = emptyList()
        sp.edit().remove("recent_json").apply()
    
        }
    }

    fun clearHistory() = clearRecent()

    // ==================== مواضع متابعة الأفلام والحلقات (⏵ مواصلة المشاهدة) ====================
    private fun resumeSpKey(itemId: String, kind: ItemKind, accountId: String): String =
        "pos_v2_" + com.iptvlite.tv.model.DataIdentity.digest(accountId,kind.name,itemId)

    private fun resumeFallbackKey(item: StreamItem): String {
        val normName = item.name.removePrefix("⏵ متابعة المشاهدة:").trim().lowercase(Locale.US).replace(Regex("\\s+"), " ")
        if(normName.isEmpty()) return ""
        return "pos_fb_v2_"+com.iptvlite.tv.model.DataIdentity.digest(item.accountId,item.kind.name,
            item.seriesId.trim(),item.seasonId.trim(),normName)
    }

    private fun isCompletedThreshold(posMs: Long, durMs: Long): Boolean {
        return durMs >= 120_000L && posMs >= (durMs * 95L) / 100L && posMs >= durMs - 30_000L
    }

    fun getResumePos(item: StreamItem): Long {
        synchronized(personalDataLock) {
        val key=resumeSpKey(item.id,item.kind,item.accountId)
        resumePosRamCache[key]?.let { return it }
        val saved=sp.getLong(key,-1L)
        if(saved>=0L) {resumePosRamCache[key]=saved;return saved}
        // Legacy JSON has an explicit owner and per-entry snapshot. Never use global pos_ID
        // for a scoped account: its last writer is unknowable on multi-account installations.
        val owned=getResumeEntries().firstOrNull { it.item.favKey()==item.favKey() }
        if(owned!=null) {resumePosRamCache[key]=owned.posMs;return owned.posMs}
        return 0L
    
        }
    }

    fun getResumePos(itemId: String, kind: ItemKind? = null, accountId: String = getActiveAccountId()): Long {
        synchronized(personalDataLock) {
        if(itemId.isBlank())return 0L
        if(kind!=null)return getResumePos(StreamItem(itemId,"",kind=kind,accountId=accountId))
        return getResumeEntries().firstOrNull {it.item.id==itemId && it.item.accountId==accountId}?.posMs ?: 0L
    
        }
    }

    fun saveResumePos(itemId: String, posMs: Long, durMs: Long, kind: ItemKind = ItemKind.VOD,
        accountId: String = getActiveAccountId()) {
        synchronized(personalDataLock) {
        if(itemId.isBlank() || posMs<MIN_RESUME_POS_MS)return
        if(isCompletedThreshold(posMs,durMs)) {clearResumePos(itemId,kind,accountId);return}
        val key=resumeSpKey(itemId,kind,accountId)
        resumePosRamCache[key]=posMs
        sp.edit().putLong(key,posMs).apply()
        }
    }

    fun saveResumeEntry(item: StreamItem, posMs: Long, durMs: Long, accountId: String = "") {
        synchronized(personalDataLock) {
        if (item.id.isBlank()) return
        if (posMs < MIN_RESUME_POS_MS) return
        val normalizedItem = if (item.name.startsWith("⏵ متابعة المشاهدة:")) {
            item.copy(name = item.name.removePrefix("⏵ متابعة المشاهدة:").trim())
        } else {
            item
        }
        val effAccId = normalizedItem.accountId.ifBlank { accountId }
        val stamped = if (normalizedItem.accountId.isNotBlank()) normalizedItem else normalizedItem.copy(accountId = effAccId)
        if (isCompletedThreshold(posMs, durMs)) {
            clearResumePos(stamped)
            return
        }
        val spKey = resumeSpKey(stamped.id, stamped.kind, stamped.accountId)
        val fbKey = resumeFallbackKey(stamped)
        resumePosRamCache[spKey] = posMs

        if (fbKey.isNotEmpty()) resumePosRamCache[fbKey] = posMs

        val ed = sp.edit()
            .putLong(spKey, posMs)

        if (fbKey.isNotEmpty()) ed.putLong(fbKey, posMs)
        ed.apply()

        val cur = getResumeEntries().toMutableList()
        cur.removeAll {
            it.item.favKey() == stamped.favKey()
        }
        cur.add(
            0,
            ResumeEntry(
                item = stamped,
                posMs = posMs,
                durMs = durMs.coerceAtLeast(0L),
                accountId = effAccId,
                updatedEpochSec = System.currentTimeMillis() / 1000L
            )
        )
        writeResumeEntries(cur.take(60))
    
        }
    }

    fun getLatestSeriesResumeEntry(seriesId: String, accountId: String = getActiveAccountId()): ResumeEntry? {
        synchronized(personalDataLock) {
        if (seriesId.isBlank()) return null
        return getResumeEntries().firstOrNull {
            it.item.kind == ItemKind.EPISODE &&
                it.item.seriesId == seriesId &&
                it.item.accountId == accountId &&
                it.posMs >= MIN_RESUME_POS_MS
        }
    
        }
    }

    fun getResumeEntries(): List<ResumeEntry> {
        synchronized(personalDataLock) {
        cachedResumeEntries?.let { return it }
        val raw = sp.getString("resume_entries_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<ResumeEntry>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isBlank()) continue
                val kind = runCatching {
                    ItemKind.valueOf(o.optString("kind", "VOD"))
                }.getOrDefault(ItemKind.VOD)
                val accId = o.optString("accId")
                val spKey = resumeSpKey(id, kind, accId)
                val posMs = resumePosRamCache[spKey] ?: sp.getLong(spKey,o.optLong("posMs",0L))
                if (posMs < MIN_RESUME_POS_MS) continue
                resumePosRamCache[spKey] = posMs
                val item = StreamItem(
                    id = id,
                    name = o.optString("name"),
                    cmd = o.optString("cmd"),
                    categoryId = o.optString("categoryId"),
                    logo = o.optString("logo"),
                    kind = kind,
                    subtitle = o.optString("subtitle"),
                    seriesId = o.optString("seriesId"),
                    seasonId = o.optString("seasonId"),
                    containerExt = o.optString("containerExt"),
                    year = o.optString("year"),
                    rating = o.optString("rating"),
                    accountId = accId
                )
                out.add(
                    ResumeEntry(
                        item = item,
                        posMs = posMs,
                        durMs = o.optLong("durMs", 0L),
                        accountId = accId,
                        updatedEpochSec = o.optLong("updatedTs", 0L)
                    )
                )
            }
            cachedResumeEntries = out
            out
        } catch (_: Exception) {
            emptyList()
        }
    
        }
    }

    private fun writeResumeEntries(list: List<ResumeEntry>) {
        synchronized(personalDataLock) {
        cachedResumeEntries = list
        val arr = JSONArray()
        for (e in list) {
            val s = e.item
            arr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("name", s.name)
                    put("cmd", s.cmd)
                    put("categoryId", s.categoryId)
                    put("logo", s.logo)
                    put("kind", s.kind.name)
                    put("subtitle", s.subtitle)
                    put("seriesId", s.seriesId)
                    put("seasonId", s.seasonId)
                    put("containerExt", s.containerExt)
                    put("year", s.year)
                    put("rating", s.rating)
                    put("posMs", e.posMs)
                    put("durMs", e.durMs)
                    put("accId", e.accountId)
                    put("updatedTs", e.updatedEpochSec)
                }
            )
        }
        sp.edit().putString("resume_entries_json", arr.toString()).apply()
    
        }
    }

    fun clearResumePos(item: StreamItem) {
        synchronized(personalDataLock) {
        clearResumePos(item.id,item.kind,item.accountId)
    
        }
    }

    fun clearResumePos(itemId: String, kind: ItemKind? = null, accountId: String = getActiveAccountId()) {
        synchronized(personalDataLock) {
        if(itemId.isBlank())return
        val existing=getResumeEntries()
        val removed=existing.filter {it.item.accountId==accountId && it.item.id==itemId && (kind==null || it.item.kind==kind)}
        val ed=sp.edit()
        val kinds=if(kind==null)ItemKind.values().toList()else listOf(kind)
        for(k in kinds) {
            val key=resumeSpKey(itemId,k,accountId);resumePosRamCache.remove(key);ed.remove(key)
        }
        removed.forEach {entry->
            val fb=resumeFallbackKey(entry.item)
            if(fb.isNotEmpty()) {resumePosRamCache.remove(fb);ed.remove(fb)}
        }
        ed.apply()
        writeResumeEntries(existing.filterNot {it in removed})
    
        }
    }

    fun clearAllResumeEntries() {
        synchronized(personalDataLock) {
        val cur = getResumeEntries()
        resumePosRamCache.clear()
        cachedResumeEntries = emptyList()
        val e = sp.edit().remove("resume_entries_json")
        // Explicit clear-all includes quarantined legacy keys; individual removal never does.
        sp.all.keys.filter { it.startsWith("pos_") }.forEach { e.remove(it) }
        for (r in cur) {
            e.remove("pos_${r.item.id}")
            e.remove(resumeSpKey(r.item.id, r.item.kind, r.item.accountId))
            val fb = resumeFallbackKey(r.item)
            if (fb.isNotEmpty()) e.remove(fb)
        }
        e.apply()
    
        }
    }

    // ==================== تنبيهات البرامج (🔔) والتسجيلات المجدولة (⏰) — ذاكرة O(1) ====================
    fun hasActiveSchedules(): Boolean {
        return getReminders().isNotEmpty() ||
            getScheduledRecs().any { it.state == "pending" || it.state == "recording" }
    }

    fun getReminders(): List<ProgramReminder> {
        synchronized(schedulesLock) {
        cachedReminders?.let { return it }
        val raw = sp.getString("reminders_json", null) ?: run {
            cachedReminders = emptyList()
            return emptyList()
        }
        val parsed = try {
            val arr = JSONArray(raw)
            val out = ArrayList<ProgramReminder>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    ProgramReminder(
                        id = o.optString("id"),
                        channelId = o.optString("chId"),
                        channelName = o.optString("chName"),
                        channelCmd = o.optString("chCmd"),
                        progName = o.optString("prog"),
                        startTs = o.optLong("startTs"),
                        remindAtTs = o.optLong("remindAt"),
                        accountId = o.optString("accId")
                    )
                )
            }
            out.sortedBy { it.remindAtTs }
        } catch (_: Exception) {
            emptyList()
        }
        cachedReminders = parsed
        return parsed
    
        }
    }

    fun addReminder(rem: ProgramReminder) {
        synchronized(schedulesLock) {
        val cur = getReminders().toMutableList()
        val replaced = cur.filter { it.accountId == rem.accountId && it.channelId == rem.channelId && it.startTs == rem.startTs }
        replaced.forEach { ScheduleHelper.cancelReminder(appCtx, it.id) }
        cur.removeAll { it.accountId == rem.accountId && it.channelId == rem.channelId && it.startTs == rem.startTs }
        cur.add(rem)
        saveReminders(cur.take(60))
        ScheduleHelper.scheduleReminder(appCtx, rem)
    
        }
    }

    fun removeReminder(id: String) {
        synchronized(schedulesLock) {
        if (id.isBlank()) return
        ScheduleHelper.cancelReminder(appCtx, id)
        val cur = getReminders().filterNot { it.id == id }
        saveReminders(cur)
    
        }
    }

    fun clearReminders() {
        synchronized(schedulesLock) {
        getReminders().forEach { ScheduleHelper.cancelReminder(appCtx, it.id) }
        cachedReminders = emptyList()
        sp.edit().remove("reminders_json").apply()
    
        }
    }

    fun getScheduledRecs(): List<ScheduledRecording> {
        synchronized(schedulesLock) {
        cachedScheduledRecs?.let { return it }
        val raw = sp.getString("scheduled_recs_json", null) ?: run {
            cachedScheduledRecs = emptyList()
            return emptyList()
        }
        val parsed = try {
            val arr = JSONArray(raw)
            val out = ArrayList<ScheduledRecording>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    ScheduledRecording(
                        id = o.optString("id"),
                        accountId = o.optString("accId"),
                        channelId = o.optString("chId"),
                        channelName = o.optString("chName"),
                        channelCmd = o.optString("chCmd"),
                        progName = o.optString("prog"),
                        startTs = o.optLong("startTs"),
                        durationMin = o.optInt("durMin", 30).coerceIn(1, 360),
                        state = o.optString("state", "pending"),
                        filePath = o.optString("filePath")
                    )
                )
            }
            out.sortedBy { it.startTs }
        } catch (_: Exception) {
            emptyList()
        }
        cachedScheduledRecs = parsed
        return parsed
    
        }
    }

    fun addScheduledRec(rec: ScheduledRecording) {
        synchronized(schedulesLock) {
        val cur = getScheduledRecs().toMutableList()
        val replaced = cur.filter { it.accountId == rec.accountId && it.channelId == rec.channelId && it.startTs == rec.startTs && it.state == "pending" }
        replaced.forEach { ScheduleHelper.cancelRecording(appCtx, it.id) }
        cur.removeAll { it.accountId == rec.accountId && it.channelId == rec.channelId && it.startTs == rec.startTs && it.state == "pending" }
        cur.add(rec)
        saveScheduledRecs(cur.take(60))
        ScheduleHelper.scheduleRecording(appCtx, rec)
    
        }
    }

    fun updateScheduledRecState(id: String, state: String, filePath: String = "") {
        synchronized(schedulesLock) {
        val cur = getScheduledRecs().map {
            if (it.id == id) it.copy(state = state, filePath = filePath.ifBlank { it.filePath }) else it
        }
        saveScheduledRecs(cur)
    
        }
    }

    fun removeScheduledRec(id: String) {
        synchronized(schedulesLock) {
        if (id.isBlank()) return
        ScheduleHelper.cancelRecording(appCtx, id)
        saveScheduledRecs(getScheduledRecs().filterNot { it.id == id })
    
        }
    }

    fun clearScheduledRecs() {
        synchronized(schedulesLock) {
        getScheduledRecs().forEach { ScheduleHelper.cancelRecording(appCtx, it.id) }
        cachedScheduledRecs = emptyList()
        sp.edit().remove("scheduled_recs_json").apply()
    
        }
    }

    fun popDueScheduledRecs(nowEpochSec: Long): List<ScheduledRecording> {
        synchronized(schedulesLock) {
        val all = getScheduledRecs()
        if (all.isEmpty()) return emptyList()
        // إذا فات موعد البرنامج بأكثر من ساعتين دون تشغيل نعلّمه كفائت
        var mutated = false
        val due = ArrayList<ScheduledRecording>()
        val updated = all.map { r ->
            if (r.state == "pending") {
                val endSec = r.startTs + r.durationMin * 60L
                when {
                    nowEpochSec > endSec + 300L -> {
                        mutated = true
                        r.copy(state = "missed")
                    }
                    r.startTs <= nowEpochSec + 15L -> {
                        mutated = true
                        val active = r.copy(state = "recording")
                        due.add(active)
                        active
                    }
                    else -> r
                }
            } else {
                r
            }
        }
        if (mutated) saveScheduledRecs(updated)
        return due
    
        }
    }

    private fun saveScheduledRecs(list: List<ScheduledRecording>) {
        synchronized(schedulesLock) {
        cachedScheduledRecs = list.sortedBy { it.startTs }
        val arr = JSONArray()
        for (r in list) {
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("accId", r.accountId)
                    put("chId", r.channelId)
                    put("chName", r.channelName)
                    put("chCmd", r.channelCmd)
                    put("prog", r.progName)
                    put("startTs", r.startTs)
                    put("durMin", r.durationMin)
                    put("state", r.state)
                    put("filePath", r.filePath)
                }
            )
        }
        sp.edit().putString("scheduled_recs_json", arr.toString()).apply()
    
        }
    }

    fun popDueReminders(nowEpochSec: Long): List<ProgramReminder> {
        synchronized(schedulesLock) {
        val all = getReminders()
        if (all.isEmpty()) return emptyList()
        val due = all.filter { it.remindAtTs <= nowEpochSec }
        if (due.isNotEmpty()) {
            due.forEach { ScheduleHelper.cancelReminder(appCtx, it.id) }
            val remaining = all.filter { it.remindAtTs > nowEpochSec }
            saveReminders(remaining)
        }
        return due
    
        }
    }

    private fun saveReminders(list: List<ProgramReminder>) {
        synchronized(schedulesLock) {
        cachedReminders = list.sortedBy { it.remindAtTs }
        val arr = JSONArray()
        for (r in list) {
            arr.put(
                JSONObject().apply {
                    put("id", r.id)
                    put("chId", r.channelId)
                    put("chName", r.channelName)
                    put("chCmd", r.channelCmd)
                    put("prog", r.progName)
                    put("startTs", r.startTs)
                    put("remindAt", r.remindAtTs)
                    put("accId", r.accountId)
                }
            )
        }
        sp.edit().putString("reminders_json", arr.toString()).apply()
    
        }
    }

    // ==================== إحصائيات المشاهدة (📊) ====================
    fun recordStreamOpened(kind: ItemKind) {
        val e = sp.edit()
        e.putInt("stat_opens_total", sp.getInt("stat_opens_total", 0) + 1)
        when (kind) {
            ItemKind.LIVE -> e.putInt("stat_opens_live", sp.getInt("stat_opens_live", 0) + 1)
            ItemKind.VOD -> e.putInt("stat_opens_vod", sp.getInt("stat_opens_vod", 0) + 1)
            ItemKind.EPISODE -> e.putInt("stat_opens_ep", sp.getInt("stat_opens_ep", 0) + 1)
            ItemKind.CATCHUP -> e.putInt("stat_opens_cu", sp.getInt("stat_opens_cu", 0) + 1)
            else -> Unit
        }
        e.apply()
    }

    fun recordWatchSeconds(seconds: Long) {
        if (seconds <= 0L) return
        val prev = sp.getLong("stat_watch_sec", 0L)
        sp.edit().putLong("stat_watch_sec", prev + seconds.coerceAtMost(28_800L)).apply()
    }

    fun incrementWatchCount(kind: ItemKind) = recordStreamOpened(kind)
    fun addWatchSeconds(seconds: Long) = recordWatchSeconds(seconds)
    fun getWatchSeconds(): Long = sp.getLong("stat_watch_sec", 0L)
    fun incrementRecCount() {
        sp.edit().putInt("stat_recs_total", sp.getInt("stat_recs_total", 0) + 1).apply()
    }
    fun getRecCount(): Int = sp.getInt("stat_recs_total", 0)
    fun getWatchCounts(): Triple<Int, Int, Int> = Triple(
        sp.getInt("stat_opens_live", 0),
        sp.getInt("stat_opens_vod", 0) + sp.getInt("stat_opens_ep", 0),
        sp.getInt("stat_opens_cu", 0)
    )

    fun getStatsMap(): Map<String, String> {
        val totalSec = sp.getLong("stat_watch_sec", 0L)
        val hours = totalSec / 3600L
        val mins = (totalSec % 3600L) / 60L
        return linkedMapOf(
            "⏱ إجمالي وقت المشاهدة" to "${hours} ساعة و ${mins} دقيقة",
            "📺 القنوات المباشرة المشغّلة" to "${sp.getInt("stat_opens_live", 0)}",
            "🎬 الأفلام المشغّلة" to "${sp.getInt("stat_opens_vod", 0)}",
            "📚 الحلقات المشغّلة" to "${sp.getInt("stat_opens_ep", 0)}",
            "↺ برامج الأرشيف المشغّلة" to "${sp.getInt("stat_opens_cu", 0)}",
            "⏺ التسجيلات المحفوظة" to "${getRecCount()}",
            "⭐ عدد عناصر المفضّلة" to "${getFavorites().size}",
            "👤 عدد الاشتراكات المحفوظة" to "${getAccounts().size}"
        )
    }

    fun resetStats() {
        sp.edit()
            .remove("stat_watch_sec")
            .remove("stat_opens_total")
            .remove("stat_opens_live")
            .remove("stat_opens_vod")
            .remove("stat_opens_ep")
            .remove("stat_opens_cu")
            .remove("stat_recs_total")
            .apply()
    }

    // ==================== استيراد البوابات والنسخ الاحتياطي (JSON / working_portals / نصّي) ====================
    fun exportFullBackupJson(): String {
        synchronized(accountsLock) { synchronized(personalDataLock) {
        val root = JSONObject()
        root.put("app", "IPTV_Lite_TV")
        root.put("version", 4)
        root.put("exportedAt", System.currentTimeMillis() / 1000L)
        root.put("accounts", JSONArray(encodeAccountList(getAccounts())))
        root.put("favorites", JSONArray(sp.getString("favorites_json", "[]") ?: "[]"))
        root.put("fav_custom_folders", JSONArray(sp.getString("fav_custom_folders_json", "[]") ?: "[]"))
        root.put("fav_item_folders", JSONObject(sp.getString("fav_item_folders_json", "{}") ?: "{}"))
        root.put("recent", JSONArray(sp.getString("recent_json", "[]") ?: "[]"))
        val resumeJson=JSONArray(sp.getString("resume_entries_json", "[]") ?: "[]")
        for(i in 0 until resumeJson.length()) {
            val o=resumeJson.getJSONObject(i)
            val kind=runCatching {ItemKind.valueOf(o.optString("kind","VOD"))}.getOrDefault(ItemKind.VOD)
            val key=resumeSpKey(o.optString("id"),kind,o.optString("accId"))
            o.put("posMs",sp.getLong(key,o.optLong("posMs")))
        }
        root.put("resume_entries",resumeJson)
        val prefsObj = JSONObject().apply {
            val p = loadPrefs()
            put("cacheMs", p.cacheMs)
            put("autoNextEpisode", p.autoNextEpisode)
            put("autoReconnect", p.autoReconnect)
            put("aspectMode", p.aspectMode)
            put("themeMode", p.themeMode)
            put("autoPlayLastOnStart", p.autoPlayLastOnStart)
            put("audioBoostPct", p.audioBoostPct)
            put("subSizeSp", p.subSizeSp)
            put("subColorIndex", p.subColorIndex)
            put("subBgTranslucent", p.subBgTranslucent)
            put("autoLockAdult", getAutoLockAdult())
        }
        root.put("prefs", prefsObj)
        return root.toString(2)
        } }
    }

    /**
     * يدعم بدقّة:
     * 1) ملف البوابات اليومية `working_portals.json` الخاص بنسخة الكمبيوتر (`{"portals": [{"portal":..., "mac":..., "ms":...}]}`)
     * 2) ملف النسخة الاحتياطية لسطح المكتب `iptv_backup.json` (`tables.saved_accounts` + `tables.favorites`)
     * 3) ملف النسخة الاحتياطية للتلفاز والهاتف (`accounts` + `favorites` + `prefs`)
     * 4) القوائم النصية الملصوقة مباشرة (سواء `URL | MAC` أو كتل `Portal: ... MAC: ...` أو روابط Xtream/M3U)
     */
    fun importAnyPortalsOrBackup(rawContent: String): ImportSummary {
        val trimmed = rawContent.trim().removePrefix("\uFEFF")
        if (trimmed.isEmpty()) {
            return ImportSummary(0, 0, "الملف أو النص فارغ")
        }

        // A channel playlist is imported as ONE private local M3U account, never as portal URLs per line.
        if (trimmed.startsWith("#EXTM3U", true) || trimmed.startsWith("#EXTINF", true)) {
            if (trimmed.contains("#EXT-X-TARGETDURATION", true)) {
                return ImportSummary(0, 0, "اختر قائمة قنوات M3U، لا ملف مقاطع بث HLS؛ أضف رابط البث من إعداد الاشتراك.")
            }
            if (trimmed.toByteArray(Charsets.UTF_8).size > 18_000_000) return ImportSummary(0, 0, "الحد الأقصى للقائمة 18 ميجابايت")
            return runCatching {
                val dir = java.io.File(appCtx.filesDir, "imported_playlists").apply { mkdirs() }
                val hash = java.security.MessageDigest.getInstance("SHA-256").digest(trimmed.toByteArray(Charsets.UTF_8))
                    .joinToString("") { "%02x".format(it.toInt() and 255) }.take(24)
                val file = java.io.File(dir, "$hash.m3u")
                val atomic = android.util.AtomicFile(file)
                val stream = atomic.startWrite()
                try { stream.write(trimmed.toByteArray(Charsets.UTF_8)); atomic.finishWrite(stream) }
                catch (err: Exception) { atomic.failWrite(stream); throw err }
                val acc = PortalClient.normalizeAccountInput(ProviderType.M3U, "قائمة مستوردة", android.net.Uri.fromFile(file).toString(), "", "", "")
                val saved = upsertAccount(acc)
                setActiveAccountId(saved.id)
                ImportSummary(1, 0, "✔ تم حفظ قائمة القنوات محلياً وتفعيلها")
            }.getOrElse { ImportSummary(0, 0, "تعذّر حفظ قائمة القنوات؛ تحقّق من مساحة التخزين") }
        }

        if(trimmed.startsWith("{")) {
            val full=runCatching {JSONObject(trimmed)}.getOrNull()
            if(full?.optString("app")=="IPTV_Lite_TV")return importFullBackup(full)
        }

        var accAdded = 0
        var favAdded = 0

        // أولاً: تجربة التحليل كـ JSON
        if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
            try {
                if (trimmed.startsWith("[")) {
                    val arr = JSONArray(trimmed)
                    accAdded += importPortalJsonArray(arr)
                } else {
                    val obj = JSONObject(trimmed)
                    // 1) صيغة working_portals.json من الكمبيوتر
                    obj.optJSONArray("portals")?.let { pArr ->
                        accAdded += importPortalJsonArray(pArr)
                    }
                    // 2) صيغة النسخة الاحتياطية لـ Android TV
                    obj.optJSONArray("accounts")?.let { aArr ->
                        accAdded += importPortalJsonArray(aArr)
                    }
                    obj.optJSONArray("favorites")?.let { fArr ->
                        favAdded += importTvFavoritesArray(fArr)
                    }
                    obj.optJSONArray("fav_custom_folders")?.let { cf ->
                        for (i in 0 until cf.length()) {
                            val nm = cf.optString(i).trim()
                            if (nm.isNotEmpty()) addCustomFavoriteFolder(nm)
                        }
                    }
                    obj.optJSONObject("fav_item_folders")?.let { fm ->
                        val merged = getFavoriteFolderMap().toMutableMap()
                        val keys = fm.keys()
                        while (keys.hasNext()) {
                            val k = keys.next()
                            val v = fm.optString(k).trim()
                            if (k.isNotEmpty() && v.isNotEmpty()) merged[k] = v
                        }
                        saveFavoriteFolderMap(merged)
                    }
                    obj.optJSONObject("prefs")?.let { po ->
                        val cur = loadPrefs()
                        savePrefs(
                            cur.copy(
                                cacheMs = po.optInt("cacheMs", cur.cacheMs),
                                autoNextEpisode = po.optBoolean("autoNextEpisode", cur.autoNextEpisode),
                                autoReconnect = po.optBoolean("autoReconnect", cur.autoReconnect),
                                aspectMode = po.optInt("aspectMode", cur.aspectMode),
                                themeMode = po.optString("themeMode", cur.themeMode),
                                autoPlayLastOnStart = po.optBoolean("autoPlayLastOnStart", cur.autoPlayLastOnStart),
                                audioBoostPct = po.optInt("audioBoostPct", cur.audioBoostPct),
                                subSizeSp = po.optInt("subSizeSp", cur.subSizeSp),
                                subColorIndex = po.optInt("subColorIndex", cur.subColorIndex),
                                subBgTranslucent = po.optBoolean("subBgTranslucent", cur.subBgTranslucent)
                            )
                        )
                    }
                    // 3) صيغة النسخة الاحتياطية لبرنامج الكمبيوتر iptv_app.py (tables.saved_accounts / favorites)
                    obj.optJSONObject("tables")?.let { tables ->
                        tables.optJSONArray("saved_accounts")?.let { sa ->
                            accAdded += importPortalJsonArray(sa)
                        }
                        tables.optJSONArray("favorites")?.let { df ->
                            favAdded += importDesktopFavoritesArray(df)
                        }
                    }
                }
                if (accAdded > 0) {
                    sortAccountsByFastest()
                    if (getActiveAccountId().isBlank()) {
                        getAccounts().firstOrNull()?.let { setActiveAccountId(it.id) }
                    }
                }
                return ImportSummary(
                    accountsAdded = accAdded,
                    favoritesAdded = favAdded,
                    message = "✔ تم استيراد $accAdded اشتراك/بوابة" +
                        if (favAdded > 0) " و $favAdded عنصر مفضّلة" else ""
                )
            } catch (_: Exception) {
                // نكمل للتحليل النصّي الذكي إن لم يكن JSON صالحاً
            }
        }

        // ثانياً: التحليل النصّي الذكي (لصق قوائم السيرفرات + الماكات أو روابط Xtream / M3U)
        val macRe = Regex("""([0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5})""")
        val urlRe = Regex("""(https?://[^\s|,;"'<>]+)""", RegexOption.IGNORE_CASE)

        var pendingUrl = ""
        for (rawLine in trimmed.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#EXTINF", ignoreCase = true)) continue

            val foundUrl = urlRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()
            val foundMac = macRe.find(line)?.groupValues?.getOrNull(1)?.trim().orEmpty()

            if (foundUrl.isNotEmpty() && foundMac.isNotEmpty()) {
                upsertAccount(
                    PortalClient.normalizeAccountInput(
                        provider = ProviderType.STALKER,
                        rawName = "",
                        rawUrl = foundUrl,
                        rawMac = foundMac,
                        rawUser = "",
                        rawPass = ""
                    )
                )
                accAdded++
                pendingUrl = ""
            } else if (foundUrl.isNotEmpty()) {
                if (foundUrl.contains("username=", ignoreCase = true) && foundUrl.contains("password=", ignoreCase = true)) {
                    upsertAccount(
                        PortalClient.normalizeAccountInput(
                            provider = ProviderType.XTREAM,
                            rawName = "",
                            rawUrl = foundUrl,
                            rawMac = "",
                            rawUser = "",
                            rawPass = ""
                        )
                    )
                    accAdded++
                    pendingUrl = ""
                } else if (foundUrl.contains(".m3u", ignoreCase = true)) {
                    upsertAccount(
                        PortalClient.normalizeAccountInput(
                            provider = ProviderType.M3U,
                            rawName = "",
                            rawUrl = foundUrl,
                            rawMac = "",
                            rawUser = "",
                            rawPass = ""
                        )
                    )
                    accAdded++
                    pendingUrl = ""
                } else {
                    pendingUrl = foundUrl
                }
            } else if (foundMac.isNotEmpty() && pendingUrl.isNotEmpty()) {
                upsertAccount(
                    PortalClient.normalizeAccountInput(
                        provider = ProviderType.STALKER,
                        rawName = "",
                        rawUrl = pendingUrl,
                        rawMac = foundMac,
                        rawUser = "",
                        rawPass = ""
                    )
                )
                accAdded++
            }
        }

        if (accAdded > 0 && getActiveAccountId().isBlank()) {
            getAccounts().firstOrNull()?.let { setActiveAccountId(it.id) }
        }
        return ImportSummary(
            accountsAdded = accAdded,
            favoritesAdded = favAdded,
            message = if (accAdded > 0) "✔ تم استخراج وحفظ $accAdded سيرفر بنجاح"
            else "⚠ لم يُعثر على سيرفرات أو عناوين MAC صالحة في النص"
        )
    }

    /** Additive restore: local personal entries win conflicts. Unknown owners remain isolated. */
    private fun importFullBackup(root:JSONObject):ImportSummary = synchronized(accountsLock) {
        synchronized(personalDataLock) {
            try {
                val plan=FullBackupPlan(root,getAccounts())
                val incomingFav=parseStreamList(plan.favorites)
                val incomingRecent=parseStreamList(plan.recent)
                require(incomingFav.size==plan.favorites.length() && incomingRecent.size==plan.recent.length())
                val getFavoritesBeforeImportCount=getFavorites().size
                val favs=(getFavorites()+incomingFav).distinctBy {it.favKey()}
                val recent=(getRecent()+incomingRecent).distinctBy {it.favKey()}
                require(favs.size<=400 && recent.size<=50) {"Personal data capacity exceeded"}
                val entries=getResumeEntries().toMutableList()
                for(i in 0 until plan.resume.length()) {
                    val o=plan.resume.getJSONObject(i)
                    val owner=o.optString("accId")
                    val itemJson=JSONObject(o.toString()).put("accountId",owner)
                    val item=parseStreamList(JSONArray().put(itemJson)).single()
                    val pos=o.optLong("posMs")
                    if(entries.none {it.item.favKey()==item.favKey()} && pos>=MIN_RESUME_POS_MS)
                        entries.add(ResumeEntry(item,pos,o.optLong("durMs"),owner,o.optLong("updatedTs")))
                }
                require(entries.size<=60) {"Resume capacity exceeded"}
                val folders=plan.folders+getFavoriteFolderMap() // Existing choices win.
                val custom=(getFavoriteFolderNames()+plan.customFolders).distinct()
                val cur=loadPrefs();val po=plan.prefs
                val prefs=if(po==null)cur else cur.copy(
                    cacheMs=po.optInt("cacheMs",cur.cacheMs).coerceIn(200,15000),
                    autoNextEpisode=po.optBoolean("autoNextEpisode",cur.autoNextEpisode),
                    autoReconnect=po.optBoolean("autoReconnect",cur.autoReconnect),
                    aspectMode=po.optInt("aspectMode",cur.aspectMode).coerceIn(0,5),
                    themeMode=po.optString("themeMode",cur.themeMode).let {if(it in setOf("dark","night","light"))it else cur.themeMode},
                    autoPlayLastOnStart=po.optBoolean("autoPlayLastOnStart",cur.autoPlayLastOnStart),
                    audioBoostPct=po.optInt("audioBoostPct",cur.audioBoostPct).coerceIn(100,200),
                    subSizeSp=po.optInt("subSizeSp",cur.subSizeSp).coerceIn(14,42),
                    subColorIndex=po.optInt("subColorIndex",cur.subColorIndex).coerceIn(0,3),
                    subBgTranslucent=po.optBoolean("subBgTranslucent",cur.subBgTranslucent))
                // All parsing, mapping and capacity checks precede writes. This is not a
                // cross-file power-loss transaction (encrypted and fast prefs are separate).
                saveAccounts(plan.accounts)
                writeStreamList("favorites_json",favs)
                writeStreamList("recent_json",recent)
                val positions=sp.edit()
                entries.forEach {e->
                    val key=resumeSpKey(e.item.id,e.item.kind,e.item.accountId)
                    if(!sp.contains(key)) {positions.putLong(key,e.posMs);resumePosRamCache[key]=e.posMs}
                }
                positions.apply()
                writeResumeEntries(entries)
                saveFavoriteFolderMap(folders)
                val customJson=JSONArray()
                custom.filterNot {it in defaultFavFolders}.forEach {customJson.put(it)}
                sp.edit().putString("fav_custom_folders_json",customJson.toString()).apply()
                savePrefs(prefs)
                if(po?.has("autoLockAdult")==true)setAutoLockAdult(po.getBoolean("autoLockAdult"))
                if(getActiveAccountId().isBlank())plan.accounts.firstOrNull()?.let {setActiveAccountId(it.id)}
                ImportSummary(plan.importedAccounts,favs.size-getFavoritesBeforeImportCount,
                    "✔ تم دمج النسخة: الحسابات والمفضلة والسجل ومواضع المتابعة والإعدادات؛ لم تُحذف بياناتك الحالية")
            } catch(e:Exception) {
                ImportSummary(0,0,"تعذّر استيراد النسخة؛ تحقق من صيغتها وسعة البيانات. لم تُعتمد بيانات غير صالحة.")
            }
        }
    }

    private fun importPortalJsonArray(arr: JSONArray): Int {
        var count = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val rawUrl = o.optString("url").ifBlank { o.optString("portal") }.trim()
            if (rawUrl.isEmpty()) continue
            val rawMac = o.optString("mac").trim()
            val rawName = o.optString("name").trim()
            val ms = o.optInt("pingMs", o.optInt("ms", 0))
            val exp = o.optString("expiry").ifBlank { o.optString("exp_date") }.trim()
            val maxC = o.optString("maxConnections").ifBlank { o.optString("max_conn") }.trim()
            val status = o.optString("status").trim()

            // التعرّف على نوع الاشتراك (بما في ذلك صيغة xtream:// من سطح المكتب)
            val acc = when {
                o.optString("provider").equals("XTREAM", ignoreCase = true) ||
                    rawMac.startsWith("xtream:", ignoreCase = true) ||
                    rawUrl.contains("username=", ignoreCase = true) -> {
                    var u = o.optString("username")
                    var p = o.optString("password")
                    if (rawMac.startsWith("xtream:", ignoreCase = true)) {
                        val rest = rawMac.substringAfter(":")
                        u = rest.substringBefore(":")
                        p = rest.substringAfter(":", "")
                    }
                    PortalClient.normalizeAccountInput(ProviderType.XTREAM, rawName, rawUrl, "", u, p)
                }

                o.optString("provider").equals("M3U", ignoreCase = true) ||
                    rawMac.startsWith("m3u:", ignoreCase = true) -> {
                    PortalClient.normalizeAccountInput(ProviderType.M3U, rawName, rawUrl, "", "", "")
                }

                else -> {
                    if (rawMac.isEmpty()) continue
                    PortalClient.normalizeAccountInput(ProviderType.STALKER, rawName, rawUrl, rawMac, "", "")
                }
            }.copy(
                expiry = exp,
                maxConnections = maxC,
                status = status.ifBlank { if (ms > 0) "شغّال ✔ (${ms}ms)" else "" },
                pingMs = ms
            )
            upsertAccount(acc)
            count++
        }
        return count
    }

    private fun importTvFavoritesArray(arr: JSONArray): Int {
        synchronized(personalDataLock) {
        val cur = getFavorites().toMutableList()
        var added = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id").trim()
            val name = o.optString("name").trim()
            val kind = runCatching { ItemKind.valueOf(o.optString("kind", "LIVE")) }.getOrDefault(ItemKind.LIVE)
            if (id.isEmpty() || name.isEmpty() || cur.any { it.id == id && it.kind == kind && it.accountId == o.optString("accountId") }) continue
            cur.add(
                StreamItem(
                    id = id,
                    name = name,
                    cmd = o.optString("cmd"),
                    categoryId = o.optString("categoryId"),
                    logo = o.optString("logo"),
                    kind = kind,
                    subtitle = o.optString("subtitle"),
                    seriesId = o.optString("seriesId"),
                    seasonId = o.optString("seasonId"),
                    containerExt = o.optString("containerExt"),
                    accountId = o.optString("accountId")
                )
            )
            added++
        }
        if (added > 0) writeStreamList("favorites_json", cur.take(400))
        return added
    
        }
    }

    private fun importDesktopFavoritesArray(arr: JSONArray): Int {
        synchronized(personalDataLock) {
        val cur = getFavorites().toMutableList()
        var added = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id").trim()
            val name = o.optString("name").trim()
            val kind = when (o.optString("type").lowercase(Locale.US)) {
                "vod" -> ItemKind.VOD
                "series" -> ItemKind.SERIES
                else -> ItemKind.LIVE
            }
            if (id.isEmpty() || name.isEmpty() || cur.any { it.id == id && it.kind == kind && it.accountId.isBlank() }) continue
            cur.add(
                StreamItem(
                    id = id,
                    name = name,
                    cmd = o.optString("cmd"),
                    categoryId = o.optString("category_id"),
                    logo = o.optString("logo"),
                    kind = kind
                )
            )
            added++
        }
        if (added > 0) writeStreamList("favorites_json", cur.take(400))
        return added
    
        }
    }

    // ==================== تسلسل القوائم ====================
    private fun readStreamList(key: String): List<StreamItem> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return runCatching {parseStreamList(JSONArray(raw))}.getOrDefault(emptyList())
    }

    private fun parseStreamList(arr:JSONArray):List<StreamItem> {
        return try {
            val out = ArrayList<StreamItem>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val kind = runCatching {
                    ItemKind.valueOf(o.optString("kind", "LIVE"))
                }.getOrDefault(ItemKind.LIVE)
                out.add(
                    StreamItem(
                        id = o.optString("id"),
                        name = o.optString("name"),
                        cmd = o.optString("cmd"),
                        categoryId = o.optString("categoryId"),
                        logo = o.optString("logo"),
                        kind = kind,
                        subtitle = o.optString("subtitle"),
                        seriesId = o.optString("seriesId"),
                        seasonId = o.optString("seasonId"),
                        containerExt = o.optString("containerExt"),
                        tvArchive = o.optBoolean("tvArchive", false),
                        tvArchiveDays = o.optInt("tvArchiveDays", 0),
                        catchupTag = o.optString("catchupTag"),
                        year = o.optString("year"),
                        rating = o.optString("rating"),
                        tvgId = o.optString("tvgId"),
                        accountId = o.optString("accountId")
                    )
                )
            }
            out
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeStreamList(key: String, list: List<StreamItem>) {
        if (key == "favorites_json") {
            cachedFavorites = list
            cachedFavIds = list.mapTo(HashSet(list.size * 2 + 1)) { it.favKey() }
        } else if (key == "recent_json") {
            cachedRecent = list
        }
        val arr = JSONArray()
        for (s in list) {
            arr.put(
                JSONObject().apply {
                    put("id", s.id)
                    put("name", s.name)
                    put("cmd", s.cmd)
                    put("categoryId", s.categoryId)
                    put("logo", s.logo)
                    put("kind", s.kind.name)
                    put("subtitle", s.subtitle)
                    put("seriesId", s.seriesId)
                    put("seasonId", s.seasonId)
                    put("containerExt", s.containerExt)
                    put("tvArchive", s.tvArchive)
                    put("tvArchiveDays", s.tvArchiveDays)
                    put("catchupTag", s.catchupTag)
                    put("year", s.year)
                    put("rating", s.rating)
                    put("tvgId", s.tvgId)
                    put("accountId", s.accountId)
                }
            )
        }
        sp.edit().putString(key, arr.toString()).apply()
    }

    // ==================== تذكّر آخر قسم والفرز وتصدير M3U ====================
    fun saveLastCategoryId(acc: AccountProfile, tab: ContentTab, categoryId: String) {
        if (categoryId.isBlank()) return
        val k = "last_cat_${sha256("${acc.cacheKey()}|${tab.code}").take(14)}"
        sp.edit().putString(k, categoryId).apply()
    }

    fun getLastCategoryId(acc: AccountProfile, tab: ContentTab): String {
        val k = "last_cat_${sha256("${acc.cacheKey()}|${tab.code}").take(14)}"
        return sp.getString(k, "").orEmpty()
    }

    fun saveSortMode(tab: ContentTab, mode: SortMode) {
        sp.edit().putString("sort_mode_${tab.code}", mode.name).apply()
    }

    fun getSortMode(tab: ContentTab): SortMode {
        val raw = sp.getString("sort_mode_${tab.code}", SortMode.DEFAULT.name).orEmpty()
        return runCatching { SortMode.valueOf(raw) }.getOrDefault(SortMode.DEFAULT)
    }

    fun sortStreamItems(items: List<StreamItem>, mode: SortMode): List<StreamItem> {
        if (mode == SortMode.DEFAULT || items.size <= 1) return items
        val yearRe = Regex("""\b(19\d{2}|20\d{2})\b""")
        fun extractYear(it: StreamItem): Int {
            it.year.take(4).toIntOrNull()?.let { y -> if (y in 1900..2100) return y }
            yearRe.find(it.name)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
            yearRe.find(it.subtitle)?.groupValues?.getOrNull(1)?.toIntOrNull()?.let { return it }
            return 0
        }
        fun extractRating(it: StreamItem): Double {
            it.rating.replace(",", ".").trim().toDoubleOrNull()?.let { return it }
            val m = Regex("""⭐\s*(\d+(?:\.\d+)?)""").find(it.subtitle)
            return m?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
        }
        return when (mode) {
            SortMode.DEFAULT -> items
            SortMode.RECENT_ADDED -> {
                // مطابق لنسخة سطح المكتب v66.86: ترتيب تنازلي حسب المعرّف الرقمي ID (الأعلى أُضيف آخراً)، أو عكس ترتيب السيرفر
                val numericCount = items.count { extractTrailingNumber(it.id) > 0L }
                if (numericCount >= items.size / 2) {
                    items.sortedByDescending { extractTrailingNumber(it.id) }
                } else {
                    items.asReversed()
                }
            }
            SortMode.NAME_ASC -> items.sortedBy { it.name.trim().lowercase(Locale.ROOT) }
            SortMode.YEAR_DESC -> items.sortedWith(
                compareByDescending<StreamItem> { extractYear(it) }
                    .thenByDescending { extractRating(it) }
                    .thenBy { it.name }
            )
            SortMode.RATING_DESC -> items.sortedWith(
                compareByDescending<StreamItem> { extractRating(it) }
                    .thenByDescending { extractYear(it) }
                    .thenBy { it.name }
            )
        }
    }

    private fun extractTrailingNumber(rawId: String): Long {
        rawId.trim().toLongOrNull()?.let { return it }
        val m = Regex("""(\d+)$""").find(rawId.trim())
        return m?.groupValues?.getOrNull(1)?.toLongOrNull() ?: -1L
    }

    fun exportItemsAsM3u(items:List<StreamItem>,groupTitle:String="IPTV Lite"):Pair<Int,String> =
        com.iptvlite.tv.util.M3uExport.direct(items,groupTitle)

    private fun sha256(s: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { String.format("%02x", it) }
    }
}
