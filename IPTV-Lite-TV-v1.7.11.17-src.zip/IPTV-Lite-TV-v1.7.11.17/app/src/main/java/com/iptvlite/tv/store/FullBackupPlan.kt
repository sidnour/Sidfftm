package com.iptvlite.tv.store

import com.iptvlite.tv.model.*
import com.iptvlite.tv.network.PortalClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Preflight only: no preference writes and no network. Merge, never silently replace local owners. */
internal class FullBackupPlan(root:JSONObject,existing:List<AccountProfile>) {
    val accounts=existing.toMutableList()
    val owners=HashMap<String,String>()
    val favorites:JSONArray
    val recent:JSONArray
    val resume:JSONArray
    val folders=HashMap<String,String>()
    val customFolders:List<String>
    val prefs:JSONObject?
    var importedAccounts=0
        private set
    private fun array(root:JSONObject,key:String,max:Int):JSONArray {
        if(!root.has(key))return JSONArray()
        val a=root.getJSONArray(key)
        require(a.length()<=max) {"Backup limit: $key"}
        return a
    }
    private fun same(a:AccountProfile,b:AccountProfile)=a.provider==b.provider &&
        DataIdentity.portalUrl(a.url)==DataIdentity.portalUrl(b.url) && a.mac.equals(b.mac,true) && a.username==b.username
    init {
        require(root.getString("app")=="IPTV_Lite_TV")
        require(root.optInt("version",1) in 1..4) {"Unsupported backup version"}
        val assigned=HashSet<String>()
        val source=array(root,"accounts",5000)
        for(i in 0 until source.length()) {
            val o=source.getJSONObject(i)
            val old=o.getString("id");require(old.isNotBlank() && !owners.containsKey(old)) {"Ambiguous account ID"}
            val provider=ProviderType.valueOf(o.getString("provider"))
            val url=o.getString("url");require(url.isNotBlank())
            val normalized=PortalClient.normalizeAccountInput(provider,o.optString("name"),url,o.optString("mac"),
                o.optString("username"),o.optString("password"),old,o.optString("epgUrl"))
                .copy(expiry=o.optString("expiry"),maxConnections=o.optString("maxConnections"),status=o.optString("status"),pingMs=o.optInt("pingMs"))
            val exact=accounts.indexOfFirst {it.id==old && same(it,normalized) && it.id !in assigned}
            val match=if(exact>=0)exact else accounts.indexOfFirst {same(it,normalized) && it.id !in assigned}
            val id=if(match>=0)accounts[match].id else if(accounts.any {it.id==old})UUID.randomUUID().toString() else old
            val a=normalized.copy(id=id)
            if(match>=0)accounts[match]=a else accounts.add(a)
            owners[old]=id;assigned.add(id);importedAccounts++
        }
        // Preserve unknown ownership without borrowing a colliding local account.
        val orphans=HashMap<String,String>()
        fun mapped(old:String):String = if(old.isBlank())"" else owners[old] ?: orphans.getOrPut(old) {
            val proposed="backup_orphan_${DataIdentity.digest(old)}"
            if(accounts.any {it.id==proposed})"backup_orphan_${UUID.randomUUID()}" else proposed
        }
        fun remap(key:String,max:Int,ownerKey:String):JSONArray {
            val arr=array(root,key,max);val out=JSONArray()
            for(i in 0 until arr.length()) {
                val src=arr.getJSONObject(i)
                require(src.getString("id").isNotBlank())
                ItemKind.valueOf(src.optString("kind",if(key=="resume_entries")"VOD" else "LIVE"))
                val copy=JSONObject(src.toString())
                copy.put(ownerKey,mapped(src.optString(ownerKey)))
                if(key=="resume_entries")require(copy.optLong("posMs",-1)>=0 && copy.optLong("durMs",0)>=0)
                out.put(copy)
            }
            return out
        }
        val originalFavs=array(root,"favorites",400)
        favorites=remap("favorites",400,"accountId")
        recent=remap("recent",50,"accountId")
        resume=remap("resume_entries",60,"accId")
        val sourceFolders=if(root.has("fav_item_folders"))root.getJSONObject("fav_item_folders")else JSONObject()
        val keyMap=HashMap<String,MutableSet<String>>()
        for(i in 0 until originalFavs.length()) {
            val old=originalFavs.getJSONObject(i);val new=favorites.getJSONObject(i)
            val kind=ItemKind.valueOf(old.optString("kind","LIVE"));val id=old.getString("id")
            val target=DataIdentity.item(new.optString("accountId"),kind,id)
            for(k in listOf(DataIdentity.item(old.optString("accountId"),kind,id),"${kind.name}:$id",id))
                keyMap.getOrPut(k) {HashSet()}.add(target)
        }
        sourceFolders.keys().forEach {k->
            val targets=keyMap[k]
            val target=if(targets?.size==1)targets.single() else "backup_orphan_folder_${DataIdentity.digest(k)}"
            folders[target]=sourceFolders.getString(k)
        }
        val cf=array(root,"fav_custom_folders",400)
        customFolders=(0 until cf.length()).map {cf.getString(it)}.filter {it.isNotBlank()}.distinct()
        prefs=if(root.has("prefs"))root.getJSONObject("prefs")else null
        // Validate known preference values before ANY store mutation; old backups may omit them.
        prefs?.let {p->
            for(k in listOf("cacheMs","aspectMode","audioBoostPct","subSizeSp","subColorIndex"))if(p.has(k))p.getInt(k)
            for(k in listOf("autoNextEpisode","autoReconnect","autoPlayLastOnStart","subBgTranslucent","autoLockAdult"))if(p.has(k))p.getBoolean(k)
        }
    }
}
