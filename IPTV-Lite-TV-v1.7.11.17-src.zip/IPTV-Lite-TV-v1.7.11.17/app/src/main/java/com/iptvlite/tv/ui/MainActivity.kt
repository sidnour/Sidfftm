package com.iptvlite.tv.ui

import kotlinx.coroutines.ensureActive
import com.iptvlite.tv.util.CancellableScan
import com.iptvlite.tv.util.PerformanceTrace
import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iptvlite.tv.R
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.CategoryItem
import com.iptvlite.tv.model.ContentTab
import com.iptvlite.tv.model.ItemKind
import com.iptvlite.tv.model.PlayQueueHolder
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.model.SortMode
import com.iptvlite.tv.model.StreamItem
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.service.RecordingService
import com.iptvlite.tv.store.AppStore
import java.lang.ref.WeakReference
import com.iptvlite.tv.util.AppExitHelper
import com.iptvlite.tv.util.AppUiTracker
import com.iptvlite.tv.util.LogoLoader
import com.iptvlite.tv.util.MediaTitleFormatter
import com.iptvlite.tv.util.NotificationHelper
import com.iptvlite.tv.util.ScheduleHelper
import com.iptvlite.tv.util.StreamRecorder
import com.iptvlite.tv.util.ThemeHelper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    companion object {
        private var autoPlayTriggeredThisProcess: Boolean = false
        private var notifPermRequestedThisProcess: Boolean = false

        @Volatile
        var isUiAlive: Boolean = false
    }

    private lateinit var store: AppStore

    private lateinit var tabLive: TextView
    private lateinit var tabVod: TextView
    private lateinit var tabSeries: TextView
    private lateinit var tabFav: TextView
    private lateinit var tabRecent: TextView
    private lateinit var btnResumeLast: TextView
    private lateinit var btnSavedLibrary: TextView
    private lateinit var etSearch: EditText
    private lateinit var btnGlobalSearch: TextView
    private lateinit var btnToggleCats: TextView
    private lateinit var btnAccounts: TextView
    private lateinit var btnCatMgr: TextView
    private lateinit var btnStats: TextView
    private lateinit var btnSettings: TextView
    private lateinit var btnRefresh: TextView
    private lateinit var btnExit: TextView

    private lateinit var categoryPane: LinearLayout
    private lateinit var tvCatHeader: TextView
    private lateinit var btnNewFavFolder: TextView
    private var etCatFilter: EditText? = null
    private lateinit var rvCategories: RecyclerView
    private lateinit var btnBackLevel: TextView
    private lateinit var tvListHeader: TextView
    private lateinit var btnViewMode: TextView
    private lateinit var btnLetterFilter: TextView
    private lateinit var btnSort: TextView
    private lateinit var btnItemAction: TextView
    private lateinit var tvListCount: TextView
    private lateinit var progressMain: ProgressBar
    private lateinit var emptyBox: LinearLayout
    private lateinit var tvEmptyState: TextView
    private lateinit var btnQuickSetup: TextView
    private lateinit var rvStreams: RecyclerView

    private lateinit var tvStatusMsg: TextView
    private lateinit var tvAccountInfo: TextView

    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var streamAdapter: StreamAdapter

    private var currentTab: ContentTab = ContentTab.LIVE
    private var currentCategoryId: String = ""
    private var currentCategoryTitle: String = ""
    private var selectedFavFolderId: String = "*"
    private var isGridViewActive: Boolean = false
    private var rawCategories: List<CategoryItem> = emptyList()
    private var visibleCategoriesMaster: List<CategoryItem> = emptyList()
    private var suppressCatFilterWatcher: Boolean = false
    private var rawItems: List<StreamItem> = emptyList()
    private var savedPreGlobalItems: List<StreamItem> = emptyList()
    private var isShowingGlobalSearch: Boolean = false
    private var currentSortMode: SortMode = SortMode.DEFAULT
    private var currentLetterFilter: String = ""
    private var pendingM3uPayload: String = ""
    private var m3uExportJob:Job?=null
    private var m3uExportScope:com.iptvlite.tv.network.PlaybackRequestScope?=null
    private var m3uExportDialog:AlertDialog?=null
    private fun cancelM3uExport() {
        m3uExportScope?.cancel {com.iptvlite.tv.network.NetworkCleanup.cancel(it)}
        m3uExportScope=null;m3uExportJob?.cancel();m3uExportJob=null
        m3uExportDialog?.dismiss();m3uExportDialog=null
    }
    private var pendingLocalM3uCallback: ((String) -> Unit)? = null
    private var lastTouchedItem: StreamItem? = null
    private var lastFocusedStreamPos: Int = 0

    // الأقسام المقفولة التي تم فتحها بالرمز السري خلال الجلسة الحالية
    private val unlockedCategoryIds = HashSet<String>()

    // مكدّس التعمّق للمسلسلات: (قائمة المسلسلات -> المواسم -> الحلقات)
    private var activeSeriesItem: StreamItem? = null
    private var activeSeasonItem: StreamItem? = null
    private var savedSeriesList: List<StreamItem> = emptyList()
    private var savedSeasonsList: List<StreamItem> = emptyList()
    private var savedSeriesFocusPos: Int = 0
    private var savedSeasonFocusPos: Int = 0

    private var browseJob: Job? = null
    private val browseGeneration=com.iptvlite.tv.util.RequestGeneration()
    private var browseScope:com.iptvlite.tv.network.PlaybackRequestScope?=null
    private val badgeGeneration=com.iptvlite.tv.util.RequestGeneration()
    private var badgeJob:Job?=null
    private var badgeScope:com.iptvlite.tv.network.PlaybackRequestScope?=null
    private fun cancelBrowse(preserveSelected:Boolean=false) {
        if(!preserveSelected)com.iptvlite.tv.network.SelectedCategoryLoad.discard()
        browseGeneration.next()
        browseScope?.cancel {com.iptvlite.tv.network.NetworkCleanup.cancel(it)}
        browseScope=null
        browseJob?.cancel()
    }
    private fun cancelBadge() {
        badgeGeneration.next()
        badgeScope?.cancel {com.iptvlite.tv.network.NetworkCleanup.cancel(it)}
        badgeScope=null;badgeJob?.cancel()
    }
    private suspend fun <T> ownedIo(owner:com.iptvlite.tv.network.PlaybackRequestScope, browse:Boolean=true, block:()->T):T =
        kotlinx.coroutines.coroutineScope {
            val watcher=launch(start=kotlinx.coroutines.CoroutineStart.UNDISPATCHED) {
                try {kotlinx.coroutines.awaitCancellation()}
                finally {owner.cancel {com.iptvlite.tv.network.NetworkCleanup.cancel(it)}}
            }
            try {withContext(Dispatchers.IO) {if(browse)com.iptvlite.tv.network.BrowseWork.run(owner,block) else owner.run(block)}}
            finally {watcher.cancel()}
        }
    private var filterJob: Job? = null
    private var suppressSearchWatcher: Boolean = false
    private var exitConfirmDialog: AlertDialog? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private val searchDebounceRunnable = Runnable { applySearchFilter() }

    private val importDocLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val text = runCatching {
                withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { com.iptvlite.tv.util.BoundedInput.read(it,18_000_000).toString(Charsets.UTF_8) }.orEmpty()
                }
            }.getOrDefault("")
            if (text.isBlank()) {
                Toast.makeText(this@MainActivity, "✖ تعذّر قراءة الملف المختار", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val summary = store.importAnyPortalsOrBackup(text)
            Toast.makeText(this@MainActivity, summary.message, Toast.LENGTH_LONG).show()
            store.getActiveAccount()?.let { onAccountActivated(it) }
        }
    }

    private val exportDocLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            val ok = runCatching {
                val json = store.exportFullBackupJson()
                withContext(Dispatchers.IO) {
                    (contentResolver.openOutputStream(uri) ?: error("output unavailable")).use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                this@MainActivity,
                if (ok) "✔ تم حفظ النسخة الاحتياطية بنجاح" else "✖ تعذّر حفظ النسخة الاحتياطية",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val exportM3uDocLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("audio/x-mpegurl")
    ) { uri ->
        val content=pendingM3uPayload
        pendingM3uPayload=""
        if(uri==null || content.isBlank())return@registerForActivityResult
        lifecycleScope.launch {
            val ok = runCatching {
                withContext(Dispatchers.IO) {
                    (contentResolver.openOutputStream(uri) ?: error("output unavailable")).use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    }
                }
                true
            }.getOrDefault(false)
            Toast.makeText(
                this@MainActivity,
                if (ok) "✔ تم تصدير ملف M3U بنجاح" else "✖ تعذّر حفظ ملف M3U",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private val localM3uPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        runCatching {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
        val cb = pendingLocalM3uCallback
        pendingLocalM3uCallback = null
        cb?.invoke(uri.toString())
    }

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ -> }

    private val immediateReminderCallback: () -> Unit = {
        if (!isFinishing && !isDestroyed) {
            checkDueRemindersAndRecs(immediate = true)
        }
    }

    private fun resolveAccountForItem(item:StreamItem):AccountProfile? {
        if(item.accountId.isNotBlank()) {
            val owner=store.getAccounts().firstOrNull {it.id==item.accountId}
            if(owner==null)Toast.makeText(this,"حساب هذا العنصر محذوف؛ استعد النسخة الاحتياطية أو أضف العنصر من حساب صالح",Toast.LENGTH_LONG).show()
            return owner
        }
        return store.getActiveAccount()
    }

    private fun checkDueRemindersAndRecs(immediate: Boolean = false) {
        val nowSec = System.currentTimeMillis() / 1000L
        val cutoff = if (immediate) nowSec + 2L else nowSec
        val due = store.popDueReminders(cutoff)
        for (rem in due) {
            TvDialogs.showNeonChoiceDialog(
                ctx = this@MainActivity,
                title = "🔔 حان موعد «${rem.programTitle}» على «${rem.channel.name}»",
                items = listOf("▶ الانتقال للمشاهدة فوراً"),
                defaultIndex = 0,
                cancelLabel = "تجاهل"
            ) {
                val acc = store.getAccounts().firstOrNull { it.id == rem.accountId }
                if(acc==null)Toast.makeText(this,"حساب التذكير غير موجود؛ أعد إضافته من الحساب الصحيح",Toast.LENGTH_LONG).show()
                if (acc != null) {
                    launchSingleStream(acc, rem.channel, listOf(rem.channel), 0)
                }
            }
        }

        if (!StreamRecorder.isRecording()) {
            val overdueRecs = store.getScheduledRecs().filter {
                it.state == "pending" && nowSec >= (it.startTs + 15L) && nowSec <= (it.startTs + it.durationMin * 60L)
            }
            for (sc in overdueRecs) {
                RecordingService.start(this@MainActivity, sc.id)
                Toast.makeText(
                    this@MainActivity,
                    "🔴 بدأ التسجيل المجدول لـ «${sc.progName}» (${sc.durationMin} دقيقة)",
                    Toast.LENGTH_LONG
                ).show()
                break
            }
        } else if (StreamRecorder.activeRecTitle.isNotBlank()) {
            tvStatusMsg.text = "🔴 تسجيل جارٍ حالياً: ${StreamRecorder.activeRecTitle}"
        }
    }

    private val reminderChecker = object : Runnable {
        override fun run() {
            if (store.hasActiveSchedules() || StreamRecorder.isRecording()) {
                checkDueRemindersAndRecs(immediate = false)
                uiHandler.postDelayed(this, 15_000L)
            } else {
                // صفر استيقاظ بالخلفية طالما لا توجد تنبيهات أو تسجيلات مجدولة (ومنبّه النظام AlarmManager يوقظها فوراً عند إضافة أي موعد!)
                uiHandler.postDelayed(this, 60_000L)
            }
        }
    }

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(com.iptvlite.tv.util.TelevisionUi.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PortalClient.initAppContext(this)
        NotificationHelper.ensureChannels(this)
        setContentView(R.layout.activity_main)
        store = AppStore(this)
        ScheduleHelper.rescheduleAll(this, store)

        bindViews()
        setupAdapters()
        applyCurrentTheme()
        setupListeners()
        setupBackNavigation()
        requestNotificationPermissionIfNeeded()

        val restoredTab = savedInstanceState?.getString("state_tab")
            ?.let { name -> ContentTab.entries.firstOrNull { it.name == name } }
            ?: ContentTab.LIVE
        savedInstanceState?.getString("state_fav_folder")?.takeIf { it.isNotBlank() }?.let {
            selectedFavFolderId = it
        }

        val active = store.getActiveAccount()
        if (active == null) {
            updateEmptyState("IPTV Lite TV v${com.iptvlite.tv.util.AboutInfo.versionName()}\nأضف سيرفرك من «👤 السيرفرات» للبدء.")
            tvAccountInfo.text = "غير متّصل"
            uiPostOpenAccounts()
        } else {
            onAccountActivated(active, initialTab = restoredTab)
            val openedFromNotif = handleNotificationIntent(intent)
            if (!openedFromNotif && savedInstanceState == null && !autoPlayTriggeredThisProcess && store.loadPrefs().autoPlayLastOnStart) {
                autoPlayTriggeredThisProcess = true
                val liveRecents = store.getRecent().filter { it.kind == ItemKind.LIVE }
                val lastLive = liveRecents.firstOrNull()
                if (lastLive != null) {
                    val targetAcc = if(lastLive.accountId.isBlank())active else store.getAccounts().firstOrNull {it.id==lastLive.accountId}
                    uiHandler.postDelayed({
                        if (!isFinishing && !isDestroyed && targetAcc!=null) {
                            Toast.makeText(this, "📺 وضع الرسيفر: تشغيل «${lastLive.name}»…", Toast.LENGTH_SHORT).show()
                            launchSingleStream(targetAcc, lastLive, liveRecents, 0)
                        }
                    }, 260L)
                }
            } else {
                autoPlayTriggeredThisProcess = true
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("state_tab", currentTab.name)
        outState.putString("state_fav_folder", selectedFavFolderId)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNotificationIntent(intent)
    }

    override fun onStart() {
        super.onStart()
        isUiAlive = true
        AppUiTracker.onActivityStarted()
    }

    override fun onStop() {
        cancelM3uExport()
        isUiAlive = false
        AppUiTracker.onActivityStopped()
        com.iptvlite.tv.network.SelectedCategoryLoad.browserHidden()
        super.onStop()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (notifPermRequestedThisProcess) return
        notifPermRequestedThisProcess = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                runCatching { notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }
    }

    private fun handleNotificationIntent(intent: Intent?): Boolean {
        val src = intent ?: return false
        val chId = src.getStringExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_ID).orEmpty()
        val chCmd = src.getStringExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_CMD).orEmpty()
        if (chId.isBlank() && chCmd.isBlank()) return false
        val chName = src.getStringExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_NAME).orEmpty().ifBlank { "قناة مباشرة" }
        val accId = src.getStringExtra(NotificationHelper.EXTRA_AUTO_OPEN_ACC_ID).orEmpty()

        src.removeExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_ID)
        src.removeExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_CMD)

        val acc = store.getAccounts().firstOrNull { it.id == accId }
        if(acc==null) {
            Toast.makeText(this,"حساب التذكير غير موجود؛ أعد جدولة البرنامج",Toast.LENGTH_LONG).show()
            return true
        }
        val chItem = StreamItem(
            id = chId.ifBlank { chCmd.hashCode().toString() },
            name = chName,
            cmd = chCmd,
            kind = ItemKind.LIVE
        )
        uiHandler.postDelayed({
            if (!isFinishing && !isDestroyed) {
                launchSingleStream(acc, chItem, listOf(chItem), 0)
            }
        }, 200L)
        return true
    }

    private fun launchOfflineLocalMedia(localItem: StreamItem) {
        val acc = store.getActiveAccount() ?: AccountProfile(
            id = "local_offline",
            name = "مكتبتي المحلية",
            provider = ProviderType.M3U,
            url = "file:///local"
        )
        launchSingleStream(acc, localItem, listOf(localItem), 0)
    }

    override fun onResume() {
        super.onResume()
        LogoLoader.isPlaybackActive = false
        val selectedAcc=store.getActiveAccount()
        if(selectedAcc!=null && com.iptvlite.tv.network.SelectedCategoryLoad.matches(selectedAcc,currentTab,currentCategoryId) && activeSeriesItem==null && !isShowingGlobalSearch) {
            com.iptvlite.tv.network.SelectedCategoryLoad.browsing()
            if(browseJob?.isActive!=true)observeSelectedCategory(selectedAcc,currentTab,currentCategoryId,tvListHeader.text.toString())
        }
        AppUiTracker.registerReminderHandler(immediateReminderCallback)
        uiHandler.removeCallbacks(reminderChecker)
        uiHandler.postDelayed(reminderChecker, 1_500L)
        if (currentTab == ContentTab.FAV || currentTab == ContentTab.RECENT) {
            loadLocalTab(currentTab)
        } else if (activeSeriesItem != null && activeSeasonItem == null) {
            val baseSeasons = rawItems.filter { it.kind == ItemKind.SEASON }
            rawItems = injectSeriesQuickResumeRow(activeSeriesItem!!, baseSeasons)
            applySearchFilter()
        } else {
            streamAdapter.notifyDataSetChanged()
        }
    }

    override fun onPause() {
        AppUiTracker.unregisterReminderHandler(immediateReminderCallback)
        super.onPause()
        uiHandler.removeCallbacks(reminderChecker)
        uiHandler.removeCallbacks(searchDebounceRunnable)
    }

    private fun uiPostOpenAccounts() {
        btnAccounts.post {
            openAccountsManager()
        }
    }

    internal fun exportBackupFromAccountManager() {launchExportPicker()}

    internal fun onAccountsRemovedFromManager(ids:Set<String>) {
        cancelM3uExport()
        val old=PlayQueueHolder.activeAccount?.id
        if(old !in ids && store.getAccounts().isNotEmpty())return
        cancelBrowse();cancelBadge();filterJob?.cancel()
        PortalClient.preemptBrowse()
        PlayQueueHolder.clear()
        rawItems=emptyList();savedPreGlobalItems=emptyList();isShowingGlobalSearch=false
        resetSeriesStack();setMasterCategories(emptyList(),"");streamAdapter.submit(emptyList())
        setLoading(false)
        val active=store.getActiveAccount()
        if(active!=null)onAccountActivated(active) else {
            tvAccountInfo.text="لا توجد سيرفرات — أضف أو استورد حسابًا"
            tvListHeader.text="القائمة فارغة"
            updateEmptyState("حُذفت السيرفرات من التطبيق. المفضلة والسجل والاستئناف محفوظة بحساباتها الأصلية. يمكنك إضافة سيرفر أو استعادة نسخة احتياطية.")
        }
    }

    private fun openAccountsManager() {
        TvDialogs.showAccountsDialog(
            ctx = this,
            store = store,
            scope = lifecycleScope,
            onPickImportFile = { launchImportPicker() },
            onOpenWebSetup = {
                FeatureDialogs.showWebSetupDialog(this, store) {
                    store.getActiveAccount()?.let { onAccountActivated(it) }
                }
            },
            onPickLocalM3uFile = { onUriPicked ->
                pendingLocalM3uCallback = onUriPicked
                if (preferWifiFiles()) {
                    pendingLocalM3uCallback = null
                    showWifiFileTransfer()
                } else runCatching {
                    localM3uPickerLauncher.launch(arrayOf("*/*"))
                }.onFailure {
                    pendingLocalM3uCallback = null
                    showWifiFileTransfer()
                }
            },
            onActivated = { acc -> onAccountActivated(acc) }
        )
    }

    private fun showWifiFileTransfer(payload: String? = null, fileName: String = "iptv_playlist.m3u") {
        FeatureDialogs.showWebSetupDialog(this, store, payload, fileName) {
            store.getActiveAccount()?.let { onAccountActivated(it) }
        }
    }

    private fun preferWifiFiles(save: Boolean = false): Boolean {
        val intent = Intent(if (save) Intent.ACTION_CREATE_DOCUMENT else Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
        return com.iptvlite.tv.util.FileTransferSupport.preferWifi(this, intent)
    }

    private fun launchImportPicker() {
        if (preferWifiFiles()) { showWifiFileTransfer(); return }
        runCatching {
            importDocLauncher.launch(arrayOf("*/*"))
        }.onFailure { showWifiFileTransfer() }
    }

    private fun launchExportPicker() {
        if (preferWifiFiles(save = true)) { showWifiFileTransfer(); return }
        runCatching {
            exportDocLauncher.launch("iptv_lite_backup.json")
        }.onFailure {
            showWifiFileTransfer()
        }
    }

    private fun launchM3uExport(items:List<StreamItem>,groupName:String,fileName:String) {
        if(m3uExportJob?.isActive==true || pendingM3uPayload.isNotBlank()) {
            Toast.makeText(this,"يوجد تصدير جارٍ؛ أكمله أو ألغِه أولاً",Toast.LENGTH_SHORT).show();return
        }
        if(items.isEmpty()) {Toast.makeText(this,"القائمة المختارة فارغة حالياً",Toast.LENGTH_SHORT).show();return}
        cancelM3uExport()
        val snapshot=items.toList()
        val accounts=store.getAccounts().toList()
        val activeId=store.getActiveAccount()?.id
        val owner=com.iptvlite.tv.network.PlaybackRequestScope()
        m3uExportScope=owner
        m3uExportDialog=AlertDialog.Builder(this)
            .setTitle("تجهيز تصدير M3U")
            .setMessage("جارٍ تجهيز الروابط… 0 / ${snapshot.size}\nيمكن الإلغاء في أي وقت. تشغيل قناة يلغي التجهيز لأولوية المشاهدة.")
            .setNegativeButton("إلغاء") {_,_->cancelM3uExport()}
            .setOnCancelListener {cancelM3uExport()}.show()
        m3uExportJob=lifecycleScope.launch {
            try {
                var lastProgress=0L
                val result=ownedIo(owner) {
                    com.iptvlite.tv.util.M3uExport.prepare(snapshot,accounts,activeId,groupName,
                        checkActive={owner.checkActive()},
                        onProgress={done,total->
                            val now=android.os.SystemClock.elapsedRealtime()
                            if(done==total || now-lastProgress>=150) {
                                lastProgress=now
                                uiHandler.post {
                                    if(m3uExportScope===owner && !isFinishing && !isDestroyed)
                                        m3uExportDialog?.setMessage("جارٍ تجهيز الروابط… $done / $total\nتشغيل قناة أو مغادرة الشاشة يلغي التجهيز.")
                                }
                            }
                        },resolve={acc,item->PortalClient.resolveM3uExportUrl(acc,item)})
                }
                kotlin.coroutines.coroutineContext.ensureActive()
                if(m3uExportScope!==owner || isFinishing || isDestroyed)return@launch
                m3uExportDialog?.dismiss();m3uExportDialog=null
                m3uExportScope=null;m3uExportJob=null
                if(result.exported==0) {
                    Toast.makeText(this@MainActivity,"لم يتم العثور على روابط قابلة للتصدير؛ تعذّر تجهيز ${result.skipped} عنصر",Toast.LENGTH_LONG).show()
                    return@launch
                }
                val message="جاهز: ${result.exported} عنصر\nتعذّر تصدير أو لم يُدعم: ${result.skipped} عنصر\n\nروابط Stalker قد تكون مؤقتة أو مرتبطة بالجلسة أو عنوان IP؛ صلاحيتها خارج التطبيق يحددها السيرفر."
                m3uExportDialog=AlertDialog.Builder(this@MainActivity).setTitle("نتيجة تجهيز M3U")
                    .setMessage(message)
                    .setPositiveButton("حفظ الملف") {_,_->
                        m3uExportDialog=null
                        savePreparedM3u(result.payload,fileName)
                    }.setNegativeButton("إلغاء") {_,_->m3uExportDialog=null}
                    .setOnCancelListener {m3uExportDialog=null}.show()
            } catch(_:CancellationException) {
                // User, activity lifecycle or playback preemption: never publish a partial file as success.
            } catch(_:Exception) {
                if(m3uExportScope===owner && !isFinishing && !isDestroyed)
                    Toast.makeText(this@MainActivity,"تعذّر تجهيز التصدير؛ أعد المحاولة",Toast.LENGTH_LONG).show()
            } finally {
                if(m3uExportScope===owner) {
                    m3uExportScope=null;m3uExportJob=null
                    m3uExportDialog?.dismiss();m3uExportDialog=null
                }
            }
        }
    }

    private fun savePreparedM3u(payload:String,fileName:String) {
        if(preferWifiFiles(save=true)) {showWifiFileTransfer(payload,fileName);return}
        pendingM3uPayload=payload
        runCatching {exportM3uDocLauncher.launch(fileName)}.onFailure {
            pendingM3uPayload="";showWifiFileTransfer(payload,fileName)
        }
    }

    private fun bindViews() {
        tabLive = findViewById(R.id.tabLive)
        tabVod = findViewById(R.id.tabVod)
        tabSeries = findViewById(R.id.tabSeries)
        tabFav = findViewById(R.id.tabFav)
        tabRecent = findViewById(R.id.tabRecent)
        btnResumeLast = findViewById(R.id.btnResumeLast)
        btnSavedLibrary = findViewById(R.id.btnSavedLibrary)
        etSearch = findViewById(R.id.etSearch)
        btnGlobalSearch = findViewById(R.id.btnGlobalSearch)
        btnToggleCats = findViewById(R.id.btnToggleCats)
        btnAccounts = findViewById(R.id.btnAccounts)
        btnCatMgr = findViewById(R.id.btnCatMgr)
        btnStats = findViewById(R.id.btnStats)
        btnSettings = findViewById(R.id.btnSettings)
        btnRefresh = findViewById(R.id.btnSync)
        btnExit = findViewById(R.id.btnExit)

        categoryPane = findViewById(R.id.categoryPane)
        tvCatHeader = findViewById(R.id.tvCatsHeader)
        btnNewFavFolder = findViewById(R.id.btnNewFavFolder)
        etCatFilter = findViewById(R.id.etCatFilter)
        rvCategories = findViewById(R.id.rvCategories)
        btnBackLevel = findViewById(R.id.btnDrillBack)
        tvListHeader = findViewById(R.id.tvItemsHeader)
        btnViewMode = findViewById(R.id.btnViewMode)
        btnLetterFilter = findViewById(R.id.btnLetterFilter)
        btnSort = findViewById(R.id.btnSort)
        btnItemAction = findViewById(R.id.btnItemAction)
        tvListCount = findViewById(R.id.tvCountBadge)
        progressMain = findViewById(R.id.pbLoading)
        emptyBox = findViewById(R.id.emptyBox)
        tvEmptyState = findViewById(R.id.tvEmptyMsg)
        btnQuickSetup = findViewById(R.id.btnQuickSetup)
        rvStreams = findViewById(R.id.rvItems)

        tvStatusMsg = findViewById(R.id.tvStatus)
        tvAccountInfo = findViewById(R.id.tvAccountBadge)
    }

    private fun setupAdapters() {
        categoryAdapter = CategoryAdapter(
            onSelect = { cat, _ ->
                onCategorySelected(cat)
            },
            onLongSelect = { cat, _ ->
                if (currentTab == ContentTab.FAV) {
                    onFavoriteFolderLongPressed(cat)
                } else {
                    openCategoryManagerForCurrentTab()
                }
            }
        )
        rvCategories.layoutManager = LinearLayoutManager(this)
        rvCategories.setHasFixedSize(true)
        rvCategories.itemAnimator = null
        rvCategories.setItemViewCacheSize(4)
        rvCategories.recycledViewPool.setMaxRecycledViews(0, 10)
        rvCategories.adapter = categoryAdapter

        streamAdapter = StreamAdapter(
            isFavFn = { store.isFavorite(it) },
            onClick = { item, pos, currentList ->
                lastTouchedItem = item
                onStreamClicked(item, pos, currentList)
            },
            onLongClick = { item, pos ->
                lastTouchedItem = item
                showItemContextMenu(item, pos)
            },
            resumeBadgeFn = { item ->
                when (item.kind) {
                    ItemKind.VOD, ItemKind.EPISODE -> {
                        val ms = store.getResumePos(item)
                        if (ms >= AppStore.MIN_RESUME_POS_MS) "⏵ متابعة ${AppStore.formatResumeTime(ms)}" else ""
                    }
                    ItemKind.SERIES -> {
                        val entry = store.getLatestSeriesResumeEntry(item.id, item.accountId)
                        if (entry != null) "⏵ متابعة ${AppStore.formatResumeTime(entry.posMs)}" else ""
                    }
                    else -> ""
                }
            },
            onItemFocused = { pos ->
                lastFocusedStreamPos = pos
                val cur = streamAdapter.currentItems()
                if (pos in cur.indices) {
                    lastTouchedItem = cur[pos]
                }
            }
        )
        rvStreams.layoutManager = LinearLayoutManager(this)
        rvStreams.setHasFixedSize(true)
        rvStreams.itemAnimator = null
        rvStreams.setItemViewCacheSize(6)
        rvStreams.recycledViewPool.setMaxRecycledViews(0, 12)
        rvStreams.recycledViewPool.setMaxRecycledViews(1, 9)
        rvStreams.adapter = streamAdapter
    }

    private fun setMasterCategories(cats: List<CategoryItem>, activeId: String) {
        visibleCategoriesMaster = cats
        etCatFilter?.visibility = if (cats.size > 6) View.VISIBLE else View.GONE
        val q = etCatFilter?.text?.toString()?.trim().orEmpty()
        val filtered = if (q.isEmpty()) {
            cats
        } else {
            cats.filter { c ->
                c.title.contains(q, ignoreCase = true) ||
                    MediaTitleFormatter.parseCategory(c.title).cleanTitle.contains(q, ignoreCase = true)
            }
        }
        categoryAdapter.submit(filtered, activeId)
    }

    private fun applyGridOrListMode(enableGrid: Boolean) {
        isGridViewActive = enableGrid
        val isPortrait = resources.configuration.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
        val catsHidden = categoryPane.visibility != View.VISIBLE
        val desiredSpans = when {
            com.iptvlite.tv.util.TelevisionUi.isTelevision(this) -> if (catsHidden) 4 else 3
            isPortrait -> 3
            catsHidden -> 5
            else -> 4
        }
        val curLm = rvStreams.layoutManager
        if (enableGrid) {
            if (curLm !is GridLayoutManager || curLm.spanCount != desiredSpans) {
                rvStreams.layoutManager = GridLayoutManager(this, desiredSpans)
            }
        } else {
            if (curLm is GridLayoutManager || curLm == null) {
                rvStreams.layoutManager = LinearLayoutManager(this)
            }
        }
        streamAdapter.gridMode = enableGrid
        btnViewMode.text = if (isPortrait) {
            if (enableGrid) "☰" else "▦"
        } else {
            if (enableGrid) "☰ قائمة" else "▦ بوسترات"
        }
    }

    private fun onFavoriteFolderLongPressed(cat: CategoryItem) {
        if (cat.id == "__new_fav_folder__") {
            btnNewFavFolder.performClick()
            return
        }
        if (cat.id == "*" || store.isDefaultFavoriteFolder(cat.id)) {
            Toast.makeText(this, "المجلّدات الأساسية ثابتة — يمكنك إنشاء أو حذف مجلّداتك المخصّصة عبر «➕ مجلّد»", Toast.LENGTH_SHORT).show()
            return
        }
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "📂 حذف المجلّد «${cat.title}»؟ (تبقى القنوات في كل المفضّلة)",
            items = listOf("🗑 حذف المجلّد المخصّص"),
            defaultIndex = 0,
            cancelLabel = "إلغاء"
        ) {
            store.deleteCustomFavoriteFolder(cat.id)
            selectedFavFolderId = "*"
            loadLocalTab(ContentTab.FAV)
            Toast.makeText(this, "تم حذف المجلّد «${cat.title}»", Toast.LENGTH_SHORT).show()
        }
    }

    private fun onCategorySelected(cat: CategoryItem) {
        if (currentTab == ContentTab.FAV) {
            if (cat.id == "__new_fav_folder__") {
                categoryAdapter.selectedId = selectedFavFolderId
                categoryAdapter.notifyDataSetChanged()
                btnNewFavFolder.performClick()
                return
            }
            selectedFavFolderId = cat.id
            loadLocalTab(ContentTab.FAV)
            return
        }
        val acc = store.getActiveAccount() ?: return
        val lockKey = "${acc.cacheKey()}|${currentTab.name}|${cat.id}"
        if (cat.locked && lockKey !in unlockedCategoryIds) {
            FeatureDialogs.showPinPromptDialog(this, store, "🔒 القسم «${cat.title}» محميّ برمز عائلي") {
                unlockedCategoryIds.add(lockKey)
                proceedCategorySelection(cat)
            }
            // إرجاع التحديد البصري إلى القسم المفتوح حالياً ريثما يُدخل الرمز
            categoryAdapter.selectedId = currentCategoryId
            categoryAdapter.notifyDataSetChanged()
            return
        }
        proceedCategorySelection(cat)
    }

    private fun applyCurrentTheme() {
        val prefs = store.loadPrefs()
        val pal = ThemeHelper.setMode(prefs.themeMode)
        val density = resources.displayMetrics.density

        findViewById<View?>(R.id.rootMain)?.setBackgroundColor(pal.bgMain)
        findViewById<View?>(R.id.navRail)?.setBackgroundColor(pal.bgRail)
        findViewById<View?>(R.id.railBorderLine)?.setBackgroundColor(pal.borderSubtle)
        findViewById<View?>(R.id.railDividerTop)?.setBackgroundColor(pal.borderSubtle)
        findViewById<View?>(R.id.railDividerBottom)?.setBackgroundColor(pal.borderSubtle)
        findViewById<View?>(R.id.topBarDivider)?.setBackgroundColor(pal.borderSubtle)
        findViewById<View?>(R.id.statusBarDivider)?.setBackgroundColor(pal.borderSubtle)
        findViewById<View?>(R.id.topBar)?.setBackgroundColor(pal.bgPanel)
        findViewById<View?>(R.id.topTabRow)?.setBackgroundColor(pal.bgPanel)
        findViewById<View?>(R.id.topSearchRow)?.setBackgroundColor(pal.bgPanel)
        findViewById<View?>(R.id.bottomStatusBar)?.setBackgroundColor(pal.bgPanel)

        categoryPane.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(pal.bgPanel)
            setStroke(1, pal.borderSubtle)
        }
        findViewById<View?>(R.id.itemsPane)?.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(pal.bgPanel)
            setStroke(1, pal.borderSubtle)
        }

        findViewById<TextView?>(R.id.tvBrand)?.setTextColor(pal.accent)
        findViewById<TextView?>(R.id.tvBrandSub)?.setTextColor(pal.textSecondary)
        tvCatHeader.setTextColor(pal.accent)
        tvListHeader.setTextColor(pal.textPrimary)
        tvListCount.setTextColor(pal.accent)
        tvStatusMsg.setTextColor(pal.textSecondary)
        tvEmptyState.setTextColor(pal.textSecondary)

        etSearch.background = ThemeHelper.buildInputBackground(pal, density)
        etSearch.setTextColor(pal.textPrimary)
        etSearch.setHintTextColor(pal.textSecondary)

        etCatFilter?.let { cf ->
            cf.background = ThemeHelper.buildInputBackground(pal, density)
            cf.setTextColor(pal.textPrimary)
            cf.setHintTextColor(pal.textSecondary)
        }

        val tabs = listOf(tabLive, tabVod, tabSeries, tabFav, tabRecent)
        for (tb in tabs) {
            tb.background = ThemeHelper.buildChipBackground(pal, dp(20).toFloat(), density)
            val sel = tb.isSelected
            tb.setTextColor(if (sel) Color.WHITE else pal.textPrimary)
        }

        val actionBtns = listOf(
            btnSavedLibrary,
            btnAccounts,
            btnCatMgr,
            btnStats,
            btnRefresh,
            btnSettings,
            btnViewMode,
            btnLetterFilter,
            btnSort,
            btnBackLevel
        )
        for (b in actionBtns) {
            b.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
            b.setTextColor(pal.textPrimary)
        }
        btnToggleCats.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnToggleCats.setTextColor(pal.accent)
        btnBackLevel.setTextColor(
            if (pal.mode == com.iptvlite.tv.model.AppThemeMode.LIGHT) Color.parseColor("#B45309")
            else Color.parseColor("#FBBF24")
        )
        btnNewFavFolder.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnGlobalSearch.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnGlobalSearch.setTextColor(pal.accent)
        btnItemAction.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnItemAction.setTextColor(
            if (currentTab == ContentTab.RECENT) Color.parseColor("#FCA5A5") else pal.accent
        )
        btnResumeLast.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnResumeLast.setTextColor(Color.parseColor("#34D399"))
        btnQuickSetup.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = true)
        btnQuickSetup.setTextColor(Color.WHITE)
        btnExit.background = ThemeHelper.buildPillButtonBackground(pal, density, primary = false)
        btnExit.setTextColor(Color.parseColor("#F87171"))

        if (::categoryAdapter.isInitialized) categoryAdapter.notifyDataSetChanged()
        if (::streamAdapter.isInitialized) streamAdapter.notifyDataSetChanged()
    }

    private fun proceedCategorySelection(cat: CategoryItem) {
        resetSeriesStack()
        resetLetterFilterUi()
        isShowingGlobalSearch = false
        lastFocusedStreamPos = 0
        currentCategoryId = cat.id
        currentCategoryTitle = cat.title
        store.getActiveAccount()?.let { acc ->
            if (!cat.locked && currentTab in listOf(ContentTab.LIVE, ContentTab.VOD, ContentTab.SERIES)) {
                store.saveLastCategoryId(acc, currentTab, cat.id)
            }
        }
        categoryAdapter.selectedId = cat.id
        categoryAdapter.notifyDataSetChanged()
        loadSelectedCategoryItems(cat)
    }

    private fun setupListeners() {
        tabLive.setOnClickListener { switchTab(ContentTab.LIVE) }
        tabVod.setOnClickListener { switchTab(ContentTab.VOD) }
        tabSeries.setOnClickListener { switchTab(ContentTab.SERIES) }
        tabFav.setOnClickListener { switchTab(ContentTab.FAV) }
        tabRecent.setOnClickListener { switchTab(ContentTab.RECENT) }

        btnResumeLast.setOnClickListener {
            resumeLastWatchedChannel()
        }

        btnGlobalSearch.setOnClickListener {
            runGlobalServerSearch()
        }

        btnViewMode.setOnClickListener {
            val nextGrid = !isGridViewActive
            store.saveViewGridMode(currentTab, nextGrid)
            applyGridOrListMode(nextGrid)
            tvStatusMsg.text = if (nextGrid) "▦ تم التبديل إلى عرض شبكة البوسترات" else "☰ تم التبديل إلى عرض القائمة السريعة"
        }

        btnNewFavFolder.setOnClickListener {
            TvDialogs.showCreateFavFolderDialog(this, store) { newFolder ->
                selectedFavFolderId = newFolder
                loadLocalTab(ContentTab.FAV)
                tvStatusMsg.text = "📂 تم إنشاء وفتح مجلّد «$newFolder»"
            }
        }

        btnLetterFilter.setOnClickListener {
            showLetterFilterDialog()
        }

        btnSort.setOnClickListener {
            showSortModeDialog()
        }

        btnToggleCats.setOnClickListener {
            if (currentTab == ContentTab.RECENT) return@setOnClickListener
            val nextVis = if (categoryPane.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            categoryPane.visibility = nextVis
            btnToggleCats.text = if (nextVis == View.VISIBLE) "📂 الباقات ▾" else "📂 الباقات ▸"
            if (isGridViewActive) {
                applyGridOrListMode(true)
            }
        }

        etCatFilter?.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (suppressCatFilterWatcher) return
                val activeSel = if (currentTab == ContentTab.FAV) selectedFavFolderId else currentCategoryId
                setMasterCategories(visibleCategoriesMaster, activeSel)
            }
        })

        btnAccounts.setOnClickListener { openAccountsManager() }
        btnQuickSetup.setOnClickListener { openAccountsManager() }

        btnSavedLibrary.setOnClickListener {
            FeatureDialogs.showSavedMediaLibraryDialog(this) { localItem ->
                launchOfflineLocalMedia(localItem)
            }
        }

        btnCatMgr.setOnClickListener {
            openCategoryManagerForCurrentTab()
        }

        btnStats.setOnClickListener {
            FeatureDialogs.showStatsAndBackupDialog(
                ctx = this,
                store = store,
                onExportBackupFile = { launchExportPicker() },
                onImportBackupFile = { launchImportPicker() },
                onExportFavM3u = {
                    launchM3uExport(store.getFavorites(), "Favorites", "iptv_favorites.m3u")
                },
                onExportCurrentListM3u = {
                    val cur = streamAdapter.currentItems()
                    val grp = currentCategoryTitle.ifBlank { currentTab.titleAr }
                    launchM3uExport(cur, grp, "iptv_playlist.m3u")
                },
                onHistoryCleared = {
                    if (currentTab == ContentTab.RECENT) loadLocalTab(ContentTab.RECENT)
                },
                onResumeItem = { entry ->
                    val acc = store.getAccounts().firstOrNull { it.id == entry.accountId } ?: store.getActiveAccount()
                    if (acc != null) {
                        launchSingleStream(acc, entry.item, listOf(entry.item), 0)
                    } else {
                        openAccountsManager()
                    }
                },
                onPlayLocalMedia = { localItem ->
                    launchOfflineLocalMedia(localItem)
                }
            )
        }

        btnItemAction.setOnClickListener {
            if (currentTab == ContentTab.RECENT) {
                showClearRecentDialog()
                return@setOnClickListener
            }
            val candidate = resolveFocusedOrFirstItem()
            if (candidate == null) {
                Toast.makeText(this, "اختر عنصراً من القائمة أولاً", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (currentTab == ContentTab.FAV) {
                val idx = streamAdapter.currentItems().indexOfFirst { it.id == candidate.id && it.kind == candidate.kind }
                showItemContextMenu(candidate, idx)
                return@setOnClickListener
            }
            val acc = resolveAccountForItem(candidate) ?: return@setOnClickListener
            when (candidate.kind) {
                ItemKind.LIVE -> openEpgDialogForChannel(acc, candidate)
                ItemKind.VOD, ItemKind.SERIES -> openMediaCard(acc, candidate)
                else -> showItemContextMenu(candidate, 0)
            }
        }

        btnSettings.setOnClickListener {
            TvDialogs.showSettingsDialog(this, store) { prefs ->
                applyCurrentTheme()
                tvStatusMsg.text = "✔ تم تحديث المظهر والإعدادات (${prefs.cacheMs}ms)"
            }
        }

        btnRefresh.setOnClickListener {
            PortalClient.clearCaches()
            val acc = store.getActiveAccount()
            if (acc != null) {
                tvStatusMsg.text = "↻ جارٍ تحديث القوائم من السيرفر…"
                onAccountActivated(acc)
            }
        }

        btnExit.setOnClickListener {
            showExitConfirmationDialog()
        }

        btnBackLevel.setOnClickListener {
            stepBackSeriesLevel()
        }

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (suppressSearchWatcher) return
                uiHandler.removeCallbacks(searchDebounceRunnable)
                val txt = s?.toString()?.trim().orEmpty()
                if (isShowingGlobalSearch && txt.isEmpty()) {
                    exitGlobalSearchMode()
                } else if (txt.isEmpty()) {
                    applySearchFilter()
                } else {
                    uiHandler.postDelayed(searchDebounceRunnable, 160L)
                }
            }
        })

        etSearch.setOnEditorActionListener { _, actionId, event ->
            val isEnter = event != null && event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ENTER
            if (actionId == EditorInfo.IME_ACTION_SEARCH || isEnter) {
                hideSoftKeyboard(etSearch)
                runGlobalServerSearch()
                true
            } else {
                false
            }
        }

        setupDpadFocusPolish()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDpadFocusPolish() {
        val interactiveButtons = listOf(
            tabLive, tabVod, tabSeries, tabFav, tabRecent,
            btnResumeLast, btnGlobalSearch, btnAccounts, btnSettings, btnRefresh, btnExit,
            btnSavedLibrary, btnStats, btnCatMgr, btnToggleCats, btnViewMode,
            btnLetterFilter, btnSort, btnItemAction, btnNewFavFolder, btnBackLevel, btnQuickSetup
        )
        for (btn in interactiveButtons) {
            ThemeHelper.attachFocusScale(btn, 1.045f) { v, hasFocus ->
                if (hasFocus) {
                    v.requestRectangleOnScreen(Rect(0, 0, v.width, v.height), false)
                }
            }
        }

        // منع فتح لوحة المفاتيح بالخطأ عند مجرّد المرور بالريموت فوق حقل البحث؛ تُفتح فقط عند الضغط الفعلي (OK أو لمسة الأصبع)
        val searchFields = listOfNotNull(etSearch, etCatFilter)
        for (field in searchFields) {
            field.showSoftInputOnFocus = false
            field.setOnClickListener {
                openSoftKeyboardExplicitly(field)
            }
            field.setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_UP) {
                    field.requestFocus()
                    openSoftKeyboardExplicitly(field)
                }
                false
            }
            ThemeHelper.attachFocusScale(field, 1.015f)
        }
    }

    private fun openSoftKeyboardExplicitly(field: EditText) {
        field.requestFocus()
        field.setSelection(field.text?.length ?: 0)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(field, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideSoftKeyboard(view: View) {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun resumeLastWatchedChannel() {
        val acc = store.getActiveAccount()
        if (acc == null) {
            openAccountsManager()
            return
        }
        val recents = store.getRecent()
        val last = recents.firstOrNull { it.kind in listOf(ItemKind.LIVE, ItemKind.VOD, ItemKind.EPISODE) }
        if (last == null) {
            Toast.makeText(this, "لا توجد قناة أو فيلم سابق في سجلّ المشاهدة بعد", Toast.LENGTH_SHORT).show()
            return
        }
        val sameKindList = recents.filter { it.kind == last.kind }
        launchSingleStream(acc, last, sameKindList.ifEmpty { listOf(last) }, 0)
    }

    private fun extractInitialBucket(name: String): String {
        val ch = name.trim().firstOrNull { it.isLetterOrDigit() } ?: return "#"
        return when {
            ch.isDigit() -> "0-9"
            ch in 'أ'..'ي' || ch in 'ء'..'غ' || ch in setOf('آ', 'إ', 'أ', 'ا') -> {
                when (ch) {
                    'أ', 'إ', 'آ' -> "ا"
                    'ة' -> "ه"
                    'ى' -> "ي"
                    else -> ch.toString()
                }
            }
            else -> ch.uppercaseChar().toString()
        }
    }

    private fun resetLetterFilterUi() {
        currentLetterFilter = ""
        if (::btnLetterFilter.isInitialized) {
            btnLetterFilter.text = "🔤 الكل"
        }
    }

    private fun showLetterFilterDialog() {
        if (rawItems.isEmpty()) {
            Toast.makeText(this, "القائمة فارغة حالياً", Toast.LENGTH_SHORT).show()
            return
        }
        val counts = LinkedHashMap<String, Int>()
        for (it in rawItems) {
            val b = extractInitialBucket(it.name)
            counts[b] = (counts[b] ?: 0) + 1
        }
        val sortedBuckets = counts.keys.sortedWith(
            compareBy<String> {
                when {
                    it.first().code in 0x0600..0x06FF -> 0 // الحروف العربية أولاً
                    it == "0-9" -> 2
                    it == "#" -> 3
                    else -> 1 // الحروف اللاتينية A-Z
                }
            }.thenBy { it }
        )

        val entries = ArrayList<Pair<String, String>>(sortedBuckets.size + 1)
        val allMark = if (currentLetterFilter.isEmpty()) "✔ " else ""
        entries.add("" to "${allMark}🔤 عرض الكل (${rawItems.size})")
        for (b in sortedBuckets) {
            val mark = if (currentLetterFilter == b) "✔ " else ""
            entries.add(b to "$mark$b  (${counts[b]} عنصر)")
        }

        val defaultIdx = entries.indexOfFirst { it.first == currentLetterFilter }.coerceAtLeast(0)
        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "🔤 الفلترة السريعة بالحرف الأول",
            items = entries.map { it.second },
            defaultIndex = defaultIdx
        ) { which ->
            val chosen = entries[which].first
            currentLetterFilter = chosen
            btnLetterFilter.text = if (chosen.isEmpty()) "🔤 الكل" else "🔤 $chosen"
            applySearchFilter()
            tvStatusMsg.text = if (chosen.isEmpty()) {
                "✔ عرض جميع الحروف (${rawItems.size})"
            } else {
                "✔ فلترة بالحرف «$chosen»"
            }
        }
    }

    private fun showSortModeDialog() {
        val modes = SortMode.entries
        val labels = modes.map { m ->
            if (m == currentSortMode) "✔ ${m.labelAr}" else m.labelAr
        }
        val defaultIdx = modes.indexOf(currentSortMode).coerceAtLeast(0)

        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "⇅ ترتيب وعرض القائمة",
            items = labels,
            defaultIndex = defaultIdx
        ) { which ->
            val chosen = modes[which]
            currentSortMode = chosen
            store.saveSortMode(currentTab, chosen)
            btnSort.text = chosen.shortLabel
            applySearchFilter()
            tvStatusMsg.text = "✔ الترتيب الحالي: ${chosen.labelAr}"
        }
    }

    private fun computeRestrictedCategoryIds(acc: AccountProfile, tab: ContentTab): Set<String> {
        val prefs = store.getCategoryPrefsMap(acc, tab)
        val autoAdult = store.isAutoLockAdult()
        val blocked = HashSet<String>()
        for (c in rawCategories) {
            if (c.id == "*") continue
            val p = prefs[c.id]
            val hidden = p?.hidden == true
            val locked = (p?.locked == true) || (autoAdult && AppStore.isAdultCategoryTitle(c.title))
            val lockKey = "${acc.cacheKey()}|${tab.name}|${c.id}"
            if (hidden || (locked && lockKey !in unlockedCategoryIds)) {
                blocked.add(c.id)
            }
        }
        return blocked
    }

    private fun runGlobalServerSearch() {
        val acc = store.getActiveAccount()
        if (acc == null) {
            openAccountsManager()
            return
        }
        val q = etSearch.text.toString().trim()
        if (q.length < 2) {
            Toast.makeText(this, "أدخل حرفين على الأقل في خانة البحث للبحث الشامل في السيرفر", Toast.LENGTH_SHORT).show()
            etSearch.requestFocus()
            return
        }
        val targetTab = if (currentTab in listOf(ContentTab.LIVE, ContentTab.VOD, ContentTab.SERIES)) {
            currentTab
        } else {
            ContentTab.LIVE
        }
        if (!isShowingGlobalSearch) {
            savedPreGlobalItems = rawItems
        }
        isShowingGlobalSearch = true
        resetSeriesStack()
        val excluded = computeRestrictedCategoryIds(acc, targetTab)

        cancelBrowse()
        tvListHeader.text = "🌐 البحث الشامل (${targetTab.titleAr}): «$q»"
        rawItems = emptyList()
        streamAdapter.submit(emptyList())
        setLoading(true, "⏳ جارٍ البحث الشامل في كل أقسام ${targetTab.titleAr} عن «$q»…")

        val ticket=browseGeneration.current()
        val requestScope=com.iptvlite.tv.network.PlaybackRequestScope()
        browseScope=requestScope
        var requestFinished=false
        browseJob = lifecycleScope.launch {
            val res = runCatching {
                ownedIo(requestScope) {
                    PortalClient.globalSearch(acc, targetTab, q, excluded)
                }
            }
            requestFinished=true
            if(!browseGeneration.accepts(ticket) || isFinishing || isDestroyed || store.getActiveAccount()?.id!=acc.id) return@launch
            setLoading(false)
            res.onSuccess { hits ->
                rawItems = hits
                applySearchFilter()
                tvStatusMsg.text = "✔ البحث الشامل عن «$q»: ${hits.size} نتيجة"
                if (hits.isEmpty()) {
                    updateEmptyState("لم يُعثر على نتائج مطابقة لـ «$q» في كل أقسام ${targetTab.titleAr}.")
                }
            }.onFailure { err ->
                if (err is CancellationException) return@onFailure
                updateEmptyState("✖ تعذّر إكمال البحث الشامل: ${err.message}")
            }
        }
    }

    private fun exitGlobalSearchMode(): Boolean {
        if (!isShowingGlobalSearch) return false
        cancelBrowse()
        PortalClient.preemptBrowse()
        isShowingGlobalSearch = false
        tvListHeader.text = MediaTitleFormatter.parseCategory(currentCategoryTitle).cleanTitle.ifBlank { currentTab.titleAr }
        rawItems = savedPreGlobalItems
        savedPreGlobalItems = emptyList()
        applySearchFilter()
        return true
    }

    private fun resolveFocusedOrFirstItem(): StreamItem? {
        val focused = rvStreams.focusedChild
        if (focused != null) {
            val pos = rvStreams.getChildAdapterPosition(focused)
            val list = streamAdapter.currentItems()
            if (pos in list.indices) return list[pos]
        }
        return lastTouchedItem ?: streamAdapter.currentItems().firstOrNull()
    }

    private fun openCategoryManagerForCurrentTab() {
        val acc = store.getActiveAccount()
        if (acc == null) {
            openAccountsManager()
            return
        }
        val targetTab = if (currentTab in listOf(ContentTab.LIVE, ContentTab.VOD, ContentTab.SERIES)) {
            currentTab
        } else {
            ContentTab.LIVE
        }
        FeatureDialogs.showCategoryManagerDialog(
            ctx = this,
            store = store,
            acc = acc,
            tab = targetTab,
            rawCategories = rawCategories,
            onChanged = {
                refreshVisibleCategoriesAndItems(acc)
            }
        )
    }

    private fun refreshVisibleCategoriesAndItems(acc: AccountProfile) {
        if (currentTab !in listOf(ContentTab.LIVE, ContentTab.VOD, ContentTab.SERIES)) return
        val visibleCats = store.applyCategoryPrefs(acc, currentTab, rawCategories)
        if (visibleCats.isEmpty()) {
            setMasterCategories(emptyList(), "")
            rawItems = emptyList()
            applySearchFilter()
            updateEmptyState("جميع الأقسام مخفية حالياً — افتح «🔒 الأقسام» لإظهارها.")
            return
        }
        val curStillVisible = visibleCats.firstOrNull { it.id == currentCategoryId } ?: visibleCats.first()
        currentCategoryId = curStillVisible.id
        currentCategoryTitle = curStillVisible.title
        setMasterCategories(visibleCats, curStillVisible.id)
        loadSelectedCategoryItems(curStillVisible)
    }

    private fun showClearRecentDialog() {
        val recents = store.getRecent()
        if (recents.isEmpty()) {
            Toast.makeText(this, "سجلّ المشاهدة (الأخير) فارغ حالياً", Toast.LENGTH_SHORT).show()
            return
        }
        val focused = resolveFocusedOrFirstItem()
        val options = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        if (focused != null) {
            options.add("🗑 حذف «${focused.name}» فقط من السجلّ")
            actions.add {
                store.removeRecentItem(focused)
                if (lastTouchedItem?.id == focused.id) lastTouchedItem = null
                loadLocalTab(ContentTab.RECENT)
                Toast.makeText(this, "✔ حُذِف «${focused.name}» من السجلّ", Toast.LENGTH_SHORT).show()
            }
        }

        options.add("🧹 مسح سجلّ الأخير بالكامل (${recents.size} عنصر)")
        actions.add {
            TvDialogs.showNeonChoiceDialog(
                ctx = this,
                title = "🧹 مسح جميع عناصر «🕘 الأخير» (${recents.size})؟ (لا تتأثّر المفضّلة ★)",
                items = listOf("✔ نعم، مسح السجلّ بالكامل"),
                defaultIndex = 0,
                cancelLabel = "إلغاء"
            ) {
                store.clearRecent()
                lastTouchedItem = null
                loadLocalTab(ContentTab.RECENT)
                Toast.makeText(this, "✔ تمّ مسح سجلّ المشاهدة (الأخير) بالكامل", Toast.LENGTH_SHORT).show()
            }
        }

        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = "🕘 إدارة سجلّ المشاهدة (الأخير)",
            items = options,
            defaultIndex = 0,
            cancelLabel = "إلغاء"
        ) { which ->
            actions[which].invoke()
        }
    }

    private fun showItemContextMenu(item: StreamItem, adapterPos: Int) {
        val acc = resolveAccountForItem(item)
        val isFav = store.isFavorite(item)
        val options = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        if (currentTab == ContentTab.RECENT) {
            options.add("🗑 حذف هذا العنصر من السجلّ (الأخير)")
            actions.add {
                store.removeRecentItem(item)
                if (lastTouchedItem?.id == item.id && lastTouchedItem?.kind == item.kind) lastTouchedItem = null
                loadLocalTab(ContentTab.RECENT)
                Toast.makeText(this, "✔ حُذِف «${item.name}» من السجلّ", Toast.LENGTH_SHORT).show()
            }
            val recCount = store.getRecent().size
            if (recCount > 1) {
                options.add("🧹 مسح سجلّ الأخير بالكامل ($recCount عنصر)")
                actions.add {
                    TvDialogs.showNeonChoiceDialog(
                        ctx = this,
                        title = "🧹 مسح جميع عناصر «🕘 الأخير» ($recCount)؟",
                        items = listOf("✔ نعم، مسح الكلّ"),
                        defaultIndex = 0,
                        cancelLabel = "إلغاء"
                    ) {
                        store.clearRecent()
                        lastTouchedItem = null
                        loadLocalTab(ContentTab.RECENT)
                        Toast.makeText(this, "✔ تمّ مسح سجلّ الأخير بالكامل", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        if (acc != null && item.kind == ItemKind.LIVE) {
            options.add("📋 دليل البرامج وأرشيف الإعادة (Catch-up)")
            actions.add { openEpgDialogForChannel(acc, item) }
            if (StreamRecorder.isRecording()) {
                options.add("⏹ إيقاف التسجيل الجاري (${StreamRecorder.activeRecTitle})")
                actions.add {
                    StreamRecorder.stopRecording()
                    Toast.makeText(this, "⏹ تم إيقاف التسجيل وحفظ الملف", Toast.LENGTH_SHORT).show()
                }
            } else {
                options.add("⏺ بدء تسجيل مباشر لهذه القناة الآن")
                actions.add { startBackgroundLiveRecording(acc, item) }
            }
        } else if (acc != null && (item.kind == ItemKind.VOD || item.kind == ItemKind.SERIES)) {
            options.add("🎬 بطاقة العمل (القصة · التقييم · الممثلون)")
            actions.add { openMediaCard(acc, item) }
        }

        if (acc != null && (item.kind == ItemKind.VOD || item.kind == ItemKind.EPISODE)) {
            options.add("📥 تحميل الفيلم / الحلقة إلى الجهاز")
            actions.add { promptVodDownload(acc, item) }
        }

        options.add(if (isFav) "★ إزالة من المفضّلة" else "☆ إضافة إلى المفضّلة")
        actions.add {
            val nowFav = store.toggleFavorite(item)
            if (adapterPos in 0 until streamAdapter.itemCount) {
                streamAdapter.notifyItemChanged(adapterPos)
            } else {
                streamAdapter.notifyDataSetChanged()
            }
            Toast.makeText(
                this,
                if (nowFav) "★ أُضيفت إلى المفضّلة: ${item.name}" else "☆ أُزيلت من المفضّلة",
                Toast.LENGTH_SHORT
            ).show()
            if (currentTab == ContentTab.FAV) loadLocalTab(ContentTab.FAV)
        }

        val curFavFolder = store.getFavoriteItemFolder(item)
        val folderSuffix = if (curFavFolder.isNotBlank()) " ($curFavFolder)" else ""
        options.add("📂 تصنيف في مجلّد مفضّلة…$folderSuffix")
        actions.add {
            TvDialogs.showFavoriteFolderPickerDialog(this, store, item) {
                if (adapterPos in 0 until streamAdapter.itemCount) {
                    streamAdapter.notifyItemChanged(adapterPos)
                } else {
                    streamAdapter.notifyDataSetChanged()
                }
                if (currentTab == ContentTab.FAV) loadLocalTab(ContentTab.FAV)
            }
        }

        val savedResumePos = if (item.kind == ItemKind.VOD || item.kind == ItemKind.EPISODE) {
            store.getResumePos(item)
        } else 0L

        options.add(
            when {
                item.kind == ItemKind.SERIES -> "📂 فتح المواسم والحلقات"
                savedResumePos >= AppStore.MIN_RESUME_POS_MS -> "⏵ متابعة التشغيل من ${AppStore.formatResumeTime(savedResumePos)}"
                else -> "▶ تشغيل فوري"
            }
        )
        actions.add {
            val list = streamAdapter.currentItems()
            val idx = list.indexOfFirst { it.id == item.id && it.kind == item.kind }.coerceAtLeast(0)
            onStreamClicked(item, idx, list.ifEmpty { listOf(item) })
        }

        if (savedResumePos >= AppStore.MIN_RESUME_POS_MS) {
            options.add("⏮ تشغيل من البداية (مسح موضع الاستئناف)")
            actions.add {
                store.clearResumePos(item)
                streamAdapter.notifyDataSetChanged()
                val list = streamAdapter.currentItems()
                val idx = list.indexOfFirst { it.id == item.id && it.kind == item.kind }.coerceAtLeast(0)
                onStreamClicked(item, idx, list.ifEmpty { listOf(item) })
            }
        }

        TvDialogs.showNeonChoiceDialog(
            ctx = this,
            title = MediaTitleFormatter.parseMedia(item.name).cleanTitle.ifBlank { item.name },
            items = options,
            defaultIndex = 0
        ) { which ->
            actions[which].invoke()
        }
    }

    private fun openEpgDialogForChannel(acc: AccountProfile, ch: StreamItem) {
        FeatureDialogs.showEpgArchiveDialog(
            ctx = this,
            store = store,
            scope = lifecycleScope,
            acc = acc,
            ch = ch,
            onPlayLive = { liveCh ->
                val list = streamAdapter.currentItems().ifEmpty { listOf(liveCh) }
                val idx = list.indexOfFirst { it.id == liveCh.id }.coerceAtLeast(0)
                launchSingleStream(acc, liveCh, list, idx)
            },
            onPlayCatchup = { catchupItem, srcCh ->
                PlayQueueHolder.archiveSourceChannel = srcCh
                launchSingleStream(acc, catchupItem, listOf(catchupItem), 0, keepArchiveSrc = true)
            }
        )
    }

    private fun startBackgroundLiveRecording(acc: AccountProfile, item: StreamItem) {
        val appCtx = applicationContext
        val selfRef = WeakReference(this)
        val ok = StreamRecorder.startRecording(
            context = appCtx,
            acc = acc,
            item = item,
            onTick = { elSec, bytes ->
                val act = selfRef.get()
                if (act != null && !act.isFinishing && !act.isDestroyed) {
                    val m = elSec / 60L
                    val s = elSec % 60L
                    act.tvStatusMsg.text = String.format(
                        java.util.Locale.US,
                        "🔴 يُسجّل الآن: %s (%02d:%02d · %s)",
                        item.name,
                        m,
                        s,
                        StreamRecorder.formatSizeMb(bytes)
                    )
                }
            },
            onFinished = { savedOk, savedPath, bytes, err ->
                val act = selfRef.get()
                if (savedOk) {
                    AppStore(appCtx).incrementRecCount()
                    val msg = "✔ تم حفظ التسجيل (${StreamRecorder.formatSizeMb(bytes)}) في $savedPath"
                    if (act != null && !act.isFinishing && !act.isDestroyed) {
                        act.tvStatusMsg.text = msg
                    }
                    Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show()
                } else if (err.isNotBlank()) {
                    if (act != null && !act.isFinishing && !act.isDestroyed) {
                        act.tvStatusMsg.text = "✖ تعذّر التسجيل: $err"
                    }
                    Toast.makeText(appCtx, "✖ تعذّر التسجيل: $err", Toast.LENGTH_LONG).show()
                }
            }
        )
        if (ok) {
            Toast.makeText(this, "🔴 بدأ تسجيل «${item.name}» في مجلد التنزيلات", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "⚠ يوجد تسجيل جارٍ بالفعل", Toast.LENGTH_SHORT).show()
        }
    }

    private fun promptVodDownload(acc: AccountProfile, item: StreamItem) {
        val appCtx = applicationContext
        val selfRef = WeakReference(this)
        FeatureDialogs.showVodDownloadChoiceDialog(
            ctx = this,
            scope = lifecycleScope,
            acc = acc,
            item = item,
            onStartInternalDownload = { resolvedUrl ->
                tvStatusMsg.text = "📥 جارٍ الاتصال بالسيرفر لبدء تحميل «${item.name}»…"
                val started = StreamRecorder.startDownload(
                    context = appCtx,
                    acc = acc,
                    item = item,
                    directUrl = resolvedUrl,
                    onProgress = { pct, dlBytes, totBytes ->
                        val act = selfRef.get()
                        if (act != null && !act.isFinishing && !act.isDestroyed) {
                            val dlTxt = StreamRecorder.formatSizeMb(dlBytes)
                            val totTxt = if (totBytes > 0L) " / ${StreamRecorder.formatSizeMb(totBytes)}" else ""
                            val pctTxt = if (pct >= 0) "$pct% · " else ""
                            act.tvStatusMsg.text = "📥 تحميل «${item.name}»: $pctTxt$dlTxt$totTxt"
                        }
                    },
                    onFinished = { ok, savedPath, dlBytes, err ->
                        val act = selfRef.get()
                        if (ok) {
                            val msg = "✔ اكتمل تحميل «${item.name}» (${StreamRecorder.formatSizeMb(dlBytes)}) في $savedPath"
                            if (act != null && !act.isFinishing && !act.isDestroyed) {
                                act.tvStatusMsg.text = msg
                            }
                            Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show()
                        } else if (err.isNotBlank()) {
                            val msg = "⚠ لم يكتمل التحميل: $err"
                            if (act != null && !act.isFinishing && !act.isDestroyed) {
                                act.tvStatusMsg.text = msg
                            }
                            Toast.makeText(appCtx, msg, Toast.LENGTH_LONG).show()
                        }
                    }
                )
                if (started) {
                    Toast.makeText(this, "📥 بدأ التحميل المباشر لـ «${item.name}» إلى مجلد التنزيلات", Toast.LENGTH_LONG).show()
                }
            }
        )
    }

    private fun openMediaCard(acc: AccountProfile, item: StreamItem) {
        FeatureDialogs.showMediaInfoDialog(
            ctx = this,
            store = store,
            scope = lifecycleScope,
            acc = acc,
            item = item,
            onOpenOrPlay = { target ->
                val list = streamAdapter.currentItems().ifEmpty { listOf(target) }
                val idx = list.indexOfFirst { it.id == target.id }.coerceAtLeast(0)
                onStreamClicked(target, idx, list)
            },
            onFavChanged = {
                streamAdapter.notifyDataSetChanged()
                if (currentTab == ContentTab.FAV) loadLocalTab(ContentTab.FAV)
            },
            onDownloadVod = { target ->
                promptVodDownload(acc, target)
            }
        )
    }

    private fun onAccountActivated(acc: AccountProfile, initialTab: ContentTab = ContentTab.LIVE) {
        PlayQueueHolder.activeAccount = acc
        tvAccountInfo.text = "👤 ${acc.name} · [${acc.provider.label}]"
        refreshAccountBadgeAsync(acc)
        switchTab(initialTab, forceReload = true)
    }

    private fun refreshAccountBadgeAsync(acc: AccountProfile) {
        cancelBadge()
        val ticket=badgeGeneration.current()
        val owner=com.iptvlite.tv.network.PlaybackRequestScope()
        badgeScope=owner
        badgeJob=lifecycleScope.launch {
            runCatching {ownedIo(owner,false) {
                owner.checkActive()
                val attempt=store.beginAccountStatusRefresh(acc) ?: throw CancellationException("Account changed")
                attempt to PortalClient.fetchAccountStatus(acc)
            }}.onSuccess {(attempt,info)->
                val active=store.getActiveAccount()
                if(!badgeGeneration.accepts(ticket) || isFinishing || isDestroyed ||
                    active?.networkCacheKey()!=acc.networkCacheKey()) return@onSuccess
                if(!withContext(Dispatchers.IO) {store.finishAccountStatusRefresh(acc,attempt,info)})return@onSuccess
                val pingPart=if(info.pingMs>0)" · ⚡ ${info.pingMs}ms" else ""
                tvAccountInfo.text="👤 ${acc.name} · ⏳ ${info.expiry} · 🔗 ${info.maxConnections}$pingPart"
            }
        }
    }

    private fun switchTab(tab: ContentTab, forceReload: Boolean = false) {
        if (currentTab == tab && !forceReload) return
        currentTab = tab
        isShowingGlobalSearch = false
        savedPreGlobalItems = emptyList()
        currentSortMode = store.getSortMode(tab)
        btnSort.text = currentSortMode.shortLabel
        applyGridOrListMode(store.isViewGridMode(tab))
        resetLetterFilterUi()
        resetSeriesStack()
        lastTouchedItem = null
        lastFocusedStreamPos = 0
        suppressSearchWatcher = true
        etSearch.setText("")
        suppressSearchWatcher = false
        suppressCatFilterWatcher = true
        etCatFilter?.setText("")
        suppressCatFilterWatcher = false

        tabLive.isSelected = (tab == ContentTab.LIVE)
        tabVod.isSelected = (tab == ContentTab.VOD)
        tabSeries.isSelected = (tab == ContentTab.SERIES)
        tabFav.isSelected = (tab == ContentTab.FAV)
        tabRecent.isSelected = (tab == ContentTab.RECENT)
        val pal = ThemeHelper.current
        for (tb in listOf(tabLive, tabVod, tabSeries, tabFav, tabRecent)) {
            tb.setTextColor(if (tb.isSelected) Color.WHITE else pal.textPrimary)
        }

        btnItemAction.text = when (tab) {
            ContentTab.LIVE -> "📋 الدليل والأرشيف"
            ContentTab.VOD, ContentTab.SERIES -> "🎬 بطاقة العمل"
            ContentTab.RECENT -> "🗑 مسح السجلّ"
            else -> "★ خيارات"
        }
        btnItemAction.setTextColor(
            if (tab == ContentTab.RECENT) Color.parseColor("#FCA5A5") else pal.accent
        )

        if (tab == ContentTab.FAV) {
            categoryPane.visibility = View.VISIBLE
            btnToggleCats.visibility = View.VISIBLE
            tvCatHeader.text = "📂 مجلّدات المفضّلة"
            btnNewFavFolder.visibility = View.VISIBLE
            btnToggleCats.text = "📂 المجلّدات ▾"
            applyGridOrListMode(store.isViewGridMode(tab))
            loadLocalTab(ContentTab.FAV)
            return
        }

        if (tab == ContentTab.RECENT) {
            categoryPane.visibility = View.GONE
            btnToggleCats.visibility = View.GONE
            btnNewFavFolder.visibility = View.GONE
            applyGridOrListMode(store.isViewGridMode(tab))
            loadLocalTab(ContentTab.RECENT)
            return
        }

        categoryPane.visibility = View.VISIBLE
        btnToggleCats.visibility = View.VISIBLE
        tvCatHeader.text = "الباقات"
        btnNewFavFolder.visibility = View.GONE
        btnToggleCats.text = "📂 الباقات ▾"
        applyGridOrListMode(store.isViewGridMode(tab))

        val acc = store.getActiveAccount()
        if (acc == null) {
            updateEmptyState("أضف أو استورد سيرفراً أولاً من زر «👤 السيرفرات» بالأعلى.")
            return
        }

        cancelBrowse()
        PortalClient.preemptBrowse()
        setLoading(true, "… جارٍ جلب باقات ${tab.titleAr}")
        rawCategories = emptyList()
        setMasterCategories(emptyList(), "")
        rawItems = emptyList()
        applySearchFilter()

        val ticket=browseGeneration.current()
        val requestScope=com.iptvlite.tv.network.PlaybackRequestScope()
        browseScope=requestScope
        var requestFinished=false
        browseJob = lifecycleScope.launch {
            val res = runCatching {
                ownedIo(requestScope) { PortalClient.loadCategories(acc, tab) }
            }
            requestFinished=true
            if(!browseGeneration.accepts(ticket) || isFinishing || isDestroyed || store.getActiveAccount()?.id!=acc.id) return@launch
            setLoading(false)
            res.onSuccess { cats ->
                rawCategories = cats
                val visibleCats = store.applyCategoryPrefs(acc, tab, cats)
                if (visibleCats.isEmpty()) {
                    updateEmptyState("لا توجد أقسام ظاهرة في «${tab.titleAr}».")
                    return@onSuccess
                }
                val rememberedId = store.getLastCategoryId(acc, tab)
                val rememberedCat = visibleCats.firstOrNull { it.id == rememberedId && !it.locked }
                // اختيار أول قسم فعلي سريع بدلاً من تحميل جميع القنوات (*) افتراضياً عند فتح سيرفر جديد!
                val first = rememberedCat
                    ?: visibleCats.firstOrNull { it.id != "*" && !it.locked }
                    ?: visibleCats.firstOrNull { !it.locked }
                    ?: visibleCats.first()
                currentCategoryId = first.id
                currentCategoryTitle = first.title
                setMasterCategories(visibleCats, first.id)
                val targetIdx = visibleCats.indexOfFirst { it.id == first.id }
                if (targetIdx > 0) {
                    rvCategories.scrollToPosition(targetIdx)
                }
                tvStatusMsg.text = "✔ ${visibleCats.size} قسماً في ${tab.titleAr}"
                if (first.locked) {
                    onCategorySelected(first)
                } else {
                    loadSelectedCategoryItems(first)
                }
            }.onFailure { err ->
                if (err is CancellationException) return@onFailure
                updateEmptyState("✖ تعذّر جلب الأقسام: ${err.message}")
            }
        }
    }

    private fun loadLocalTab(tab: ContentTab) {
        cancelBrowse()
        PortalClient.preemptBrowse()
        setLoading(false)
        if (tab == ContentTab.FAV) {
            val favCats = store.getFavoriteCategories()
            if (favCats.none { it.id == selectedFavFolderId }) {
                selectedFavFolderId = "*"
            }
            setMasterCategories(favCats, selectedFavFolderId)
            val items = store.getFavoritesInFolder(selectedFavFolderId)
            val activeFolderTitle = favCats.firstOrNull { it.id == selectedFavFolderId }?.title ?: "⭐ كل المفضّلة"
            tvListHeader.text = activeFolderTitle
            rawItems = items
            applySearchFilter()
            if (items.isEmpty()) {
                updateEmptyState(
                    if (selectedFavFolderId == "*")
                        "قائمة المفضّلة فارغة حالياً.\nاضغط مطوّلاً على أي قناة أو فيلم لإضافته للمفضّلة ★ أو تصنيفه في مجلّد 📂"
                    else
                        "المجلّد «$activeFolderTitle» فارغ حالياً.\nاضغط مطوّلاً على أي قناة واختر «📂 تصنيف في مجلّد مفضّلة…» لإضافتها هنا."
                )
            }
        } else {
            val items = store.getRecent()
            tvListHeader.text = "🕘 آخر المشاهدات"
            rawItems = items
            applySearchFilter()
            if (items.isEmpty()) {
                updateEmptyState("سجلّ المشاهدة (الأخير) فارغ حالياً.")
                tvStatusMsg.text = "🕘 سجلّ الأخير فارغ"
            } else {
                tvStatusMsg.text = "🕘 ${items.size} عنصر في السجلّ — اضغط مطوّلاً لحذف عنصر منفرد أو «🗑 مسح السجلّ» بالأعلى"
            }
        }
    }

    private fun loadSelectedCategoryItems(cat: CategoryItem) {
        val acc = store.getActiveAccount() ?: return
        val tab = currentTab
        val cleanCatName = MediaTitleFormatter.parseCategory(cat.title).cleanTitle
        cancelBrowse()
        PortalClient.preemptBrowse()
        tvListHeader.text = cleanCatName
        rawItems = emptyList()
        applySearchFilter()
        setLoading(true, "… جارٍ جلب عناصر «$cleanCatName»")

        if(acc.provider==ProviderType.STALKER) {
            com.iptvlite.tv.network.SelectedCategoryLoad.start(acc,tab,cat.id)
            observeSelectedCategory(acc,tab,cat.id,cleanCatName)
            return
        }
        val ticket=browseGeneration.current()
        val requestScope=com.iptvlite.tv.network.PlaybackRequestScope()
        browseScope=requestScope
        var requestFinished=false
        browseJob = lifecycleScope.launch {
            val res = runCatching {
                ownedIo(requestScope) {
                    PortalClient.loadCategoryItems(acc, tab, cat.id) { partialSnapshot ->
                        val cleanPartial = filterOutRestrictedChannelsInAllView(acc, tab, cat.id, partialSnapshot)
                        uiHandler.post {
                            if (!requestFinished && requestScope.isActive() && browseGeneration.accepts(ticket) && !isFinishing && !isDestroyed && store.getActiveAccount()?.id==acc.id && currentTab == tab && currentCategoryId == cat.id && !isShowingGlobalSearch && activeSeriesItem == null) {
                                rawItems = cleanPartial
                                emptyBox.visibility = View.GONE
                                applySearchFilter()
                                tvStatusMsg.text = "⏳ $cleanCatName — ظهر ${cleanPartial.size} عنصر (جارٍ استكمال البقيّة…)"
                            }
                        }
                    }
                }
            }
            requestFinished=true
            if(!browseGeneration.accepts(ticket) || isFinishing || isDestroyed || store.getActiveAccount()?.id!=acc.id) return@launch
            setLoading(false)
            res.onSuccess { list ->
                val filteredByParental = filterOutRestrictedChannelsInAllView(acc, tab, cat.id, list)
                rawItems = filteredByParental
                applySearchFilter()
                tvStatusMsg.text = "✔ $cleanCatName (${filteredByParental.size} عنصر)"
                if (filteredByParental.isEmpty()) {
                    updateEmptyState("هذا القسم فارغ حالياً.")
                }
            }.onFailure { err ->
                if (err is CancellationException) return@onFailure
                if (rawItems.isEmpty()) {
                    updateEmptyState("✖ تعذّر تحميل القسم: ${err.message}")
                } else {
                    tvStatusMsg.text="⚠ القائمة غير مكتملة (${rawItems.size} عنصر) — أعد فتح القسم للمحاولة"
                }
            }
        }
    }

    private fun observeSelectedCategory(acc:AccountProfile,tab:ContentTab,catId:String,title:String) {
        val ticket=browseGeneration.current()
        browseJob=lifecycleScope.launch {
            var revision=-1L
            while(com.iptvlite.tv.network.SelectedCategoryLoad.matches(acc,tab,catId) && browseGeneration.accepts(ticket)) {
                val status=com.iptvlite.tv.network.SelectedCategoryLoad.status() ?: break
                if(isFinishing || isDestroyed || !acc.hasSameNetworkIdentity(store.getActiveAccount()) || currentTab!=tab || currentCategoryId!=catId || isShowingGlobalSearch || activeSeriesItem!=null)break
                if(status.revision!=revision) {
                    revision=status.revision
                    rawItems=filterOutRestrictedChannelsInAllView(acc,tab,catId,status.items)
                    applySearchFilter()
                    if(rawItems.isNotEmpty()) {setLoading(false);emptyBox.visibility=View.GONE}
                }
                val count=if(status.total>0)"${status.items.size} من ${status.total}" else "${status.items.size}"
                tvStatusMsg.text=when {
                    status.failed->"⚠ $title — القائمة غير مكتملة ($count)؛ ${status.error}"
                    status.complete->"✔ $title (${rawItems.size} عنصر)"
                    status.paused->"⏸ $title — حُمّل $count؛ معلّق لأولوية التشغيل"
                    else->"⏳ $title — حُمّل $count؛ جارٍ استكمال البقيّة…"
                }
                if(status.complete || status.failed) {
                    setLoading(false)
                    if(rawItems.isEmpty())updateEmptyState(if(status.failed)"✖ تعذّر إكمال تحميل القسم؛ أعد المحاولة" else "هذا القسم فارغ حالياً.")
                    break
                }
                kotlinx.coroutines.delay(250)
            }
        }
    }

    private fun filterOutRestrictedChannelsInAllView(
        acc: AccountProfile,
        tab: ContentTab,
        catId: String,
        items: List<StreamItem>
    ): List<StreamItem> {
        if (catId != "*") return items
        val blockedIds = computeRestrictedCategoryIds(acc, tab)
        if (blockedIds.isEmpty()) return items
        return items.filter { it.categoryId !in blockedIds }
    }

    private fun onStreamClicked(item: StreamItem, pos: Int, visibleList: List<StreamItem>) {
        val acc = resolveAccountForItem(item) ?: return
        when (item.kind) {
            ItemKind.SERIES -> {
                openSeriesSeasons(acc, item)
            }

            ItemKind.SEASON -> {
                val ser = activeSeriesItem ?: return
                openSeasonEpisodes(acc, ser, item)
            }

            ItemKind.LIVE, ItemKind.VOD, ItemKind.EPISODE, ItemKind.CATCHUP -> {
                launchSingleStream(acc, item, visibleList, pos)
            }
        }
    }

    private fun launchSingleStream(
        acc: AccountProfile,
        item: StreamItem,
        playlist: List<StreamItem>,
        index: Int,
        keepArchiveSrc: Boolean = false
    ) {
        // الأولوية القصوى الفورية للتشغيل: إيقاف أي تصفّح قوائم أو شعارات خلفية خلال أقلّ من 1ms!
        cancelM3uExport()
        LogoLoader.isPlaybackActive = true
        cancelBadge()
        com.iptvlite.tv.network.SelectedCategoryLoad.playbackStarting()
        cancelBrowse(preserveSelected=true)
        filterJob?.cancel()
        PortalClient.preemptBrowse()
        setLoading(false)

        if (!keepArchiveSrc) {
            PlayQueueHolder.archiveSourceChannel = if (item.kind == ItemKind.LIVE) item else null
        }
        // استبعاد مجلّدات المسلسلات والمواسم من طابور التقليب السريع CH+/CH- حتى لا يتعثّر التقليب داخل المفضّلة أو الأخير
        val playableList = playlist.filter { it.kind != ItemKind.SERIES && it.kind != ItemKind.SEASON }
            .ifEmpty { listOf(item) }
        val safeIdx = if (index in playableList.indices &&
            playableList[index].id == item.id &&
            playableList[index].kind == item.kind
        ) {
            index
        } else {
            playableList.indexOfFirst { it.id == item.id && it.kind == item.kind }.coerceAtLeast(0)
        }
        com.iptvlite.tv.network.SelectedCategoryLoad.bindQueue(acc,playableList,
            currentTab==ContentTab.LIVE && !isShowingGlobalSearch && currentSortMode==SortMode.DEFAULT && currentLetterFilter.isEmpty() && etSearch.text.toString().isBlank())
        PlayQueueHolder.activeAccount = acc
        PlayQueueHolder.playlist = playableList
        PlayQueueHolder.currentIndex = safeIdx
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun injectSeriesQuickResumeRow(seriesItem: StreamItem, seasons: List<StreamItem>): List<StreamItem> {
        val resumeEntry = store.getLatestSeriesResumeEntry(seriesItem.id, seriesItem.accountId) ?: return seasons
        val rawEpTitle = resumeEntry.item.name.removePrefix("⏵ متابعة المشاهدة:").trim()
        val epClean = MediaTitleFormatter.parseMedia(rawEpTitle).cleanTitle
        val quickItem = resumeEntry.item.copy(
            name = "⏵ متابعة المشاهدة: $epClean",
            subtitle = "استئناف فوري من ${AppStore.formatResumeTime(resumeEntry.posMs)}"
        )
        return listOf(quickItem) + seasons
    }

    private fun focusStreamItemAt(targetIdx: Int) {
        rvStreams.post {
            if (isFinishing || isDestroyed) return@post
            val cnt = streamAdapter.itemCount
            if (cnt > 0) {
                val safeIdx = targetIdx.coerceIn(0, cnt - 1)
                lastFocusedStreamPos = safeIdx
                rvStreams.scrollToPosition(safeIdx)
                rvStreams.post {
                    rvStreams.findViewHolderForAdapterPosition(safeIdx)?.itemView?.requestFocus()
                        ?: rvStreams.getChildAt(0)?.requestFocus()
                }
            } else if (btnBackLevel.visibility == View.VISIBLE) {
                btnBackLevel.requestFocus()
            }
        }
    }

    private fun openSeriesSeasons(acc: AccountProfile, seriesItem: StreamItem) {
        savedSeriesFocusPos = lastFocusedStreamPos
        savedSeriesList = rawItems
        activeSeriesItem = seriesItem
        activeSeasonItem = null
        lastFocusedStreamPos = 0
        applyGridOrListMode(false)
        val cleanSeriesTitle = MediaTitleFormatter.parseMedia(seriesItem.name).cleanTitle
        btnBackLevel.visibility = View.VISIBLE
        tvListHeader.text = "📚 $cleanSeriesTitle — المواسم"
        rawItems = emptyList()
        applySearchFilter()
        btnBackLevel.requestFocus()
        setLoading(true, "… جارٍ جلب مواسم «$cleanSeriesTitle»")

        cancelBrowse()
        val ticket=browseGeneration.current()
        val requestScope=com.iptvlite.tv.network.PlaybackRequestScope()
        browseScope=requestScope
        var requestFinished=false
        browseJob = lifecycleScope.launch {
            val res = runCatching {
                ownedIo(requestScope) { PortalClient.loadSeasons(acc, seriesItem) }
            }
            requestFinished=true
            if(!browseGeneration.accepts(ticket) || isFinishing || isDestroyed || store.getActiveAccount()?.id!=acc.id) return@launch
            setLoading(false)
            res.onSuccess { seasons ->
                rawItems = injectSeriesQuickResumeRow(seriesItem, seasons)
                applySearchFilter()
                if (seasons.isEmpty()) {
                    updateEmptyState("لم يُعثر على مواسم لهذا المسلسل.")
                } else {
                    focusStreamItemAt(0)
                }
            }.onFailure { err ->
                if (err is CancellationException) return@onFailure
                updateEmptyState("✖ تعذّر جلب المواسم: ${err.message}")
            }
        }
    }

    private fun openSeasonEpisodes(acc: AccountProfile, seriesItem: StreamItem, seasonItem: StreamItem) {
        savedSeasonFocusPos = lastFocusedStreamPos
        savedSeasonsList = rawItems.filter { it.kind == ItemKind.SEASON }
        activeSeasonItem = seasonItem
        lastFocusedStreamPos = 0
        val cleanSeriesTitle = MediaTitleFormatter.parseMedia(seriesItem.name).cleanTitle
        btnBackLevel.visibility = View.VISIBLE
        tvListHeader.text = "🎬 $cleanSeriesTitle · ${seasonItem.name}"
        rawItems = emptyList()
        applySearchFilter()
        btnBackLevel.requestFocus()
        setLoading(true, "… جارٍ جلب الحلقات")

        cancelBrowse()
        val ticket=browseGeneration.current()
        val requestScope=com.iptvlite.tv.network.PlaybackRequestScope()
        browseScope=requestScope
        var requestFinished=false
        browseJob = lifecycleScope.launch {
            val res = runCatching {
                ownedIo(requestScope) { PortalClient.loadEpisodes(acc, seriesItem, seasonItem) }
            }
            requestFinished=true
            if(!browseGeneration.accepts(ticket) || isFinishing || isDestroyed || store.getActiveAccount()?.id!=acc.id) return@launch
            setLoading(false)
            res.onSuccess { eps ->
                rawItems = eps
                applySearchFilter()
                if (eps.isEmpty()) {
                    updateEmptyState("لا توجد حلقات متاحة في هذا الموسم.")
                } else {
                    focusStreamItemAt(0)
                }
            }.onFailure { err ->
                if (err is CancellationException) return@onFailure
                updateEmptyState("✖ تعذّر جلب الحلقات: ${err.message}")
            }
        }
    }

    private fun stepBackSeriesLevel(): Boolean {
        if(activeSeasonItem!=null || activeSeriesItem!=null) {cancelBrowse();PortalClient.preemptBrowse()}
        if (activeSeasonItem != null) {
            activeSeasonItem = null
            val ser = activeSeriesItem
            val cleanSer = MediaTitleFormatter.parseMedia(ser?.name.orEmpty()).cleanTitle
            tvListHeader.text = "📚 $cleanSer — المواسم"
            rawItems = if (ser != null) {
                injectSeriesQuickResumeRow(ser, savedSeasonsList.filter { it.kind == ItemKind.SEASON })
            } else {
                savedSeasonsList
            }
            applySearchFilter()
            focusStreamItemAt(savedSeasonFocusPos)
            return true
        }
        if (activeSeriesItem != null) {
            activeSeriesItem = null
            btnBackLevel.visibility = View.GONE
            applyGridOrListMode(store.isViewGridMode(currentTab))
            tvListHeader.text = MediaTitleFormatter.parseCategory(currentCategoryTitle).cleanTitle
            rawItems = savedSeriesList
            applySearchFilter()
            focusStreamItemAt(savedSeriesFocusPos)
            return true
        }
        return false
    }

    private fun resetSeriesStack() {
        val wasInSeries = (activeSeriesItem != null)
        activeSeriesItem = null
        activeSeasonItem = null
        savedSeriesList = emptyList()
        savedSeasonsList = emptyList()
        btnBackLevel.visibility = View.GONE
        if (wasInSeries && ::streamAdapter.isInitialized) {
            applyGridOrListMode(store.isViewGridMode(currentTab))
        }
    }

    private fun applySearchFilter() {
        filterJob?.cancel()
        val q = etSearch.text.toString().trim()
        val letFilter = currentLetterFilter
        val snapshot = rawItems
        val isSeriesDrill = activeSeasonItem != null || activeSeriesItem != null
        val globalMode = isShowingGlobalSearch
        val sortMode = currentSortMode

        // القوائم الصغيرة والمتوسطة دون فلترة معقّدة تُحدَّث في 0.1ms مباشرةً بدون أي وميض
        if (snapshot.size <= 500 && q.isEmpty() && letFilter.isEmpty() && (isSeriesDrill || sortMode == SortMode.DEFAULT)) {
            deliverFilteredItems(snapshot, q, globalMode)
            return
        }

        // القوائم الضخمة أو الترتيب/البحث تعمل على خيط خلفي لمنع أي تهنيج في الواجهة!
        filterJob = lifecycleScope.launch {
            val computed = withContext(Dispatchers.Default) {
                val context=kotlin.coroutines.coroutineContext
                PerformanceTrace.section("iptv.list.filterSort") {
                    val filterLetter=letFilter.isNotEmpty() && !isSeriesDrill
                    val filterQuery=q.isNotEmpty() && !globalMode
                    val filtered=if(!filterLetter && !filterQuery)snapshot else
                        CancellableScan.filter(snapshot,{context.ensureActive()}) {item->
                            (!filterLetter || extractInitialBucket(item.name)==letFilter) &&
                                (!filterQuery || item.name.contains(q,ignoreCase=true))
                        }
                    context.ensureActive()
                    val result=if(isSeriesDrill)filtered else store.sortStreamItems(filtered,sortMode)
                    context.ensureActive()
                    result
                }
            }
            deliverFilteredItems(computed, q, globalMode)
        }
    }

    private fun deliverFilteredItems(sorted: List<StreamItem>, q: String, globalMode: Boolean) {
        streamAdapter.submit(sorted)
        if (sorted.isNotEmpty()) {
            tvListCount.text = "${sorted.size}"
            tvListCount.visibility = View.VISIBLE
            emptyBox.visibility = View.GONE
        } else {
            tvListCount.text = ""
            tvListCount.visibility = View.GONE
            if (progressMain.visibility != View.VISIBLE) {
                if (q.isNotEmpty() && !globalMode) {
                    updateEmptyState("لا توجد نتائج في هذا القسم لـ «$q»\nاضغط «🌐 شامل» للبحث في السيرفر كله")
                } else if (currentLetterFilter.isNotEmpty() && rawItems.isNotEmpty()) {
                    updateEmptyState("لا توجد عناصر تبدأ بالحرف «$currentLetterFilter» في هذه القائمة.\nاضغط «🔤 $currentLetterFilter» بالأعلى لاختيار حرف آخر أو عرض الكل.")
                }
            }
        }
    }

    private fun setLoading(loading: Boolean, status: String = "") {
        progressMain.visibility = if (loading) View.VISIBLE else View.GONE
        if (loading) {
            emptyBox.visibility = View.GONE
        }
        if (status.isNotBlank()) {
            tvStatusMsg.text = status
        }
    }

    private fun updateEmptyState(msg: String) {
        tvEmptyState.text = msg
        emptyBox.visibility = View.VISIBLE
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                handleMainBackNavigation()
            }
        })
    }

    private fun handleMainBackNavigation() {
        if (stepBackSeriesLevel()) {
            return
        }
        if (isShowingGlobalSearch) {
            etSearch.setText("")
            exitGlobalSearchMode()
            return
        }
        if (etSearch.text.toString().isNotBlank()) {
            etSearch.setText("")
            etSearch.clearFocus()
            return
        }
        if (currentLetterFilter.isNotEmpty()) {
            resetLetterFilterUi()
            applySearchFilter()
            return
        }
        showExitConfirmationDialog()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showExitConfirmationDialog() {
        if (isFinishing || isDestroyed) return
        if (exitConfirmDialog?.isShowing == true) return

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(24), dp(22), dp(24), dp(20))
        }

        val tvTitle = TextView(this).apply {
            text = "🚪 تأكيد الخروج من البرنامج"
            setTextColor(Color.parseColor("#60A5FA"))
            textSize = 18.5f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        card.addView(tvTitle)

        val pendingSchedCount = store.getScheduledRecs().count { it.state == "pending" }
        val activeRecNow = StreamRecorder.isRecording()
        val tvMsg = TextView(this).apply {
            text = buildString {
                append("هل تريد الخروج من تطبيق IPTV Lite وإغلاقه الآن؟")
                if (activeRecNow) {
                    append("\n⚠ تنبيه: يوجد تسجيل نشط حالياً سيتوقّف إذا أغلقت التطبيق بالكامل.")
                } else if (pendingSchedCount > 0) {
                    append("\n⏰ لديك ($pendingSchedCount) تسجيل مجدول سيعمل في موعده عبر منبّه النظام دون أي استهلاك بالخلفية.")
                }
            }
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 14.5f
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(20))
        }
        card.addView(tvMsg)

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            clipChildren = false
            clipToPadding = false
        }

        val btnYes = TextView(this).apply {
            id = View.generateViewId()
            text = "✔ نعم"
            setTextColor(Color.WHITE)
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_tv_danger_btn)
            isClickable = true
            isFocusable = true
            minWidth = dp(125)
            setPadding(dp(22), dp(11), dp(22), dp(11))
            ThemeHelper.attachFocusScale(this, 1.05f)
        }

        val btnNo = TextView(this).apply {
            id = View.generateViewId()
            text = "✖ لا"
            setTextColor(Color.WHITE)
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setBackgroundResource(R.drawable.bg_tv_btn)
            isClickable = true
            isFocusable = true
            minWidth = dp(125)
            setPadding(dp(22), dp(11), dp(22), dp(11))
            ThemeHelper.attachFocusScale(this, 1.05f)
        }

        // في التخطيط العربي RTL: «نعم» يميناً و«لا» يساراً
        btnYes.nextFocusLeftId = btnNo.id
        btnYes.nextFocusRightId = btnYes.id
        btnNo.nextFocusRightId = btnYes.id
        btnNo.nextFocusLeftId = btnNo.id

        val lpYes = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        ).apply { marginEnd = dp(12) }

        val lpNo = LinearLayout.LayoutParams(
            0,
            LinearLayout.LayoutParams.WRAP_CONTENT,
            1f
        )

        btnRow.addView(btnYes, lpYes)
        btnRow.addView(btnNo, lpNo)
        card.addView(btnRow)

        val dlg = AlertDialog.Builder(this)
            .setView(card)
            .setCancelable(true)
            .create()

        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        btnYes.setOnClickListener {
            dlg.dismiss()
            uiHandler.removeCallbacksAndMessages(null)
            cancelBrowse()
            filterJob?.cancel()
            AppExitHelper.terminateAppCompletely(this)
        }

        btnNo.setOnClickListener {
            dlg.dismiss()
        }

        dlg.setOnDismissListener {
            exitConfirmDialog = null
        }

        exitConfirmDialog = dlg
        dlg.show()
        // تركيز افتراضي آمن على زرّ «لا» حتى لا يخرج المستخدم بالخطأ عند الضغط السريع بالريموت
        btnNo.post { btnNo.requestFocus() }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN && !AppUiTracker.isAnyUiVisible) {
            // عند ضغط زرّ الهوم والانتقال للخلفية فعلياً (مع عدم وجود PlayerActivity أو تسجيل نشط):
            if (!StreamRecorder.isRecording()) {
                PortalClient.evictIdleConnections()
            }
            LogoLoader.trimMemory(clearAll = level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND)
        }
        if (level >= ComponentCallbacks2.TRIM_MEMORY_MODERATE && !AppUiTracker.isAnyUiVisible) {
            PortalClient.clearCaches()
        }
    }

    override fun onDestroy() {
        cancelM3uExport()
        cancelBrowse(preserveSelected=true);cancelBadge()
        uiHandler.removeCallbacksAndMessages(null)
        exitConfirmDialog?.dismiss()
        exitConfirmDialog = null
        super.onDestroy()
    }

    private fun isDescendantOf(child: View?, container: View?): Boolean {
        if (child == null || container == null) return false
        var cur: View? = child
        while (cur != null) {
            if (cur === container) return true
            cur = cur.parent as? View
        }
        return false
    }

    private fun activeTabView(): View = when (currentTab) {
        ContentTab.LIVE -> tabLive
        ContentTab.VOD -> tabVod
        ContentTab.SERIES -> tabSeries
        ContentTab.FAV -> tabFav
        ContentTab.RECENT -> tabRecent
    }

    private fun focusSelectedCategory(): Boolean {
        if (categoryPane.visibility != View.VISIBLE || categoryAdapter.itemCount <= 0) return false
        val targetPos = categoryAdapter.selectedIndex().coerceIn(0, categoryAdapter.itemCount - 1)
        val existingVh = rvCategories.findViewHolderForAdapterPosition(targetPos)
        if (existingVh != null) {
            return existingVh.itemView.requestFocus()
        }
        rvCategories.scrollToPosition(targetPos)
        rvCategories.post {
            rvCategories.findViewHolderForAdapterPosition(targetPos)?.itemView?.requestFocus()
                ?: rvCategories.getChildAt(0)?.requestFocus()
        }
        return true
    }

    private fun focusPreferredStreamOrToolbar(): Boolean {
        val count = streamAdapter.itemCount
        if (rvStreams.visibility == View.VISIBLE && count > 0) {
            val targetPos = lastFocusedStreamPos.coerceIn(0, count - 1)
            val existingVh = rvStreams.findViewHolderForAdapterPosition(targetPos)
            if (existingVh != null) {
                return existingVh.itemView.requestFocus()
            }
            rvStreams.scrollToPosition(targetPos)
            rvStreams.post {
                rvStreams.findViewHolderForAdapterPosition(targetPos)?.itemView?.requestFocus()
                    ?: rvStreams.getChildAt(0)?.requestFocus()
            }
            return true
        }
        if (emptyBox.visibility == View.VISIBLE && btnQuickSetup.visibility == View.VISIBLE) {
            return btnQuickSetup.requestFocus()
        }
        return btnViewMode.requestFocus()
    }

    private fun canLeaveEditHorizontally(et: EditText, keyCode: Int): Boolean {
        val txt = et.text?.toString().orEmpty()
        if (txt.isEmpty()) return true
        val sel = et.selectionStart
        if (sel < 0) return true
        val firstCharRtl = Character.getDirectionality(txt[0]) in listOf(
            Character.DIRECTIONALITY_RIGHT_TO_LEFT,
            Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
        )
        return if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
            if (firstCharRtl) sel >= txt.length else sel <= 0
        } else {
            if (firstCharRtl) sel <= 0 else sel >= txt.length
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val navRail = findViewById<View?>(R.id.navRail)
            val topBar = findViewById<View?>(R.id.topBar)
            val itemsPane = findViewById<View?>(R.id.itemsPane)
            val focused = currentFocus

            // عند الضغط على OK فوق حقل البحث نفتح لوحة المفاتيح صراحةً
            if ((event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER) &&
                (focused === etSearch || focused === etCatFilter)
            ) {
                openSoftKeyboardExplicitly(focused as EditText)
                return true
            }

            // توجيه ذكي بين المناطق الأربع في الوضع الأفقي (RTL): الشريط الجانبي <-> الأقسام <-> القنوات/البوسترات <-> الشريط العلوي
            if (navRail != null && focused != null) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        if (isDescendantOf(focused, navRail)) {
                            if (!focusSelectedCategory()) {
                                focusPreferredStreamOrToolbar()
                            }
                            return true
                        }
                        if (isDescendantOf(focused, rvCategories) || focused === btnNewFavFolder ||
                            (focused === etCatFilter && canLeaveEditHorizontally(etCatFilter!!, KeyEvent.KEYCODE_DPAD_LEFT))
                        ) {
                            focusPreferredStreamOrToolbar()
                            return true
                        }
                        if (focused === etSearch && canLeaveEditHorizontally(etSearch, KeyEvent.KEYCODE_DPAD_LEFT)) {
                            btnGlobalSearch.requestFocus()
                            return true
                        }
                    }

                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (isDescendantOf(focused, rvCategories) || focused === btnNewFavFolder ||
                            (focused === etCatFilter && canLeaveEditHorizontally(etCatFilter!!, KeyEvent.KEYCODE_DPAD_RIGHT))
                        ) {
                            activeTabView().requestFocus()
                            return true
                        }
                        if (focused === btnToggleCats) {
                            activeTabView().requestFocus()
                            return true
                        }
                        if (focused === etSearch && canLeaveEditHorizontally(etSearch, KeyEvent.KEYCODE_DPAD_RIGHT)) {
                            if (btnToggleCats.visibility == View.VISIBLE) {
                                btnToggleCats.requestFocus()
                            } else {
                                activeTabView().requestFocus()
                            }
                            return true
                        }
                        if (isDescendantOf(focused, rvStreams)) {
                            val itemRoot = rvStreams.findContainingItemView(focused)
                            val pos = if (itemRoot != null) rvStreams.getChildAdapterPosition(itemRoot) else RecyclerView.NO_POSITION
                            val lm = rvStreams.layoutManager
                            // في RTL: العمود الأيمن في الشبكة هو الموضع (pos % spanCount == 0)، وفي القائمة كلّ الصفوف تقع على الحافّة اليمنى
                            val atRightEdge = when (lm) {
                                is GridLayoutManager -> pos == RecyclerView.NO_POSITION || (pos % lm.spanCount == 0)
                                else -> true
                            }
                            if (atRightEdge) {
                                if (!focusSelectedCategory()) {
                                    activeTabView().requestFocus()
                                }
                                return true
                            }
                        }
                        if (focused === btnQuickSetup || focused === btnBackLevel ||
                            (focused === btnViewMode && btnBackLevel.visibility != View.VISIBLE)
                        ) {
                            if (!focusSelectedCategory()) {
                                activeTabView().requestFocus()
                            }
                            return true
                        }
                    }

                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        if (isDescendantOf(focused, topBar)) {
                            hideSoftKeyboard(focused)
                            if (focused === btnToggleCats && categoryPane.visibility == View.VISIBLE) {
                                if (!focusSelectedCategory()) {
                                    focusPreferredStreamOrToolbar()
                                }
                            } else if (!focusPreferredStreamOrToolbar()) {
                                focusSelectedCategory()
                            }
                            return true
                        }
                        if (focused === btnNewFavFolder) {
                            if (etCatFilter?.visibility == View.VISIBLE) {
                                etCatFilter!!.requestFocus()
                            } else if (!focusSelectedCategory()) {
                                focusPreferredStreamOrToolbar()
                            }
                            return true
                        }
                        if (focused === etCatFilter) {
                            hideSoftKeyboard(focused)
                            if (!focusSelectedCategory()) {
                                focusPreferredStreamOrToolbar()
                            }
                            return true
                        }
                        if (isDescendantOf(focused, itemsPane) &&
                            !isDescendantOf(focused, rvStreams) &&
                            focused !== btnQuickSetup
                        ) {
                            focusPreferredStreamOrToolbar()
                            return true
                        }
                    }

                    KeyEvent.KEYCODE_DPAD_UP -> {
                        if (isDescendantOf(focused, rvStreams)) {
                            val itemRoot = rvStreams.findContainingItemView(focused)
                            val pos = if (itemRoot != null) rvStreams.getChildAdapterPosition(itemRoot) else RecyclerView.NO_POSITION
                            val span = (rvStreams.layoutManager as? GridLayoutManager)?.spanCount ?: 1
                            if (pos in 0 until span) {
                                val targetToolbarBtn = when {
                                    btnBackLevel.visibility == View.VISIBLE -> btnBackLevel
                                    btnViewMode.visibility == View.VISIBLE -> btnViewMode
                                    btnSort.visibility == View.VISIBLE -> btnSort
                                    else -> etSearch
                                }
                                targetToolbarBtn.requestFocus()
                                return true
                            }
                        }
                        if (isDescendantOf(focused, itemsPane) &&
                            !isDescendantOf(focused, rvStreams)
                        ) {
                            etSearch.requestFocus()
                            return true
                        }
                        if (isDescendantOf(focused, rvCategories)) {
                            val itemRoot = rvCategories.findContainingItemView(focused)
                            val pos = if (itemRoot != null) rvCategories.getChildAdapterPosition(itemRoot) else RecyclerView.NO_POSITION
                            if (pos == 0) {
                                val target = when {
                                    etCatFilter?.visibility == View.VISIBLE -> etCatFilter!!
                                    btnNewFavFolder.visibility == View.VISIBLE -> btnNewFavFolder
                                    btnToggleCats.visibility == View.VISIBLE -> btnToggleCats
                                    else -> etSearch
                                }
                                target.requestFocus()
                                return true
                            }
                        }
                        if (focused === etCatFilter) {
                            val target = when {
                                btnNewFavFolder.visibility == View.VISIBLE -> btnNewFavFolder
                                btnToggleCats.visibility == View.VISIBLE -> btnToggleCats
                                else -> etSearch
                            }
                            target.requestFocus()
                            return true
                        }
                        if (focused === btnNewFavFolder) {
                            val target = if (btnToggleCats.visibility == View.VISIBLE) btnToggleCats else etSearch
                            target.requestFocus()
                            return true
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MEDIA_PLAY || keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
            resumeLastWatchedChannel()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_HELP || keyCode == KeyEvent.KEYCODE_SLASH) {
            TvDialogs.showHelpShortcutsDialog(this)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_INFO && event?.isLongPress == true && !etSearch.hasFocus()) {
            TvDialogs.showAboutDialog(this)
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_FORWARD_DEL || keyCode == KeyEvent.KEYCODE_CLEAR ||
            (keyCode == KeyEvent.KEYCODE_DEL && !etSearch.hasFocus())
        ) {
            if (currentTab == ContentTab.RECENT) {
                val cand = resolveFocusedOrFirstItem()
                if (cand != null) {
                    store.removeRecentItem(cand)
                    if (lastTouchedItem?.id == cand.id) lastTouchedItem = null
                    loadLocalTab(ContentTab.RECENT)
                    Toast.makeText(this, "✔ حُذِف «${cand.name}» من السجلّ", Toast.LENGTH_SHORT).show()
                    return true
                }
            }
        }
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_INFO || keyCode == KeyEvent.KEYCODE_GUIDE) {
            val cand = resolveFocusedOrFirstItem()
            if (cand != null) {
                showItemContextMenu(cand, -1)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
