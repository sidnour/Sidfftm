package com.iptvlite.tv.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.iptvlite.tv.model.ProgramReminder
import com.iptvlite.tv.model.ScheduledRecording
import com.iptvlite.tv.receiver.ScheduleReceiver
import com.iptvlite.tv.store.AppStore

/**
 * جدولة دقيقة عبر AlarmManager لتعمل التنبيهات (🔔) والتسجيلات المجدولة (⏰) حتى لو كان التطبيق مغلقاً بالكامل،
 * دون إبقاء أي عملية أو خيط يعمل في الخلفية قبل حلول موعد البرنامج!
 */
object ScheduleHelper {

    const val ACTION_REMINDER = "com.iptvlite.tv.action.REMINDER_DUE"
    const val ACTION_RECORD = "com.iptvlite.tv.action.RECORD_DUE"
    const val ACTION_STOP_RECORDING = "com.iptvlite.tv.action.STOP_RECORDING"
    const val EXTRA_ID = "extra_schedule_id"

    private fun pendingIntentFor(
        context: Context,
        action: String,
        id: String,
        noCreate: Boolean = false,
        legacy: Boolean = false
    ): PendingIntent? {
        val appCtx = context.applicationContext
        val intent = Intent(appCtx, ScheduleReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_ID, id)
            if(!legacy) data = android.net.Uri.parse(ScheduleIdentity.data(action,id))
        }
        val reqCode = ((action.hashCode() * 31) xor id.hashCode()) and 0x7FFFFFFF
        var flags = if (noCreate) PendingIntent.FLAG_NO_CREATE else PendingIntent.FLAG_UPDATE_CURRENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags = flags or PendingIntent.FLAG_IMMUTABLE
        }
        return PendingIntent.getBroadcast(appCtx, reqCode, intent, flags)
    }

    private fun cancelLegacy(context: Context, action: String, id: String) {
        val alarm=context.applicationContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val old=pendingIntentFor(context,action,id,noCreate=true,legacy=true) ?: return
        runCatching { alarm.cancel(old);old.cancel() }
    }

    private fun setExactAlarm(context: Context, triggerAtMs: Long, pi: PendingIntent) {
        val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val safeTrigger = triggerAtMs.coerceAtLeast(System.currentTimeMillis() + 1_500L)
        runCatching {
            when {
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                    if (am.canScheduleExactAlarms()) {
                        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
                    } else {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
                    }
                }
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
                }
                else -> {
                    am.setExact(AlarmManager.RTC_WAKEUP, safeTrigger, pi)
                }
            }
        }.onFailure {
            runCatching { am.set(AlarmManager.RTC_WAKEUP, safeTrigger, pi) }
        }
    }

    fun scheduleReminder(context: Context, rem: ProgramReminder) {
        if (rem.id.isBlank() || rem.remindAtTs <= 0L) return
        cancelLegacy(context,ACTION_REMINDER,rem.id)
        val pi = pendingIntentFor(context, ACTION_REMINDER, rem.id) ?: return
        setExactAlarm(context, rem.remindAtTs * 1000L, pi)
    }

    fun cancelReminder(context: Context, id: String) {
        if (id.isBlank()) return
        val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        cancelLegacy(context,ACTION_REMINDER,id)
        val pi = pendingIntentFor(context, ACTION_REMINDER, id, noCreate = true) ?: return
        runCatching { am.cancel(pi); pi.cancel() }
    }

    fun scheduleRecording(context: Context, rec: ScheduledRecording) {
        if (rec.id.isBlank() || rec.startTs <= 0L || rec.state != "pending") return
        cancelLegacy(context,ACTION_RECORD,rec.id)
        val pi = pendingIntentFor(context, ACTION_RECORD, rec.id) ?: return
        // نوقظ الخدمة قبل موعد البرنامج بـ 5 ثوانٍ لتجهيز الاتصال في اللحظة المحدّدة
        val triggerMs = (rec.startTs * 1000L) - 5_000L
        setExactAlarm(context, triggerMs, pi)
    }

    fun cancelRecording(context: Context, id: String) {
        if (id.isBlank()) return
        val am = context.applicationContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        cancelLegacy(context,ACTION_RECORD,id)
        val pi = pendingIntentFor(context, ACTION_RECORD, id, noCreate = true) ?: return
        runCatching { am.cancel(pi); pi.cancel() }
    }

    fun rescheduleAll(context: Context, store: AppStore) {
        val appCtx = context.applicationContext
        val nowSec = System.currentTimeMillis() / 1000L
        for (rem in store.getReminders()) {
            if (rem.startTs + 600L > nowSec) {
                scheduleReminder(appCtx, rem)
            }
        }
        val recActiveNow = StreamRecorder.isRecording()
        for (rec in store.getScheduledRecs()) {
            val endSec = rec.startTs + rec.durationMin * 60L
            when (rec.state) {
                "pending" -> {
                    if (endSec > nowSec) {
                        scheduleRecording(appCtx, rec)
                    } else {
                        store.updateScheduledRecState(rec.id, "missed")
                    }
                }
                "recording" -> {
                    if (!recActiveNow) {
                        if (endSec > nowSec + 30L) {
                            store.updateScheduledRecState(rec.id, "pending")
                            com.iptvlite.tv.service.RecordingService.start(appCtx, rec.id)
                        } else {
                            store.updateScheduledRecState(rec.id, "done")
                        }
                    }
                }
            }
        }
    }
}
