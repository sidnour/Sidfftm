package com.iptvlite.tv.util

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import com.iptvlite.tv.BuildConfig

/**
 * Content of the «حول البرنامج» (About) screen.
 *
 * Deliberately factual and short: identity, version, platform, capabilities and legal notices.
 * Shortcut/gesture instructions live ONLY in the control guide — this screen never duplicates them.
 * No account, token, provider or network data is read or shown here.
 */
object AboutInfo {
    const val APP_NAME = "IPTV Lite TV"
    const val DEVELOPER = "IPTVLite"

    /** Filled from the release config so the screen and the APK can never disagree. */
    fun versionName(): String = BuildConfig.APP_VERSION_NAME

    fun versionCode(): Int = BuildConfig.VERSION_CODE

    fun platform(context: Context): String {
        val tv = (context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager)
            ?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            (context.resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) ==
            Configuration.UI_MODE_TYPE_TELEVISION
        return if (tv) "Android TV · تلفاز" else "هاتف / جهاز لوحي"
    }

    fun deviceLabel(): String {
        val name = listOf(Build.MANUFACTURER.orEmpty().trim(), Build.MODEL.orEmpty().trim())
            .filter { it.isNotEmpty() }.joinToString(" ")
        return name.ifBlank { "غير معروف" }
    }

    fun androidLabel(): String = "Android ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}"

    /** Short capability list — one line each, no marketing copy. */
    val CAPABILITIES: List<String> = listOf(
        "Xtream Codes · Stalker Portal · M3U",
        "بثّ مباشر · أفلام · مسلسلات",
        "دليل برامج EPG · مفضّلة · سجلّ · استئناف",
        "تسجيل فوري ومجدول · تنزيل · مكتبة محلية",
        "نسخ احتياطي واستعادة · نقل عبر Wi-Fi"
    )

    val STORAGE: List<String> = listOf(
        "التسجيلات: Downloads/IPTVLite_Recordings",
        "التنزيلات: Downloads/IPTVLite_Downloads"
    )

    const val PRIVACY =
        "لا يُرسل التطبيق بياناتك إلى أي خادم للمطوّر. بيانات الحسابات تُخزَّن مشفّرة على الجهاز، " +
            "والاتصال يجري مباشرة مع المزوّد الذي تضيفه."

    const val DISCLAIMER =
        "التطبيق مشغّل فقط ولا يوفّر أي محتوى أو اشتراك. استخدم مصادر تملك حقّ الوصول إليها."

    const val ACCOUNT_SAFETY =
        "الفحص التلقائي لا يحذف حسابًا، ونتيجة الشبكة ليست دليل انتهاء. الحذف يدوي بتأكيد، " +
            "ويقبل الرفض المؤكد خلال 30 دقيقة فقط."

    /** One line for the header; tests and every screen share it. */
    fun versionLine(): String = "الإصدار ${versionName()} · بناء ${versionCode()}"
}
