package com.iptvlite.tv.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.iptvlite.tv.R
import com.iptvlite.tv.model.AccountProfile
import com.iptvlite.tv.model.AppPrefs
import com.iptvlite.tv.model.AppThemeMode
import com.iptvlite.tv.model.ProviderType
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.util.AboutInfo
import com.iptvlite.tv.util.ControlGuide
import com.iptvlite.tv.util.ThemeHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

object TvDialogs {

    fun dp(ctx: Context, v: Int): Int =
        (v * ctx.resources.displayMetrics.density).toInt()

    /**
     * نافذة قوائم منبثقة احترافية بطراز النيون (Neon Studio Choice Sheet)
     * توفّر تحديداً بصرياً واضحاً جدّاً بالريموت مع تركيز تلقائي على الخيار النشط وتنقّل عمودي سلس.
     */
    fun showNeonChoiceDialog(
        ctx: Context,
        title: String,
        items: List<String>,
        defaultIndex: Int = 0,
        cancelLabel: String = "إغلاق",
        onPick: (Int) -> Unit
    ) {
        if (items.isEmpty()) return
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            setPadding(dp(ctx, 18), dp(ctx, 16), dp(ctx, 18), dp(ctx, 14))
        }

        root.addView(
            TextView(ctx).apply {
                text = title
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 16.5f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            }
        )

        root.addView(
            View(ctx).apply {
                setBackgroundColor(Color.parseColor("#293548"))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(ctx, 1)
                ).apply { topMargin = dp(ctx, 10); bottomMargin = dp(ctx, 10) }
            }
        )

        val maxScrollH = (ctx.resources.displayMetrics.heightPixels * 0.56f).toInt().coerceAtLeast(dp(ctx, 220))
        val useScroll = items.size > 6
        val listCol = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 2), dp(ctx, 2), dp(ctx, 2), dp(ctx, 2))
        }

        if (useScroll) {
            val scroll = ScrollView(ctx).apply {
                isVerticalScrollBarEnabled = true
                clipChildren = false
                clipToPadding = false
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    maxScrollH
                )
                addView(listCol)
            }
            root.addView(scroll)
        } else {
            root.addView(listCol)
        }

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val rowViews = ArrayList<TextView>(items.size)
        for ((idx, label) in items.withIndex()) {
            val isHighlighted = label.startsWith("✔") || label.startsWith("⏵") || idx == defaultIndex
            val isDestructive = label.startsWith("🗑") || label.startsWith("🧹") || label.startsWith("⏹")
            val tvRow = TextView(ctx).apply {
                id = View.generateViewId()
                text = label
                textSize = 14f
                setTypeface(typeface, if (isHighlighted) Typeface.BOLD else Typeface.NORMAL)
                setTextColor(
                    when {
                        isDestructive -> Color.parseColor("#FCA5A5")
                        label.startsWith("✔") || label.startsWith("⏵") -> Color.parseColor("#34D399")
                        else -> Color.parseColor("#F8FAFC")
                    }
                )
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                isFocusable = true
                isClickable = true
                isSelected = label.startsWith("✔")
                minHeight = dp(ctx, 48)
                setBackgroundResource(R.drawable.bg_tv_row)
                setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(ctx, 6) }
                setOnClickListener {
                    dlg.dismiss()
                    onPick(idx)
                }
            }
            ThemeHelper.attachFocusScale(tvRow, 1.016f) { v, hasFocus ->
                if (hasFocus) {
                    v.requestRectangleOnScreen(Rect(0, 0, v.width, v.height), false)
                }
            }
            rowViews.add(tvRow)
            listCol.addView(tvRow)
        }

        val closeBtn = makeTvButton(ctx, cancelLabel) { dlg.dismiss() }.apply {
            id = View.generateViewId()
        }
        val footer = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(0, dp(ctx, 6), 0, 0)
            addView(closeBtn)
        }
        root.addView(footer)

        // ربط اتجاهات الريموت عمودياً بدقّة بدون ضياع التركيز
        for (i in rowViews.indices) {
            rowViews[i].nextFocusUpId = if (i > 0) rowViews[i - 1].id else closeBtn.id
            rowViews[i].nextFocusDownId = if (i < rowViews.lastIndex) rowViews[i + 1].id else closeBtn.id
        }
        closeBtn.nextFocusUpId = rowViews.last().id
        closeBtn.nextFocusDownId = rowViews.first().id

        dlg.show()
        val focusIdx = defaultIndex.coerceIn(0, rowViews.lastIndex)
        rowViews[focusIdx].post {
            rowViews[focusIdx].requestFocus()
        }
    }

    fun showAccountsDialog(
        ctx:Context,store:AppStore,scope:CoroutineScope,
        onPickImportFile:()->Unit,onOpenWebSetup:()->Unit,
        onPickLocalM3uFile:(((String)->Unit)->Unit)?=null,
        onActivated:(AccountProfile)->Unit
    ) {
        AccountManagerDialog(ctx,store,scope,onPickImportFile,onOpenWebSetup,onPickLocalM3uFile,onActivated,
            onDeleted={ids->(ctx as? MainActivity)?.onAccountsRemovedFromManager(ids)},
            onBackup={(ctx as? MainActivity)?.exportBackupFromAccountManager()}).show()
    }

    fun showBulkPasteDialog(
        ctx: Context,
        store: AppStore,
        onImported: () -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
        }
        root.addView(
            TextView(ctx).apply {
                text = "📋 استيراد جماعي للسيرفرات أو JSON"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )
        root.addView(
            TextView(ctx).apply {
                text = "الصق هنا قوائم البورتال وعناوين MAC، أو روابط Xtream / M3U، أو محتوى working_portals.json:"
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 12.5f
                setPadding(0, dp(ctx, 4), 0, dp(ctx, 8))
            }
        )

        val etBulk = EditText(ctx).apply {
            hint = "http://portal.example:8080/c | 00:1A:79:AA:BB:CC\nأو نص JSON كامل..."
            minLines = 6
            maxLines = 10
            gravity = Gravity.TOP or Gravity.START
            textDirection = View.TEXT_DIRECTION_LTR
            setTextColor(Color.parseColor("#E8ECF3"))
            setHintTextColor(Color.parseColor("#8B96A8"))
            setBackgroundResource(R.drawable.bg_input)
            setPadding(dp(ctx, 12), dp(ctx, 10), dp(ctx, 12), dp(ctx, 10))
        }
        root.addView(etBulk)

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(ctx, 12), 0, 0)
        }
        val btnImport = makeTvButton(ctx, "🚀 استيراد وحفظ", primary = true) {
            val raw = etBulk.text.toString().trim()
            if (raw.isEmpty()) {
                Toast.makeText(ctx, "الحقل فارغ", Toast.LENGTH_SHORT).show()
                return@makeTvButton
            }
            val summary = store.importAnyPortalsOrBackup(raw)
            Toast.makeText(ctx, summary.message, Toast.LENGTH_LONG).show()
            if (summary.accountsAdded > 0 || summary.favoritesAdded > 0) {
                dlg.dismiss()
                onImported()
            }
        }
        val btnCancel = makeTvButton(ctx, "إلغاء") { dlg.dismiss() }
        bar.addView(btnImport)
        bar.addView(btnCancel)
        root.addView(bar)
        dlg.show()
        etBulk.requestFocus()
    }

    fun showFetchStbEmuDialog(
        ctx: Context,
        store: AppStore,
        scope: CoroutineScope,
        onPickImportFile: () -> Unit,
        onOpenWebSetup: () -> Unit,
        onPickLocalM3uFile: (((String) -> Unit) -> Unit)? = null,
        onActivated: (AccountProfile) -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 18), dp(ctx, 14), dp(ctx, 18), dp(ctx, 14))
        }
        root.addView(
            TextView(ctx).apply {
                text = "🔗 جلب أحدث بوابات StbEmu فوراً"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )
        root.addView(
            TextView(ctx).apply {
                text = "يسحب أحدث بطاقات البوابات وعناوين MAC من stbemu.com.tr ويضيفها مباشرةً إلى قائمة السيرفرات بدون فحص مسبق، لتتمكّن بعدها من فحص ما تشاء بزرّ «⚡ فحص الكل» أو «⚡» بجانب كل سيرفر.\n(اختياري: اترك حقل الرابط فارغاً للجلب التلقائي أو الصق رابط صفحة معيّنة)."
                setTextColor(Color.parseColor("#CBD5E1"))
                textSize = 12.5f
                setPadding(0, dp(ctx, 6), 0, dp(ctx, 10))
            }
        )
        val entUrl = makeEdit(ctx, "https://www.stbemu.com.tr/... (اختياري)", "").apply {
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        root.addView(entUrl)

        val progressBar = android.widget.ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(ctx, 10) }
        }
        root.addView(progressBar)

        val statusLbl = TextView(ctx).apply {
            text = "جاهز للجلب السريع بدون فحص مسبق"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 12.5f
            setPadding(0, dp(ctx, 8), 0, dp(ctx, 10))
        }
        root.addView(statusLbl)

        val dlg = AlertDialog.Builder(ctx).setView(root).setCancelable(false).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        root.addView(bar)

        var fetchJob: kotlinx.coroutines.Job? = null
        lateinit var btnStart: TextView
        btnStart = makeTvButton(ctx, "🚀 جلب السيرفرات فوراً", primary = true) {
            val manual = entUrl.text?.toString()?.trim().orEmpty()
            statusLbl.setTextColor(Color.parseColor("#FBBF24"))
            statusLbl.text = "⏳ جارٍ سحب بطاقات السيرفرات…"
            progressBar.isIndeterminate = true
            btnStart.isEnabled = false
            btnStart.alpha = 0.5f

            fetchJob = scope.launch {
                val result = runCatching {
                    com.iptvlite.tv.network.PortalFetcher.fetchPairsOnly(
                        manualArticleUrl = manual.ifBlank { null },
                        maxPairs = 50
                    ) { msg ->
                        progressBar.post {
                            val act = ctx as? android.app.Activity
                            if (act != null && (act.isFinishing || act.isDestroyed)) return@post
                            statusLbl.text = msg
                        }
                    }
                }
                val act = ctx as? android.app.Activity
                if (act != null && (act.isFinishing || act.isDestroyed)) return@launch

                result.onSuccess { fr ->
                    if (fr.pairs.isEmpty()) {
                        progressBar.isIndeterminate = false
                        btnStart.isEnabled = true
                        btnStart.alpha = 1f
                        statusLbl.setTextColor(Color.parseColor("#F87171"))
                        statusLbl.text = "⚠ لم يُعثر على بطاقات Portal/MAC في الصفحة المحدّدة"
                        return@onSuccess
                    }

                    val existingKeys = store.getAccounts().mapTo(HashSet()) { existingAcc ->
                        "${existingAcc.url.trim().trimEnd('/').lowercase(Locale.US)}|${existingAcc.mac.trim().uppercase(Locale.US)}"
                    }
                    val fetchedAccounts = com.iptvlite.tv.network.PortalFetcher.pairsToAccounts(fr.pairs)
                    var added = 0
                    var skippedExisting = 0
                    for (acc in fetchedAccounts) {
                        val k = "${acc.url.trim().trimEnd('/').lowercase(Locale.US)}|${acc.mac.trim().uppercase(Locale.US)}"
                        if (k in existingKeys) {
                            skippedExisting++
                        } else {
                            store.upsertAccount(acc)
                            existingKeys.add(k)
                            added++
                        }
                    }

                    val summaryMsg = if (skippedExisting > 0) {
                        "✔ تمّ جلب ${fr.pairs.size} سيرفر (أُضيف $added جديد، و$skippedExisting محفوظ مسبقاً) — استخدم زرّ ⚡ للفحص"
                    } else {
                        "✔ تمّ جلب وإضافة $added سيرفر فوراً — استخدم زرّ ⚡ للفحص متى شئت"
                    }
                    Toast.makeText(ctx, summaryMsg, Toast.LENGTH_LONG).show()
                    runCatching { dlg.dismiss() }
                    showAccountsDialog(
                        ctx, store, scope, onPickImportFile, onOpenWebSetup, onPickLocalM3uFile, onActivated
                    )
                }.onFailure { e ->
                    if (e is kotlinx.coroutines.CancellationException) {
                        statusLbl.text = "أُلغي الجلب"
                    } else {
                        statusLbl.setTextColor(Color.parseColor("#F87171"))
                        statusLbl.text = "✖ ${(e.message ?: e.toString()).take(180)}"
                    }
                    progressBar.isIndeterminate = false
                    btnStart.isEnabled = true
                    btnStart.alpha = 1f
                }
            }
        }

        bar.addView(btnStart)
        bar.addView(
            makeTvButton(ctx, "إلغاء") {
                fetchJob?.cancel()
                runCatching { dlg.dismiss() }
            }
        )
        dlg.show()
        // تركيز افتراضي على زرّ البدء في Android TV حتى لا تفتح لوحة المفاتيح الافتراضية تلقائياً فوق الشاشة!
        btnStart.post { btnStart.requestFocus() }
    }

    fun showAddOrEditAccountDialog(
        ctx: Context,
        store: AppStore,
        scope: CoroutineScope,
        existing: AccountProfile? = null,
        onPickLocalM3uFile: (((String) -> Unit) -> Unit)? = null,
        onActivated: (AccountProfile) -> Unit
    ) {
        val scroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
        }
        scroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = if (existing == null) "➕ إضافة اشتراك جديد" else "✎ تعديل الاشتراك"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 18f
            }
        )

        val rg = RadioGroup(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(ctx, 8), 0, dp(ctx, 8))
        }
        val rbStalker = RadioButton(ctx).apply {
            text = "Stalker MAC"
            setTextColor(Color.WHITE)
        }
        val rbXtream = RadioButton(ctx).apply {
            text = "Xtream Codes"
            setTextColor(Color.WHITE)
        }
        val rbM3u = RadioButton(ctx).apply {
            text = "M3U / M3U8"
            setTextColor(Color.WHITE)
        }
        rg.addView(rbStalker)
        rg.addView(rbXtream)
        rg.addView(rbM3u)
        root.addView(rg)

        val etName = makeEdit(ctx, "اسم اختياري (مثلاً: السيرفر الرئيسي)", existing?.name.orEmpty())
        val etUrl = makeEdit(ctx, "الرابط (http://host:port/c أو رابط/ملف M3U)", existing?.url.orEmpty())
        val btnPickLocalM3u = makeTvButton(ctx, "📂 اختيار ملف M3U / M3U8 محلّي من الجهاز أو الفلاشة") {
            if (onPickLocalM3uFile != null) {
                onPickLocalM3uFile.invoke { uriStr ->
                    etUrl.setText(uriStr)
                    if (etName.text.isNullOrBlank()) {
                        val tail = uriStr.substringAfterLast('/').substringBefore('?').take(26)
                        etName.setText(if (tail.isNotBlank()) "قائمة $tail" else "قائمة M3U محلّية")
                    }
                }
            } else {
                Toast.makeText(ctx, "اختر استيراد ملف M3U من مدير السيرفرات", Toast.LENGTH_SHORT).show()
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 8) }
        }
        val etMac = makeEdit(ctx, "عنوان MAC (مثال: 00:1A:79:XX:XX:XX)", existing?.mac.orEmpty())
        val etUser = makeEdit(ctx, "اسم المستخدم (Username)", existing?.username.orEmpty())
        val etPass = makeEdit(
            ctx,
            "كلمة المرور (Password)",
            existing?.password.orEmpty(),
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        )
        val etEpgUrl = makeEdit(
            ctx,
            "📅 رابط دليل البرامج XMLTV اختياري (.xml أو .xml.gz)",
            existing?.epgUrl.orEmpty()
        )

        root.addView(etName)
        root.addView(etUrl)
        root.addView(btnPickLocalM3u)
        root.addView(etEpgUrl)
        root.addView(etMac)
        root.addView(etUser)
        root.addView(etPass)

        fun syncVis(p: ProviderType) {
            etMac.visibility = if (p == ProviderType.STALKER) View.VISIBLE else View.GONE
            etUser.visibility = if (p == ProviderType.XTREAM) View.VISIBLE else View.GONE
            etPass.visibility = if (p == ProviderType.XTREAM) View.VISIBLE else View.GONE
            etEpgUrl.visibility = if (p == ProviderType.M3U) View.VISIBLE else View.GONE
            btnPickLocalM3u.visibility =
                if (p == ProviderType.M3U && onPickLocalM3uFile != null) View.VISIBLE else View.GONE
        }

        val initProv = existing?.provider ?: ProviderType.STALKER
        when (initProv) {
            ProviderType.STALKER -> rbStalker.isChecked = true
            ProviderType.XTREAM -> rbXtream.isChecked = true
            ProviderType.M3U -> rbM3u.isChecked = true
        }
        syncVis(initProv)

        rg.setOnCheckedChangeListener { _, checkedId ->
            val p = when (checkedId) {
                rbXtream.id -> ProviderType.XTREAM
                rbM3u.id -> ProviderType.M3U
                else -> ProviderType.STALKER
            }
            syncVis(p)
        }

        val tvTestStatus = TextView(ctx).apply {
            text = ""
            setTextColor(Color.parseColor("#FBBF24"))
            textSize = 12f
            setPadding(0, dp(ctx, 6), 0, dp(ctx, 6))
        }
        root.addView(tvTestStatus)

        val dlg = AlertDialog.Builder(ctx).setView(scroll).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        fun buildProfile(): AccountProfile? {
            val prov = when {
                rbXtream.isChecked -> ProviderType.XTREAM
                rbM3u.isChecked -> ProviderType.M3U
                else -> ProviderType.STALKER
            }
            val acc = PortalClient.normalizeAccountInput(
                provider = prov,
                rawName = etName.text.toString(),
                rawUrl = etUrl.text.toString(),
                rawMac = etMac.text.toString(),
                rawUser = etUser.text.toString(),
                rawPass = etPass.text.toString(),
                existingId = existing?.id ?: java.util.UUID.randomUUID().toString(),
                rawEpgUrl = if (prov == ProviderType.M3U) etEpgUrl.text.toString() else ""
            )
            if (acc.url.isBlank()) {
                Toast.makeText(ctx, "أدخل رابط السيرفر أو القائمة", Toast.LENGTH_SHORT).show()
                return null
            }
            if (prov == ProviderType.STALKER && acc.mac.length < 11) {
                Toast.makeText(ctx, "أدخل عنوان MAC صحيحاً", Toast.LENGTH_SHORT).show()
                return null
            }
            if (prov == ProviderType.XTREAM && (acc.username.isBlank() || acc.password.isBlank())) {
                Toast.makeText(ctx, "أدخل اسم المستخدم وكلمة المرور", Toast.LENGTH_SHORT).show()
                return null
            }
            return acc
        }

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnSave = makeTvButton(ctx, "💾 حفظ وتفعيل فوراً", primary = true) {
            val acc = buildProfile() ?: return@makeTvButton
            val saved = store.upsertAccount(acc)
            store.setActiveAccountId(saved.id)
            dlg.dismiss()
            onActivated(saved)
        }
        val btnProbe = makeTvButton(ctx, "🔍 اختبار الاتصال") {
            val acc = buildProfile() ?: return@makeTvButton
            tvTestStatus.text = "… جارٍ فحص الاتصال بالسيرفر"
            scope.launch {
                val res = runCatching {
                    withContext(Dispatchers.IO) { PortalClient.fetchAccountStatus(acc, forceProbe = true) }
                }
                res.onSuccess { info ->
                    tvTestStatus.setTextColor(Color.parseColor("#34D399"))
                    tvTestStatus.text = "✔ ناجح (${info.pingMs}ms) — الصلاحية: ${info.expiry} · اتصالات: ${info.maxConnections}"
                }.onFailure { err ->
                    tvTestStatus.setTextColor(Color.parseColor("#F87171"))
                    tvTestStatus.text = "✖ فشل: ${err.message?.take(70)}"
                }
            }
        }
        val btnCancel = makeTvButton(ctx, "إلغاء") { dlg.dismiss() }

        bar.addView(btnSave)
        bar.addView(btnProbe)
        bar.addView(btnCancel)
        root.addView(bar)

        dlg.show()
        etUrl.requestFocus()
    }

    fun showSettingsDialog(
        ctx: Context,
        store: AppStore,
        onSaved: (AppPrefs) -> Unit
    ) {
        val cur = store.loadPrefs()
        var chosenTheme = cur.themeMode
        var chosenAspect = cur.aspectMode

        val outerScroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
        }
        outerScroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = "⚙ إعدادات المظهر والمشغّل والتخزين المؤقّت"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17.5f
            }
        )

        // 1) اختيار المظهر اللوني (مطابق لـ v66.86: داكن Dark · ليلي Night · فاتح Light)
        root.addView(
            TextView(ctx).apply {
                text = "🎨 المظهر اللوني للواجهة (Themes):"
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 13f
                setPadding(0, dp(ctx, 10), 0, dp(ctx, 4))
            }
        )
        val themeScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val themeRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        themeScroll.addView(themeRow)
        root.addView(themeScroll)

        fun rebuildThemeButtons(focusCode: String? = null) {
            themeRow.removeAllViews()
            var target: View? = null
            for (tm in AppThemeMode.entries) {
                val btn = makeTvButton(ctx, tm.labelAr, primary = chosenTheme.equals(tm.code, ignoreCase = true)) {
                    chosenTheme = tm.code
                    rebuildThemeButtons(focusCode = tm.code)
                }
                if (focusCode != null && tm.code.equals(focusCode, ignoreCase = true)) target = btn
                themeRow.addView(btn)
            }
            target?.let { v -> v.post { v.requestFocus() } }
        }
        rebuildThemeButtons()

        // 2) نسبة أبعاد الشاشة الافتراضية (6 أوضاع مطابقة لـ v66.86)
        root.addView(
            TextView(ctx).apply {
                text = "📐 نسبة أبعاد الفيديو الافتراضية:"
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 13f
                setPadding(0, dp(ctx, 8), 0, dp(ctx, 4))
            }
        )
        val aspectScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val aspectRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        aspectScroll.addView(aspectRow)
        root.addView(aspectScroll)

        val aspectLabels = listOf(
            0 to "تلقائي أصلي",
            1 to "ملء كامل",
            2 to "قصّ الزوم",
            3 to "16:9",
            4 to "4:3",
            5 to "21:9 سينمائي"
        )
        fun rebuildAspectButtons(focusAspect: Int? = null) {
            aspectRow.removeAllViews()
            var target: View? = null
            for ((idx, lbl) in aspectLabels) {
                val btn = makeTvButton(ctx, lbl, primary = (chosenAspect == idx)) {
                    chosenAspect = idx
                    rebuildAspectButtons(focusAspect = idx)
                }
                if (focusAspect == idx) target = btn
                aspectRow.addView(btn)
            }
            target?.let { v -> v.post { v.requestFocus() } }
        }
        rebuildAspectButtons()

        // 4) مضخّم الصوت الافتراضي وتنسيق الترجمة
        var chosenBoost = cur.audioBoostPct
        root.addView(
            TextView(ctx).apply {
                text = "🔊 مضخّم الصوت الافتراضي للقنوات والأفلام المنخفضة (Hardware Audio Booster):"
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 13f
                setPadding(0, dp(ctx, 8), 0, dp(ctx, 4))
            }
        )
        val boostScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val boostRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(ctx, 2), 0, dp(ctx, 6))
        }
        boostScroll.addView(boostRow)
        root.addView(boostScroll)

        fun rebuildBoostButtons(focusBoost: Int? = null) {
            boostRow.removeAllViews()
            var target: View? = null
            for (pct in listOf(100, 130, 160, 200)) {
                val active = (chosenBoost == pct)
                val label = if (pct == 100) "100% (طبيعي)" else "🔊 $pct%"
                val btn = makeTvButton(ctx, if (active) "✔ $label" else label, primary = active) {
                    chosenBoost = pct
                    rebuildBoostButtons(focusBoost = pct)
                }
                if (focusBoost == pct) target = btn
                boostRow.addView(btn)
            }
            target?.let { v -> v.post { v.requestFocus() } }
        }
        rebuildBoostButtons()

        var chosenSubSize = cur.subSizeSp
        var chosenSubColor = cur.subColorIndex
        var chosenSubBg = cur.subBgTranslucent
        root.addView(
            TextView(ctx).apply {
                text = "💬 حجم ولون خطّ الترجمة الافتراضي:"
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 13f
                setPadding(0, dp(ctx, 6), 0, dp(ctx, 4))
            }
        )
        val subScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
        }
        val subRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(ctx, 2), 0, dp(ctx, 6))
        }
        subScroll.addView(subRow)
        root.addView(subScroll)

        val colorLabels = listOf("أبيض", "أصفر سينمائي", "سماوي")
        fun rebuildSubButtons(focusSlot: Int? = null) {
            subRow.removeAllViews()
            var target: View? = null
            var slotIdx = 0
            for ((spVal, lbl) in listOf(18 to "صغير", 22 to "متوسّط", 28 to "كبير", 34 to "ضخم")) {
                val mySlot = slotIdx++
                val active = (chosenSubSize == spVal)
                val btn = makeTvButton(ctx, if (active) "✔ $lbl" else lbl, primary = active) {
                    chosenSubSize = spVal
                    rebuildSubButtons(focusSlot = mySlot)
                }
                if (focusSlot == mySlot) target = btn
                subRow.addView(btn)
            }
            val colorSlot = slotIdx++
            val btnColor = makeTvButton(ctx, "🎨 ${colorLabels.getOrElse(chosenSubColor) { "أبيض" }}") {
                chosenSubColor = (chosenSubColor + 1) % 3
                rebuildSubButtons(focusSlot = colorSlot)
            }
            if (focusSlot == colorSlot) target = btnColor
            subRow.addView(btnColor)

            val bgSlot = slotIdx
            val btnBg = makeTvButton(ctx, if (chosenSubBg) "▪ خلفية شفّافة" else "▫ بدون خلفية") {
                chosenSubBg = !chosenSubBg
                rebuildSubButtons(focusSlot = bgSlot)
            }
            if (focusSlot == bgSlot) target = btnBg
            subRow.addView(btnBg)
            target?.let { v -> v.post { v.requestFocus() } }
        }
        rebuildSubButtons()

        val chkAutoPlayStart = CheckBox(ctx).apply {
            text = "📺 وضع الرسيفر: تشغيل آخر قناة مباشرة تلقائياً فور فتح التطبيق"
            isChecked = cur.autoPlayLastOnStart
            setTextColor(Color.parseColor("#E8ECF3"))
        }
        val chkAutoNext = CheckBox(ctx).apply {
            text = "تشغيل الحلقة التالية تلقائياً في المسلسلات"
            isChecked = cur.autoNextEpisode
            setTextColor(Color.parseColor("#E8ECF3"))
        }
        val chkReconnect = CheckBox(ctx).apply {
            text = "استئناف تشغيل الأفلام والمسلسلات والأرشيف تلقائياً من نفس الموضع عند انقطاع الشبكة"
            isChecked = cur.autoReconnect
            setTextColor(Color.parseColor("#E8ECF3"))
        }
        root.addView(chkAutoPlayStart)
        root.addView(chkAutoNext)
        root.addView(chkReconnect)
        val dlg = AlertDialog.Builder(ctx).setView(outerScroll).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val barScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(0, dp(ctx, 12), 0, 0)
        }
        val bar = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        barScroll.addView(bar)

        val btnSave = makeTvButton(ctx, "💾 حفظ وتطبيق", primary = true) {
            val nextPrefs = cur.copy(
                cacheMs = cur.cacheMs,
                autoNextEpisode = chkAutoNext.isChecked,
                autoReconnect = chkReconnect.isChecked,
                aspectMode = chosenAspect,
                themeMode = chosenTheme,
                autoPlayLastOnStart = chkAutoPlayStart.isChecked,
                audioBoostPct = chosenBoost,
                subSizeSp = chosenSubSize,
                subColorIndex = chosenSubColor,
                subBgTranslucent = chosenSubBg,
                diagnosticsEnabled = cur.diagnosticsEnabled
            )
            store.savePrefs(nextPrefs)
            dlg.dismiss()
            onSaved(nextPrefs)
            Toast.makeText(ctx, "✔ تم حفظ الإعدادات والمظهر بنجاح", Toast.LENGTH_SHORT).show()
        }
        val btnHelp = makeTvButton(ctx, "⌨ دليل التحكّم") {
            showHelpShortcutsDialog(ctx)
        }
        val btnAbout = makeTvButton(ctx, "ℹ حول البرنامج") {
            showAboutDialog(ctx)
        }.apply { tag = "about_open" }
        val btnCancel = makeTvButton(ctx, "إلغاء") { dlg.dismiss() }
        bar.addView(btnSave)
        bar.addView(btnHelp)
        bar.addView(btnAbout)
        bar.addView(btnCancel)
        root.addView(barScroll)

        dlg.show()
        btnSave.requestFocus()
    }

    /**
     * دليل التحكّم: أزرار الريموت والإيماءات ومسارات الحفظ فقط.
     * لا يحتوي مزايا الإصدار ولا نصوصًا تسويقية؛ تلك في «حول البرنامج».
     */
    fun showHelpShortcutsDialog(ctx: Context) {
        val scroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
            tag = "control_guide_dialog"
        }
        scroll.addView(root)

        root.addView(
            TextView(ctx).apply {
                text = "⌨ دليل التحكّم"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 18f
            }
        )
        root.addView(
            TextView(ctx).apply {
                text = "أزرار الريموت، إيماءات اللمس، ومسارات الحفظ."
                setTextColor(Color.parseColor("#8B96A8"))
                textSize = 12.5f
                setPadding(0, dp(ctx, 2), 0, dp(ctx, 6))
            }
        )

        fun section(value: ControlGuide.Section) {
            root.addView(
                TextView(ctx).apply {
                    text = value.title
                    setTextColor(Color.parseColor("#93C5FD"))
                    textSize = 15f
                    setPadding(0, dp(ctx, 12), 0, dp(ctx, 4))
                }
            )
            root.addView(
                TextView(ctx).apply {
                    text = value.rows.joinToString("\n")
                    setTextColor(Color.parseColor("#E8ECF3"))
                    textSize = 13f
                    setLineSpacing(dp(ctx, 5).toFloat(), 1f)
                }
            )
        }
        ControlGuide.SECTIONS.forEach { section(it) }

        val dlg = AlertDialog.Builder(ctx).setView(scroll).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val btnOk = makeTvButton(ctx, "إغلاق", primary = true) { dlg.dismiss() }
        root.addView(btnOk)
        dlg.show()
        btnOk.requestFocus()
    }

    /**
     * «حول البرنامج»: الهوية والإصدار والمنصّة والقدرات والإشعارات القانونية فقط.
     * لا يكرّر دليل التحكّم ولا يعرض أي بيانات حساب أو مزوّد.
     */
    fun showAboutDialog(ctx: Context) {
        val scroll = ScrollView(ctx)
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 18), dp(ctx, 20), dp(ctx, 16))
            tag = "about_dialog"
        }
        scroll.addView(root)
        fun title(value: String, size: Float = 15f, color: String = "#93C5FD") = TextView(ctx).apply {
            text = value
            setTextColor(Color.parseColor(color))
            textSize = size
            setPadding(0, dp(ctx, 14), 0, dp(ctx, 4))
        }
        fun body(value: String, size: Float = 13f, color: String = "#E8ECF3") = TextView(ctx).apply {
            text = value
            setTextColor(Color.parseColor(color))
            textSize = size
            setLineSpacing(dp(ctx, 4).toFloat(), 1f)
        }

        root.addView(TextView(ctx).apply {
            text = AboutInfo.APP_NAME
            setTextColor(Color.parseColor("#F1F5F9"))
            textSize = 21f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(ctx).apply {
            tag = "about_version"
            text = AboutInfo.versionLine()
            setTextColor(Color.parseColor("#A7F3D0"))
            textSize = 14.5f
            setPadding(0, dp(ctx, 3), 0, dp(ctx, 2))
        })
        root.addView(body("${AboutInfo.platform(ctx)} · ${AboutInfo.deviceLabel()} · ${AboutInfo.androidLabel()}", 12f, "#8B96A8"))

        root.addView(title("القدرات"))
        root.addView(body(AboutInfo.CAPABILITIES.joinToString("\n")))

        root.addView(title("مجلّدات الحفظ"))
        root.addView(body(AboutInfo.STORAGE.joinToString("\n")))

        root.addView(title("الخصوصية"))
        root.addView(body(AboutInfo.PRIVACY))

        root.addView(title("الاستخدام"))
        root.addView(body(AboutInfo.DISCLAIMER))

        root.addView(title("سلامة الحسابات"))
        root.addView(body(AboutInfo.ACCOUNT_SAFETY))

        root.addView(
            body("${AboutInfo.DEVELOPER}", 12f, "#64748B").apply { setPadding(0, dp(ctx, 14), 0, dp(ctx, 4)) }
        )

        val dlg = AlertDialog.Builder(ctx).setView(scroll).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val btnOk = makeTvButton(ctx, "إغلاق", primary = true) { dlg.dismiss() }
        root.addView(btnOk)
        dlg.show()
        btnOk.requestFocus()
    }

    /**
     * نافذة إنشاء مجلّد مفضّلة مخصّص جديد.
     */
    fun showCreateFavFolderDialog(
        ctx: Context,
        store: AppStore,
        onCreated: (String) -> Unit
    ) {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundResource(R.drawable.bg_dialog_surface)
            clipChildren = false
            clipToPadding = false
            setPadding(dp(ctx, 20), dp(ctx, 16), dp(ctx, 20), dp(ctx, 16))
        }
        root.addView(
            TextView(ctx).apply {
                text = "📂 إنشاء مجلّد مفضّلة جديد"
                setTextColor(Color.parseColor("#60A5FA"))
                textSize = 17f
            }
        )
        val etFolder = makeEdit(ctx, "اسم المجلّد (مثلاً: ⚽ الدوريات الأوروبية أو 🌙 رمضان)", "")
        root.addView(etFolder)

        val dlg = AlertDialog.Builder(ctx).setView(root).create()
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(ctx, 8), 0, 0)
        }
        val btnSave = makeTvButton(ctx, "➕ إنشاء المجلّد", primary = true) {
            val raw = etFolder.text.toString().trim()
            if (raw.isEmpty()) {
                Toast.makeText(ctx, "أدخل اسماً للمجلّد", Toast.LENGTH_SHORT).show()
                return@makeTvButton
            }
            val finalName = if (raw.first().code > 0x2000) raw else "📁 $raw"
            store.addCustomFavoriteFolder(finalName)
            dlg.dismiss()
            onCreated(finalName)
        }
        val btnCancel = makeTvButton(ctx, "إلغاء") { dlg.dismiss() }
        bar.addView(btnSave)
        bar.addView(btnCancel)
        root.addView(bar)
        dlg.show()
        etFolder.requestFocus()
    }

    /**
     * نافذة نقل/إضافة عنصر إلى أحد مجلّدات المفضّلة.
     */
    fun showFavoriteFolderPickerDialog(
        ctx: Context,
        store: AppStore,
        item: com.iptvlite.tv.model.StreamItem,
        onChanged: (String) -> Unit
    ) {
        val folders = store.getFavoriteFolderNames()
        val curFolder = store.getFavoriteItemFolder(item)
        val labels = ArrayList<String>(folders.size + 2)
        for (f in folders) {
            val mark = if (curFolder == f) "✔ " else ""
            labels.add("$mark$f")
        }
        labels.add("➕ إنشاء مجلّد جديد وإضافة العنصر إليه…")
        if (curFolder.isNotBlank()) {
            labels.add("✕ إزالة من المجلّد (الإبقاء في كل المفضّلة فقط)")
        }

        val defaultIdx = folders.indexOf(curFolder).coerceAtLeast(0)
        showNeonChoiceDialog(
            ctx = ctx,
            title = "📂 اختر مجلّد المفضّلة لـ: ${item.name.take(36)}",
            items = labels,
            defaultIndex = defaultIdx
        ) { which ->
            when {
                which in folders.indices -> {
                    val chosen = folders[which]
                    store.setFavoriteItemFolder(item, chosen)
                    Toast.makeText(ctx, "★ أُضيف إلى مجلّد: $chosen", Toast.LENGTH_SHORT).show()
                    onChanged(chosen)
                }
                which == folders.size -> {
                    showCreateFavFolderDialog(ctx, store) { newFolder ->
                        store.setFavoriteItemFolder(item, newFolder)
                        Toast.makeText(ctx, "★ أُضيف إلى مجلّد: $newFolder", Toast.LENGTH_SHORT).show()
                        onChanged(newFolder)
                    }
                }
                else -> {
                    store.setFavoriteItemFolder(item, "")
                    Toast.makeText(ctx, "أُزيل تصنيف المجلّد مع بقاء العنصر في المفضّلة", Toast.LENGTH_SHORT).show()
                    onChanged("*")
                }
            }
        }
    }

    fun makeEdit(
        ctx: Context,
        hintText: String,
        initial: String,
        inputType: Int = InputType.TYPE_CLASS_TEXT
    ): EditText {
        return EditText(ctx).apply {
            hint = hintText
            setText(initial)
            this.inputType = inputType
            isSingleLine = true
            setTextColor(Color.parseColor("#F8FAFC"))
            setHintTextColor(Color.parseColor("#94A3B8"))
            setBackgroundResource(R.drawable.bg_input)
            setPadding(dp(ctx, 14), dp(ctx, 10), dp(ctx, 14), dp(ctx, 10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(ctx, 8) }
        }
    }

    fun makeTvButton(
        ctx: Context,
        label: String,
        primary: Boolean = false,
        onClick: () -> Unit
    ): TextView {
        return TextView(ctx).apply {
            text = label
            setTextColor(if (primary) Color.WHITE else Color.parseColor("#F8FAFC"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            isFocusable = true
            isClickable = true
            setBackgroundResource(if (primary) R.drawable.bg_tv_primary_btn else R.drawable.bg_tv_btn)
            setPadding(dp(ctx, 15), dp(ctx, 8), dp(ctx, 15), dp(ctx, 8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { marginEnd = dp(ctx, 6) }
            ThemeHelper.attachFocusScale(this, 1.04f) { v, hasFocus ->
                if (hasFocus) {
                    v.requestRectangleOnScreen(Rect(0, 0, v.width, v.height), false)
                }
            }
            setOnClickListener { onClick() }
        }
    }
}
