package com.iptvlite.tv.util

/** Opt-in RAM-only, bounded, allow-listed telemetry. Never accepts URLs, names or exception text. */
object PlaybackDiagnostics {
    enum class Operation { OPEN, CHANNEL_SWITCH, MANUAL_REOPEN, VOD_RESUME, SUBTITLE_RELOAD, LIVE_RECOVERY }
    enum class Stage { START, URL_READY, BUFFERING, READY, FIRST_FRAME, ERROR, LIVE_STOPPED, REUSE_LINK, RESOLVE_LINK }
    private const val CAPACITY = 120
    private val events = java.util.ArrayDeque<String>()
    @Volatile private var enabled = false

    @Synchronized fun configure(value: Boolean) {
        enabled = value
        if (!value) events.clear()
    }
    @Synchronized fun record(id: Long, operation: Operation, stage: Stage, elapsedMs: Long, errorCode: Int? = null) {
        if (!enabled) return
        if (events.size >= CAPACITY) events.removeFirst()
        events.addLast("#$id ${operation.name} ${stage.name} ${elapsedMs.coerceAtLeast(0L)}ms" +
            (errorCode?.let { " code=$it" } ?: ""))
    }
    @Synchronized fun snapshot(): String = if (enabled) events.joinToString("\n") else "التشخيص الاختياري معطّل. لا يوجد سجل محفوظ."
}
