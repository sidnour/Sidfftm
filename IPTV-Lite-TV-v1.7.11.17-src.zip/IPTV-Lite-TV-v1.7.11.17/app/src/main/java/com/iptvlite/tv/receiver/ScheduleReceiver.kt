package com.iptvlite.tv.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.iptvlite.tv.network.PortalClient
import com.iptvlite.tv.service.RecordingService
import com.iptvlite.tv.store.AppStore
import com.iptvlite.tv.ui.MainActivity
import com.iptvlite.tv.util.AppUiTracker
import com.iptvlite.tv.util.LogoLoader
import com.iptvlite.tv.util.NotificationHelper
import com.iptvlite.tv.util.ScheduleHelper
import com.iptvlite.tv.util.StreamRecorder

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val appCtx = context.applicationContext
        val store = AppStore(appCtx)

        when (action) {
            ScheduleHelper.ACTION_REMINDER -> {
                val remId = intent.getStringExtra(ScheduleHelper.EXTRA_ID).orEmpty()
                if (remId.isBlank()) return
                val rem = store.getReminders().firstOrNull { it.id == remId } ?: return
                // إذا كانت شاشة التطبيق أو المشغّل مفتوحة أمام المستخدم فنعرض نافذة التلفاز التفاعلية فوراً،
                // وإذا كان التطبيق في الخلفية أو مغلقاً فنرسل إشعار النظام مع فتح القناة عند الضغط.
                if (AppUiTracker.isAnyUiVisible && AppUiTracker.dispatchImmediateReminderCheck()) {
                    return
                }
                store.removeReminder(rem.id)
                val openChIntent = Intent(appCtx, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra(NotificationHelper.EXTRA_AUTO_OPEN_ACC_ID, rem.accountId)
                    putExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_ID, rem.channelId)
                    putExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_NAME, rem.channelName)
                    putExtra(NotificationHelper.EXTRA_AUTO_OPEN_CH_CMD, rem.channelCmd)
                }
                NotificationHelper.notifyEvent(
                    context = appCtx,
                    notifId = (rem.id.hashCode() and 0x7FFFFFFF).coerceAtLeast(3001),
                    title = "🔔 حان موعد برنامجك على «${rem.channelName}»",
                    body = "بدأ الآن «${rem.progName}» — اضغط للمشاهدة فوراً",
                    openIntent = openChIntent
                )
            }

            ScheduleHelper.ACTION_RECORD -> {
                val recId = intent.getStringExtra(ScheduleHelper.EXTRA_ID).orEmpty()
                if (recId.isBlank()) return
                val rec = store.getScheduledRecs().firstOrNull { it.id == recId } ?: return
                if (rec.state != "pending") return
                RecordingService.start(appCtx, rec.id)
            }

            ScheduleHelper.ACTION_STOP_RECORDING -> {
                val wasActive = StreamRecorder.isRecording()
                StreamRecorder.stopRecording()
                // إذا كان التسجيل نشطاً فسيتكفّل خيط التسجيل بتفريغ آخر حزمة وحفظ الملف ثمّ إيقاف الخدمة بأمان عبر onFinished
                if (!wasActive) {
                    appCtx.stopService(Intent(appCtx, RecordingService::class.java))
                    if (!AppUiTracker.isAnyUiVisible && !StreamRecorder.isDownloading()) {
                        runCatching { PortalClient.evictIdleConnections() }
                        runCatching { LogoLoader.trimMemory(clearAll = true) }
                    }
                }
            }
        }
    }
}
