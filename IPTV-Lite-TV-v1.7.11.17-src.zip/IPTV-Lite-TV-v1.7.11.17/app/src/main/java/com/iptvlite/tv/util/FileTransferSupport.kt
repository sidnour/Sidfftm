package com.iptvlite.tv.util

import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration

object FileTransferSupport {
    fun preferWifi(context: Context, intent: Intent): Boolean {
        val mode = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        if (mode?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            context.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)) return true
        @Suppress("DEPRECATION")
        val candidates = context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
        return candidates.none {
            val name = "${it.activityInfo.packageName}/${it.activityInfo.name}".lowercase(java.util.Locale.ROOT)
            !name.contains("stub") && !name.contains("frameworkpackagestubs")
        }
    }
}
