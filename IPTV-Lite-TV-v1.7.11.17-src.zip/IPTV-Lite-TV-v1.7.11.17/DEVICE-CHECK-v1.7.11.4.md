# Manual TV/Nox check — pending, not executed

Version 1.7.11.4 /188 is a test-coverage release, not a playback tuning release. Automated fixture passes do not certify smooth video, provider compatibility, OS process death, or real endpoint changes.

1. Install over187 (same application ID/certificate). Do not uninstall or clear storage. Confirm accounts/preferences remain.
2. Open an authorized Stalker account, choose one Movies/Series category and verify its list. Play a channel, switch channels repeatedly, and check requested playback remains responsive.
3. Exit with the existing confirmation. Reopen and confirm categories/playback work. For OS process-death coverage, separately force-stop and reopen on the device; a JVM RAM reset is not equivalent.
4. Repeat the list/playback check with an authorized Xtream account. Do not expect a Stalker handshake/refresh-token flow for Xtream.
5. Leave one Live channel playing; record observed picture/audio continuity and any reconnects. Then test an intentional local network outage and restoration on the same channel/source. Do not infer a stutter fix from this release.
6. Test real session expiration/endpoint change only in a controlled provider/test environment you administer. Do not edit/enumerate unrelated subscriptions or production infrastructure. Fixture tests cover synthetic stale-path failures, not every provider dialect.
7. Check Exit stops playback/background work as in the previous version. Report TV model/Android version/provider type, steps, approximate time and sanitized error if a failure occurs. Never share passwords, tokens, full authenticated URLs or personal MACs.

Remaining work follows ROADMAP_TV.md. No cloud test, billing, real-provider request, physical TV/Nox operation, Timeshift, Live pause, PiP, Multi-View, OpenSubtitles or alternate-server failover is authorized or introduced by this test expansion.
